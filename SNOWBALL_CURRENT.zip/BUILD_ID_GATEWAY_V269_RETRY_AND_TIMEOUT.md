# SNOWBALL V269 · Chat gateway reliability-only patch

- Scope: tools/chat-gateway/server.mjs only (plus test/docs); no APK/index.html/financial changes.
- Gemini low-latency model remains Render GEMINI_MODEL=gemini-3.5-flash-lite.
- Change: chat provider deadline 16s -> 48s with one bounded retry on transient Gemini timeouts, network errors and 408/5xx, *never* 401/403/429 or other hard errors.
- Max two Google text-generation requests per single /chat request when transient retry occurs (may incur additional API usage).
- New optional Render-only env settings: CHAT_PROVIDER_TIMEOUT_MS (default 48000), GEMINI_ATTEMPT_TIMEOUT_MS (default 21500), GEMINI_RETRY_DELAY_MS (default 800).
- Existing app request readTimeout=105000 and UI timeout=115000; no app update required for this server patch.
- Deploy in Render only after pushing this ZIP to GitHub Snowball-apk main; Render autoDeploy is off. Existing API secrets untouched.
- No real-provider success claim until a real app request returns an answer. Voice misrecognition is separate and unchanged.
