# V277: Calendar Official Results — corrective release

- V276 omitted the unresolved V275 calendar issue. On 2026-10-22, Bank of Korea published an official monetary policy decision and remarks, yet the calendar returned the generic "official announcement not found" status.
- Root: calendar reused the shared chat send (busy/no connection fallthrough), demanded the upstream AI return `latestChecked` **and** a direct official-domain source, while general Gemini grounding source links can be non-official redirects. Errors were swallowed into an undifferentiated failure.
- Fix: BOK 2026-10-22 official result is shown from a clearly dated verified publication snapshot, not from imaginary current values. Other past events use a separate silent, voice-free OpenAI web search with official-domain-only filtering (requires configured OpenAI API credits and consumes web search tokens). Ordinary microphone/standby remains Gemini.
- For failed live lookups, UI distinguishes chat busy, network delay, no consent/connection, and lack of direct official corroboration. No speculative meeting numbers.
- Do NOT infer that all future calendar events are automatically verified. Official outcome availability and Galaxy functionality remain unverified until live deployment.
- Source: https://www.bok.or.kr/eng/bbs/E0000627/view.do?menuNo=400022&nttId=11065824
- Existing ECOS, stocks, news collection, voice commands, Render settings, keys and portfolio files remain unchanged.
