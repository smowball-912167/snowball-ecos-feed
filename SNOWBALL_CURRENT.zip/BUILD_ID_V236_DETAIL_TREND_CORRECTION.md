# V236 | 2026-10-17 | Correct V235 UI misunderstanding

Keep the yield/quantity-percent toggle and the date-range graph for every account detail. Yield and quantity growth are distinct metrics.
Delete ONLY the below-graph duplicate per-stock summary cards, rendered by `trendRows(model,kind)` inside `renderPanel`.
Keep the original (above-chart) `assetsHtml` holdings cards, account totals, snapshots, transactional history and application data untouched.
Restore trend-controls and renderPanel(g) removed in V235, leave V235 home startup and market compact styles intact.
Correct V235 guide wording; add V236 in-app guide and V236 DOCX appendix.
`versionCode` 60317; short `versionName` 6.0.8-r9-v236; same app ID/signature configuration.
