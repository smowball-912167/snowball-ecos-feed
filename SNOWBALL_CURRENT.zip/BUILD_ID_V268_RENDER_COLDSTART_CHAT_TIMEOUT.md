# V268 눈탱이 무료 AI 서버 첫 응답 실패 보완

- Render 로그에 사용자 시험(2026-10-24 08:14 KST)과 같은 시각 서버 재기동 기록. 절전 복구 시 앱의 Java ReadTimeout 17초가 지나기 쉬움.
- Java 통신: connect 13초, read 105초; JavaScript 요청 대기 115초. 첫 요청은 무료 서버 절전 해제 대기 가능.
- 주소는 `https://snowball-chat-gateway.onrender.com`와 `/chat` 모두 허용, Android에서 `/chat` 보정.
- 401/404/429/502/연결 실패 등 원인을 구별해서 안내; 보안 정보는 표시하지 않음.
- OpenAI 기존 목소리·Gemini 목소리·V265 음성인식 진단, ECOS 금융·시장환경 보존.
- 검사: ZIP CRC, manifest SHA256 3개, Node JS 문법 확인. 실기기 APK 빌드 및 실제 유료 AI 통신은 아직 확인되지 않음.
- 서버측 API 키 재발급 및 Render 재배포는 이번 앱 수정과 무관. GitHub APK 저장소에 ZIP 업로드 후 빌드 필요.
