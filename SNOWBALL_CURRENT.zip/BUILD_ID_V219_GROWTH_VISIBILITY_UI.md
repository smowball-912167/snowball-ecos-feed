# SNOWBALL V219 / 2026-10-15
- V218 source S1 identity retained exactly: sourceRevision V208-S1-DIAG-v1.
- The archived 589 article records are preserved; live new article acquisition remains unconnected.
- On theme entry, reset inherited search/type/region filters; zero-result recovery explains stored records and provides a restore action.
- Remove nonfunctional ‘자료 수집’ status chip (was not a collection button).
- Remove floating duplicate back, article top extra close and bottom duplicate close.
- Detailed article actions in one row: 좋아요, 싫어요, 원본보기. Original retry remains only for missing/partial body.
- Compact theme back button within UI V36 touch minimum; typography standardized across all 20 themes.
- Cache-bust theme JS assets to 219; sync DOCX and app guide.
- Preserved localStorage keys, source archive, voice settings, account and trading state, signature configuration.
