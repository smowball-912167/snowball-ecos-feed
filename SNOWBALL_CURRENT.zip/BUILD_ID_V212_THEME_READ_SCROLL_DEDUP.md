# V212 · 테마성장 기사 화면·수집 표기 개선 (2026-10-14)

## 기준 / 사용자가 확정한 사항
- 제목: 눈탱이 32번 연속 수정. V211 기준, 20개 테마와 원본 589건의 기사 제목·출처·날짜·URL, 기존 계좌/보유·백업 데이터를 보존한다.
- **AI 검증 및 내용 필터링은 잠정 비활성화한다. 단 중복은 제외 또는 통합한다.** 기사 내용/평가/긍부정/인기도로 수집을 버리지 않는다. 추가 재활성화는 사용자 지시 전까지 하지 않는다.
- 원본 수집 589건은 삭제하지 않는다. V212 화면은 동일 URL 또는 같은 날짜의 동일 제목만 묶어 586건 표시(현재 빌트인 데이터 기준).
- 국내·글로벌 모두 본문을 확보하면 서론-본론-결론 3단락 발췌·읽기 기능 제공. 기술적 본문 확인과 번역 성공 여부를 AI 선별로 혼동하지 않는다. 미확인 자료는 제목 요지를 명시적으로 제목 기반이라고 표시하고, 상세에서 제목 읽기와 원문 접근이 가능하다.
- 기사 상세는 별도 전체화면 독립 세로 스크롤. 고정 헤더의 `목록으로`·`닫기`, 하단 닫기, Escape, 갤럭시 하드웨어 뒤로가기 우선 소모. 읽기는 닫을 때 중단한다.
- 해외 기사는 한국어 제목 변환 실패 시 `제목 한글 번역 다시` 제공. 실패한 번역을 만들어내지 않는다.

## 구현 위치
- app/src/main/assets/ntv211_theme_article.js: V212 detail overlay/scroll/back/read/translation retry
- app/src/main/assets/ntv210_theme_growth.js: duplicate grouping, list/count, no AI-selection wording
- app/src/main/java/com/snowball/noontangi/MainActivity.java: onBackPressed -> consumeBack() 우선
- app/src/main/assets/index.html: v212 캐시버스터. app/build.gradle / app/src/main/assets/s1_manifest.json: 버전·소스 지문 갱신.

## 제한
- Chromium DOM/모의 원문/모의 음성 함수 시험을 수행. 국내·글로벌 실제 언론사 WebView 접근, 라이브 원문 번역, 실제 삼성 기기 뒤로가기, GitHub Actions APK 빌드 성공은 별도 현장 확인 대상.
- 원본 링크가 Google News RSS 중계/접근제한인 경우 발췌 3단락 생성이 실패할 수 있다. 장기 수집기, 동영상·보고서 자동 수집, AI 자유서술 요약 등 기존에 미구현된 기능을 완료했다고 선언하지 않는다.
