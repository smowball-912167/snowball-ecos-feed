# V224 · 공통 팝업 상단·하단 맞춤, 닫기 및 독립 스크롤

- Based on source V222 plus V223 assets extracted from user-provided APK, not a decompilation of native binary.
- Market indicator settings and market news details now live on document.body, between fixed header and bottom navigation, with pinned close and footer actions and separate scrollable center.
- Android physical Back first consumes an open V224 overlay. No account/holding/news archive resets.
- Long AI market explanation panel removed. Market only-news V223 pipeline retained.
- Major news, firemouth, theme news, market news headline weight 600.
- DOCX manual, app guide, JS/CSS and native Android source synced.
- V224 versionCode 60305; APK build requires existing GitHub Actions signing secrets and Android toolchain.
- Requires real device test before claiming deployment success.
