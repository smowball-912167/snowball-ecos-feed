# V197 요구사항 매트릭스 — 사진 5장 · 사용자 지적 6항목

| 항목 | 변경 | 검증 경계 |
|---|---|---|
| 발언 후보 뜻 | `발언 후보 N건 · 원문·발언 검증 전` 로 표시; 실제 발언/의도 검증 미완료를 명시 | 모의 후보 화면. N=검색후보 수; 준비완료 수와 혼동 금지 |
| 주요뉴스 선택읽기 | 활성 `ntv190ArticleMonitor.open`을 HOME보다 우선, 현재 펼친 verified `.v190-art-row[open] > .v190-art-detail p`만 | Mock native TTS browser PASS, 실기기 미확인 |
| 불주댕이 선택읽기 | 활성 `ntv106Firemouth.open`에서 열려있는 `.fm107-recent.is-open` 정리문만 | Mock native TTS browser PASS, 실기기 미확인 |
| 기사 닫기/탭 전환 | `stopSpeechOnly` + `SnowballVoice.stop()`; closePanel/articleClose에도 동일. 닫으면 focus 해제 | Mock native stop browser PASS, 실기기 음성 이어짐 미확인 |
| 글로벌 한국어 | 표시 본문 한글 우세검사, cache 오염 진단, 실기기 접근 시 한정 재시도. 미준비면 영어를 숨기고 명시적으로 대기 | 로컬 규칙 테스트; 실제 외부 번역은 미확인 |
| 기사 표현 | `상황:` 삭제, AMD 중복 등 표시문 정제. 원문 기사 저장내용은 변경하지 않음 | 브라우저/패턴 테스트; 실제 기사별 점검 미확인 |

원칙: V172 보류한 AI 속뜻·투자 연결 기능을 사용자 몰래 다시 켜지 않는다. 수집 실패/영어 번역 실패 시 허위 성공 표시 금지.
