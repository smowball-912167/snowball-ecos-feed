/* V201 MARKET / RADAR / LONG — read-only, shared evidence projection.
   Original market fetch, Info Engine event ledger, journal and holdings are never mutated. */
(function () {
  'use strict';
  var KEY = 'nt_info_engine_v1_items';
  var TARGETS = [
    {page:'pageMarket',slot:'ntv201Market',role:'market'},
    {page:'pageRadar',slot:'ntv201Radar',role:'radar'},
    {page:'pageLong',slot:'ntv201Long',role:'long'}
  ];
  function esc(x){return String(x==null?'':x).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function raw(){try{var a=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(a)?a:[]}catch(e){return []}}
  function norm(x){return String(x||'').toLowerCase().replace(/\s+/g,'').replace(/[^0-9a-z가-힣]/g,'')}
  function day(x){var v=String(x.publishedAt||x.createdAt||'');return /^\d{4}-\d{2}-\d{2}/.test(v)?v.slice(0,10):''}
  function group(a){var m={},out=[];a.forEach(function(it,i){if(!it||typeof it!=='object')return;var title=norm(it.title);var key=title ? 't:'+title+'|'+day(it)+'|'+norm(it.theme) : 'i:'+String(it.id||i);
    var row=m[key];if(!row){row={representative:it,records:[it],key:key};m[key]=row;out.push(row)}else{row.records.push(it);
      var better=function(z){return (z.sourceType==='official'?4:z.sourceType==='research'?3:z.sourceType==='media'?2:1)+(z.sourceUrl?1:0)};
      if(better(it)>better(row.representative))row.representative=it;
    }});return out}
  function macro(it){var t=[it.title,it.theme,it.evidenceKind].join(' ');return /금리|국채|인플레이션|물가|소비자물가|cpi|pce|기준금리|연준|한국은행|통화정책|환율|유가|원유|전쟁|거시경제|금융시장|fomc/i.test(t)}
  function stat(){var a=raw(),g=group(a),themes={},stocks={},mc=0;g.forEach(function(row){var it=row.representative;
    if(macro(it))mc++;
    var th=String(it.theme||'').trim();if(th&&!/^기타|없음|미분류$/i.test(th))themes[th]=(themes[th]||0)+1;
    row.records.forEach(function(j){(Array.isArray(j.stocks)?j.stocks:[]).forEach(function(st){if(String(st||'').trim())stocks[st]=1})});
  });return {total:a.length,events:g.length,duplicates:a.length-g.length,macro:mc,themes:themes,stocks:Object.keys(stocks).length}}
  function links(role){var b=[['market','rMarket','시장환경'],['radar','rRadar','밑밥'],['long','rLong','장기투자']];return '<div class="ntv201-links">'+b.filter(function(x){return x[0]!==role}).map(function(x){return '<button type="button" data-ntv201-go="'+x[1]+'">'+x[2]+'로 이동 →</button>'}).join('')+'</div>'}
  function themeChips(t){var keys=Object.keys(t).sort(function(a,b){return t[b]-t[a]}).slice(0,5);return keys.length?'<div class="ntv201-themes">'+keys.map(function(k){return '<span>'+esc(k)+' <b>'+t[k]+'</b></span>'}).join('')+'</div>':'<div class="ntv201-empty">아직 연결된 테마 근거가 없습니다. 샘플 점수 대신 자료 없음으로 표시합니다.</div>'}
  function html(role,s){var head,body;if(role==='market'){
    head='거시경제는 시장환경에서만 상세 판단';
    body='금리·물가·환율·유동성·지수 분석의 기준 화면입니다. 밑밥과 장기투자에는 이 그래프를 복제하지 않습니다. 저장된 사건형 근거 중 거시 관련 <b>'+s.macro+'건</b>을 다른 메뉴에서 참조할 수 있습니다.';
  }else if(role==='radar'){
    head='밑밥은 새로운 변화와 근거의 발견';
    body='공통 근거기록 <b>'+s.total+'건</b> · 사건 기준 <b>'+s.events+'건</b> · 같은 제목·테마·일자 중복 <b>'+s.duplicates+'건</b>. 원본을 지우지 않고 같은 사건을 한 번만 집계합니다. 확증되지 않은 근거를 투자추천으로 간주하지 않습니다.';
  }else{
    head='장기투자는 검증 근거의 누적 해석';
    body='밑밥의 공통 사건기록에서 연결된 테마 <b>'+Object.keys(s.themes).length+'개</b> · 종목 <b>'+s.stocks+'개</b>. 현재 이는 연계 현황일 뿐, 기업 분석점수나 테마 선정 완료를 의미하지 않습니다.';
    body+=themeChips(s.themes);
  }
  return '<section class="ntv201-panel" aria-label="메뉴 역할 및 공통 근거 연계"><div class="ntv201-panel-title">'+head+'</div><p>'+body+'</p>'+links(role)+'</section>'
  }
  function mount(spec,s){var p=document.getElementById(spec.page);if(!p)return;var main=(spec.role==='long' && document.getElementById('longInnerHome'))||p.querySelector('main.container');if(!main)return;
    var el=document.getElementById(spec.slot);if(!el){el=document.createElement('div');el.id=spec.slot;main.insertBefore(el,main.firstChild)}
    var markup=html(spec.role,s);if(el.__v201markup!==markup){el.innerHTML=markup;el.__v201markup=markup}
  }
  function render(){try{var s=stat();TARGETS.forEach(function(t){mount(t,s)});window.NOONTANGI_MENU_BRIDGE_V201.lastSnapshot=s}catch(e){window.NOONTANGI_MENU_BRIDGE_V201.lastError=String(e)}}
  var scheduled=false;
  function queue(){if(scheduled)return;scheduled=true;setTimeout(function(){scheduled=false;render()},75)}
  document.addEventListener('click',function(e){var btn=e.target.closest&&e.target.closest('[data-ntv201-go]');if(btn){var id=btn.getAttribute('data-ntv201-go'),r=document.getElementById(id);if(r){r.checked=true;r.dispatchEvent(new Event('change',{bubbles:true}));queue()}return}
    if(e.target.closest&&e.target.closest('[data-ntie-save],[data-ntie-star],[data-ntie-recalc],[data-v3hyp],[data-v3market]'))queue();
  },true);
  document.addEventListener('change',function(e){if(e.target&&/^(rMarket|rRadar|rLong|lhHome|lhTheme)$/.test(e.target.id))queue()},true);
  window.addEventListener('storage',function(e){if(!e||e.key===KEY)queue()});
  window.NOONTANGI_MENU_BRIDGE_V201={project:stat,group:group,render:render,lastSnapshot:null,lastError:null};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){queue();setTimeout(queue,350)},{once:true});else{queue();setTimeout(queue,350)}
})();
