# V202 — CURRENT VISIBLE SURFACE / TTS COMPLETE / MAJOR INDICATORS (2026-10-10)

- Base: V201. No account/ledger changes, no new automatic theme or macro-data engine.
- Voice: use the currently visible highest auxiliary surface or selected main route, not the previously opened news/card. When a calendar is open read the visible event's heading, announcement description, watch points, and expanded description. For existing news/firemouth read only the expanded prepared summary.
- Native Android TTS: send final utterance ID through an optional third argument of `onNativeState`. Close the original auxiliary surface only on matching final utterance completion. Ignore stale IDs, manual stop, or errors. Do not close top-level menu routes. Stop on screen/tab or card change.
- Major indicators: chart default period 5Y, weekly sampling, benchmark KOSPI; subsequent deliberate user settings remain intact. Existing primary/extra indicator listing remains. Many extra rows still have *proxy charts*, not each named index's official historic series: do not conflate.
- V201 market/radar/long summary is small read-only evidence projection; not a major UI redesign or complete investment engine. Appearance changes can be subtle or absent when evidence is empty.
- Verification: 98 inline JS syntax checks passed. Isolated Chromium mock TTS tests passed including calendar priority over older news, stopping, stale final callback rejection, close-on-completion, non-closing main menu. Full HTML booted and displayed V201 bridge objects in Chromium but opaque-origin errors occurred around localStorage/sessionStorage and one legacy listener; full runtime regression not passed.
- Not verified: Android Gradle/APK build, actual Samsung TextToSpeech end callback, all native voice/routes, live macro data and manual end-to-end.
- Package name `SNOWBALL_CURRENT.zip`; versionCode 60248; versionName `6.0.8-r9-v121-voice-current-indicators-r84-v202`; cache 791.
