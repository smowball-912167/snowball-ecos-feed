# V250 — 2 JS runtime repairs + official market indicator diagnostics (2026-10-18)

- V249 installed build 60330 remained intact during analysis. Next update source is V250, versionCode 60331, versionName 6.0.8-r9-v250; same package ID and signing policy.
- Diagnosed from shared V249 JSON: JavaScript events at index.html lines 8673 and 17527; no raw error message was supplied.
- Deterministic code defects found: chart `ensure()` called `bind()` before assigning `resetBtn`; S17 export referenced undeclared `parseCSV`, also used by S17/S19 import.
- Repaired init sequencing; CSV import now validates real date/close rows, handles known header/quoted thousands separator, rejects invalid/duplicate/negative prices without synthesizing prices.
- Diagnostic type `시장지표·수집` added. Report lists 30 allowed, public four-factor official indicators with only stable metric ID, CONNECTED / MISSING / STALE / UNKNOWN, and optional YYYY-MM-DD observation date. No metric values, individual accounts, positions, trades, secret keys, URLs or news bodies.
- Data limitations: 30 public official indicators status is NOT a full audit of every 33 market/environment + 21 correlation indicators. V249 missing-14 source restrictions remain. Some sources remain unapproved, require API keys/server publishing, or await 20 joint observed trading sessions; do not claim all indicators connected.
- Preserved four-factor formula, previously connected sources, correlations, charts and UI, account databases, package name and native signing requirements. No automatic migration or cache clearing.
- Validation: Node V250 CSV/rebind smoke, V249 batch, V247 and V245 regressions, inline JS syntax, digest audit. Real Galaxy install + actual market data remains pending.
