# V231 / build 60312 / 2026-10-17

Source V230, changes: gold quote call for default ninth tile, duplicate settings button removed, chart dialog compact, news headline weight and source RSS image fallback, four market axes can surface current relevant collected articles and validated institutional flow (only when available), concise single daily equity summary, strategy label. Original data preserved.

Validation: source hash check; JS parse check; ZIP integrity; not an APK compilation or network test.
