V243: ECOS server-only keyed data collector prepared for kr03y and krRate. No user credential, no app-side API call, not yet linked to Android feed. Existing UI and source collectors unchanged.
