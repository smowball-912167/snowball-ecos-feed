# V275 · Quiet Standby & Verified Calendar Outcomes

- On launch, migrate saved 'auto' mode to 'button' once; never auto-rearm on silence or recognizer BUSY. Gemini remains standby/response provider.
- Button begins one voice turn, then silently returns to standby without requiring the user to speak again. Explicit opt-in auto mode remains available and may produce system STT sounds.
- Market calendar, after event end and only when calendar is opened: fetches latest completed event with Gemini live search. Manual outcome lookup for other past events. Strict official-source URL gate, 6-hour successful-result cache, no fabricated meeting decisions. FOMC has additional day/time buffer.
- No asynchronous monitoring when app is closed. No Render, ECOS, finance, stock balance or APK signing changes.
