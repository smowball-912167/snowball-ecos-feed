# V261 · 금융·수급 3개 검증된 원천 일괄 수용 (2026-10-22)

- 60340 / 6.0.8-r9-v261. 이전 V260 전체 기능 보존.
- 기존 GitHub Pages market/finance.json 한 번의 조회로 고객예탁금·신용융자 2개는 기존 그대로 수용.
- 추가로 외국인 20거래일 합계, 신용잔고율(시장 전체 시총 대비), VKOSPI200의 선택적 조건부 수용 경로 구현.
- 세 지표 모두 게시자 측 원천 확인·공개 재배포 허가 문서가 필요하며 licenseReviewed 및 publicRedistributionAuthorized 표시만으로 실제 법적 허가가 발생하지 않음. 허가 없는 공개 피드 업로드 금지.
- 외국인: ECOS 802Y001의 양시장 순매수와 KOSPI/KOSDAQ 지수 거래일 20개, 같은 날짜·단위·합산값 검증.
- 신용잔고율: 금융위원회 정의에 따라 검증된 당일 신용융자잔고 / (KRX KOSPI + KOSDAQ 당일 전체 시가총액) ×100. 같은 날짜·정확한 원천·분자 일치 필요. 종목별 잔고율로 대체하지 않음.
- VKOSPI: KRX VKOSPI200 공식 일별 종가만; VIX나 유사 변동성으로 대체하지 않음.
- 원천 부재/권한 부재면 기존 앱 5/8 보존. 성공 수신 5/8 또는 8/8 실제 앱에서만 판단할 것.
- APK 및 공개 서버 피드·GitHub 리포지토리는 이 ZIP 제작으로 자동 배포되지 않음.
- 참조: https://www.fsc.go.kr/no010101/85654, https://openapi.krx.co.kr/contents/OPP/DATA/OPPDATA003.jsp
