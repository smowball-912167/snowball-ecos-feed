# V245 ECOS 실시간 피드 경로

- ECOS_API_KEY는 GitHub Actions Secrets 환경변수 전용; 앱/ZIP/공개JSON 저장 금지.
- 사용자 GitHub Pages 권한/설정 확인 및 게시 완료 전 앱에는 최신 ECOS 관측값 자동 반영되지 않음.
- 실행: `.github/workflows/ecos-live-feed-publish.yml` 파일을 repo에 업로드하고 Settings > Pages의 Actions 게시 설정 후 워크플로 수동 실행.
- 공개 URL: `https://smowball-912167.github.io/snowball-ecos-feed/ecos/feed.json` (계정/저장소명이 실제와 다른 경우 수정해야 함).
- 19개 원천 검증 수집 시도; 호환 5개만 기존 시장환경 원천에 보충; 동일/더 최신 자료 기존 우선.
- 54개 구성, 장기/단기/뉴스/개인계좌 및 65/35 동일지표 조건, 기능 유지.
- 사용자 승인 전 나머지 모호 지표 자동대체 없음.
- GitHub Free + private repo에서는 Pages 사용 불가일 수 있음. 이 경우 Pages 가능한 별도 공개 데이터 전용 저장소 또는 다른 HTTPS 호스팅이 필요하며, 앱이 바로 수신된다고 설명하지 않는다.

- 공개 피드 재배포 범위를 5개 연결시험 지표로 제한한다. KRX, 해외 등 나머지 원천은 공개 재배포하지 않고 이용조건 검토가 필요하다.

- 앱 가이드 ntv245-guide-sync 및 마스터 DOCX V245 동기화.
