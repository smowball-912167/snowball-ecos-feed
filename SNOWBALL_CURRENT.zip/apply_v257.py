from pathlib import Path
import hashlib,json,re
p=Path(__file__).parent
js=p/'app/src/main/assets/ntv249_batch_connectors.js'
s=js.read_text()
s=s.replace("var ID='NOONTANGI_V249_BATCH_STATUS', FLOWKEY=", "var ID='NOONTANGI_V249_BATCH_STATUS', STARTUP_STATUS='NOONTANGI_V257_FINANCE_STARTUP', FLOWKEY=")
s=s.replace('function collectFinance(){return get(FINANCE_URL).then(',"var financeInFlight=null;\nfunction collectFinance(){if(financeInFlight)return financeInFlight;financeInFlight=get(FINANCE_URL).then(")
s=s.replace(".catch(function(){return {status:'not-published',verified:0,updated:0}})}\nfunction refresh(force)",".catch(function(){return {status:'not-published',verified:0,updated:0}}).finally(function(){financeInFlight=null});return financeInFlight}\nfunction refresh(force)")
assert 'financeInFlight' in s
start=s.index('if(root.document){root.document.addEventListener(\'change\'')
end=s.index('root.NOONTANGI_BATCH_V249=',start)
new=r'''/* V257: prefetch ONLY verified finance data when app initially loads, no Market tab entry needed.
 * Exactly one GET when it succeeds; up to two extra attempts after failure/partial feed.
 * No background activity when app is closed; on-focus and foreground periodic checks are throttled.
 * Original market-triggered ISM/flow collectors and already verified cache remain intact. */
var startupAttempts=0,startupFinished=false,lastAutoFinance=0,retryTimer=null;
var AUTO_MIN_INTERVAL=30*60000;
function storeFinanceAuto(status,reason){save(STARTUP_STATUS,{version:'V257',attempts:startupAttempts,lastAttempt:new Date().toISOString(),reason:reason,status:status&&status.status||'unavailable',verified:Number(status&&status.verified||0)});}
function startupFinanceAttempt(){
 if(startupFinished||startupAttempts>=3||root.document&&root.document.hidden)return;
 startupAttempts++;lastAutoFinance=Date.now();
 collectFinance().then(function(result){
   storeFinanceAuto(result,'app-launch');
   if(result.verified===2){startupFinished=true;return;}
   if(startupAttempts>=3){startupFinished=true;return;}
   retryTimer=setTimeout(function(){retryTimer=null;startupFinanceAttempt()},startupAttempts===1?20000:60000);
 });
}
function periodicFinance(){
 if(!startupFinished){if(!retryTimer)startupFinanceAttempt();return;}
 if(root.document&&root.document.hidden)return;
 if(Date.now()-lastAutoFinance<AUTO_MIN_INTERVAL)return;
 lastAutoFinance=Date.now();collectFinance().then(function(result){storeFinanceAuto(result,'foreground-refresh')});
}
function bootFinance(){setTimeout(startupFinanceAttempt,1800);
  root.addEventListener('focus',periodicFinance);
  root.document.addEventListener('visibilitychange',function(){if(!root.document.hidden)periodicFinance()});
  setInterval(periodicFinance,30*60000);
}
function guideFinance(){var doc=root.document.querySelector('#nt1232Guide .nt-master-doc');if(!doc||doc.querySelector('#ntv257-finance-autofetch-guide'))return;var el=root.document.createElement('section');el.id='ntv257-finance-autofetch-guide';el.className='nt-master-v';el.innerHTML='<h3>V257 · 앱 실행 시 일별 금융자료 자동 수신</h3><p>눈탱이 앱을 실행하면 시장환경 메뉴를 누르지 않아도 금융위원회 고객예탁금·신용융자 잔고 2개를 공개 검증 피드에서 자동으로 확인한다. 성공 시 1회 조회하고 자료 부재·접속 실패 시에만 최대 2회 추가 시도한다. 마지막 정상 통계와 날짜를 보존하며 미확인 자료를 0으로 대체하지 않는다.</p><p>서버는 매일 오전 8시 10분(한국시간) 통계 갱신을 예약한다. 앱이 실행 중일 때만 30분 이상 지난 경우 다시 확인하며, 앱을 완전히 종료하면 별도의 백그라운드 수집을 하지 않는다. 인증키는 앱에 포함하지 않고, 기존 ECOS 15개·시장환경·계좌·뉴스·차트를 유지한다. GitHub 빌드 성공과 갤럭시 설치·재시작 시 실제 수신은 별도 확인이 필요하다.</p>';doc.prepend(el)}
if(root.document){root.document.addEventListener('change',function(e){if(e.target&&e.target.id==='rMarket'&&e.target.checked){setTimeout(function(){refresh(false)},2300);setTimeout(collectFlow,11000)}},true);
 var boot=function(){var t=root.document.getElementById('rMarket');if(t&&t.checked)setTimeout(function(){refresh(false)},2600);bootFinance();guideFinance()};
 if(root.document.readyState==='loading')root.document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 root.document.addEventListener('click',function(e){if(e.target&&e.target.closest&&e.target.closest('#nt1232GuideOpen,[data-v1232-guide-open]'))setTimeout(guideFinance,0)},true);
}
'''
s=s[:start]+new+s[end:]
s=s.replace("parseIsm:parseIsm,validFinanceFeed:validFinanceFeed,version:'V249'","parseIsm:parseIsm,validFinanceFeed:validFinanceFeed,refreshFinance:collectFinance,financeAutoState:function(){return read(STARTUP_STATUS)},version:'V257'")
js.write_text(s)
# stable identity: bump gradle version only. Keep index.html exactly bit-for-bit for data and s1 signature.
gradle=p/'app/build.gradle'
g=gradle.read_text();assert 'versionCode 60336' in g
g=g.replace('versionCode 60336','versionCode 60337').replace("versionName '6.0.8-r9-v255'","versionName '6.0.8-r9-v257'")
gradle.write_text(g)
mani=p/'app/src/main/assets/s1_manifest.json';m=json.loads(mani.read_text());m['versionCode']=60337;m['versionName']='6.0.8-r9-v257';m['gradleSha256']=hashlib.sha256(gradle.read_bytes()).hexdigest();m['scope']='V257: immediate verified finance feed prefetch at app launch, up to 3 attempts only on failures; 30-minute foreground check; preserve ECOS 15, core 33/21 indicators, all accounts, markets, app-signature.'
mani.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
(p/'BUILD_ID_V257_APP_LAUNCH_FINANCE.md').write_text('''# V257 · 앱 최초 실행 금융자료 자동 조회\n\n- 앱 홈 실행 직후 금융위원회 고객예탁금 / 신용융자 잔고 공개 데이터 1회 조회\n- 둘 다 성공하면 즉시 중단; 실패·부분 수집이면 20초 후 1회, 추가 60초 후 1회. 초기 최대 3회\n- 앱 사용 중 foreground 30분 이상 경과 시 최신 데이터 재확인; 종료 상태에서는 앱 측 백그라운드 수집 없음\n- GitHub 서버 자동 수집은 기존 매일 08:10 KST. 서버 설정 변경하지 않음\n- 시장환경 미진입에서도 네이티브 브리지를 통해 공개 검증 자료만 조용히 조회\n- 최신 확인치·날짜 보존, 차트·계좌·뉴스·기존 ECOS 15개 및 승인 사항 불변\n- 60337; 6.0.8-r9-v257; 설치 서명은 기존 GitHub signing identity 사용. 이 ZIP 자체는 APK 아님\n- 민감 API 키 비포함, GitHub 실제 빌드·갤럭시 검증은 별도\n''',encoding='utf8')
print('modified JS',len(s),'Gradle SHA',m['gradleSha256'])
