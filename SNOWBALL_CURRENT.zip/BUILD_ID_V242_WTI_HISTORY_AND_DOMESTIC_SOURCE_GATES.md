V242 WTI 60 fully completed sessions derived from Yahoo CL=F daily close. Strict freshness/code/currency/60-session checks. Domestic official keyed sources still pending secure collection.
