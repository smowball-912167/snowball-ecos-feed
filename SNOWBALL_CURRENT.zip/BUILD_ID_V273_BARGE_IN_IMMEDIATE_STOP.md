# V273: Immediate conversation stop and barge-in trial

- Fixed lower-right AI conversation button now displays "■ 즉시 중지" during spoken answer, and "■ 대화 중지" otherwise. Existing position unchanged.
- V118 stop invalidates all pending AI chat responses/timeouts, clears delayed Gemini TTS fallback and calls native voice stop. A late HTTP reply cannot restart speech.
- Android stopVoiceNative invalidates pending Gemini /speak generation, stops MediaPlayer and device TTS, and cancels active SpeechRecognizer.
- While TTS/AI playback occurs, Android SpeechRecognizer listens only for short stop commands such as "잠깐 대화 중지", "그만 말해", and "잠깐만". Other recognition including AI output echo is discarded and **never** transmitted as a question. Command recognition over device speaker is best-effort, not guaranteed on Samsung: thumb STOP is reliable fallback.
- When user explicitly stops conversation, auto-listening stays off until the user presses AI대화 again, including foreground resumption.
- Live app device test pending. Source tests are not proof of microphone/speaker duplex reliability.
