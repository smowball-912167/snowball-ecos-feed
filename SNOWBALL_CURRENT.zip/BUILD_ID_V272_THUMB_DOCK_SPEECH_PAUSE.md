# V272 — Right-thumb voice dock / diagnostic position / thinking pause

- AI conversation and selection-reading controls use the same existing listeners and move together to the fixed lower-right position 8 CSS px above the seven-item main navigation bar. No duplicated controls.
- The existing temporary “오류 진단” launcher moves to the upper banner bottom-right, at the old selection-reading position. Diagnosis feature/panel unchanged.
- Voice dock and diagnostic launcher retain the highest app stacking level, except that the voice dock temporarily hides behind the active diagnostic panel and safety-critical trade dialogs.
- Android speech recognition hints changed: complete-silence 2600→3800 ms, possibly-complete 1500→2200 ms. The Samsung recognition provider can ignore these hints; this is an improvement attempt, not a guaranteed speech endpoint fix.
- The default AI assistant remains Gemini; no AI routing, TTS profile, historical data, sources, trading, ECOS or user settings are changed.
- Build version 60349 / 6.0.8-r9-v272. Actual device placement & recognition behavior require Android APK install and field validation.
