'use strict';
const assert=require('assert');
const path=require('path');
let prior={};
const fs=require('fs');
const code=fs.readFileSync(path.join(__dirname,'app/src/main/assets/ntv245_ecos_live.js'),'utf8');
const vm=require('vm');
const storage={};
const doc={readyState:'loading',addEventListener(){},getElementById(){return null}};
const mock={document:doc,localStorage:{getItem(k){return storage[k]||null},setItem(k,v){storage[k]=v}},
 NOONTANGI_FOUR_FACTORS:{official(k){return prior[k]||null},ingest(){return 0}},
 addEventListener(){},dispatchEvent(){}, Event:function(){},setTimeout(){return 1},clearTimeout(){},
 module:{exports:{}},Date:Date,Promise:Promise,Number:Number,JSON:JSON,Object:Object,Math:Math,console:console};
mock.window=mock;mock.globalThis=mock;
vm.createContext(mock);vm.runInContext(code,mock);
const api=mock.module.exports;
assert.equal(api.version,'V254');
const ids=['kospi_d','kosdaq_d','kospi_foreign_d','kosdaq_foreign_d'];
const specs={kospi_d:['0001000','1980.01.04=100'],kosdaq_d:['0089000','1996.07.01=1000'],kospi_foreign_d:['0030000','억원'],kosdaq_foreign_d:['0113000','억원']};
const now=new Date();now.setUTCHours(0,0,0,0);
let ds=[];for(let i=0;ds.length<32&&i<80;i++){let d=new Date(now.getTime()-i*86400000);if(d.getUTCDay()!==0&&d.getUTCDay()!==6)ds.push(d.toISOString().slice(0,10).replaceAll('-',''))}ds.reverse();
function item(id,days=ds){let spec=specs[id];return {table:'802Y001',item:spec[0],cycle:'D',unit:spec[1],latest:days[days.length-1],
 status:'observed_not_auto_approved',value:id==='kospi_d'?6000+days.length-1:id==='kosdaq_d'?900+days.length-1:id==='kospi_foreign_d'?100:50,history:days.map((date,n)=>[date,id==='kospi_d'?6000+n:id==='kosdaq_d'?900+n:id==='kospi_foreign_d'?100:50])}}
function feed(){const sources={};ids.forEach(id=>sources[id]=item(id));return {schema:'NT_ECOS_LIVE_V245',generatedAt:new Date().toISOString(),sourceCount:4,sources}}
let f=feed();
let x=api.foreign20Candidate(f);assert(x,'all four daily sources should produce a rolling sum');assert.equal(x.id,'foreign20d');assert.equal(x.value,3000);assert.equal(x.history.length,13);assert(x.source.includes('20개'));
let vals=api.match(f);assert.equal(vals.length,1);assert.equal(vals[0].value,3000);
console.log('PASS aligned exact 20 sessions; indicator value 3000 and matching provenance');
// All four sources must be published, not just the two flows.
for(let id of ids){let z=feed();delete z.sources[id];assert.equal(api.foreign20Candidate(z),null,`missing ${id} must not connect`)}
console.log('PASS four independent missing-source gates');
let z=feed();z.sources.kosdaq_d.history[z.sources.kosdaq_d.history.length-1][0]='20260102';assert.equal(api.foreign20Candidate(z),null);
console.log('PASS mismatched index trading sessions');
z=feed();z.sources.kospi_foreign_d.history.splice(-5,1);assert.equal(api.foreign20Candidate(z),null);
console.log('PASS daily foreign observation missing in the last 20 sessions');
z=feed();z.sources.kosdaq_foreign_d.cycle='M';assert.equal(api.foreign20Candidate(z),null);
console.log('PASS monthly-as-daily confusion rejected');
z=feed();z.sources.kosdaq_foreign_d.unit='원';assert.equal(api.foreign20Candidate(z),null);
console.log('PASS unit mismatch rejected');
z=feed();z.sources.kosdaq_foreign_d.status='NOT_PUBLISHED';assert.equal(api.foreign20Candidate(z),null);
console.log('PASS not-public source rejected');
z=feed();z.sources.kosdaq_foreign_d.history[z.sources.kosdaq_foreign_d.history.length-1][1]=Infinity;assert.equal(api.foreign20Candidate(z),null);
console.log('PASS non-finite foreign-flow rejected');
z=feed();prior.foreign20d={id:'foreign20d',asOf:new Date(Date.now()+86400000).toISOString(),source:'verified existing'};assert.equal(api.match(z).length,0);prior={};
console.log('PASS newer existing value preserved');
let m=api.foreign20Candidate(feed());assert(!Object.keys(m).includes('customerDeposits'));
console.log('PASS daily market flow has no implicit monthly finance substitution');
