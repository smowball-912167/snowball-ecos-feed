# V234 · 갤럭시 APK 설치 메타데이터 보정 (2026-10-17)

- 기준: V233 소스(`versionCode=60314`)를 그대로 이어받는 최소 수정.
- 진단: GitHub #449 빌드 성공, 갤럭시 "앱을 설치할 수 없음 / 앱 파일에 문제가 있습니다", `phoneVerified=false`.
- 확인된 소스 결함: 이전 `versionName`은 1078자이며 Android 공식 매니페스트 속성 제한 1024자를 초과한다. 설치 오류의 유력한 원인이지만 Android의 정확한 내부 오류 코드는 아직 확보되지 않았다.
- 수정: `versionCode=60315` / `versionName=6.0.8-r9-v234` (짧은 이름). 전체 과거 변경명은 아래에 기록해 보존한다.
- 앱 식별자 유지: `com.snowball.noontangi.v60isolated` (변경 금지).
- 기존 `snowballStable` GitHub Secrets 서명 구조 유지. 키스토어/비밀번호는 ZIP에 포함하지 않는다.
- `minSdk=26`, `targetSdk=35`, 앱 화면/기사/매매/보관 동작과 사용자 데이터 처리 로직 유지.
- 사전검사: ZIP 무결성·Gradle/manifest S1 SHA-256·기존 MainActivity 지문·앱 가이드 동기화.
- 기기 검증: 새 GitHub Actions APK 빌드 후 기존 눈탱이를 삭제하지 말고 업데이트 설치 시험. 빌드 PASS는 설치 성공이 아니다.

## V233 장문 versionName (이력 보관)

`6.0.8-r9-v121-news-routing-journal-ui-r89-v208-s1-diagnostic-backupfix-r2-holdingsscroll-r1-s2-ui-scale-r1-s3-portfolio-r1-s4-commodity-guide-r1-s5-ui-density-r1-s6-commodity-quote-r1-s7-gold-don-unit-r1-s8-detail-layout-r1-s9-density-data-first-s10-sharedgap-fire-refresh-r1-s11-shortcut-library-r1-s12-fire-evidence-ko-lanes-r1-s13-collection-feedback-r1-s14-20themes-manualsearch-r1-s15-collection-depth-reject-r1-s16-home-summary-privacy-r1-s17-event-study-r1-s18-event-timeline-story-r1-s19-sp500-ks200-date-r1-s20-sourced-atmosphere-r1-s21-index-additive-r1-s22-historical-volatility-r1-s23-compact-event-ui-r1-s24-marketday-5y-r1-s25-theme-archive-r1-s26-theme-growth-r1-s27-theme-korean-reader-v220-growth-live-refresh-v221-market-photo-ui-v222-market-approved-compact-ui-v223-market-dedicated-news-v224-modal-scroll-lock-ui-v225-market-risk-prefetch-v226-veteran-multitheme-v227-theme-reader-nav-roster-v228-fixed-theme-veteran-v229-veteran-article-scroll-v230-title-spacing-theme-scroll-v231-market-source-ui-v232-market-news-reader-compact-v233-news-brief-system-back`
