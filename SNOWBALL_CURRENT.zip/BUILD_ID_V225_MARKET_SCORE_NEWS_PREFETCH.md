V225 | 2026-10-16
- Restore 8 validated quote (not fundamentals) 100pt score + 6 constituent axes, colored status; unknown earnings and foreign investor flow remain unscored.
- Dynamic positive/risk drivers and conditional investment response.
- 4 market news lanes stay distinct from major-news lane. One representative per lane background article text prefetch, shared in-flight promise, cache. Cached opens immediately; foreground source 9000ms + translation 6000ms max, 3s progress signal; failures link to original. Never summarize title as read body.
- preserve V224 modal owner and original user data.
- Internal guide and DOCX synchronize; Android signed build/device validation still required.
