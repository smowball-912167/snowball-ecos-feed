# SNOWBALL V248 — daily FX volatility fallback (2026-10-18)

- Based on V247 60328; versionCode 60329 / versionName 6.0.8-r9-v248.
- If V247 ECOS public feed does not carry fx_d, fetch existing approved native Yahoo Finance KRW=X daily history from within app on market screen only. This is not an ECOS observation nor a public feed and is labeled Yahoo.
- Require exact currency pair, daily history, valid 21+ weekdays, verified latest quote age, sane units, no anomalous 20-day returns. Derive 20-day simple daily percentage return sample standard deviation, non-annualized.
- Existing same-day or newer verified observations always preserved. Equal-date validated ECOS supersedes Yahoo.
- V247 monthly reference candidate gates and unapproved imports/foreign net buys unchanged. Existing four-factor scores, daily collection, correlation charts, portfolios, records, and source identity untouched.
- Tested locally with mocked Yahoo fixture, V247 regression and publisher gate. Real Yahoo availability and device display NOT verified until next GitHub APK build and installation.
- No new secret or published data source required.
