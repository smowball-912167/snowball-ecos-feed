# V229 · Veteran / theme reader unification and footer fix
- Input: V228, code 60309, library snapshot 2026-10-17 11:50 KST.
- Four fixed buttons: 국내, 글로벌, 최신기사 요청, 베테랑.
- Removed inline veteran buttons on all 20 theme cards. Veteran selection changes theme card counts and opens byline-confirmed veteran articles in the SAME title list/detail reader as normal theme articles.
- 일반 최신기사 요청: fresh search of selected theme, or 20 sequential theme refreshes on root. 베테랑: select theme then force byline verification for that reporter group. No news content/fact changes.
- Removed like/dislike from title/list; preserved detail buttons and cached votes. Detail title weight 500.
- Detail WebView overlay bottom derives from mainNav element top; additional scroller padding ensures bottom actions stay reachable on Galaxy.
- Source originals, legacy index and reporter roster intact. In-app guide and DOCX V229 synchronized.
- Static checks do not prove APK install/network behavior.
