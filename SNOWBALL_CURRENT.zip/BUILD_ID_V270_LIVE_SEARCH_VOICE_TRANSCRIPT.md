# SNOWBALL V270 | 2026-10-24

- Gemini: Google Search grounding only for current events/finance/news/continuations. OpenAI: Responses web_search only for recent factual queries. Return verified grounding sources separately, show links in voice answer popup and archive. Never claim lookup succeeded without grounding citations. Some requests may incur extra tool costs.
- Remove legacy V121R4 `prefixStock` automatic insertion. Recognized utterance is passed verbatim to AI. Explicit stock navigation commands remain supported.
- Settings > AI Voice: checkbox for AI floating conversation transcript visibility, defaults visible; audio and stored chat persist if hidden.
- Pause handling: native recognizer requests longer post-speech silence (best-effort only; recognizer may ignore), and prevent microphone restart during pending AI reply.
- ChatGPT continues preselected device TTS. Gemini continues provider speech with fallback.
- Market/ECOS/finance/KRX redistribution gates unchanged. Do not insert API keys in app ZIP.
- Verification: Node server syntax and mocked requests, inline JS parsing, manifest sha checks and ZIP CRC. Actual API lookup and on-device voice remain unverified until deployment and APK build.
