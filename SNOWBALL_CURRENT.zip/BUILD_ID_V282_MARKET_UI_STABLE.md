V282 / 2026-10-26 / 60359 / 6.0.8-r9-v282
Source-based update: guidance in chart detail, redundant text removed, ECOS refresh relocated, targeted market DOM updates and unchanged short chart redraw avoidance. APK and Galaxy tests remain pending. See MANUAL_SYNC_V282_2026-10-26.md.
