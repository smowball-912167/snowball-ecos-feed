# V255 ECOS 15-source screen refresh and references

- Public ECOS GitHub Actions #8: 15 sources OK. This version does NOT modify the public publisher.
- Discards V254 20-hour success cache on V255 first run. Subsequent success cache lasts 30 minutes; failures retry after 3 minutes.
- Adds market-screen manual ECOS refresh with 2-minute client cooldown. Button does not change remote sources or GitHub settings.
- Displays only validated shared series as supplementary (Korean 10Y daily; US CPI raw index monthly; US policy monthly; WTI/gold/copper monthly). Monthly deposit/credit reference already exists.
- Does not count supplementary lines among primary verified 4-factor items; never substitute monthly figures for daily or raw CPI index for YoY.
- Foreign20 remains unavailable without the 4 separate authorized KRX-produced daily series.
- Preserve signing package, account data, news, correlation periods, 4-factor scores, APK source identity.
- Device/APK build test pending.
