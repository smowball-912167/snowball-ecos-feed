# V245 ECOS 공개 피드 실제 주소 확정 (2026-10-18)

- 공개 데이터 전용 저장소: smowball-912167/snowball-ecos-feed (Public)
- 앱 본체 저장소: Snowball-apk (Private, 변경하지 않음)
- Pages 파일: `https://smowball-912167.github.io/snowball-ecos-feed/ecos/feed.json`
- GitHub Actions `Snowball ECOS Daily Public Feed #1`: Success, 37초, Artifact 1개 (사용자 화면 14:21 KST)
- Chrome 공개 JSON 조회 화면: 스키마 `NT_ECOS_LIVE_V245`, `sourceCount=5`, `displayIndicatorsPreserved=54`, ECOS 원천 history를 사용자 화면에서 확인 (14:29 KST)
- 수정 파일: Java HTTPS exact allowlist, 앱 JS URL, index.html 가이드, 마스터 매뉴얼 URL, 무결성 manifest, 설명 문서.
- 앱 화면 표시/실기기 네트워크/서명된 APK 설치 성공은 아직 검증하지 못함.
- 데이터 기존 최신값 보호 및 54개 지표/4대 점수/뉴스/계좌/버튼 구조는 변경하지 않음.
- 주의: 공개된 원천은 5개뿐이며 ECOS 키는 GitHub Actions Secret으로 유지. 앱 ZIP이나 API 키를 공개 repo에 업로드하지 말 것.
