# V230 · S1 source identity manifest sync — 2026-10-17

## Failure
GitHub Actions Build SNOWBALL APK #442, `Validate S1 source identity`, exit 1:
`Source integrity mismatch: app/src/main/assets/index.html`.

## Root cause
S1 manifest embedded outdated SHA-256 for the V230 modified HTML and Gradle file.

## Correction
Update only `app/src/main/assets/s1_manifest.json` hash values and its scope description; retain existing `MainActivity.java` hash (unchanged).

## Validation
- Manifest hashes match byte-exact ZIP members for index.html, app/build.gradle, MainActivity.java.
- Manifest version code and version name equal Gradle (60311 / V230).
- All existing ZIP members except the manifest are byte-for-byte unchanged.
- `testzip()` passes; GitHub Action and APK installation still need testing.

## Scope limits
No UI changes, no modifications to signing settings, no historical data deletion.
