# SNOWBALL S1-BACKUPFIX-R1 (후보, 설치 금지)

날짜: 2026-10-10

## 확인된 장애
- WebView: native bridge `ping()` 검사에 V59를 요구
- Android MainActivity: 실제 `ping()`은 BACKUP-OK-V60
- 이 불일치가 구형 Blob 다운로드 fallback 및 확인되지 않은 저장 성공 메시지를 유발할 수 있음

## 변경
1. 네이티브 V60 브리지 연결 복구; 백업 데이터 0건이면 저장 중단
2. Blob fallback은 저장을 확정하지 않고 사용자 확인을 요청
3. Android Documents 저장 후 길이 + SHA-256을 모두 검증한 다음에만 success 콜백
4. S1 진단 및 매매·계좌 처리 로직은 수정하지 않음
5. applicationId 유지, versionCode 60265 유지, versionName 끝에 -backupfix-r1 표기
6. 서명키, 계좌 데이터, 개인정보는 번들에 추가하지 않음

## 검사
- JavaScript 인라인 113개 node --check 통과
- 모의 클릭/브리지/오류 표시 테스트 7개 통과
- 매니페스트 SHA-256 3개 일치
- 실제 APK 컴파일, 서명, 갤럭시 실행/백업 파일 생성 미검증

## 안전 고지
- **현재 갤럭시에 외부 데이터 백업이 확인되지 않아 설치·업데이트를 보류**
- 기존 앱 삭제·저장공간 데이터 지우기·복원 실행 금지
- 이 패키지는 사전 점검용 후보이며 GitHub Actions 최신 빌드 #365의 결과물이 아님
- 실제 앱에 데이터가 남아 있는지 확인해야 하며 홈 금액이 동일하다고 전체 원장이 보존됐다고 확정할 수 없음
- 기존 GitHub workflow는 이 패키지의 60265 및 S1 manifest schema를 허용하지만, 새 APK의 검증과 사용자 데이터 보호는 별개의 관문
