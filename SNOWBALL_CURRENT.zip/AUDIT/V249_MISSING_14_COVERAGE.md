# V249 — 14 currently missing market-environment observations (screen evidence, 2026-10-18)

V248 achieved USD/KRW FX and FX-volatility; the 9/9 rates group is retained. The following cannot all be truthfully declared connected by a source-code-only patch.

| Indicator | V249 status / gating |
|---|---|
| Taiwan exports YoY | pending Taiwan official series definition and route |
| Korea semiconductor export amount | pending Customs HS-code and unit validation, API key |
| Korea semiconductor shipments | pending Statistics Korea category and units, API key |
| Semiconductor price | pending exact DRAM/NAND series and licence |
| Semiconductor inventory | pending official industrial production inventory statistical series, seasonality |
| U.S. ISM Manufacturing PMI | V249 official report direct reader (device HTTP success not guaranteed) |
| Korean import price index | ECOS source has multiple dimensions: still fail closed |
| U.S. 10-year BEI | preexisting FRED attempt, new bridge does not replace with approximation |
| CNN Fear & Greed | pending licensed dependable daily source |
| Foreign 20-trading-day net buy | V249 accumulates existing validated KOSPI+KOSDAQ daily flows; only after 20 matched dates |
| Customer deposits | V249 prepared approved daily financial-feed reader; actual feed/key not yet published |
| Credit loans outstanding | same, exact credit-loan component needed; never mistake total credit provision |
| Credit balance ratio | percentage requires verified matching denominator; cannot derive from credit stock alone |
| VKOSPI | pending official exact index daily licence/data |

Pre-existing connected KOSDAQ daily foreign/institutional net buys, base ECOS feed and all other market/correlation/account series are preserved.
