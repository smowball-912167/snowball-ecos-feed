# SNOWBALL S1 BackupFix R2 · Candidate (NOT INSTALLED)

**Date:** 2026-10-10

## Scope
- Preserve original V208/S0/S1 files and existing phone app. Only a separate staged working copy was modified.
- Native bridge `BACKUP-OK-V60`, Android `ACTION_CREATE_DOCUMENT`, native SHA-256 read-back validation remain from R1.
- Newly validate nonempty holdings `noontangi_v1230i_account_holdings`; validate `noontangi_v13_trade_history` JSON array if present.
- Carry an optional snapshot of 8 *explicitly approved-by-code* auxiliary preference/history keys. These **are not restored by the existing restore action**, which deliberately remains unchanged. This is not a complete restoration guarantee.
- Does not touch, reset or read any real user holdings or trading data.

## Static / simulated tests
- JavaScript syntax: 113 embedded scripts passed.
- Fake-data simulated backup cases: 9 passed (valid, missing account, malformed account, empty assets, malformed trades, absent optional trade history, no bridge, no false success, saved callback).
- S1 source-manifest hashes: 3 matched.
- No keystore/passwords packaged.

## Critical restriction
- AndroidManifest disables system backup (`android:allowBackup="false"`).
- Actual backup file on current phone not located, so ***do not install this candidate over the existing app without separately discussing the risk***.
- Building it in private GitHub Actions does **not** modify or install anything on the phone. The existing GitHub workflow from build #365 can validate the source and build it using GitHub Secrets.
- APK compilation/signing, handset backup document write/readback and live account/trade preservation: **NOT verified**.

## Before any phone install
1. Obtain a user-approved backup strategy; do not erase the existing app or storage.
2. If building the candidate, check workflow output versionCode 60265, matching signing cert and exact `s1_manifest.json` / HTML hashes.
3. After explicit data-risk approval only, update *in-place* (never uninstall) and test native file-picker backup as the very first action. Verify the JSON document is visible in My Files with non-zero size, and independently inspect its structure without sharing personal data.
4. Verify original holdings / ledger, UI and diagnostic button separately.
