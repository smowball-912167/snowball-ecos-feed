# V216 S1 Source identity packaging repair R1 · 2026-10-14

## Incident
- GitHub `Build SNOWBALL APK #406`, step `Validate S1 source identity`, failed: `Source integrity mismatch: app/src/main/assets/index.html`.
- V216 source and Gradle were updated, but `s1_manifest.json` still contained V215 SHA-256 and version metadata.

## Patch (manifest only; no app logic changes)
- `assetSha256`: `e6b3fc05a2ed10a26a597d1334f120e2a21ecd58ddd8533582782e950440a06d`
- `gradleSha256`: `9cb6139a336263bb27081a3118d75817d364728a6f70e66fdb243014429b7738`
- `mainActivitySha256`: `d2c3dee625c645beae3fd327569175b6f6ca46779f861a78105b451fd70a8df7` (unchanged)
- `versionCode`: `60297`
- `versionName`: `6.0.8-r9-v121-news-routing-journal-ui-r89-v208-s1-diagnostic-backupfix-r2-holdingsscroll-r1-s2-ui-scale-r1-s3-portfolio-r1-s4-commodity-guide-r1-s5-ui-density-r1-s6-commodity-quote-r1-s7-gold-don-unit-r1-s8-detail-layout-r1-s9-density-data-first-s10-sharedgap-fire-refresh-r1-s11-shortcut-library-r1-s12-fire-evidence-ko-lanes-r1-s13-collection-feedback-r1-s14-20themes-manualsearch-r1-s15-collection-depth-reject-r1-s16-home-summary-privacy-r1-s17-event-study-r1-s18-event-timeline-story-r1-s19-sp500-ks200-date-r1-s20-sourced-atmosphere-r1-s21-index-additive-r1-s22-historical-volatility-r1-s23-compact-event-ui-r1-s24-marketday-5y-r1-s25-theme-archive-r1-s26-theme-growth-r1-s27-theme-korean-reader-v216-growth-summary-read`
- `sourceRevision`: `V208-S1-DIAG-v1` (preserved for stable S1 identity)
- Other manifest policy metadata preserved; scope corrected for V216.

## Unchanged
- `index.html`, `app/build.gradle`, `MainActivity.java`, all app source, app guide, DOCX manual, signing configuration, historical archives, stored user data.
- New audit file created to record this packaging fix. No localStorage migration or reset.

## Tests
- ZIP `testzip()` and file enumeration after package rewrite
- SHA-256 of three required files exactly equals revised manifest fields
- Gradle version metadata equals revised manifest
- A comparison of archived files from input versus patched output reports no differences except manifest and this new audit file.
- GitHub build + APK signing + Galaxy runtime must still be tested.
