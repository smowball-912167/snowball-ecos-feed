# V253 한국 수입물가지수 실제 ECOS 코드 정정 (2026-10-19)

## 출처와 확인된 오류
- 사용자가 2026-10-18 GitHub Actions에서 직접 수행한 `ECOS-54-LIVE-AUDIT.zip`의 `ECOS_미확정_항목후보.csv`(StatisticItemList 실제 결과) 확인.
- 통계표 401Y015, Group2(통화계약구분코드): W=원화기준, C=계약통화기준, D=달러기준.
- 기존 V252 YAML과 V252 앱은 C만 사용하며 이를 원화기준 후보로 취급한 설계 오류. 2차 감사 시계열 CSV는 C만 69개월 저장했기 때문에 W 원화기준 원자료 확인에 해당하지 않음.

## 이번 수정
- 배포 YAML: 수입물가지수를 명시적으로 승인한 경우에만 현재 ECOS StatisticItemList에서 W/C/D 정의를 재조회·검증. 정확한 W 원화기준의 총지수만 채택. 자료 행에 ITEM_NAME2가 없을 때에도 공식 메타데이터 확인으로 검증하고, 행 명칭이 반대면 거부.
- 피드: W 확증 시 dimensionResolution=ITEM_CODE2_W_KRW_VERIFIED, dimensionCode2=W, dimensionName2=원화기준 포함.
- 앱 V253(60334) 후보: W 검증 3필드가 없으면 import_price_m 연결 거부. 이전 C 표시/캐시 무효화. 기존 5개, 외부 수집처, 고객계좌, 차트, 점수 규칙 불변.
- 앱 가이드, DOCX 마스터 매뉴얼 동기화. GitHub 암호·API 키는 포함하지 않음.

## 배포·승인 잠금
- 한국은행 공공데이터 제공대상 여부 및 ECOS 원천별 제3자 공개 재배포 권한은 별도 확인 필요. 이번 코드는 승인 변수를 자동 설정하지 않음.
- 현재 GitHub 공개 게시 원천은 사용자 캡처 기준 5개이며, 신규 원천은 아직 공개하지 않음. 앱 설치로 수입물가지수가 바로 연결되는 것은 아님.
- 수정된 YAML은 ECOS 저장소의 기존 `.github/workflows/ecos-live-feed-publish-PUBLIC-V252.yml` *대체 후보*이다. 새 워크플로 추가 금지.
- V253 앱은 `SNOWBALL_CURRENT.zip`으로 제공하지만, 기존 앱 V251/V252를 삭제하지 말고 GitHub 빌드 및 실기기 테스트가 필요. 승인·게시가 완료되지 않았다면 APK 업데이트를 서두르지 말 것.

## 외부 약관
- https://www.bok.or.kr/portal/main/contents.do?menuNo=200228
