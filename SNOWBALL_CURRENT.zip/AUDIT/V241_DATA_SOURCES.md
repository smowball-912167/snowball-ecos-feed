BIS KR https://stats.bis.org/api/v2/data/dataflow/BIS/WS_CBPOL/1.0/M.KR?startPeriod=2025-01&format=csv
BIS US https://stats.bis.org/api/v2/data/dataflow/BIS/WS_CBPOL/1.0/M.US?startPeriod=2025-01&format=csv
FRED 10Y BEI https://fred.stlouisfed.org/graph/fredgraph.csv?id=T10YIE
Only country/year/month/daily valid records, matched timeseries, freshness, attribution; no keys; no new scores.