# S20 R1 - integrity correction (2026-10-11)
- GitHub build #384 stopped in Validate S1 source identity: index.html SHA mismatch
- Root cause: S20 source and Gradle built as 60285, but s1_manifest.json remained S19 / 60284 with S19 SHA256 and versionName
- Recreated assetSha256, gradleSha256, mainActivitySha256 from byte-exact packaged files, set manifest versionCode/versionName from S20 app/build.gradle
- No modifications to index.html, build.gradle, Android package identity, MainActivity, keystore usage or signing certificate checks
- Preserve full existing ZIP checks. GitHub build and physical Android installation unverified at creation time.
