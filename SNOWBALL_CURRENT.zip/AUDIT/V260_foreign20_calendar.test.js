// Read-only synthetic unit tests: no public API, no live statistics.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const SCRIPT=fs.readFileSync(__dirname+'/../app/src/main/assets/ntv249_batch_connectors.js','utf8');
const fixed=Date.parse('2026-10-22T12:00:00Z');
class Clock extends Date { static now(){return fixed;} }
const DAY=86400000, holidays=new Set(['20261009','20261005']);
let dates=[];
for(let d=Date.parse('2026-09-15T12:00:00Z');d<=Date.parse('2026-10-21T12:00:00Z');d+=DAY){
 let date=new Date(d),weekday=date.getUTCDay(),ymd=date.toISOString().slice(0,10).replace(/-/g,'');
 if(weekday!==0&&weekday!==6&&!holidays.has(ymd))dates.push(ymd);
}
dates=dates.slice(-20);assert(dates.length===20&&dates.every(x=>x!=='20261009'));
function run({verified=false,mismatch=false,less=false}={}){
 const useDates=less?dates.slice(1):dates;
 const journal={};useDates.forEach(d=>journal[d]={KOSPI:10,KOSDAQ:5});
 const storage={'NOONTANGI_V249_MARKET_DAILY_FLOW':JSON.stringify(journal)};
 const localStorage={getItem(k){return storage[k]??null},setItem(k,v){storage[k]=v}};
 const bridge={getSharedSeries(id){let points=(mismatch?useDates.slice(0,-1):useDates).map(period=>({period,value:100}));return {table:'802Y001',item:id==='kospi_d'?'0001000':'0089000',cycle:'D',latest:points[points.length-1].period,points};}};
 const sandbox={module:{exports:{}},localStorage,Date:Clock,Promise,Math,JSON,Number,String,Object,Array,Error,Set,clearTimeout,setTimeout};
 if(verified)sandbox.NOONTANGI_ECOS_V245=bridge;
 vm.runInNewContext(SCRIPT,sandbox,{filename:'ntv249_batch_connectors.js'});
 return sandbox.module.exports.computeForeign20();
}
assert.strictEqual(run(),null,'without trusted calendar fail closed on weekday holiday');
assert.strictEqual(run({verified:true,mismatch:true}),null,'different calendar cannot pass');
assert.strictEqual(run({verified:true,less:true}),null,'fewer than 20 dates cannot pass');
const result=run({verified:true});
assert(result&&result.value===300&&result.history.length===20,'verified 20 sessions pass');
assert(result.history.every(x=>Number.isFinite(x.value)));
console.log('V260: 5 assertions PASS; holiday accepted only with matching verified ECOS index calendars.');
