S18 / 2026-10-11 / app versionCode 60283
1. S16 HOME summary visibility ON/OFF and S17 report in trade journal preserved.
2. Event chart displays sourced time markers when manually added; verified daily close CSV is mandatory to plot a real price line or infer delayed 3% daily movements.
3. A dedicated '당시 상세설명' button reveals archived event context: stage-by-stage record order, article/news, TV/broadcast, influential speaker statements, retail investor reactions, and contrasting optimistic and cautious viewpoints.
4. Each item carries publication date, optional clock time, type, stance, title, summary, HTTPS source URL and verification status; user input is always unverified until source validation.
5. A verified seed official case without opposing sources displays 'not confirmed' instead of fabricating reactions or escalating tension; item order alone does not establish causal influence or rising mood.
6. S18 marker data localStorage key noontangi_s18_event_markers_v1, separate from trades, accounts and prices. User can delete their added marker. Markers are excluded from S17 price data.
7. Historical press archives, investor forums, automatic source capture and intraday price data are NOT implemented; this version is foundation for phase-1 sourced ingestion.
8. Simulated mobile browser tests 360/393/412, markers + opposing viewpoints; JavaScript syntax check; ZIP integrity and source SHA256. On-device APK/signing not verified.
