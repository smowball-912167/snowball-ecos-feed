# 눈탱이 V243: ECOS 서버 측 수집 준비

- 범위: **한국 국고채 3년물** (ECOS 817Y002 / 010200000), **한국은행 기준금리** (722Y001 / 0101000). 
- `ECOS_API_KEY`는 개인 서버의 환경 변수에서만 읽으며, 코드·APK·ZIP·출력 JSON에는 키가 들어가지 않습니다.
- ECOS 통계표/항목/기준일/단위/최신성 확인을 통과한 원자료만 로컬 JSON 파일에 씁니다.
- 사용자에게서 키를 채팅으로 받거나, APK에 넣지 않습니다.
- 수집 명령(서버에서만): `ECOS_API_KEY=... python3 tools/ecos_private_collector.py --out /private/data/nt_ecos_verified.json`
- 로컬 단위시험: `python3 tools/test_ecos_private_collector.py`
- **중요: 아직 안드로이드 앱 자동 연결은 아닙니다.** 인증키와 승인된 서버 배포 경로가 없으며, 사용자 계좌나 앱 디자인을 바꾸지 않았습니다.
- 수입물가·PPI는 정확한 표/항목 코드를 인증 후 ECOS 통계목록에서 확인해야 하므로 임의의 코드나 다른 지표로 대체하지 않습니다.
- 서버에서 만들 공개 피드는 출처·이용조건·개인정보·인증 등을 확인한 뒤 별도 승인받아 연결합니다.
- Python 스크립트를 Android WebView에서 실행하지 않으며 기존 Yahoo/BIS/BLS/OECD 수집기를 유지합니다.
