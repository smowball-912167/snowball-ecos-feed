# SNOWBALL V216 · 빌드 기록 정합성 수정 R2 (2026-10-14)

## 목적
- `CURRENT_BUILD.txt`의 오래된 `versionCode=60291` 및 V210 표기를 실제 앱/서명된 S1 manifest 버전(V216, 60297)과 일치시킴.
- V216 이외의 앱 소스, 앱 가이드, 마스터 매뉴얼, S1 해시/manifest, Gradle 스크립트, 서명 설정, 테마 20개와 589건 기록은 변경하지 않음.

## 검사
- `app/build.gradle`: versionCode 60297, versionName과 `s1_manifest.json` 일치.
- `s1_manifest.json`의 SHA-256 세 항목(index.html, app/build.gradle, MainActivity.java) 모두 원본 바이트 해시와 일치.
- ZIP 무결성과 원본 대비 차이 범위 검사 통과.
- 앱 소스에는 기능적 변경이 없으므로 DOCX 매뉴얼·앱 가이드는 V216 기준 그대로 유지. 이 점검 기록을 배포 이력으로 남김.

## 명확한 한계
- GitHub Actions #407의 `SNOWBALL-S1-DIAG-APK-NOT-INSTALLED` 산출물 및 워크플로 로그가 제공되지 않아 APK 생성 실패의 실제 원인은 확인 불가.
- 소스 ZIP에 `.github/workflows` 폴더가 포함되어 있지 않으므로 GitHub 실행 파이프라인은 이 ZIP으로 수정되지 않음.
- 본 패키지는 **APK나 APK 생성 성공 보증이 아님**. 서명된 APK를 GitHub Actions에서 다시 확인해야 함.
- 기존 설치 앱을 삭제하거나 저장데이터를 초기화하지 말 것.
