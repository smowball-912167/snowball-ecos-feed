# S1 R1a · GitHub #367 diagnostic source identity repair (2026-10-11)

## Evidence
- Workflow Build SNOWBALL APK #367, stage `Validate S1 source identity`: `AssertionError: Wrong diagnostic source version`.
- ZIP's `app/src/main/assets/s1_manifest.json` erroneously advertised `sourceRevision: V208-S1-DIAG-v1-HOLDINGS-SCROLL-R1`.
- The successful #366 baseline's GitHub S1 identity contract expects `sourceRevision: V208-S1-DIAG-v1`.

## Minimal correction
- Revert only `sourceRevision` to `V208-S1-DIAG-v1`.
- Preserve independent `holdingsScrollFixRevision: S1-HOLDINGS-SCROLL-R1`, `versionCode: 60266`, and the R1 scrolling code unchanged.
- Do not modify the workflow's validation logic, Android signing configuration, holdings storage, or trading history.

## Validation
- Source identity local condition matches the #366 baseline.
- Manifest SHA-256 fields match HTML, Gradle and Java sources.
- APK build, GitHub verification, and Galaxy touchscreen acceptance remain to be tested.
