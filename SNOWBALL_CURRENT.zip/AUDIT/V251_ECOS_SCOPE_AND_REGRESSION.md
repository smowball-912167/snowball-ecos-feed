# SNOWBALL V251 ECOS pipeline diagnostic candidate (2026-10-19)

- Source patch only; does NOT install/replace the Galaxy V250 build.
- Does NOT change GitHub Actions, API secret, GitHub Pages publisher or public-scope approvals.
- V250 existing account, watchlists, news, 4 market factors and correlation external sources remain unchanged.
- One change to the ECOS JS bridge: preserve categorized failure codes; distinguish received count, mapped count, ingestion count and display verification (never claim display success).
- One change to the built-in diagnostic export and preview: ECOS source-pipeline metadata without any API key, numerical market values or holdings.
- On WebView start with Market tab already checked, perform one bounded refresh (existing change-event path preserved).
- Also guards invalid unit shape in source parsing.

KNOWN BLOCKER REMAINS: Current public publisher only publishes 5 base ECOS sources; its 3 conditional additions are disabled without explicit permission variable. Other 11+ sources require definition/license validation and a separate approved publish process. No automatic 54-indicator switchover is made.

Testing: Node client baseline & regression checks. Android APK compilation and physical device test NOT completed; do not label as verified release until those tests pass.
