# 눈탱이 S1 Holdings Scroll R1 · 2026-10-11

- **Root cause**: V204 document-capture `touchmove` guard recognized only `.ntv125-body` while the holdings list/edit pane is a sibling `.v204-holdings-pane`, and thus called `preventDefault()` on holdings swipes.
- **Scope**: permit holdings panel within the existing single guard; scrollable pane and stock-edit focused layout; return to prior list scroll position after edit/save. Other features unchanged.
- **Storage**: ACC/META/ANCHOR correction code preserved; trade/cash history logic unchanged. No real user records used in tests.
- **Regression**: Chromium mobile viewport synthetic touch event original prevented=true / patched false; 15 fake holdings scrollHeight>clientHeight; browser wheel scroll works; item 15 quantity/average edit/save verifies storage; fake trade history unchanged; close removes pane.
- **Caveat**: native Galaxy swipe, keyboard overlap, APK build and signing on GitHub were NOT tested in this container. User to verify after GitHub build.
- **Version**: versionCode 60266, original applicationId and signing scheme unchanged. S1 manifest HTML and Gradle SHA-256 refreshed.
- **Out of scope**: HOME performance/quantity history interval chart, other S2 architecture rework, auto trading, live market news.
