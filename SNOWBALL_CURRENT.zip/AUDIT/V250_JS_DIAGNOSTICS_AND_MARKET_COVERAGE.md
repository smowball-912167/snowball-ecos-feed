# V250 limited audit

## Device evidence
V249 JSON showed build 60330, expected asset SHA MATCH, news 8/8, fire and news recent, two JS errors (original index lines 8673 and 17527). Errors have line numbers only; no exception text.

## Source-level bugs
- `ensure()` constructed reset button then invoked `bind()` **before** assigning `resetBtn`, which `bind()` accesses. Fixed by binding after all DOM references assigned.
- S17/S19 uses and exports `parseCSV` but no function was defined in V249; V250 restores strict CSV parser for actual closes.

## Market source status (per V249 audit, no device proof)
- V248 daily USD/KRW / 20-day FX volatility preserved.
- V249 candidate: official ISM monthly report, subject to network and actual report parsing.
- Foreign 20 trading days needs 20 same-session KOSPI+KOSDAQ snapshots; no historical guessing.
- Customer deposits/margin credit awaiting exact-definition signed server-side daily finance.json and rights check.
- Taiwan exports, Korean semiconductor quantities/price/inventory, Korean import-price dimension, FRED BEI, CNN fear-greed, credit ratio, VKOSPI etc. remain gated by exact definition, series, rights or stable direct access.
- No ECOS API key is included, embedded or published by this source.

## Next device verification
After a verified GitHub build & APK install, open market environment, then diagnostics > 시장지표·수집, share JSON to confirm the 30 official observation states. For remaining 21 correlation indicators, inspect separately.
