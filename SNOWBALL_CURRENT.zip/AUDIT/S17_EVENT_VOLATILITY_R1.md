S17 / 2026-10-11 / app versionCode 60282
1. S16 HOME privacy ON/OFF preserved unmodified, localStorage key ntb_s16_home_summary_visible; no ledger or account changes.
2. HOME quick menu: Report -> 사건연구. Report still exists and opens from 매매일지 submenu button. Single existing report render and trade history preserved.
3. Seed event dates and primary URL authority (no fabricated market-price data): SEC Lehman 2008-09-15; WHO pandemic 2020-03-11; US 9/11 Commission 2001-09-11; UN Ukraine 2022-02-24; Fed Powell speech 2022-08-26; NVIDIA earnings 2023-05-24; FDIC SVB 2023-03-10.
4. CSV price parsing: date,close (Korean header recognized by skipping). At least 15 valid daily bars; 1MB file limit; max 2500 rows; original-data localStorage, no external network call. One symbol per case per import; additional symbols separately. Missing market prices => unverified; app never manufactures returns.
5. Recovery: start from maximum trough within event+250 trading days; first close>=pre-event last close; peak reversion first close<=pre-event last close; return unobserved when no bounce or insufficient range.
6. Signal: first daily close-to-close absolute move >=3% within event T-5..T+10 sessions (not a causal event indicator). Trading-only analysis cannot tell intraday speech sequencing/market closures; review timestamp and adjusted prices externally.
7. Further auto article ingestion/historical price API/AI investment recommendation not implemented in S17. User requested 기타사항 without scope; not guessed or built.
8. No keys/credentials, signing identity, account/holding/trade storage modification. Duplicative source owners not added to old journal/report; new S17 owner only for event study UI.
9. Tests: Node syntax for all inline scripts; Playwright 360/393/412 browser smoke test, simulate daily-price CSV and report navigation; ZIP integrity and source SHA256. No GitHub APK build or user Galaxy validation claimed.
