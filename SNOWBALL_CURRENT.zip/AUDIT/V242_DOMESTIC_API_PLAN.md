# V242 verified sources and safety status

CONNECTED-CODE, NEEDS REAL DEVICE VALIDATION: Yahoo Finance chart CL=F daily 60 completed sessions for WTI moving average.

OFFICIAL SOURCE, NEEDS USER KEY / SECURE BACKEND: Bank of Korea ECOS (BoK policy rate table 722Y001 item 0101000; 3Y Treasury table 817Y002 — item code requires lookup; import prices and PPI table/item need validation), KOSIS industrial production/shipment/inventory, Korea Customs monthly HS goods exports, KRX market data.

CAUTION: FRED series KORPPDMMINMEI stopped in 2022, do not use as current Korean PPI. pykrx is not an authenticated official API and does not imply deposit/credit/VKOSPI coverage.

Do not place secret keys in Android, frontend HTML, ZIP, logs, or persisted asset JSON. No new scoring, no proxy values, keep original 65/35 identical KR/US metric rule.

## Resilience and library usage policy
Third-party no-key sources may break or rate-limit; no guaranteed uninterrupted availability. Always validate source, observed period, freshness, license and rate limits. Fail without replacing previous verified values; old values must expire. Server-side Python only (cannot run inside Android webview). Pin packages and regression-test before upgrade; prefer official data API, never put secret keys in frontend/APK/ZIP.
