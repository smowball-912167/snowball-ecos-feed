S19 (2026-10-11) versionCode 60284
1. Dual benchmark normalized historical plot SP500 versus KOSPI200 for selected historical event.
2. Actual 2020-02-20 to 2020-03-26 historical data example for pandemic case from FRED and public KOSPI200 daily closes; other cases and longer history require independent CSV, user file not automatically verified.
3. Click plot calendar date or date picker for 2-index summary and event news published on selected date.
4. Compute event-before common trading-day baseline, daily close changes, trough and recovery trading sessions within available series.
5. Avoid false cross-timezone simultaneous inference: US/East Asian market sessions end at different hours.
6. Preserve earlier S18 markers, S17 event sources, S16 home visibility and account ledger.
7. 360/393/412 Playwright simulated tests and Node.js owner syntax check. Other legacy errors may exist. GitHub APK, live data APIs and Galaxy device remain unverified.
