OECD CPI: https://sdmx.oecd.org/public/rest/data/OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL,1.0/KOR.M.N.CPI.PA._T.N.GY?startPeriod=2025-01&dimensionAtObservation=AllDimensions&format=csvfile
OECD CLI: https://sdmx.oecd.org/public/rest/data/OECD.SDD.STES,DSD_STES@DF_CLI,4.1/KOR.M.LI...AA...H?startPeriod=2025-01&dimensionAtObservation=AllDimensions&format=csvfile
Only verified monthly KOR observations with matching code, current publication period, actual source, plausibility stored. No guesses or replacements.
