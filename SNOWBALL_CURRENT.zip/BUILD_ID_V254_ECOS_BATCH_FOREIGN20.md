# V254 ECOS batch: separately-approved verified data only

- versionCode 60335, versionName 6.0.8-r9-v254.
- ECOS feed remains 6 approved sources (5 core + import_price_m), no new publication as part of app update.
- New foreign20d same-session four-series matching is additive and fails closed.
- Existing BLS CPI YoY, FOMC policy rates, daily finance and WTI data are preserved.
- Metadata, ECOS rights and GitHub variable approval required for remaining 13.
- Manual and app guide synchronized. No API key is packaged.
- GitHub build and Android display not yet verified.
