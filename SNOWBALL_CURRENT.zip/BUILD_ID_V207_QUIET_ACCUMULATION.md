# V207 — Foreign / institutional accumulation divergence watcher

Baseline: V206. Date: 2026-10-10. versionCode 60262. versionName `6.0.8-r9-v121-news-routing-journal-ui-r89-v207`.

## Scope
- Reuse real daily OHLCV + foreign/institutional DAILY NET BUY records from the short-chart/KRX CSV integration (NAVER, TOSS, KRX import); store last evaluated snapshot per stock locally.
- Analyze 20 / 60 / 120 / 250 / 750 trading-day windows **only** if ≥80% same-day price-flow coverage and >=18 paired trading days. No interpolation of missing flow data.
- Evaluate sideways/weak price action vs cumulative foreign/institutional net buying, sustained breadth across 4 subperiods, OBV from daily closing direction and real volume, short-term volume change. Exclude strong price rally from the 'quiet' classification.
- Display source, date range, trading days, net foreign / institutional and total purchases in SHARES, price change %, OBV direction and source in AI candidate proof. Label `매집 의심`, `수급 누적 관찰`, `매집 판정 보류`, or `자료 갱신 필요`.
- Existing **separate business-progress source-evidence** qualification remains the auto-recommendation gate. Flow signal is only a *supplemental reason* and does not produce unverified new AI recommendations or watchlist additions.
- Maintain manual trading and user-only watchlist selection; NO broker trading automation.
- No false inference that OBV identifies the buyer, that broker/program trading identifies the ultimate owner, or that net buying equals growth in ownership. Stale/missing data must never appear as current accumulation.

## Known limitations
- Evaluates **stocks for which the device has already retrieved matching daily price and flow records**. Not yet an unattended full-market scanner with reliable multi-year exchange investor data.
- Periods beyond actual available history must not be claimed. Historical KRX CSV per stock may be needed for long-range views. Identical same-day snapshots are not re-saved to prevent UI flicker and needless storage writes.
- Android APK build and Galaxy runtime not verified, live feeds/permissions not verified.

## QA
- 110 inline script syntax checks passed; `ntv207_accumulation.js` syntax passed with Node.
- Test cases: 60-day sideways price + persistent net buying yields '매집 의심' including period/volume/price; sharp price rise yields no quiet accusation; 50% missing investor trade rows yields insufficient data; 180-day stale dataset marked stale; same snapshot not persisted twice.
- Chromium full-page navigation blocked by execution environment (`ERR_BLOCKED_BY_ADMINISTRATOR`), so full-app UI runtime test was not performed.
