# V276 · Single Voice Owner / Gemini First / Quiet Voice Controls

## Root causes fixed
- The V121R4 keyword router was still installed after V118 and overwrote `onVoiceTurn`, `onVoiceCandidates`, and `onVoiceResult`, routing finance/stock/latest words into old article headlines and stock commands. This installed voice override has been removed; other Firemouth/data capabilities remain.
- The V203 selected-article reader also took over spoken phrases containing `읽어` anywhere; it now owns only an explicit selected-read button/action, not general AI chat.
- MainActivity native STT final result previously consumed menu/stock names before JS free chat; these are now sent to the single JS owner and explicit app navigation is routed there.
- V118 was auto-rearming Samsung STT after idle, NO_SPEECH, or RECOGNIZER_BUSY regardless of V275 button mode; button mode now starts from a user tap and does not restart on silence/idle.
- AI-debate/selection-read buttons used the same speaking indicator, so both could appear blue; read highlighting now tracks explicitly selected reading rather than any AI speech.

## Behavior and limits
- Ordinary talk about stocks, latest news and selected holdings always goes through Gemini free conversation; only phrases explicitly asking `앱에서 ... 화면/차트 열어줘` are interpreted as app commands.
- Gemini remains the default chat/standby voice choice from saved user settings. Button mode stays the quiet default; optional auto mode is not removed.
- Native speaking-time interruption remains device dependent; button stop is the dependable control.
- This release changes only app voice routing/UI and Android STT navigation, not Render chat gateway, API keys, ECOS, finance, portfolio, stock data, news collectors or signing secrets.
- Basic offline tests passed; actual Galaxy app behavior and GitHub build require confirmation.
