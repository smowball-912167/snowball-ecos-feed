# SNOWBALL Chat Gateway fix — 2026-10-24

Server-only change on top of V268. App HTML, Java, Gradle, APK versionCode and s1_manifest.json are byte-identical.
- Gemini 3.8 Flash: low thinking level and 4096 max output tokens (was 900).
- Safe server-side log codes for provider HTTP errors and empty answers; no prompts or API keys.
- No changes to market, finance, voice recognition or selected TTS settings.
- Server requires a fresh Render deploy after replacing SNOWBALL_CURRENT.zip on GitHub (auto deploy disabled).
- Actual OpenAI/Gemini provider response not verified here.
