V238 · domestic four-factor extension
User approved: preserve all old US/overseas indicators; add all domestic indicators and original bullish/bearish conditions. Apply KR65/US35 ONLY to same indicators with valid observations. No new score. Missing official feeds explicitly unconnected. Reuse market correlation quotes and existing recent order flow. No APK installation implied by ZIP generation.
