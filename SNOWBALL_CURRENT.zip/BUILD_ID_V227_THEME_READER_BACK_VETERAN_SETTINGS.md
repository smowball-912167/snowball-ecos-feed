# V227 · Theme growth read-only navigation, article cleaning and veteran management

- Date: 2026-10-17
- Source baseline: V226, versionCode 60307
- Delivery: V227, versionCode 60308
- Scope: 20 growth themes, article detail reader, veteran journalist roster/settings, app guide and master DOCX

## Verified source changes
1. The growth themes home/detail/reader expose a pinned `국내 / 글로벌 / 최신기사 요청` three-button bar.
2. Home's redundant search/filter/statistics/technical message stack is visually suppressed. Hidden DOM is retained to avoid breaking listeners and local caches.
3. A theme detail retains its separate `베테랑 기자` entry. It uses the pinned domestic/global selection.
4. Read-only theme and article detail navigation removes redundant `목록으로` and `기사 요약 / 원문 한국어` switcher. System Back consumes article detail, veteran panel, theme detail in that order; editing/settings close buttons are retained.
5. Article summary display removes high-confidence photo/byline/datetime/newswire/promotional/related-article tails, preserving stored originals, source URL and facts. Previously verified summaries use local cached content before network requests.
6. Warm only the first article per opened theme after list render; newly selected article remains prioritized.
7. Veteran discovery window increases from 180 to 365 days; verifies up to 10 article candidates per reporter, with strict byline match. No unverified articles are added to veteran results. This is a discovery improvement, **not** proof of coverage of all reporters.
8. Settings → Ops → Veteran reporter list supports add, exclude/remove from collection, and restore, all local to device. Historical source article records and URLs remain stored.
9. V227 manual and in-app guide describe the same behavior and explicit verification boundary.

## Tests completed
- `node --check` for 14 JavaScript assets: PASS
- 131 non-empty inline `<script>` parse checks: PASS
- Chromium mock: 20 theme cards, pinned buttons, domestic selection, article summary, system Back sequence: PASS
- Chromium mock: local journalist add/removal: PASS
- Article content fixture clean: PASS (sample newswire, byline, caption, and unrelated recommended story)
- Document ZIP opens, 99 pages rendered; new last pages visually inspected: PASS

## Tests not completed
- Full existing index.html full-integration touchscreen on Galaxy
- Android Gradle APK build/install; source ZIP does not itself install
- Real journalist articles or actual journalist affiliation/author-page verification
- Actual news-network latency or 3s guaranteed article display
- Global app-wide Back paths outside the growth-theme reader; existing settings close controls deliberately retained

Do not report these unverified items as PASS.
