# V249 · Unconnected market indicators batch bridge

- App versionCode 60330 / versionName 6.0.8-r9-v249.
- Keyless direct official ISM manufacturing PMI report for previous published month; strict year, month, numeric parse, 70-day freshness and source tagging. Direct HTTP may fail at runtime; no fabricated values.
- Preserve existing verified daily KOSPI/KOSDAQ flow snapshots and derive 20 joint trading day sum only after 20 complete date pairs (not 20 calendar days). This does not backfill missing prior days.
- Approved-server-only finance JSON reader: /market/finance.json, typed daily definitions for investor deposits and margin credit, unit 100 million KRW, history and source checks; does nothing unless publisher and actual feed exist. Never embed data.go.kr service key.
- Taiwan exports, semiconductor sector figures, import-price component, fear-greed, VKOSPI, credit ratio etc. explicitly remain missing until validated licensed same-definition series exist.
- No changes to existing 54 definitions, existing score, account, daily series, charts, correlation or app ID.
- V248 FX volatility success on device (0.733%) is preserved.
- Device real integration still requires deploy/install, and signed/approved finance source serviceKey must be configured server-side to receive it.
