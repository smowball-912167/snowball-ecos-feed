# V210 · USER-APPROVED THEME GROWTH SCREEN
2026-10-14 / replaces the visible LONG INVESTMENT route with テ마성장 (themed archive screen).
- bottom tab changed: 장기투자 -> 테마성장; route id rLong preserved (no navigation regression)
- screenshot-informed white card design, search, six content type pills, stats, 20 historical themes, detail article lists, bookmarks
- 589 RSS news metadata unchanged; category '기사' only, no fabricated analysis, no automatic collection/AI
- replaces visual owner only; legacy long-investment markup remains hidden to protect other features
- S1 source integrity hashes regenerated for V210; existing signing and applicationId unchanged
- Browser isolated fixture: 20 cards, 589 article records, detail 20 row pagination, tabs/search tested
- Real GitHub Actions and Android APK runtime: not yet verified
