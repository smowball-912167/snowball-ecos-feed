# V204 — 뉴스 사전정리·관점별 분류·수동 거래원장 보호 (2026-10-10)

## 사용자 확정 원칙
- 자동매매 기능 없음. 최종 매수·매도 주문은 이용자가 증권사에서 직접 실행한다.
- 매매실적은 실제 거래 후 이용자가 매매일지에 직접 입력한다. 앱이 자동으로 계산하는 것은 보유수량·평단·현금·손익 등 저장값이며 실제 주문 실행이 아니다.
- AI추천은 후보 의견과 근거일 뿐 자동 주문이 아니다. 사용자 관심종목은 환경설정에서 독립적으로 직접 등록할 수 있다.

## V204 구현 범위
- 국내·글로벌 주요뉴스 및 불주댕이 화면은 저장된 검증 완료 기사 목록을 즉시 표시. 앱이 전경에서 실행 중일 때 순차 사전 수집/정독 시도. 앱 완전 종료 후 지속 수집은 미지원.
- 기사 하나만 펼침. 다음 기사 선택 시 이전 기사 닫기. 오래된 기사 닫기 동작이 현재 기사 음성을 중단하지 않도록 처리.
- 매매일지 보조창 내부 스크롤 끝에서 HOME 뒤 화면이 따라 올라오지 않게 overscroll/touch 전파 차단.
- 원문 검증 전 발언·기사 후보는 사용자 목록에 표시하지 않으며 현재 회차 정보만 짧게 남겨 오래된 후보 재노출 방지. 내부 진단용 후보/미채택 수 집계.
- 기사는 확인된 소스 기준으로 시장환경·밑밥·장기투자 독립 범주로 분류. 한 기사는 복수 연결 가능, 기타 보관과 미검증 제외는 구분. 키워드 중심의 분류 보조이며 AI 기업 투자 의견이 아님. 새 정보는 별도 메타데이터로 저장하며 원문·계좌원장을 건드리지 않음.
- 환경설정에 '관심종목 등록' 탭 분리, 종목명·6자리 코드·시장·관심 체크, 편집과 삭제.
- 매매일지에 '보유종목 편집' 별도 뷰: 보유 이름·코드·계좌(거래이력 있으면 변경불가)·수량·평단 기준값 정정. 거래/현금 이력 보존, 감사 기록에 before/after 보관. 정정은 새로운 매매를 만들어내지 않음.

## 실기기와 데이터 검증 경계
- 인라인 JavaScript 정적 구문 및 분리된 브라우저 모의시험 통과(기사 전환/음성, 사전 수집 호출 순서, 근거 복수 분류, 관심 추가, 보유량 정정·거래이력 보존).
- 실제 Android APK 컴파일, 실기기 네트워크 수집 완료·번역, TTS 종료, 계좌 동기화 통합 동작은 미검증.
- 시장환경·밑밥·장기투자의 완전한 AI 분석, 종목 추천, 백그라운드 수집, 실제 투자 판단은 이 버전의 완료 범위가 아니다.

## 배포
- `SNOWBALL_CURRENT.zip`, versionCode `60250`, versionName `6.0.8-r9-v121-news-routing-journal-r86-v204`, WebView cache `v793`.

---

# V201 — 시장환경·밑밥·장기투자 역할 분리 / 시장 캘린더 / 일정별 발표 내용 안내 (2026-10-09)

## 메뉴 중복 최적화
- 기존 시장환경·밑밥·장기투자 메뉴와 원본 계좌/거래원장을 보존한다.
- 공통 밑밥 근거(`nt_info_engine_v1_items`)를 읽기 전용 집계하여 동일한 제목·테마·발표일을 한 사건으로 묶어 표시한다. 실제 원본은 삭제·수정하지 않는다.
- 시장환경=거시지표 설명, 밑밥=사건형 증거 집계, 장기투자=테마·종목 연결 현황에 한정한다.
- 이 연결은 집계/내비게이션 기반이며 20개 테마 자동분석, 종목의 재무평가, 장기 AI추천 엔진 완성으로 오인하면 안 된다.

## 시장 캘린더 활성화
- HOME 빠른메뉴 시장 캘린더 터치를 활성화하여 국내·글로벌 금리/물가/경기/고용 관련 공식 일정을 표시한다.
- 한국은행, 미 연준 FOMC, BLS, BEA, ECB 공식 일정 페이지를 연결하고, 기본 확인 일정은 정적 데이터다. Android 네이티브에는 BLS 공식 ICS 피드의 일부 발표를 갱신하는 읽기 전용 경로가 있다.
- 각 일정에 `발표 내용 안내`·`핵심 확인`·`자세한 설명`을 추가했다. CPI/PCE/기준금리/ECB/GDP/고용 관련 항목별 서로 다른 한국어 문장으로 표시한다.
- 발표 전에는 예상할 수 있는 발표 항목과 중요 변수를 설명하며, 실제 발표 결과·수치·금리결정은 **자동 수집되거나 확인되지 않았다.** 지나간 일정에도 근거 없는 결과값을 표시하지 않고 공식기관 페이지를 연결한다.
- 공통 고정 헤더 아래, 하단 메뉴 위에 보조창 배치. 내부 세로 스크롤/상단 닫기 X/하단 메뉴 탭 시 1회 닫기/키보드 Esc/모바일 412×915 점검.

## 시험·배포
- JavaScript 인라인 97개 node --check 오류 0, 독립 Chromium UI 테스트 발표내용·확인 항목·상세 펼침·월 이동·국내/글로벌·스크롤·닫기 통과.
- 공식 인터넷 일정 변경·실제 발표 수치 자동 갱신은 일부만 지원하므로 날짜와 결과는 기관 페이지에서 재확인 필요. BLS ICS 외 주요기관의 원격 실시간 갱신은 미구현.
- Android APK 빌드, 실기기 네트워크·클릭·스크롤 검증은 미수행.
- SNOWBALL_CURRENT.zip, versionCode 60247, versionName 6.0.8-r9-v121-market-radar-calendar-r83-v201, cache v790.

---

# V200 — 매매일지 단일 원장 · AI 자동후보 · 관심종목 직접등록 (2026-10-09)

## 사용자 확인사항
- 액션벨에 남아 있는 별도 거래기록 입력 경로를 HOME 빠른메뉴 매매일지로 연결하고, 리포트에서 거래이력을 확인한다.
- AI추천 종목은 환경설정에서 수동으로 추천 지정하지 않는다. 실제 수집근거가 있는 후보만 자동 표시하며, 사용자가 최종 선택하고 관심종목에 넣는다.
- **관심종목은 AI추천 여부와 무관하게 사용자가 환경설정에서 직접 종목명·6자리 코드·시장·관심 체크로 추가·수정·해제·삭제할 수 있다.** AI추천 목록에서 별표 선택도 가능하다.

## 구현 구조
- `ntv199_stock_registry_v1`의 `watch`를 유지하여 직접 등록 종목과 AI추천에서 별표로 선택한 종목을 같은 관심 탭에 노출한다.
- 이전 수동 AI 플래그(`ai`)는 삭제하지 않고 롤백용으로만 남기며, 활성 AI추천 계산에서 제외한다.
- 수집 정보 `nt_info_engine_v1_items` 안에서 최근 120일 이내 날짜·검증 가능한 URL·근거 링크·서로 다른 2일의 사업 진전 등 일정 조건을 만족한 **기존 등록/보유 종목**을 '자동발굴 후보'로 제공한다. 근거 부족 시 빈 목록으로 두며 실제 기업 재무·수급·저평가 등은 미검증임을 안내한다.
- 현재 자동선정은 제한된 보유·등록 종목 범위에 대한 근거 규칙형 예비 선별이다. 완전한 전종목 발굴, AI 장기매수 의견, 액션벨 자동 알림과 실행 추적은 미구현이다.
- 거래이력 원본은 `noontangi_v13_trade_history`; 이전 액션벨 원장은 중복 방지를 위해 자동 합산하지 않고 별도 확인 목록으로 유지.
- 종목 목록 편집은 실제 거래원장·보유량·평단을 변경하지 않는다.

## 검사·범위
- V200 인라인 JavaScript 95개 `node --check` 통과.
- Chromium 분리 테스트: 환경설정 관심 추가/편집/해제/재지정/삭제, AI 수동 체크박스 부재, page errors=0.
- Chromium 분리 테스트: 근거 없음→자동후보 0건, 다른 날짜·도메인의 확인근거 2건→자동발굴 후보/근거 표시, page errors=0.
- 전체 앱/실기기 APK 빌드/실제 기사 수집·번역·매매일지 동작은 별도 검증 필요. 실제 자동추천 성공 사례와 투자 성과는 확인하지 않았다.

## 릴리스
- `SNOWBALL_CURRENT.zip` · versionCode=60246 · versionName=6.0.8-r9-v121-journal-auto-evidence-r82-v200 · cache v=789.

---

# V199 — 종목 분류·단기투자 차트 연동·환경설정 편집 (2026-10-09)

## 사용자 요청
- AI추천 종목과 사용자 선택 관심종목, 실제 매집/보유 종목을 구분해 단기투자 종목선택에서 자동 제공.
- 연금·IRP 분류 유지. 전량매도된 종목은 보유에서 자동 제외(매매 기록 보존).
- 환경설정에서 모든 종목을 관리하되 실제 계좌 보유·매매 데이터의 원천을 훼손하지 않음.

## V199 구현
- 차트 엔진 MAP의 계좌 동기화를 개별·ISA·연금·IRP로 확대하고 등록종목 동기화 키를 별도 유지.
- picker의 보유는 실제 qty>0 개별·ISA, 연금/IRP 별도 그룹; 관심은 선택된 watch, AI추천은 수동 등록/차후 확정 목록.
- 고정 5개 AI 추천점수 표시 제거(실제 AI 엔진이 연결된 것이 아니므로 실적·점수 오인 방지).
- 환경설정 → 계좌·기준값에 목록 편집: 이름, 6자리 한국 종목코드, KOSPI/KOSDAQ, 관심·AI추천 분류. 추가·수정·삭제가 차트 종목 선택에 연결.
- 보유수량/평단/계좌·거래원장 편집은 기존 계좌·매매일지에서 진행; 목록 분류 삭제는 원장 삭제가 아님.
- 새 종목 선택 시 차트 원천 Yahoo symbol은 국내 시장 선택(KS/KQ)에 맞춰 생성; 데이터 조회 성공은 기기 네트워크/실제 상장코드에 따라 달라짐.
- localStorage 신규 `ntv199_stock_registry_v1`, 기존 `noontangi_photo3_watchlist` 및 계좌 원천 유지.

## 검증 및 한계
- 94개 HTML inline script 문법 통과(0 fail).
- Chromium 분리 컴포넌트 모의: 보유/관심/AI추천/연금/IRP, 종목 선택, 환경설정 추가·수정·삭제, pageerror 0.
- 실제 차트 MAP 코드 분리 실행: 개별 보유, IRP, 등록 종목, KOSDAQ .KQ, qty=0 보유 제외 통과.
- 전체 앱 브라우저 통합 실행은 컨테이너 접근 제한과 시간 초과로 미검증. Android APK 빌드·휴대폰 WebView 실동작·실시간 데이터 연결도 미검증.
- AI 추천 후보는 현재 실제 AI추천 엔진 출력이 없는 한 자동 추천을 의미하지 않고 수동으로 등록한 분류다. 향후 AI추천 엔진을 연결할 때 출처·근거를 명시하여 등록 필요.

## 배포
- `SNOWBALL_CURRENT.zip` · versionCode=60245 · versionName=6.0.8-r9-v121-stock-registry-r81-v199 · WebView cache v=788.
- 기존 V198 뉴스/번역/음성 코드와 마스터 매뉴얼 변경이력 누적 보존.

---

## V198 — 사용자 실기기 6항목 + 기사정리 패턴 보정 (2026-10-09)
- 변경 요청 ① 너무 짧아 이해하기 어려운 핵심메시지를 구체적인 근거·조건으로 설명 ② 정부·기업 일정만 나열하는 일반 일정기사 제외 ③ 각 기사 제목 옆 관심 ♡/빨간 ♥ 토글, 관심 신호 누적 저장 ④ 기존 압축/기자 핵심/정형 투자연결 요약 패턴을 실제 원문 서론→구체적 사실·이유→메시지로 교체 ⑤ 글로벌 번역이 끝나지 않는 현상 원인 점검 ⑥ 국내 기사에 섞인 영어 원문 등 번역 누락 보정.
- 주요뉴스 요약의 기존 4개 고득점 문장 절단, `기자가 결국 강조하는 핵심은`, `이 기사가 투자에 주는 확인 포인트는 ...` 획일 템플릿 제거. 기사 신뢰본문 문장을 원래 순서로 최대 8개까지 근거 중심 정리, 원문에 없는 종목·수요·이익 경로 삽입 금지. 현재는 소스-귀속 추출 요약이며 품질은 실기사 검증 필수.
- 기사 일정: 검색 후보와 기존 저장 기사/후보 조회, 불주댕이 검증대기·준비완료 목록에서도 일정표 자체를 제외. 실제 정책 집행·확정 계약·실적 사실을 일정이라는 단어만으로 무조건 제외하지 않는다.
- 관심: 좋아요/관심을 기사 고유 ID로 기기 localStorage `nt_v198_reader_hearts`에 저장하고 독립 인터페이스 `NOONTANGI_READER_INTEREST.list()`로 제공. 사용자가 의중을 보여주는 명시적 선호 신호이며 자동 매수·진실성 판단·기사 하드필터로 사용하지 않는다. 추천모델에서 실제 사용은 별도 검증 후 단계적으로 연결한다.
- 번역원인: JS 응답대기가 18초인데 네이티브는 3번까지 접속/읽기 시간 재시도로 18초(불주댕이 12초)를 초과할 수 있어 정상적으로 늦게 도착한 콜백이 무시될 수 있었음. 기사 원문 요약 + 제목만 번역, 대기 상한 주요뉴스 40초·불주댕이 55초로 조정. 글로벌뿐 아니라 국내 검색의 영어 본문도 별도 한국어 준비 전 출력 금지. 실패/대기 상태 구분. 외부 공개번역 API 실패·율제한·네트워크 실패는 로컬로 확인 불가.
- 회귀 잠금: V179 UI 단일 owner, V195 수집 복구, V196 불주댕이 발언 엄격 필터, V197 기사 선택읽기/닫기-중단/번역 가드, V193 주요뉴스 영향력 정렬, V194 HOME 메뉴 위치 유지. V172 보류 AI 속뜻/자동 투자컨설팅을 켜지 않는다.
- 개발 검증: inline JS 93 구문통과; Playwright mock에서 주요뉴스 일정 제외/좋아요 관심 토글, 불주댕이 관심 토글, 국내 영어 본문 숨김, pageerror 0 확인. APK/실제 글로벌 공공 번역·뉴스 수집/완전 자동 기자 의도 분석은 미검증.
- 배포: SNOWBALL_CURRENT.zip, versionCode=60244, versionName=6.0.8-r9-v121-major-news-reader-interest-r80-v198, cache=787. 마스터 DOCX/앱가이드 누적 개정.

## V197 — 사용자 실기기 사진 6항목: 기사 선택읽기/중단·글로벌 번역·문장 정제 (2026-10-09)
- 근거: 앱 실기기 사진에서 주요뉴스가 HOME 투자현황을 읽고 불주댕이도 처음에는 HOME 내용, 여러 번 터치 후에야 해당 기사를 읽는 오류. 기사를 닫아도 음성이 계속됨. 글로벌 주요뉴스 영어 본문이 표시됨. 제목·본문의 `상황:` 및 `AMD AMD는` 반복 표현. `원문 확인 대기 · 발언 후보 12건` 의미 문의.
- 사용자 요구: (1) 미확인 발언 후보 뜻 명확히 (2) 주요뉴스 국내/글로벌 현재 기사 낭독 (3) 불주댕이 현재 기사 낭독 (4) 기사 닫기·탭 전환·화면 닫기에 TTS 중지 (5) 글로벌 기사 제목/본문 자연스러운 한국어로 (6) 중복·의미 없는 라벨 제거.
- 적용: V110 로컬 음성 controller 단일 경로 안에서 현재 열린 주요뉴스 overlay를 활성 읽기 surface로 인식; 주요뉴스 details[open] 및 불주댕이 `.is-open`의 준비된 기사 정리만 낭독. 활성 기사가 없으면 HOME 카드로 넘어가지 않는다. 닫기·기사 전환·글로벌/국내 탭 전환·메인 메뉴 이동에는 stopSpeechOnly/Java native stop을 연결.
- 번역: 글로벌 주요뉴스는 번역 완료 flag만 믿지 않고 한글 본문 우세 여부를 검사해 영어 원문 노출 차단, 제목/본문 번역 별도 요청 및 탭 진입 시 한정 재시도. 불주댕이 글로벌도 영어가 대부분인 cached 번역을 거부하고 다시 준비 상태로 분류. 번역 미성공을 임의 번역으로 채우지 않는다.
- 문장: 화면 표시 시 `상황:`/`AMD AMD는` 등 반복 문구 정제; 원문과 의미변경 없는 기존 캐시만 표시 정제. 미확인 발언 후보는 `발언 후보 N건 · 원문·발언 검증 전`으로 구분. 수량은 검증 통과 건수가 아니다.
- 검증: JS inline 93문법 통과; V191 및 V192 회귀 테스트 통과; Playwright browser mock에서 현재 뉴스 읽기/무선 HOME fallback/불주댕이 읽기/닫기 stop 통과. 브라우저 환경의 localStorage 제한으로 모의시험 중 console 에러는 있었고 Android TTS 및 실제 글로벌 번역 성공은 확인하지 못함.
- 회귀잠금: V179 단일 불주댕이 UI owner/V121R4 데이터 서비스, V172 AI 심층분석 보류, V193 주요뉴스 정렬, V194 HOME quick 메뉴 교체, V195 RSS 갱신 경로, V196 발언자 일치 요약 게이트는 유지.
- 배포: `SNOWBALL_CURRENT.zip` v197 versionCode=60243, WebViewCache=786. DOCX 마스터 V197와 앱 가이드 동시 갱신.

## V196 — 불주댕이 R2 발언 필터 및 기사 정리 (2026-10-09)
- User explicitly approved development after R2 requirements review. In scope: previously approved FM-S01~S09; do not activate V172-suspended hidden-intent/investment AI.
- Root cause in V195: fireSpeechBodyVerified() fallback could attribute B's quote to headline actor A merely because A was in a preceding sentence; fireSpeechNarrativeText() could include contextually loose post-quote sentences and slice summary at a raw character limit.
- V196 removes that dangerous fallback, allows only trusted-body speaker-anchored statements and tightly linked consecutive citations, terminates on journalist commentary/new speaker, retains source sentence order, cuts only at sentence boundaries, requires original evidence and status.
- Original body, 7-day current, 30-day history, domestic/global independent lanes, V195 queue, Korean translation, importance sort, Firemouth V106 UI owner preserved. New trusted pre-read rows carry `summaryRuleVersion=V196-R2`, while `deepVersion=V189` remains for data-schema compatibility. Preexisting cached rows retain their summary until refreshed; they are not silently rewritten or labeled V196-compliant.
- App guide has updated V196 requirements table and V196 display header; master docx has appendix; R2 review and verification matrix are packaged.
- Offline Chromium synthetic tests include correct domestic summary and conclusion, foreign quote, mismatched headline-speaker rejection, generic partnership rejection, journalist-tail removal. JS 93 scripts and legacy V191/V192 checks are tested separately.
- NOT VERIFIED: publisher live RSS/original-body extraction on Android, native Korean translation, full APK build, user physical device. Do not call V196 an end-to-end release.
- Package: SNOWBALL_CURRENT.zip · versionCode 60242 · versionName 6.0.8-r9-v121-firemouth-r2-summary-r78-v196 · WebView cache=785.

## V195 — 불주댕이·주요뉴스 갱신 장애 수집 경로 수정 (2026-10-09)
- Root causes detected in V194 source: (0) Critical missing fireKey()/fireHash() definitions caused ReferenceError on first RSS candidate; (1) native silently truncated queries at 260 characters, potentially leaving an unmatched OR expression; (2) Firemouth returned false when a new domestic/global request arrived while already fetching the other tab; V106 screen triggered domestic and global auto-load only 1.2 seconds apart, so global fetch could be lost; (3) only full WebView-extracted original-body items showed in the prepared Firemouth list, leaving the user with an entirely blank screen if original publishers deny web extraction.
- V195 sends balanced compact RSS queries; Android uses a broad public RSS retry if a specific query yields 0 items (and retains actual error messages if it still fails). No substitute news or result is fabricated.
- Firemouth now queues the last requested domestic/global tab fetch; it executes after the ongoing fetch completes and indicates queued requests. Separate tab success/failure metadata is saved. Unverified RSS speech candidates are shown in a visually separated subsection only, never treated as verified or included in speech judgement/Bell.
- Major News uses per-tab success/error/pending metadata and retains old verified stories and a separate preview list; stale summaries are not silently replaced by unverified text.
- Same HOME positions and overlay layout as V194. No user ledger/portfolio settings reset. package=SNOWBALL_CURRENT.zip; versionCode 60241; WebViewCache v784.
- This is code-path/offline-test verified, NOT live Android network/Google RSS success. Field test both domestic and global and compare at least one new timestamp.

## V194 — HOME 주요뉴스·매매일지 위치 교환 / 뉴스 화면 가림 수정 (2026-10-09)
- In the 3×3 HOME quickbar, swap **the complete click-target nodes**: first row right `주요뉴스` now has `data-v190-article-open`; third row left `매매일지` now has `data-v121r9-journal-open`. No changes to their handlers, icon/label pairing, other positions, or stored user data.
- Critical visual defect: the news overlay used `inset:0` with z-index 2147483100, beneath the viewport mascot header 2147483300. Header, close X and tab could be covered while scrolling. Overlay is now restricted by `--ntv127-symbol-total` top and `--ntv53-nav-height + --android-bottom-inset` bottom. Sticky sub-header and close X remain in the overlay's visible scroll viewport.
- Opening/switching news tab resets overlay scrollTop; bottom-nav navigation closes the open news panel without hijacking route navigation.
- No claim of fixing or proving real-time news RSS network success: `수집 연결 실패` remains a separate live-network issue.
- Build 60240 / 6.0.8-r9-v121-major-news-layout-r76-v194 / WebViewCache=783 / SNOWBALL_CURRENT.zip.
- Verify on Android: HOME fast menu positions, main symbol clear, news heading/X visible, domestic/global tap, sticky toolbar, bottom nav, refresh.

## V193 — 주요뉴스 투자 영향력 우선정렬 (2026-10-09)
- User selected recommended default `투자 영향력순` for 주요뉴스; `최신순` is an optional client-side switch. Sort selection is remembered locally and does not alter Firemouth.
- Verified original-body articles only: weighted classification 실적·수주 / 정책·규제 / 자금·투자 / 선행신호 / 시장 일반; original-body evidence, existing investment relevance, and publication recency contribute. Speculative headlines are down-weighted. Tie-break by most recent publication and stable article id.
- The sort score is a heuristic ranking, not proof of a contract's execution, stock-price prediction, or journalist accuracy. Existing 130-day track history stays chronologically sorted and unverified previews remain separate below ready articles.
- KR/GLOBAL share the same scoring on original article fields; translated Korean display remains V192 behavior. User can toggle ranking/latest without re-fetch or rewriting stored articles.
- Build 60239 / versionName `6.0.8-r9-v121-major-news-priority-r75-v193` / WebView cache v=782 / package `SNOWBALL_CURRENT.zip`.
- APK build, real network freshness and physical Android UI still require device/CI verification.

## V192 — 주요뉴스 / 불주댕이 UI 연계 / 글로벌 한국어 (2026-10-09)
V192 · 2026-10-09 · MAJOR NEWS / GLOBAL KOREAN / FIREMOUTH LAYOUT
1. Rename HOME quick menu '기사모니터' to '주요뉴스'. Keep separate from speech-only 불주댕이.
2. Domestic/Global high-visibility tabs, headline-first expandable cards and clear refresh + check status modeled on Firemouth layout.
3. Root fix: native Google News RSS items contained `link`, while article pre-read used only `url`, dropping all original URLs. Normalize `link -> url` in JS; native also returns url alias.
4. Broaden search with shorter targeted KR/GLOBAL queries and fallback. Show unverified headline candidates in visibly separated section instead of silently empty list; no factual analysis until original article confirmed.
5. Enqueue a tab request if another feed is collecting (previously dropped when ARTICLE_RUNNING).
6. Restore Korean headline + detail after asynchronous translation. Bounded 2-worker translation queue, distinct previews and trusted-body summaries; original English not presented as verified Korean.
7. Stable article ID new translation merges update prior data instead of preferring stale rows; reporter profile still unique per story.
8. Retain previous 7/30/90-day evidence observation with separate 130-day screen. Offline tests use mocked RSS and translation; APK/device/network still unverified.
Build code 60238 / versionName 6.0.8-r9-v121-major-news-ko-r74-v192 / WebView cache v=781.
ZIP is the source update package `SNOWBALL_CURRENT.zip` (not a compiled APK).


# V167 handoff addendum — 2026-10-05
- Current build: V60.8 · V121 / V167 FIREMOUTH NATURAL ANALYSIS / versionCode 60213 / `6.0.8-r9-v121-firemouth-natural-r49-v167` / WebView cache v=756.
- Required pre-edit review was completed against `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`, `NOONTANGI_DATA_SOURCE_STANDARD_V1.md`, and the V166 table master before code changes.
- Device regression case: Firemouth could show healthy collection stats (`최근24h`, `수집 8/8`) while the actual list remained empty until the user tapped `재확인`. V167 treats that as a display/store mismatch, not as a user action requirement: it preserves a last-valid visible-list cache, seeds it whenever valid rows exist, auto-recollects when stats and rows disagree, and labels the state `목록 자동 복구 중` rather than misleadingly `정상`.
- Firemouth detail is no longer written like a study guide. User-facing `가설 A/B/C` wording is removed. The natural order is `먼저, 기사 핵심 → 이게 무슨 뜻인가 → 다른 자료까지 확인해보니 → 그래서 AI 판단은 → 이 판단이 틀릴 수 있는 경우 → 투자에 연결하면`. Internal multiple-hypothesis reasoning may remain, but the screen must clearly separate confirmed facts from interpretation.
- Article summary must remove semantic duplicates. Before deep-reading finishes, the detail also uses the same deduplicating summary builder instead of concatenating title + RSS description.
- Story type owns the analysis. For pre-IPO/IPO coverage, completed investment, underwriter selection, preliminary-review discussions, backlog, use of proceeds and stated listing target are reported as article facts when present. A target date is not promoted to a confirmed listing date. Customer relationships alone are not a buy signal for listed customers.
- Regression example: the Digitrone pre-IPO article must explain in plain Korean that institutional money and underwriter/preliminary-review preparation mean the listing process has materially advanced, while exchange review is still pending; it must not answer with generic defense/geopolitical hypotheses.

# V64 handoff addendum — 2026-09-27
- Current build: V60.8 R9 V64 MARKET OVERALL SCORE / versionCode 60105 / `6.0.8-r9-v64-market-overall-score`.
- Market Environment now starts with `시장환경 종합평가`: a 0~100 friendliness score where higher is more favorable, plus grade (매우 우호/우호/중립/주의/위험), direction versus the previous valid snapshot, confidence, and the strongest positive/caution axes.
- The existing internal risk model remains the calculation base; the user-facing score is the favorable-direction representation (`100 - risk`) so larger numbers read naturally as better market environment.
- The score is never forced when the 8 core market indicators fail validation. Incomplete/abnormal data stays `판단 보류`.
- Market Environment screen is explicitly grouped into `주요 내용` (overall evaluation, core indicators, 6-axis forest state) and `보조 · 부속` (investment-type limits, domestic flow, timing handoff/detail evidence).
- Canonical table manual and in-app App Guide are synchronized to the V64 market-environment structure without replacing the v1.2 table baseline.

# V63 handoff addendum — 2026-09-27
- Current build: V60.8 R9 V63 SETTINGS COMPACT TRADE ENTRY / versionCode 60104 / `6.0.8-r9-v63-settings-compact-trade-entry`.
- Settings top tabs (`계좌·보유관리 / 백업·복원 / 앱 관리`) are compacted about 20%, while the whole settings shell starts slightly below the Android status area so the title and X close control no longer overlap.
- Settings > Account/Holdings is input/correction focused: the `보유 종목 입력·수정` heading is removed, `+ 종목/거래 추가` is renamed to `매매이력등록`, and the duplicate `거래 이력 관리 · n건` control is removed. Normal history viewing remains HOME Quick Menu > Report.
- Holding delete controls are about 30% smaller. In any trade-history detail management surface, the per-history delete control is about 30% smaller and row spacing is about 50% tighter.
- Do not reintroduce a duplicate Settings history-view button unless the user explicitly requests it.

# V62 handoff addendum — 2026-09-27
- Current build: V60.8 R9 V62 REPORT DIRECT ENTRY / versionCode 60103 / `6.0.8-r9-v62-report-direct-entry`.
- V61 device check failed for Report UX: the Report card existed in `pageReport`, but HOME Quick Menu `리포트` had no active handler after Report was removed from the common 7-item bottom navigation/swipe route in V41/V53.
- V62 gives HOME Quick Menu `리포트` a dedicated direct route owner: it checks `rReport`, dispatches route change, scrolls to top, and renders the read-only transaction history. The bottom 7-item nav remains unchanged and Report stays excluded from swipe order.
- Settings > Account/Holdings remains management-only. Per-account duplicate history blocks are no longer shown by default; one top `거래 이력 관리` control opens the deletable management ledger only when correction is needed.
- Holding deletion continues to preserve history; only explicit `이력삭제` removes a trade.

# V61 handoff addendum — 2026-09-27
- Current build: V60.8 R9 V61 HISTORY PRESERVE REPORT / versionCode 60102 / `6.0.8-r9-v61-history-preserve-report`.
- Current-holding delete removes only the holding record/meta/anchor. It MUST NOT remove transaction history.
- Transaction history may be removed only by the explicit per-history `이력삭제` action after confirmation.
- Each trade stores asset-name/account snapshots so history remains readable after the holding is removed.
- HOME > Report is the primary read-only place to review buy/sell history; Settings > Account/Holdings remains the management place for corrections and history deletion.

# SNOWBALL / 눈탱이 project handoff

## V60 SETTINGS HISTORY · DELETE · LIVE PRICE — 2026-09-27
- Base: V59 single-owner transaction manager. versionCode 60101 / versionName `6.0.8-r9-v60-settings-history-delete-live-price`.
- Settings > 계좌·보유관리 always refreshes to the single V60 manager; legacy NT1230J delete buttons/handlers are suppressed when V60 is present.
- `+ 종목/거래 추가` and a full-width `전체 거래 이력 보기` button are shown at the top. The history button opens all accumulated buy/sell records immediately; account-level history remains available too.
- Asset delete is correction-only: V60 delete button → in-app stock-name confirmation → delete asset and linked transaction records → immediate manager refresh, with no `location.reload()`.
- + quantity is new buy when the selected account has no same stock, additional buy when it already exists; - quantity is partial/full sell. Oversell is blocked. Weighted average is recalculated only on buys; partial sells preserve average cost; full sells set quantity to 0 and current-holdings screens hide it while history remains.
- Manually added quantity-based holdings with no code are resolved by stock name through the market search endpoint. Exact/unique near matches are accepted; ambiguous matches are not guessed.
- Once a code is resolved, HOME immediately queries the real market price. During an open session it targets ~5-second refresh; after close it keeps the day's final quote and stops repeated polling. No sample/fake price is shown as live data.
- The canonical table master `NUNTANGI_Master_Manual_Scenario_v1_2_2026-09-24.docx` and in-app App Guide are synchronized with these V60 rules without restructuring the master.



## V54 MASTER TABLE APP GUIDE — 2026-09-26
- Canonical master baseline is the user-verified table document `NUNTANGI_Master_Manual_Scenario_v1_2_2026-09-24.docx`.
- Do not replace its table/menu structure with a newly invented Markdown/HTML structure.
- Quick Menu > 앱 가이드 now renders this table-based master content in the original document order.
- Future confirmed changes accumulate on this table-based master. Any structural rewrite requires explicit user approval first.
- Scope is limited to the App Guide/manual baseline; V53 navigation/data/chart/ledger behavior is unchanged.
- versionCode 60095 / versionName `6.0.8-r9-v54-master-table-app-guide`.

## Current baseline
- Stable recovery baseline: V60.8.
- A previous attempt to apply eight screenshot changes at once caused regressions. Do not repeat that bulk change.
- Work in small steps, preserve the last working ZIP, and wait for the user to visually verify each step.

## Working method
1. Read this file and CURRENT_BUILD.txt before editing.
2. Do not reinterpret a screenshot request if the user already clarified it.
3. Make the smallest targeted change possible.
4. Keep prior stable backups.
5. Validate JavaScript and ZIP integrity before delivery.
6. Deliver final build as SNOWBALL_CURRENT.ZIP by Gmail when requested.
7. During work, show short progress updates so the user knows the task is active.

## Current three-screenshot direction
1. Stock picker includes 보유 / 관심 / AI추천.
2. HOME removes 오늘의 시장 현황 and moves 주요 뉴스·속보 upward.
3. Short-term screen: the relocated summary and the chart must be fully synchronized to the same selected stock. The old lower status/OHLC text area is removed and the summary information is reused there without increasing the card height.

## Current R6 fixes after user verification
- R4/R5 did not fully synchronize the relocated summary: selected stock could be 한온시스템 while summary still showed SKC. R6 updates name/code/market/52-week high/low in the actual live update path and again after DOM relayout.
- The requested date axis is moved upward toward the volume boundary in every known renderer (interactive canvas and SVG fallback paths).
- Relocated summary typography is enlarged about 18% beyond R4, card height unchanged.

## Important
- Earlier interpretation that top summary and chart should be independent is obsolete. They MUST synchronize.

## R7 user-verified follow-up
- R6 stock synchronization is visually confirmed working (selected stock and relocated summary/chart match).
- R6 date-axis vertical move is visually confirmed working.
- R7 only fixes two remaining layout issues: remove the large empty investor-flow body when no actual flow data exists, and keep the rightmost date label from overlapping the right price-axis number.
- Do not undo the R6 synchronization or date-axis vertical position.

## R8 live-session/data rules
- Cold app/Short-Term boot starts at 일봉 + 자동(=1년 visible trading-day window).
- During an active regular or supported over-market session, current quote/chart refresh target is 5 seconds.
- Over-market support reads public over-market quote metadata when present; session runs only while that quote metadata says the over-market is active and local time is within the after-market window.
- After the supported session ends, stock selection performs one full query and then schedules no polling until the app/page is started again during an active session.
- Investor cumulative flow now tries the current stock.naver.com detail trend endpoint first, then the three legacy/mobile fallbacks, with expanded net-buy quantity field aliases. Never invent flow values when upstream data is absent.
- Investor-flow current endpoint is paged in 100-row chunks (0/100/200) to cover roughly a trading year without relying on an oversized single request.

## V60.8 LIVE R9 (2026-09-21)
- R8 is preserved as verified backup before this edit.
- App launch now starts daily/1-year market-data preload immediately, even before the short-investment route is opened.
- Quote/history/flow requests are started through async paths so chart readiness is not blocked by the old synchronous full-load path.
- While the app is visible and the market session is active, quote refresh target remains 5 seconds. After market close, there is no repeating timer after the initial load.
- Investor cumulative flow is now range-aware: timeframe/range changes force a flow refresh for the same effective search period. The interactive chart still re-slices/re-cumulates flow to the visible viewport while dragging/zooming.
- Horizontal drag dead-zone and sensitivity were tightened to improve response on Android WebView.


## R9 INFO ENGINE V4 — 2026-09-23
- Base: R9 INFO ENGINE V3.
- Scope: Action Bell market-confirmation automation only; short chart/quote/flow code not modified.
- Confirmed information Bells are automatically rechecked against public market data.
- Signals: event-date price reaction, 5-trading-day return, volume ratio, 20-day trend, recent foreign+institution net flow.
- Result: market confirmed / contradicted / waiting. V3 promotion then runs automatically.
- Manual market choices are preserved and are never overwritten by V4.
- Native async bridge requests are isolated with an ntiev4_ callback prefix, cached for 10 minutes, and processed stock-by-stock to limit load.
- No automatic order execution.
- versionCode 60041 / versionName 6.0.8-r9-infoengine-v4.


## MARKET ENV V2 (2026-09-23)
- Market Environment V1 UI/philosophy preserved.
- Change percent is now calculated from regularMarketPrice vs regularMarketPreviousClose (previousClose fallback; chartPreviousClose last resort).
- Each KPI shows market state and its own quote timestamp, plus previous close.
- Uses a new V2 cache key so incorrect V1 percentage cache is not reused.
- All 8 core indicators must pass validation before regime/risk/6-axis computation; otherwise shows 판단 보류 and dashes.
- No changes to Info Engine V4, short chart, price, cumulative flow, ledger, or order logic.


## 2026-09-23 · MARKET ENV V3
- V2 device test: KOSPI/KOSDAQ current index values loaded but Yahoo meta previousClose returned 0, so validation correctly held the regime at 6/8.
- Fix only previous-close fallback: nonpositive previousClose is treated as missing, then derived from the last two valid daily closes.
- Validation strictness is preserved; no relaxation of the 8/8 rule.
- INFO ENGINE V4, short-term chart, flow, layout untouched.
- versionCode 60044 / versionName 6.0.8-r9-marketenv-v3.

## 2026-09-23 · MARKET ENV V4 FEED
- Base: CP04 / Market Environment V3 (8/8 device-verified market indicator validation).
- Scope: external market-news/policy/domestic-flow feed only. Core quote validation, regime/risk/6-axis math, Info Engine V4, short chart/quote/flow and ledger are untouched.
- Added an isolated `NOONTANGI_MARKET_FEED` collector module using the existing read-only native market-data bridge.
- Live public inputs:
  - NAVER Stock MAINNEWS and FLASHNEWS feeds.
  - NAVER Stock KOSPI/KOSDAQ index integration for market-wide foreign/institution/personal net trading values.
- News is deduplicated and lightly classified into `시장` vs `정책` using policy/macro keywords. The app does not treat a headline as a trading signal.
- Domestic flow displays KOSPI/KOSDAQ foreign/institution/personal net values in 억원, with the API business date.
- External feed refreshes every 5 minutes only while the Market Environment page is active; manual `외부 피드 동기화` is also available.
- Partial upstream failures preserve the last successful feed; no sample values are substituted.
- External feed is stored separately in `NOONTANGI_MARKET_EXTERNAL_V1` and injected through the existing `NOONTANGI_MARKET_ENV.ingest()` receiver.
- No automatic order execution.
- versionCode 60045 / versionName 6.0.8-r9-marketenv-v4-feed.


## 2026-09-23 · MARKET ENV V5 LINK
- Base: Market Environment V4 feed / CP04 market V3 core preserved.
- Domestic flow display is session-aware: before 09:00 KST prefer the latest prior-business-day nonzero flow; 09:00-15:30 show current-day cumulative flow; after close show latest confirmed flow.
- Pre-market current-day zero values are no longer presented as meaningful 0억 when a prior close is unavailable; UI says prior-close flow waiting instead.
- Added isolated MARKET-LINK-V1 bridge: high-impact policy/macro news and large market-wide foreign+institution flow are routed into the bait information engine.
- Added a separate Market Environment Action Bell card for market-wide policy/macro or large flow changes. This is a revalidation alert, never an order signal.
- Detailed stock timing remains bait → Action Bell → AI.
- Existing 8/8 validation, risk/regime/6-axis calculations, Info Engine V4 market-confirm logic, short chart/quote/flow and ledger are untouched.
- versionCode 60046 / versionName 6.0.8-r9-marketenv-v5-link.

## 2026-09-23 · MARKET ENV V6 EVIDENCE
- Base: Market Environment V5 LINK. Existing V60.8 R9 live chart/quote/flow behavior, ledger, account model, Info Engine V4, and order restrictions are unchanged.
- Domestic market-wide KOSPI/KOSDAQ flow now has an explicit integrity gate before downstream use. Foreign/institution/personal values must all be present; absurd ranges are rejected; a large residual among the three reported participant groups is treated as a probable mapping/unit inconsistency and shown as `검증 제외` instead of being silently trusted.
- Invalid market-wide flow remains visible with its rejection reason so data problems can be diagnosed, but it is excluded from Market Environment Action Bell aggregation.
- Risk gauge semantics are explicit: `위험도 /100 · 낮을수록 우호`.
- Each `숲의 상태 6축` row is now tappable. Expanded evidence shows the contributing current/previous values, the axis judgment rule, data source, and per-input timestamp. This supports later AI explanations of “왜 시장을 우호/주의로 봤는가?”.
- Market news rows now always expose a source label. Publisher-field aliases were expanded; when the upstream item has no publisher name, the UI explicitly labels it `NAVER 증권 피드` rather than leaving the source blank.
- Core 8/8 validation and regime/risk/6-axis math are preserved. This change improves traceability and prevents suspect external-flow data from becoming a downstream alert.
- versionCode 60047 / versionName 6.0.8-r9-marketenv-v6-evidence.

## 2026-09-23 · MARKET ENV V7 FLOWGUARD UI
- Base: V60.8 R9 Market Environment V6 Evidence.
- Device test exposed a legacy-cache compatibility gap: market-wide flow rows saved before V6 can have `valid` unset, so the V6 UI check (`valid===false`) could still present a clearly inconsistent 3-participant row as confirmed.
- V7 re-runs the KOSPI/KOSDAQ 3-participant integrity calculation at render time. Cached or legacy rows cannot bypass validation merely because their stored `valid` field is missing/stale.
- The Market Environment Action Bell bridge independently revalidates every flow row before foreign+institution aggregation. Suspect market-wide flow is therefore excluded downstream even when the old cache metadata is incomplete.
- News source remains visible for traceability but is visually demoted to small/light secondary metadata (`출처 · ...`) so it does not compete with the headline.
- The 6-axis card explicitly says `항목 터치 → 근거`; each axis remains a native details expander showing current/previous inputs, judgment rule, source and timestamp.
- Core 8/8 market-indicator validation, regime/risk/6-axis equations, V60.8 R9 short-chart live behavior, stock-level cumulative flow, ledger/account model and no-auto-order rule are unchanged.
- versionCode 60048 / versionName 6.0.8-r9-marketenv-v7-flowguard-ui.

## 2026-09-23 · V8 READABLE MARKET + BAIT
- Base: V60.8 R9 Market Environment V7 Flowguard UI.
- Device review found Market Environment evidence/details and the Bait information-engine UI too small to read comfortably on the user's phone.
- Readability is now treated as a functional requirement, not decorative polish: Market Environment and Bait small/meta/evidence text is enlarged roughly 20–35% depending on element.
- Market 6-axis evidence rows now reserve a wider label column and place the expanded evidence body full width, preventing `현재/전일`, `판단기준`, and `기준시각` from breaking into vertical characters.
- Bait mobile layout changes from 5 KPI columns to 3 and from 4 pipeline columns to 2 so the larger text remains legible without squeezing.
- No investment logic, market-regime calculation, data validation, Action Bell routing, short chart, account/ledger, or no-auto-order rule changed.
- versionCode 60049 / versionName 6.0.8-r9-v8-readable-market-bait.

## 2026-09-23 · V9 DIALOG FONT FLOOR
- Base: V60.8 R9 V8 READABLE MARKET+BAIT.
- User set a stronger phone readability rule: the **smallest meaningful app content text should be about the size of a normal ChatGPT conversation-body line**. Do not solve dense layouts by making text tiny.
- This step applies that rule to the actively reviewed screens: Market Environment, Bait/Information Engine, and the Action Bell blocks generated from those engines.
- Meaningful meta/evidence/source/timestamp text is raised to roughly 16 CSS px minimum. Titles and primary values are proportionally larger.
- Space is recovered structurally: Market flow/news timestamps move to their own row on phones, Market strategy cards stack, Bait KPIs use 2 columns and pipeline uses 2 columns, with 1-column fallback on very narrow widths. Cards may become taller; readability has priority over compression.
- Fixed global bottom navigation and unrelated pages are deliberately not changed in this step to reduce regression risk. Apply the same readability principle to other screens incrementally after device confirmation.
- No investment logic, 8/8 validation, market Flow Guard, Bait scoring/hypothesis engine, Action Bell decision logic, short chart, account/ledger, or order restrictions changed.
- versionCode 60050 / versionName `6.0.8-r9-v9-dialog-font-floor`.


## 2026-09-23 · V10 BAIT DENSITY
- Base: V60.8 R9 V9 DIALOG FONT FLOOR.
- User-approved scope is **Bait / Information Engine only** for this step. Other pages, short chart behavior and fixed bottom navigation are intentionally untouched.
- Mobile spacing follows the screenshot reference more closely: compact card gaps/padding and less unused vertical space.
- The five Bait status cards fit in one horizontal row on normal phone widths. The 8-step pipeline is 4 columns × 2 rows, so all eight steps are visible with much less scrolling.
- Supporting small text is allowed to shrink only within the user's stated limit (about 20% maximum); titles and core values remain larger.
- Collected-information rows are denser: content stays left and information score/Bell control stays in a narrow right column, while hypothesis/evidence text keeps readable line-height.
- Very narrow devices (<370 CSS px) fall back to 3 KPI columns, 2 pipeline columns and stacked information rows rather than forcing unreadably small text.
- No changes to Bait scoring/hypothesis rules, external feed synchronization, Action Bell promotion/market-confirmation logic, Market Environment, account/ledger, or no-auto-order rule.
- versionCode 60051 / versionName `6.0.8-r9-v10-bait-density`.


## 2026-09-23 · V11 EVIDENCE FIRST
- Base: V60.8 R9 V10 BAIT DENSITY.
- User review rejected the article-heavy Bait feed, broad market-status direction, and the prior confidence model as insufficiently aligned and insufficiently trustworthy. This is treated as a logic/design correction, not a cosmetic change.
- Bait is now an **evidence engine, not a news reader**. Only event-style facts with a plausible direct path to company/theme economics are eligible: orders/contracts, earnings/profit inflections, production/commercialization, named customers/partners, financing/dilution, direct policy/regulation, CAPEX/supply chain, approval/certification, and cancellation/delay/risk events. Generic market commentary, roundups, popularity headlines and broad-market items are filtered out.
- Static V2 seeded articles no longer auto-load. On first V11 run, legacy auto-generated `seed_`, `mktnews_`, `mktflow_` records are removed; manually entered evidence is preserved.
- Reliability model is changed fundamentally: **importance, popularity, and market reaction do not raise truth confidence**. Verification now rewards primary-source proof (URL/disclosure ID), source date, independent cross-sources, and surviving contradiction checks. Media/social evidence is capped when not backed by primary/independent proof.
- Manual evidence input requires the source/document and supports original URL/disclosure number, publication date and independent cross-source lines. Reposted versions of the same story must not count as independent corroboration.
- Action Bell promotion thresholds are stricter. Unverified/generic items cannot auto-promote; market reaction is a separate downstream check, not factual verification.
- Market Environment is reframed to a **background risk filter**. It must not choose stocks/themes or overwrite an evidence thesis. General market news is not shown in the market panel, and the Market Link bridge no longer routes broad market news or whole-market flow into Bait/Action Bell. Market data may only constrain exposure/timing intensity.
- Short chart, live quote/stock-level flow, account/ledger model, fixed navigation, backup, and no-auto-order rule remain unchanged.
- versionCode 60052 / versionName `6.0.8-r9-v11-evidence-first`.

## 2026-09-23 · V12 CONTEXT LEARNING
- Base: V60.8 R9 V11 EVIDENCE FIRST. This step keeps V11's evidence-first trust model and changes only Bait/Information Engine relevance filtering, ordering, and user-feedback learning.
- Editorial relevance is widened from only direct event facts to **causal, contextual, follow-up-worthy issues** when they have a plausible investment path. The reference feel is the useful issue selection seen in MTN's 07:00 morning broadcast and ShukaWorld-style issue context: explain what changed, why it matters, who/what is affected, and what should be tracked next. This is a curation reference, not a trust-source shortcut.
- Generic market wrap-ups remain excluded: daily index up/down, closing summaries, popularity headlines, broad 'related stocks strong' items and similar no-context market chatter do not enter the Bait priority set.
- Bait filtering pipeline is now explicit: **1 collect → 2 context/relevance → 3 user-interest learning → 4 primary-source verification → 5 independent cross-check → 6 counter-evidence → 7 investment impact → 8 follow-up/Action Bell**.
- Every Bait evidence/news title now has a feedback star. Default is outline `☆`; user selection changes it to yellow `★`. Star state is persisted in `nt_info_engine_v12_starred`.
- Star choices build a local interest profile in `nt_info_engine_v12_interest_profile`: recurring evidence kind, theme/industry, linked stocks and meaningful title/hypothesis keywords are accumulated. This profile changes **display/review priority and ordering**, helping the system infer what kinds of information the user repeatedly finds useful.
- Personalization and verification are strictly separated. `★`, popularity, or price reaction **must never increase verification confidence, create an Action Bell by itself, or mean buy/recommend**. Verification remains based on primary-source identity/URL, date, independent corroboration and contradiction checks.
- Starred items are shown first, followed by learned-interest priority and then evidence verification score. The UI shows an `관심학습 반영` tag and a small personalization priority so the effect is inspectable rather than hidden.
- The Bait hero shows how many star selections have been learned and the strongest learned labels. Users can unstar an item; the profile is rebuilt from the current star set so the feedback is reversible.
- Market Environment, stock-level short chart/flow, account/ledger model, backup, fixed navigation and no-auto-order rule are unchanged.
- versionCode 60053 / versionName `6.0.8-r9-v12-context-learning`.


## 2026-09-23 · V13 PORTFOLIO JOURNAL
- Base: V60.8 R9 V12 CONTEXT LEARNING. This step corrects the role of personalization, widens owned-asset monitoring, and makes the AI menu a live holdings/ledger/journal hub.
- **Objectivity is primary.** Bait ordering is now approximately 90% objective verification/investment-impact priority and at most 10% user-interest assistance. Star feedback never becomes the main filter and never increases truth confidence or Action Bell eligibility.
- For non-held candidates, V11/V12 evidence-first strictness remains. For **currently held individual stocks and ETFs**, lighter company/product-specific information may pass the relevance gate so the user does not miss useful small updates. These are explicitly tagged as `보유 모니터링`; generic market wrap-ups remain excluded, and lightly verified items cannot auto-promote to Action Bell.
- AI menu gains **내 보유종목 · 투자구분**. It reads `noontangi_v1230i_account_holdings` dynamically and shows all/long/short/ETF/individual/pension/IRP views. Account and investment-style classification can be edited inline. Direct-input add/save/delete events refresh this hub.
- User's latest account-count statement is 15 holdings total: **개별 5 / 연금 7 / IRP 3**. The previous seed was 5/6/4. On the exact old seed only, V13 provisionally reclassifies `SOL AI반도체TOP3플러스` from IRP to pension to reconcile the count while marking it `분류 확인 필요`; the user can correct the account inline. No holding is added or deleted by this migration.
- New direct-input items receive an investment-style field (long/short/unclassified). Existing pension/IRP assets and the known five individual holdings default to long for display; this is editable and does not constitute an investment recommendation.
- AI menu gains **통합 거래 히스토리 · 매매일지**. V13 trades support any quantity-based asset, save buy/sell/date/qty/price/fees/strategy/reason/stop/target/memo, and recalculate the account quantity/average price from a per-asset anchor plus subsequent trades.
- Manual holding edits establish a new per-asset anchor (snapshot cut) so older history is preserved without being double-counted. Transaction edit/delete replays from the anchor, so holdings remain internally consistent. Existing V12.20 legacy stock ledger is merged into the history view as read-only history and retains its original edit/delete path through the existing ledger.
- Every transaction (including legacy transactions) can have a **매매일지** with trade rationale, plan/invalidation conditions, plan discipline, emotion, post-trade review, and one next-rule. Journal state is persisted separately and shown as written/missing.
- No auto-order capability is added. All trading features are recording/review only. Market Environment, short-chart live behavior, fixed navigation, and existing backup behavior are otherwise preserved.
- versionCode 60054 / versionName `6.0.8-r9-v13-portfolio-journal`.
- V13 information cards are no longer just headline/meta rows for non-held candidates: they expose `왜 중요한가 / 검증 상태 / 반대근거 / 다음 확인` so weak or incomplete theses are visibly held at `판단 보류`. Low-verification owned-stock/ETF items instead use a concise `보유 모니터링 · 경량정보` block and do not become stronger evidence merely because the asset is held.


## 2026-09-23 — V14 HOLDINGS ROUTING (60055)
사용자 의도 정정: 전체계좌/투자구분 정보를 AI 메뉴에 별도 포트폴리오 화면으로 만드는 것이 목적이 아니었다. AI/직접입력 영역은 **원본 데이터 관리 지점**이고, 그 정보를 실제 사용하는 각 메뉴에 뿌리는 것이 목적이다.

### V14 화면 배포 원칙
- HOME: 직접입력된 전체 활성 보유자산을 모두 표시한다. 현재 기준 개별 5 + 연금 7 + IRP 3 = 15개 구조가 원본에서 그대로 보인다.
- 장기투자: `noontangi_v13_asset_meta.strategy == 장기`인 보유자산만 표시한다. 개별주뿐 아니라 연금/IRP/ETF도 함께 표시한다.
- 단기투자: `strategy == 단기`인 실제 보유자산만 표시한다. 장기자산을 단기 보유현황에 섞지 않는다.
- 직접입력/종목추가/삭제/거래기록/투자구분 변경은 동일 원본(localStorage)을 사용하고 각 화면이 다시 렌더링된다.
- 장기 보유행에서 투자구분을 장기↔단기로 바꿀 수 있고, 변경 즉시 해당 화면 간 이동한다.
- 장기 보유행에서 V13 거래기록/매매일지 기능을 바로 연다.
- AI 메뉴의 V13 `내 보유종목 · 투자구분` 중복 허브는 표시하지 않는다. AI 메뉴의 계좌 직접입력/추가·삭제/거래·일지 데이터는 계속 마스터 관리 기능으로 유지한다.
- 외부 실시간 시세가 없는 연금/IRP/ETF에 현재가·수익률을 만들어내지 않는다. 수량/평단 또는 직접입력 금액만 표시한다.

핵심 개념: **AI 메뉴에 모아 보여주는 것이 아니라, 한 번 입력한 보유 데이터가 HOME/장기/단기/거래일지 등 필요한 화면으로 배포되는 구조**.

## 2026-09-23 · SCENARIO LOCK V1 — 메뉴 = 투자 시나리오
- 사용자 리뷰 결과: 기능과 데이터는 늘었지만, 실제 화면에서 초기 설계의 '메뉴가 곧 시나리오'라는 큰 골격이 흐려지는 현상을 공식 회귀 위험으로 지정한다.
- Master Manual은 참고자료가 아니라 실제 화면/코드의 최상위 Source of Truth다.
- 8개 메뉴 역할을 고정한다:
  - HOME = 현재 상태/변화/해야 할 일 요약
  - 시장환경 = 숲/상위 위험·전술 필터
  - 밑밥 = 정보수집·검증·가설·산업/종목 연결
  - 장기투자 = 장기 투자논리 유지/훼손 및 보유관리
  - 단기투자 = 후보→검증→계획→실행관리→거래/복기의 핵심 엔진
  - Action Bell = 조건변화 재검증/행동 전 확인
  - 리포트 = 성과+원칙준수+매매일지+사후평가
  - AI = 모든 메뉴를 가로지르는 설명·재검증 계층이며 별도 기능 저장소가 아님
- 전체 사용자 여정: 시장환경 → 밑밥 → 장기/단기 → Action Bell → 실제 거래 입력 → 매매일지 → 리포트/사후평가 → 다음 판단 개선. HOME은 전체 상태를 요약하고 AI는 전 구간을 횡단한다.
- 현재 V14는 폐기하지 않는다. 보유데이터 라우팅, Evidence First, 시장환경 검증, 거래히스토리/매매일지, 정상 단기 차트 등 좋은 축은 KEEP한다.
- 다음 단계에서 기존 화면을 바로 삭제하지 않는다. 모든 화면/카드를 KEEP / MOVE / HIDE / REMOVE 후보로 먼저 분류하고 사용자 확인 후 변경한다.
- 첫 구조개편 우선순위는 단기투자. 차트 중심 화면을 유지하되 화면 시나리오는 후보→근거→최신재검증→차트/수급→투자규모→매수계획→매도계획→손절/익절/원금회수→Action Bell→거래기록→매매일지 순서가 보이도록 재정렬한다.
- 구조정렬 중 단기 차트 정상 동작, 시장환경 핵심 검증, 사용자 원장/거래 데이터, 백업 호환성, 하단 8개 메뉴, 자동주문 금지 원칙은 수정 금지 영역으로 둔다.
- 상세 실행 기준은 ZIP 루트의 `NOONTANGI_SCENARIO_LOCK_V1.md`를 따른다.


## 2026-09-24 · V15 SETTINGS ROUTING (60056)
- Scenario Lock V1 remains the governing structure. This is the first structure-alignment implementation, limited to management-only UI.
- The HOME `환경설정` quick-menu item and header gear now open a real full-screen `환경설정 · 데이터 관리` layer.
- Management cards are re-parented (not duplicated or deleted) from AI into Settings so their existing storage/event behavior is preserved:
  - `실제 보유 기준 관리` (`nt1230hHoldings`) → 계좌·보유관리
  - `전체계좌 실제 보유현황` / add-delete direct input (`nt1230iAccounts`) → 계좌·보유관리
  - `내 데이터 백업` (`nt1229dBackup`) → 백업·복원
  - `테스트 데이터 관리` (`nt1230aCleanup`) → 앱 관리
- A MutationObserver keeps dynamically re-rendered account cards routed back to Settings after edits.
- Trade history / 매매일지 is NOT classified as environment settings, so `ntv13TradeJournal` is deliberately left untouched for later routing to the scenario-appropriate area (Report/per-investment flow).
- AI screen is thereby reduced toward its intended role: explanation, revalidation, comparison and conversation.
- V14 holdings routing remains unchanged: master direct-input data still fans out to HOME / Long / Short.
- No changes to Market Environment, Bait evidence rules, Action Bell logic, short chart/gestures/flow, transaction arithmetic, backup format, or no-auto-order principle.


## 2026-09-24 · V16 SETTINGS UI STANDARD (60057)
- 사용자 실기 화면에서 V15 환경설정이 프로젝트의 가독성/밀도 원칙을 따르지 않는 회귀를 확인했다.
- 원인: V15는 기능 블록을 DOM 재배치만 했고, 이동된 레거시 카드가 원래 AI 화면의 8~12px 글자·넓은 모바일 카드 배치를 그대로 가져왔다. 또한 V9의 16px 원칙은 당시 시장환경/밑밥/Action Bell에만 적용되어 있었는데 이를 전역 표준처럼 취급한 설명이 부정확했다.
- `NOONTANGI_UI_STANDARD_V1.md`를 새 전역 디자인 기준으로 추가: 본문 약 16px, 보조/라벨 원칙 14px 이상, 카드 제목 17~18px, 화면 제목 20~22px, 버튼/탭 15~16px 및 40~44px 터치 높이, 카드 내부 10~14px, 카드 간격 8~10px.
- 환경설정 헤더에 Android 상태바 safe-area를 확보해 제목 겹침을 방지한다.
- 실제 보유 기준 관리는 모바일에서도 종목명/수량/평단을 가능한 한 한 행에 묶어 불필요한 세로 여백을 줄인다.
- 전체계좌 표는 8px대 글자를 제거하고 가독성을 유지하며, 좁은 화면에서는 억지 축소 대신 가로 스크롤을 허용한다.
- 백업/복원·앱관리에도 같은 글자/간격 규칙 적용.
- 데이터 구조, 보유 계산, 거래 히스토리, 백업 형식, 시장환경, 밑밥, Action Bell, 단기차트, 하단 8개 메뉴 로직은 변경하지 않는다.
- versionCode 60057 / versionName `6.0.8-r9-v16-settings-ui-standard`.


## 2026-09-24 · V17 SETTINGS STRUCTURE RESET (60058)
- V16 device feedback: visible layout was still too similar to V15 because V16 mostly overrode typography while the legacy card DOM remained.
- V17 makes a structural, visibly different Settings layout instead of another font-only patch.
- `실제 보유 기준 관리` is rendered as a compact 3-column table-like list (종목 / 수량 / 평균단가), not one tall rounded stock card per row. Repeated per-row labels are hidden and replaced by one column header.
- The long explanatory paragraph is replaced on-screen by one compact helper line; underlying data/event logic is untouched.
- `전체계좌 실제 보유현황` summary is compacted to a 4-cell row on normal phones (2x2 fallback on very narrow screens), and account accordions/table spacing is reduced.
- Header/tabs/body spacing is tightened so the Settings page uses less vertical space while preserving readable type and touch targets.
- No changes to holdings values, transaction calculation, backup format, HOME/Long/Short routing, Market/Bait/Action Bell, short chart, or no-auto-order rule.
- versionCode 60058 / versionName `6.0.8-r9-v17-settings-structure-reset`.

## 2026-09-24 · V18 MARKET SPACING LOCK (60059)
- Scope is **Market Environment only**. No font-size, data, validation, Action Bell, chart, account, ledger, navigation, or order logic changes.
- User-fixed spacing rules applied to the current Market Environment state:
  1. Text line spacing: existing extra leading reduced by 30% while preserving glyph height/readability.
  2. Window/card-to-window/card spacing: small meaningful text is 16 CSS px, so the standard gap is exactly one quarter = **4 CSS px**.
  3. Window/card inner edge padding: one small-text size = **16 CSS px** on top/right/bottom/left for primary/nested information windows.
- This is a targeted spacing calibration, not a global UI restyle.
- versionCode 60059 / versionName `6.0.8-r9-v18-market-spacing-lock`.


## 2026-09-24 · V19 FIVE BUCKET HOME (60060)
- Base: V18 MARKET SPACING LOCK.
- First scenario-program implementation after full baseline scan; deliberately small scope.
- Account categories are extended to **개별 / 연금 / IRP / ISA / 현금**. Existing holdings are preserved; no automatic ISA/cash positions are invented.
- Settings asset-add selector supports ISA and 현금. 현금 defaults to amount-input mode.
- HOME gets a **총 투자 현황** card based on the manual holdings source-of-truth. It shows total input principal and a five-bucket donut; tapping a bucket opens a drilldown with asset weights.
- Because real-time prices are not yet available for every pension/IRP/ISA asset, V19 deliberately does **not** fabricate total valuation/return. Those fields explicitly show pending until the market-data adapter is connected.
- V18 Market spacing, Market data/evidence logic, Bait, Action Bell, Short chart/flow, ledger arithmetic, fixed 8-menu navigation, and no-auto-order rule are unchanged.


## 2026-09-24 · V20 FIVE BUCKET VISIBLE (60061)
- V19 was user-visible failure because the new card was added into a fixed/overflow-hidden HOME region.
- V20 reuses the existing HOME portfolio card itself as `총 투자 현황`, so five buckets are actually visible.
- Five buckets: 개별 / 연금 / IRP / ISA / 현금. Bucket tap opens the existing drilldown modal.
- No fabricated valuation/return until all asset prices are available.

## 2026-09-24 · V21 HOME INVESTMENT FIRST (60062)
- User approved promoting `총 투자 현황` to a core HOME card.
- On mobile, the existing V20 total-investment card is moved directly below the HOME header/search and **before** `주요 시장 현황` and `오늘의 주요 이슈·뉴스`.
- The card is visually strengthened (title/readability/touch rows) but the five-bucket data source, drilldown behavior and calculations are unchanged.
- The old left-column slot is hidden only while the card is promoted; no duplicate card is created. Wide/desktop layout restores the original column location.
- Untouched: V18 Market spacing/data/evidence, Bait, Long/Short, Action Bell, ledger arithmetic, Settings, backup format, fixed 8-menu navigation, no-auto-order.
- versionCode 60062 / versionName `6.0.8-r9-v21-home-investment-first`.


## 2026-09-24 · V22 AI TOP3 IRP (60063)
- Base: V21 HOME INVESTMENT FIRST.
- User directly corrected the account for `SOL AI반도체TOP3플러스` from 연금 to **IRP**.
- Default seed is corrected to IRP, and a one-time migration moves an existing V21 saved holding with the same asset id/name from 연금 to IRP while preserving quantity 408 and average cost 16,916원.
- Latest account-count baseline becomes **개별 5 / 연금 6 / IRP 4 / ISA 0 / 현금 0**, total 15 assets.
- The previous V13 provisional IRP→연금 reconciliation is retired so it cannot move this asset back to pension.
- HOME layout, Market Environment V18, chart/flow, Bait, Action Bell, ledger calculations, fixed bottom navigation, and no-auto-order rule are unchanged.
- versionCode 60063 / versionName `6.0.8-r9-v22-ai-top3-irp`.


## V60.8 R9 V23 — Settings Mobile Fit
- versionCode 60064 / versionName `6.0.8-r9-v23-settings-mobile-fit`.
- User screenshots showed HOME > 환경설정 > 계좌·보유관리 clipping the right-side average-price fields, four-column account summary, and account table content on a phone.
- Mobile rule: do not shrink meaningful text to force three/four desktop columns. Reflow instead. The quick holdings editor is now stock-name first with quantity and average price side-by-side below; the whole-account summary is 2 columns; account details render as stacked mobile rows without the previous 570px minimum table width.
- Settings body now has additional bottom scroll clearance so save controls are not hidden by Android system navigation.
- No investment logic, account values, backup behavior, HOME/market/long/short layout, or data model was changed in this step.


## V60.8 R9 V24 — Settings Header Compact
- versionCode 60065 / versionName `6.0.8-r9-v24-settings-header-compact`.
- User marked the top Settings header/tabs as taking excessive mobile vertical space after V23.
- Mobile Settings header is reduced to the essential `⚙ 환경설정` title plus close button; the explanatory subtitle is hidden on phones and tabs sit directly below with tighter padding.
- The previous extra top safe-area padding is removed for the tested Android WebView layout, which already renders below the device status bar.
- Touch targets remain about 38–40 CSS px and readable type is preserved.
- V23 mobile account editing/reflow is retained exactly. No account values, save logic, backup, investment logic, chart, Market/Bait/Action Bell, HOME/Long/Short, or fixed navigation behavior changed.


## V60.8 R9 V25 — Home / Settings Compact Fix
- versionCode 60066 / versionName `6.0.8-r9-v25-home-settings-compact-fix`.
- User marked excessive vertical gaps between HOME `개별/연금/IRP/ISA/현금` rows. The blank spacing/padding is tightened while keeping the row text sizes unchanged.
- The legacy `포트폴리오 상세 보기` pseudo-button remains available but its height is reduced substantially to save vertical space.
- User also reported the three Settings tab labels were not fully visible. Mobile tabs now use explicit flex centering, fixed 40px touch height, unclipped overflow, and single-line Korean labels.
- V24 compact Settings header and V23 holdings mobile reflow are retained.
- No changes to holdings/account values, save/backup behavior, investment logic, chart/data pipelines, Market/Bait/Action Bell, or bottom navigation.

## 2026-09-25 V26 PORTFOLIO DETAIL HISTORY
- HOME 총 투자 현황 카드 하단 `포트폴리오 상세 보기` 버튼을 실제 동작하도록 연결했다.
- 포트폴리오 상세 모달에 계좌군 탭(개별/연금/IRP/ISA/현금)과 3개 보기 버튼(수익률추이, 주식수 가감추이, 매도주식 이력관리)을 추가했다.
- 상세 영역에는 도넛 비중, 종목별 색상 표시, 보유수량, 평균매수가, 입력원금을 함께 노출한다.
- 수익률추이는 현 단계에서 실시간 시세가 없으므로 `시세 미연동 전 원금 비중 추이`로 제공한다. 월별/연도별 전환 가능.
- 주식수 가감추이는 월별/연도별 수량 변화 흐름을 보여준다.
- 매도주식 이력관리에서는 매도 기록을 별도 보존하며, 전량 매도 이후에도 목록을 삭제하지 않는다.
- `noontangi_v26_portfolio_snapshots` 로컬 저장소를 추가해 수동입력 저장/거래기록 저장·삭제 시점의 스냅샷을 누적한다. 이를 기반으로 향후 포트폴리오 추이와 이력 보존을 유지한다.

## 2026-09-25 V27 HOME DETAIL BUTTON CLEANUP
- HOME 총 투자 현황에서 중복 노출되던 `포트폴리오 상세 보기` 버튼 2개를 제거했다.
- 첫 번째 중복은 기존 `.canon-card:after` 레거시 가상 버튼이었고, 두 번째는 V26에서 추가한 실제 버튼이었다.
- 개별/연금/IRP/ISA/현금 자산군 행 자체를 터치하면 V26 상세 모달(수익률추이/주식수 가감추이/매도주식 이력관리)로 진입하는 동작은 유지한다.
- 포트폴리오 상세 데이터/스냅샷/거래 이력 로직은 변경하지 않았다.

## 2026-09-25 V28 DETAIL SUMMARY COMMON CLEANUP
- 사용자 스크린샷 지시에 따라 포트폴리오 상세 상단을 공통 정리했다.
- 적용 범위: 개별 / 연금 / IRP / ISA. 현금은 기존 구성을 유지한다.
- 위 4개 계좌군 상세 화면에서 좌측 도넛 차트를 제거했다.
- 상단 요약은 `입력원금/금액`, `종목/상품` 2개만 세로 1열로 전체 폭 사용하도록 변경했다.
- `보기 기준` 요약 행은 제거했다. 아래의 수익률추이 / 주식수 가감추이 / 매도주식 이력관리 버튼이 동일 역할을 계속 담당한다.
- 종목 리스트, 평균매수가, 보유수량, 비중, 월별/연도별 추이, 매도 이력, 스냅샷 저장 로직은 변경하지 않았다.


## 2026-09-25 V28 MANUAL SYNC
- V28 코드 변경 내용을 매뉴얼/인계 문서에 동기화했다.
- HOME 자산군 행 클릭이 상세 진입 경로이며 별도 상세 버튼은 제거된 상태를 공식 기준으로 기록한다.
- 개별/연금/IRP/ISA 상세 상단 공통 UI, 3개 이력 버튼, 월별/연도별 추이, 환경설정 수동입력 스냅샷 반영, 전량매도 이력 보존 원칙을 UI 표준과 시나리오 잠금 문서에 명시했다.
- 앱 실행 코드와 데이터 값은 변경하지 않았다. 기준 버전은 V60.8 R9 V28 / versionCode 60069 그대로 유지한다.

## 2026-09-26 V29 HOME DASHBOARD CLEANUP
- 사용자 표시 1·2번째 스크린샷만 반영하고 3번째 스크린샷(상단 종목검색 영역)은 제외했다.
- HOME에서 중복 정보로 표시되던 `주요 시장 현황`, `오늘의 주요 이슈 · 뉴스`, `내 보유 종목 (전체계좌)`, `AI가 주목하는 테마`, HOME 요약 `액션벨` 카드를 화면에서 제거했다.
- `투자 현황` 카드는 유지한다.
- 기능 자체를 삭제한 것이 아니라 HOME 중복 노출만 제거한 것이므로 시장환경/보유종목/테마/액션벨 전용 메뉴 및 기존 데이터·로직은 유지한다.
- 상단 종목명/코드 검색바는 변경하지 않는다.

## 2026-09-26 V30 HOME LIVE TRUTH
- versionCode 60071 / versionName `6.0.8-r9-v30-home-live-truth`.
- 사용자 주석에 따라 HOME뿐 아니라 모든 메인 메뉴의 `종목명 또는 코드 검색` 상단 검색 스트립을 제거하고, 헤더가 빈 높이를 남기지 않도록 모바일 높이도 함께 축소했다. V29에서 검색바를 유지하던 예외는 V30에서 해제된다.
- HOME `총 투자 현황`의 자산군 금액/비중은 입력원금 고정 비중이 아니라 가능한 종목의 현재 시세를 반영한 평가금액 기준으로 다시 표시한다. 실시간/현재가 연결이 불가능한 자산은 평단×수량 또는 직접 입력금액을 사용하고, 몇 종목이 실제 시세로 연결됐는지 UI에 표시해 혼합값임을 숨기지 않는다.
- 총 투자원금은 기존 수량×평단/입력금액 원본을 유지한다. 평가총액과 현재 수익률은 시세 반영 평가금액을 사용한다.
- HOME `투자 현황`의 기존 72%, 보통, 적정, +12.4%, 78%, 양호 같은 정적 샘플값을 더 이상 실제 값처럼 사용하지 않는다. 큰 숫자는 `시세연동률`로 전환하고, 현금비중/현재수익률은 실제 보유·평가 데이터에서 계산한다. 위험도는 별도 위험엔진 전까지 `계산대기`, 손절·익절 준수율은 작성된 매매일지의 `계획대로` 기록이 있을 때만 산출하며 기록이 없으면 `기록부족`, 장기 원칙 이행도 근거 데이터가 부족하면 `기록부족`으로 표시한다.
- 시세 조회 실패 시 마지막 정상 캐시를 유지하고, 끝까지 확인되지 않은 자산을 임의의 현재가로 만들지 않는다.
- 계좌/수량/평단, 거래기록, 포트폴리오 상세 V28 이력, 시장환경/장기/단기/밑밥/액션벨 로직은 유지한다.

## 2026-09-26 V31 DETAIL LIVE AUTOSCALE CLEANUP
- 사용자 주석 기준 포트폴리오 상세 화면을 다시 정리했다. HOME 자산군(개별/연금/IRP/ISA/현금) 행을 눌러 들어온 계좌가 이미 확정되므로 상세 모달 내부의 중복 계좌 전환 탭은 제거했다.
- 상세 상단의 `종목/상품 N개` 중복 요약 행을 제거하고 입력원금/금액만 남겼다.
- 상세 종목 카드의 비중·금액은 V30 시세 브리지에서 확보한 현재 평가금액을 우선 사용한다. 시세 미연동 자산은 임의 가격을 만들지 않고 평단×수량/직접입력금액 기준임을 표시한다. 이 원칙은 개별·연금·IRP·ISA에 공통 적용한다.
- `수익률추이`는 포트폴리오 비중을 수익률로 잘못 표시하지 않도록 수정했다. 현재 시세가 확인된 종목만 실제 평가금액 대비 투자원금 수익률을 기록하며, 일별 시세 스냅샷(`noontangi_v31_portfolio_live_snapshots`)을 축적해 이후 월별/연도별 이력으로 사용한다. 과거 시세가 없는 기간은 0%로 조작하지 않고 공백 처리한다.
- `주식수 가감추이` 역시 과거 스냅샷이 없는 달을 0주로 만들지 않는다. 실제 저장된 보유 스냅샷이 있는 시점만 그린다.
- 두 추이 그래프 Y축은 현재 표시되는 실제 데이터의 최소/최대 범위에 맞춰 자동 스케일한다.
- 추이 하단 종목 행에서 이전 실제 이력이 없는 경우 `+현재값`처럼 오해를 만드는 중복 변화량을 숨긴다. 두 개 이상의 실제 시점이 쌓인 이후에만 변화량을 표시한다.
- HOME `빠른 메뉴`는 고정 하단 메뉴와 기능이 중복되어 제거했다. 기능 자체/하단 메뉴/환경설정/리포트/AI 진입은 삭제하지 않았다.
- HOME 투자 현황 V30 실시간 값 계산 및 총 투자 현황의 현재 시세 평가 로직은 유지한다.

## 2026-09-26 V32 DETAIL SCORE CORRECTION
- V31 회귀 수정: 포트폴리오 상세의 계좌 전환 버튼 `개별 / 연금 / IRP / ISA / 현금`은 삭제 대상이 아니다. 5개 계좌군 공통으로 복원·유지한다.
- 삭제 대상은 상단 요약의 `종목/상품 N개` 필드뿐이다. 입력원금/금액 요약은 유지한다.
- `수익률추이`와 `주식수량가감율추이` 화면의 주요 글자를 V31 대비 약 20% 확대한다.
- 명칭은 `주식수 가감추이`가 아니라 `주식수량가감율추이`를 사용한다. 현재 데이터 처리 로직은 기존 보유수량 이력 흐름을 유지하며 임의 계산식은 추가하지 않는다.
- HOME `투자 현황`의 큰 점수는 시세연동률이 아니다. 오른쪽 5개 평가항목(포트폴리오 위험도, 현금 비중, 수익률, 손절/익절 준수율, 장기 원칙 이행)의 종합평가 점수라는 의미를 유지한다.
- V30에서 시세연동률로 재해석한 것은 회귀로 간주한다. 현재 종합점수 기본값은 기존 72를 유지하며, 별도의 종합점수 저장값이 있으면 그것을 사용한다.
- 종합점수 상태색/문구 기준: 50 이하 위험=빨강, 51~79 주의=노랑, 80~89 안정적=초록, 90 이상 최고=초록.
- 오른쪽 5개 항목의 실제값 활성화 로직은 유지하되, 이들 값과 종합점수의 의미를 서로 혼동하지 않는다.

## 2026-09-26 V33 LIVE COMPOSITE SCORE
- HOME `투자 현황`의 큰 점수는 고정 72 또는 시세연동률이 아니라 오른쪽 5개 활성 평가항목의 실시간 종합평가 점수다.
- 5개 항목은 포트폴리오 위험도, 현금 비중, 현재 수익률, 손절/익절 준수율, 장기 원칙 이행이며 각 항목을 0~100점으로 환산한 뒤 동일가중(각 20%) 평균으로 종합점수를 계산한다.
- 포트폴리오 위험도 점수는 현재 평가금액 기준 종목 집중도(최대 비중)와 유효 분산도를 사용한다.
- 현금 비중 점수는 실제 현금 비중을 사용하고, 현재 수익률 점수는 실시간/최근 평가총액 대비 투자원금 수익률을 사용한다.
- 손절/익절 준수율은 매매일지의 `계획대로` 기록 비율을 사용한다. 아직 기록이 없으면 화면에 `기록대기 · 50점`으로 명시하여 중립값으로 반영하며 임의로 준수했다고 표시하지 않는다.
- 장기 원칙 이행 점수는 계좌/종목의 투자구분 메타데이터를 기준으로 계산한다. 연금/IRP/ISA는 장기 구분 여부, 개별은 장기/단기 중 명시적 구분 여부를 반영한다.
- 종합점수는 시세 갱신, 계좌/보유 변경, 거래기록/매매일지 변경 시 자동 재계산한다.
- 상태 기준: 60점 미만 `위험`(빨강), 60~79점 `주의`(노랑), 80~89점 `안정적`(초록), 90점 이상 `최고`(초록).
- 각 오른쪽 항목에도 현재 값과 해당 하위점수를 함께 표시하여 종합점수의 근거를 확인할 수 있게 한다.


## 2026-09-26 V33 MANUAL SYNC · 투자 현황 종합평가 의미/목적
- 전용 매뉴얼 `NOONTANGI_INVESTMENT_STATUS_SCORE_GUIDE_V1.md`를 추가했다. 앱 코드·점수 산식·버전은 변경하지 않는다.
- HOME `투자 현황` 큰 점수의 목적을 **매수/매도 추천이 아니라 포트폴리오 관리상태 점검**으로 정의한다.
- 종합점수는 오른쪽 5개 항목을 0~100점으로 환산하고 동일가중 20%씩 평균한다. 고정 72점 또는 시세연동률로 사용하지 않는다.
- `포트폴리오 위험도`는 최대 단일종목 비중, HHI 기반 유효 분산도, 종목 수를 이용한 분산/집중 관리점수다. 높은 점수는 위험이 높다는 뜻이 아니라 분산상태가 더 양호하다는 뜻이다.
- `현금 비중`은 대응여력과 자금효율의 균형을 보는 항목으로, 현재 기본 최적구간은 10~25%다.
- `수익률(현재)`은 평가총액 대비 투자원금의 현재 성과를 반영하되 위험조정수익률·미래예측값이 아니다.
- `손절/익절 준수율`은 매매일지의 `계획대로` 기록 비율로 측정한다. 기록이 없으면 성과를 임의 추정하지 않고 중립 50점/기록대기로 둔다.
- `장기 원칙 이행`은 장기계좌의 장기구분 및 개별계좌의 명시적 전략분류 여부를 확인하는 계획명확성 지표다. 장기투자의 우월성을 점수화하는 항목이 아니다.
- 종합점수는 시세·보유·거래·매매일지·전략분류 변경에 따라 재계산된다. 시장데이터는 120초 캐시 TTL, HOME 활성 중 60초 주기 확인 + 이벤트 즉시 재계산 구조이므로 `실시간`은 틱 스트리밍이 아니라 준실시간을 뜻한다.
- 데이터가 부족할 때 허위 숫자를 만들지 않고 캐시/평단/입력금액 폴백 또는 `기록대기`를 사용한다.
- 현재 V33 색상 구현은 0~59 위험(빨강), 60~79 주의(노랑), 80~89 안정적(초록), 90~100 최고(초록)다. 최초 사용자 표현의 51~59 공백을 연속 구간으로 처리한 현재 구현값임을 전용 가이드에 명시했다.


## 2026-09-26 V34 PORTFOLIO STANDARD LOCK
- versionCode 60075 / versionName `6.0.8-r9-v34-portfolio-standard-lock`.
- 사용자 재지적에 따라 `주식수량가감율추이`를 실제 **수량 증감률 %** 그래프로 수정했다. V33까지의 Y축 수량(주) 표시는 회귀로 간주한다.
- 첫 실제 보유 스냅샷은 0% 기준점, 이후 실제 스냅샷은 직전 실제 수량 대비 증감률로 계산한다. 데이터 없는 기간은 공백, 직전 수량 0은 미계산으로 처리한다.
- 종목 행은 현재 보유수량을 보조문구로 유지하되 주 표시값은 최근 수량 증감률 %로 표시한다.
- 포트폴리오 상세의 타이포그래피를 UI STANDARD로 다시 잠갔다: 큰 제목 22px, 작은/카드 제목 17~18px, 본문 16px, 보조 메타 14px 이상, 버튼/탭 15~16px 및 44px 이상 터치 높이.
- 상세 모달/카드 내부 패딩 16px, 카드/창/버튼 그룹 기본 간격 4px을 공통 적용한다. 글자 축소로 공간을 맞추지 않는다.
- V32에서 복원한 `개별/연금/IRP/ISA/현금` 전환 버튼의 클릭 핸들러도 재확인·복원했다. 버튼 삭제 금지. `종목/상품 N개` 필드만 삭제 상태를 유지한다.
- HOME 투자현황 V33 실시간 종합평가 점수 및 오른쪽 5개 항목 로직은 변경하지 않았다.


## 2026-09-26 V35 MASTER REVIEWED UI QUICKMENU
- **작업 운영 원칙 추가:** 눈탱이 프로그램을 수정하기 전에 현재 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md` 및 해당 기능 전용 가이드를 먼저 검토한다. 직전 사용자 지시와 마스터 기준의 충돌/회귀 여부를 확인한 뒤 코드 수정한다. 이 사전 리뷰를 생략하지 않는다.
- V31에서 HOME `빠른 메뉴`를 하단 메뉴와 중복이라는 이유로 숨긴 것은 사용자 의도와 달랐던 회귀로 확정한다. V35에서 **빠른 메뉴 전체를 원복**한다. 특히 `환경설정`, `도움말`, `앱 가이드`는 사용자가 핵심 관리/매뉴얼 기능에 접근하는 경로이므로 임의 삭제 금지다.
- 포트폴리오 상세 글자/간격은 V34 선언만으로 실제 기기 체감 확대가 부족했던 것을 확인했다. V35는 휴대폰 실기 기준으로 타이포 계층을 한 단계 확대해 강제 적용한다: 모달 큰 제목 26px, 패널 제목 22px, 종목명 19px, 본문 17px, 메타/단위 16px, 강조 수치 20~21px, 버튼/탭 17px/48px 이상.
- V34의 공간 규칙은 그대로 잠근다: 모달/카드 내부 패딩 16px, 카드/창/버튼 그룹 사이 기본 4px. 공간 부족을 글자 축소로 해결하지 않는다.
- `주식수량가감율추이` 종목 행에 **최초수량**을 추가한다. 가장 오래된 실제 보유 스냅샷의 수량을 최초수량으로 사용하고, 현재수량과 함께 `최초수량 N주 · 현재 N주` 형태로 표시한다. 증감률 그래프와 주 표시값은 계속 % 기준이다.
- HOME 투자현황 V33 종합점수, 상세 계좌전환 버튼, 종목/상품 N개 필드 삭제, 시세/이력 로직은 변경하지 않는다.
- versionCode 60076 / versionName `6.0.8-r9-v35-master-reviewed-ui-quickmenu`.


## 2026-09-26 V36 GLOBAL READABILITY STANDARD
- 사용자 최신 요구에 따라 V35 포트폴리오 상세에만 한정되어 있던 휴대폰 가독성 기준을 **전 메인 메뉴 및 모든 하위 메뉴/모달/설정 화면으로 확대 적용**한다.
- V35에서 확대가 일부 화면에만 보였던 원인은 최종 CSS 선택자가 `#ntv20PortfolioModal`에 국한되어 있었고, HOME/환경설정/시장환경/장기/단기/밑밥/액션벨/리포트/AI에 남은 레거시 8~15px `!important` 규칙이 더 작은 글자를 계속 강제했기 때문이다.
- V36 공통 타이포 계층: 화면/모달 큰 제목 26px, 패널 제목 22px, 종목명/카드 제목 19px, 본문 17px, 보조 메타/단위 16px 이상, 강조 수치 21px, 버튼/탭/입력 17px 및 최소 터치높이 48px.
- 공통 공간 기준: 주요 카드/창 내부 패딩 16px, 카드/창/버튼 그룹 기본 간격 4px. 공간 부족은 줄바꿈/세로 확장/열 수 감소로 해결하며 글자 축소로 해결하지 않는다.
- 하단 8개 메인 메뉴도 의미 있는 메뉴 텍스트로 간주하여 약 16px로 확대하고, 좁은 폭에서는 2줄 허용 및 메뉴 높이 100px로 보정한다.
- 정적 CSS뿐 아니라 동적 생성 하위메뉴에도 적용되도록 렌더 후 계산 글자크기가 16px 미만인 의미 텍스트를 끌어올리는 런타임 가독성 가드를 추가한다. SVG/장식 아이콘은 예외 처리한다.
- 투자/시세/스냅샷/점수/Action Bell/차트 데이터 로직은 변경하지 않는다.
- versionCode 60077 / versionName `6.0.8-r9-v36-global-readability-standard`.

## 2026-09-26 V37 PREVIEW APPROVED GLOBAL READABILITY LOCK
- 사용자와 **예상 출력화면을 먼저 확인·컨펌한 뒤** 실제 코드에 반영하는 절차를 적용한 첫 UI 버전이다.
- V36 전역 가독성 계층(큰 제목 26px / 패널 22px / 카드·종목명 19px / 본문 17px / 보조 메타 최소 16px / 강조수치 21px / 버튼·탭 17px·48px)을 그대로 전 메뉴·하위 메뉴의 고정 기준으로 잠근다.
- HOME / 시장환경 / 장기투자 / 단기투자 / 밑밥 / 액션벨 / 리포트 / AI / 환경설정 / 포트폴리오 상세 / role=dialog 팝업까지 명시적 선택자를 추가해, 창만 커지고 글자는 작은 상태를 허용하지 않는다.
- 하단 8개 메뉴는 16px를 유지하면서 HOME은 1줄, 시장환경·장기투자·단기투자·액션벨·리포트는 의도적 2줄로 정규화해 3줄 이상 우발 줄바꿈을 방지한다.
- 좁은 화면에서 공간이 부족하면 2열을 1열로 재배치하거나 카드가 세로 확장되며, 의미 있는 글자는 축소하지 않는다.
- 투자/시세/차트/점수/스냅샷/Action Bell 데이터 로직은 변경하지 않는다.
- versionCode 60078 / versionName `6.0.8-r9-v37-preview-approved-readability-lock`.


## 2026-09-26 V38 PORTFOLIO AMOUNT TREND COMPLETE
- 사용자 업로드 실제 화면과 승인 목업을 기준으로 포트폴리오 상세 표시를 수정했다.
- 개별/연금/IRP/ISA 종목 카드는 `투자원금(평균) 합계금액`, `현재가 합계금액`, `수익률`을 핵심값으로 표시한다. 보유주식 금액 합계가 기준이며 1주 현재가를 핵심값으로 표시하지 않는다.
- 실시간 시세가 없는 종목은 현재 합계금액을 원금 기준으로 폴백하고 `시세 미연동`을 표시하며 수익률은 만들지 않는다.
- `주식수량가감율추이` → `증감률추이`로 명칭 변경. 계산 로직은 V34/V35의 수량 증감률 % 정의 유지.
- IRP 포함 모든 계좌에서 현재 보유종목이 `수익률추이`/`증감률추이` 목록에서 데이터 부족 때문에 사라지지 않도록 보완했다. 현재 보유종목은 이력이 부족하면 `이력대기`/`—`로 남는다.
- 월/연도 그래프는 실제 데이터만 그리며 없는 과거값을 0으로 조작하지 않는다.
- 현금 상세 및 투자/차트/점수/Action Bell/거래/백업 로직은 변경하지 않았다.
- versionCode 60079 / versionName `6.0.8-r9-v38-portfolio-amount-trend-complete`.


## 2026-09-26 V39 RETURN TREND AMOUNT LAYOUT + DETAIL ROLLBACK
- V38에서 `투자원금/현재가/수익률`을 메인 개별 종목 카드에 넣은 것은 사용자 의도 오해로 확정하고 원복했다. 개별/연금/IRP/ISA의 메인 상세 종목 카드는 V37 구조로 복원한다.
- 새 금액 표시는 아래 기능인 `수익률추이` 종목 행에만 적용한다.
- 수익률추이 종목별 2행 규칙: 윗줄 `종목명 | 수익률`, 아랫줄 `투자 000원 | 현재 000원`. 긴 `투자금액/현재가 금액` 라벨은 사용하지 않는다.
- `투자`는 현재 보유 자산의 투자원금(평균매수가×보유수량 또는 직접입력 금액), `현재`는 확인된 현재 시세 기반 보유 평가 합계금액이다. 현재 시세 미확인 시 임의값을 만들지 않고 `—`로 표시한다.
- 적용 범위는 개별/연금/IRP/ISA의 수익률추이. 현금 상세는 기존 구조 유지.
- `증감률추이`는 명칭을 유지하며 기존 주식수량 증감률 % 계산 로직을 변경하지 않는다.
- IRP 포함 현재 보유종목은 수익률추이/증감률추이에서 이력 부족을 이유로 누락시키지 않는다.
- versionCode 60080 / versionName `6.0.8-r9-v39-return-trend-amount-layout-rollback`.


## 2026-09-26 V40 INSTALL VERIFY RETURN TREND
- V39 source inspection confirmed the requested return-trend layout was present in bundled index.html, while the user's device still appeared unchanged.
- To distinguish an install/update failure from a UI-code failure, V40 removes the stale V38 presentation block from active HTML, keeps the V39 return-trend implementation, bumps Android versionCode to 60081 and the WebView asset cache key to v=640, and adds a temporary visible `V40` badge to the portfolio-detail modal header.
- Expected visible behavior in 수익률추이: row 1 `종목명 | 수익률`, row 2 `투자 000원 | 현재 000원`. Main 개별/연금/IRP/ISA detail remains restored to the V37 structure.


## 2026-09-26 V41 REPORT NAV CLEANUP + TREND CONTROL FRAME
- 사용자 실기기 V40 확인 후 하단 공통 메인메뉴에서 `리포트` 버튼을 제거한다. HOME 내부 리포트 접근 경로/리포트 페이지 자체는 삭제하지 않는다.
- 하단 공통 메뉴는 7개 동일 폭으로 재배치하고 V37 전역 가독성 기준을 유지/확대한다.
- 포트폴리오 상세의 흩어진 `수익률/증감률/매도이력` 및 `월/년` 버튼을 하나의 테두리 박스로 묶는다. 박스 상단 legend 제목은 `수익률 및 주식증감률 추이`.
- 박스 내부 버튼은 1행 5열: `수익률 / 증감률 / 매도이력 / 월간 / 년간`.
- 수익률추이의 `종목명 | 수익률` + `투자 000원 | 현재 000원` 표시, 증감률 % 계산, 매도이력, 월/년 데이터 로직은 변경하지 않는다.
- V40 설치 확인 배지는 역할 완료로 제거한다.
- versionCode 60082 / versionName `6.0.8-r9-v41-report-nav-trend-control-frame`.

## 2026-09-26 V42 MASTER REVIEWED FRAME TYPOGRAPHY NAV
- 코드 수정 전 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`를 재검토하고 V41 실기기 스크린샷의 최신 사용자 지시만 반영했다.
- 포트폴리오 상세의 `수익률 및 주식증감률 추이` 제목은 테두리에 걸치는 legend 방식이 아니라 **테두리 박스 내부 상단 제목**으로 이동한다.
- 추이 제어 박스는 표준 여백을 적용한다: 내부 패딩 16px, 제목-버튼 간 8px, 버튼 간격 4px. 글자 크기는 V37 전역 가독성 기준(제목 22px, 버튼 17px/48px 이상)을 유지한다.
- 수익률추이 종목행의 두 번째 줄 `투자 000원 | 현재 000원`은 라벨과 숫자/금액 모두 과한 bold를 제거하고 16px / font-weight 500의 보조정보 계층으로 표시한다. 종목명과 수익률의 핵심 강조는 유지한다.
- 하단 공통 메뉴는 리포트 제거 상태를 유지하고 HOME/시장환경/장기투자/단기투자/밑밥/액션벨/AI 7개를 정확히 동일 폭으로 재배치한다.
- 수익률/증감률 계산, 현재가/투자금액 산식, 스냅샷, 매도이력, Action Bell, 거래원장, 백업 로직은 변경하지 않는다.
- versionCode 60083 / versionName `6.0.8-r9-v42-master-reviewed-frame-typography-nav`.


## 2026-09-26 V43 MASTER REVIEWED TREND TYPE SCALE + EXACT NAV
- 수정 전 현재 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`를 재검토하고 V42 실기기 피드백만 반영한다.
- `수익률 및 주식증감률 추이` 제목은 테두리 박스 **내부 상단** 위치를 유지하고, 사용자 추가 요청에 따라 22px에서 18px로 약 20% 축소한다.
- 같은 제어창 버튼 글씨도 축소하되 전역 가독성 하한을 지켜 16px로 제한하고 최소 터치높이 48px은 유지한다.
- 수익률추이의 `투자 / 현재` 라벨·숫자·금액은 16px을 유지하면서 font-weight 400으로 더 얇게 조정한다.
- 하단 `리포트` 삭제 상태를 유지하고 남은 7개 메뉴는 grid/min-content 영향을 받지 않도록 flex `1 1 0` + width 0 방식으로 **정확히 7등분**한다.
- 수익률/증감률 계산, 시세, 스냅샷, 매도이력, Action Bell, 거래/백업 로직은 변경하지 않는다.
- versionCode 60084 / versionName `6.0.8-r9-v43-master-reviewed-trend-type-exact-nav`.


## 2026-09-26 V44 MASTER REVIEWED NAV ROLLBACK + MODAL SCROLL GUARD
- 수정 전 현재 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`를 다시 검토하고 V43 실기기 피드백 3건을 한 번에 반영했다.
- 하단 `리포트` 삭제는 유지한다. 다만 V41~V43의 7등분 과정에서 세로 위치/높이/safe-area 관계가 흐트러진 부분은 **리포트 삭제 이전의 안정된 V40 내비게이션 기하(높이 76px, visualViewport 기반 하단 간격 18px)**를 복원한다. 남은 HOME/시장환경/장기투자/단기투자/밑밥/액션벨/AI 7개는 `repeat(7,minmax(0,1fr))`로 정확한 등간격을 유지한다.
- `매도이력` 버튼은 다른 4개 버튼과 동일한 48px 고정 높이를 유지하고, 글자만 15px/단일행/중앙정렬로 보정하여 버튼 내부 줄바꿈이나 치우침을 막는다.
- 포트폴리오 상세 모달은 `overscroll-behavior: contain`과 배경 스크롤 잠금을 함께 적용한다. 모달이 열리면 HOME/배경 문서의 현재 스크롤 위치를 저장한 채 고정하고, 모달을 닫으면 같은 위치로 복원한다. 따라서 상세 화면을 끝까지 계속 상하 드래그해도 뒤 HOME이 함께 움직이지 않는다.
- V43의 추이 제목/투자·현재 글자 굵기, 수익률/증감률 계산, 시세, 스냅샷, 매도이력 데이터, Action Bell, 거래/백업 로직은 변경하지 않는다.
- versionCode 60085 / versionName `6.0.8-r9-v44-nav-rollback-modal-scroll-guard`.

## 2026-09-26 V45 HARD FIX NAV + SELL + MODAL (60086)
- V44가 실기기에서 그대로 보인 원인을 코드 우선순위에서 확인했다.
- 하단 위치의 실제 소유자는 V34 visualViewport runtime의 `BASE_GAP=18`이었으므로 V44의 높이/패딩 수정만으로는 위치가 내려가지 않았다. V45는 실제 소유 runtime을 `10px`로 수정하고 마지막 runtime에서도 동일 geometry를 재적용한다.
- 7개 메뉴 등간격과 Report 삭제는 유지한다.
- V36 동적 가독성 guard가 `매도이력` 로컬 15px 설정을 나중에 다시 키울 수 있어 trend control을 전역 guard 예외로 잠그고, 매도이력만 14px/48px 고정 버튼으로 최종 적용한다.
- Android WebView에서 overscroll-behavior만으로 배경 drag 전달이 막히지 않는 경우를 위해 touch boundary preventDefault + body/HOME scroll lock을 같이 적용한다.


## 2026-09-26 V46 HOME CLEANUP + NAV/DETAIL TYPOGRAPHY
- 수정 전 PROJECT_HANDOFF / UI_STANDARD / SCENARIO_LOCK 재검토 후 실기기 주석 5건만 반영한다.
- 하단 Report 삭제 및 7개 등간격은 유지한다. 메뉴 아래 10px visual gap에는 HOME 내용이 비치지 않도록 메뉴와 같은 흰색 underlay를 깐다.
- 하단 메뉴명 중 한국어 3글자 이상(시장환경/장기투자/단기투자/액션벨)은 기존 16px급 대비 약 20% 축소한 13px로 표시한다. HOME/밑밥/AI는 기존 크기를 유지한다.
- HOME `투자 현황`의 큰 종합점수 산식과 5개 내부 구성점수 계산은 유지하지만, 사용자 화면에서는 각 항목 뒤의 `· 100점` 같은 개별 점수 숫자를 표시하지 않는다. 항목 값/상태만 남기고 빈 공간을 축소한다.
- 포트폴리오 상세의 종목명은 기존 19px 기준에서 약 20% 축소한 15.2px로 표시한다. 그 외 금액/수익률 로직은 변경하지 않는다.
- HOME `총 투자 현황`의 계좌군 안내에서 중복 `5개 자산군` 문구를 제거하고, KPI 하단 설명(`수량×평단 / 입력금액`, 현시세 연결 설명, `현재 평가총액 ÷ 총 투자원금`)은 화면에서 제거하여 공간을 줄인다. 핵심 총 투자원금/평가총액/총 수익률 값은 유지한다.
- versionCode 60087 / versionName `6.0.8-r9-v46-home-cleanup-nav-detail`.


## 2026-09-26 V48 HOME DONUT SCALE + RETURN COLOR STANDARD
- 수정 전 PROJECT_HANDOFF / NOONTANGI_UI_STANDARD_V1 / NOONTANGI_SCENARIO_LOCK_V1 및 V47 기준을 리뷰했다.
- HOME 총 투자 현황 도너츠 중앙의 `수익률` 라벨은 V47 12px 대비 50% 축소한 6px, `%` 기호는 30% 축소한 8.4px로 조정한다. 가운데 수익률 숫자 22px은 유지한다.
- 도너츠 아래 표기는 `총투자/총평가`에서 `투자/평가`로 단순화하고 금액 숫자는 약 10% 축소한다.
- 도너츠 오른쪽 개별/연금/IRP/ISA/현금 행의 작은 글씨에서 종목 수(`N개 ·`)를 삭제하고 금액만 표시하며 금액 글씨는 약 10% 축소한다.
- 수익률/실적 색상은 한국 주식 관례로 공통화한다: 이익/양수는 적색, 손실/음수는 파란색. 기존 HOME 및 포트폴리오 수익률 클래스도 같은 색상 규칙으로 통일한다.
- 수익률 계산, 평가금액, 포트폴리오 상세/추이, 하단 메뉴, Action Bell, 거래/백업 로직은 변경하지 않는다.
- versionCode 60089 / versionName `6.0.8-r9-v48-home-donut-return-color`.

## 2026-09-26 V49 HOME DONUT LABEL/% SCALE + BUCKET DENSITY
- V48 및 현재 마스터 UI 기준을 리뷰한 뒤 HOME 투자현황 도너츠만 국소 수정했다.
- 도너츠 중앙 `수익률` 라벨은 V48의 6px에서 7.8px로 30% 확대한다.
- `%` 기호는 V48의 8.4px에서 10.92px로 30% 확대한다.
- 가운데 수익률 숫자 본체는 22px을 유지하며, 양수/이익은 적색, 음수/손실은 파란색을 강제한다.
- 도너츠 오른쪽 개별/연금/IRP/ISA/현금 행의 세로 여백만 약 20% 축소한다. 글자/금액 크기 및 계산 로직은 변경하지 않는다.
- 수익률 계산, 평가금액, 상세/추이, 하단 메뉴, Action Bell, 거래/백업 로직은 변경하지 않는다.


## 2026-09-26 V50 SINGLE-OWNER NAV STABILITY
- 실기기에서 하단 메뉴가 드래그 중 사라짐/겹침/깜빡임하고 앱이 먹통 또는 종료되는 현상을 우선 안정화했다.
- 원인: V34/V43/V44/V45/V47의 여러 하단메뉴 runtime이 동시에 `#mainNav`의 bottom/width/transform/display를 재계산했고, 특히 visualViewport scroll/touch마다 서로 다른 geometry를 덮어썼다.
- V50에서는 해당 레거시 nav runtime을 실행 중지하고 하단 메뉴의 위치 소유자를 하나로 통합한다. Android native가 전달하는 `--android-bottom-inset`만 사용하며 visualViewport scroll/transform 계산을 사용하지 않는다.
- Report 삭제와 7개 등간격, 3글자 이상 메뉴명 13px 기준은 유지한다. 메뉴 아래 시스템 영역은 독립 흰색 floor로 완전히 가린다.
- 포트폴리오 상세 배경 scroll guard는 단일 runtime으로 재구현한다.
- WebView renderer 우선순위를 IMPORTANT로 올리고 renderer가 비정상 종료될 경우 앱 전체가 닫히지 않고 Activity를 재구성하도록 복구 핸들러를 추가한다.
- HOME 도너츠 V49 표시/색상/간격과 투자/포트폴리오 데이터 로직은 변경하지 않는다.
- versionCode 60091 / versionName `6.0.8-r9-v50-single-owner-nav-stability`.

## 2026-09-26 V51 TOP-LAYER NAV + SWIPE STABILITY
- 실기기 V50에서 하단 메뉴가 전반적으로 안정됐지만, HOME이 아닌 화면에서 좌우 스와이프로 페이지를 전환할 때 하단 메뉴가 순간 깜빡이는 현상이 남았다.
- 원인은 V39의 route swipe가 이전/다음 페이지를 `position:fixed` 전체화면 레이어로 300ms 애니메이션하며 Samsung WebView compositor와 공통 fixed nav 레이어가 순간적으로 재합성되는 데 있었다.
- V51은 좌우 스와이프 제스처와 페이지 이동 기능은 유지하되, 전체화면 fixed slide animation을 제거하고 route radio를 즉시 전환한다. 하단 nav는 변형되지 않는다.
- `#mainNav`는 앱 내부 최상위 compositor layer로 고정하고 route page는 항상 그 아래에 둔다. V50의 single-owner geometry/Android inset/7개 등간격/Report 삭제 규칙은 그대로 유지한다.
- Android system navigation 영역은 앱이 덮어쓰지 않는다. 대신 navigation bar/구분선/contrast를 흰색 계열로 맞춰 V50 floor와 시각적으로 이어지게 한다.
- HOME 도너츠, 투자현황, 포트폴리오 상세/추이, 시장환경/장기/단기/밑밥/액션벨/AI 데이터 로직은 변경하지 않는다.
- versionCode 60092 / versionName `6.0.8-r9-v51-top-layer-nav-swipe-stability`.


## 2026-09-26 V52 PHYSICAL SINGLE-OWNER NAV
- V51 실기기에서 좌우 드래그 시 하단 메뉴 깜빡임이 그대로 남아, 단순 CSS 우선순위 문제가 아니라 과거 runtime listener가 실제로 계속 실행 중인 것을 소스에서 확인했다.
- 특히 V34 `visualViewport` runtime이 scroll/touchend마다 `#mainNav`의 left/width/bottom/transform/display를 다시 쓰고 있었고, V43/V44/V45/V47 runtime도 각자 geometry를 재적용했다. V50 문서의 '실행 중지' 선언만으로는 익명 event listener가 제거되지 않아 실제 기기에서 충돌이 지속됐다.
- V52는 선언/덮어쓰기 방식이 아니라 해당 레거시 geometry runtime script 태그 자체를 소스에서 물리적으로 제거했다: V34, V43, V44, V45, V47 및 이전 V50/V51 nav runtime.
- V37 route-change 시 전역 typography 전체 재스캔 호출도 제거해 스와이프 전환 부하를 줄였다. V46 runtime은 HOME 정리/상세 종목명 기능만 남기고 nav geometry 접근을 제거했다.
- 최종 `#mainNav` geometry는 V52 CSS 단 하나가 소유한다. Android native `--android-bottom-inset`만 사용하고 visualViewport scroll/transform 계산은 사용하지 않는다. Report 삭제, 7개 등간격, 메뉴명 축소 기준은 유지한다.
- 상세 모달 배경 스크롤 잠금도 V52 runtime 하나로 통합한다.


## 2026-09-26 V53 HOME NAV TEMPLATE GLOBAL LOCK
- 수정 전 PROJECT_HANDOFF / UI_STANDARD / SCENARIO_LOCK 및 V52 하단메뉴 관련 코드를 재검토했다.
- V52가 `#mainNav` 단일 소유 runtime을 만들었어도, 과거 CSS의 `#rX:checked~#mainNav`처럼 route radio를 포함한 더 높은 specificity의 `!important` 규칙이 남아 있어 화면별로 HOME과 다른 nav geometry/typography가 다시 적용될 수 있음을 확인했다.
- V53은 HOME에서 정상적으로 보이는 하단 메뉴를 권위 템플릿으로 삼아 HOME/시장환경/장기투자/단기투자/밑밥/액션벨/AI 모든 route 상태에 **동일한 route-specific selector**로 마지막에 재잠금한다. 화면 전환 시 바뀌는 것은 선택 메뉴의 활성 색상뿐이며, 높이/위치/아이콘/문구 크기/패딩/7등분은 바뀌지 않는다.
- `리포트`는 하단 메뉴 삭제 상태를 유지한다. 좌우 스와이프 route 순서에서도 숨겨진 `rReport/pageReport`를 제거하여 7개 보이는 메뉴끼리만 이동한다. HOME 내부 리포트 진입 경로와 페이지 자체는 유지한다.
- Android native `--android-bottom-inset`, V52 floor, 포트폴리오 상세 scroll guard는 유지한다. 투자/시세/차트/도너츠/Action Bell/거래/백업 로직은 변경하지 않는다.
- versionCode 60094 / versionName `6.0.8-r9-v53-home-nav-template-global-lock`.

## V55 SETTINGS HOLDINGS MANAGER — 2026-09-26
- Baseline: V54 MASTER TABLE APP GUIDE. This change is limited to HOME 빠른 메뉴 → 환경설정 → 계좌·보유관리.
- User-confirmed role of this screen: **management only** — new holding input, existing quantity/average(or amount) edit, delete, save. Portfolio amount/value viewing belongs on HOME and portfolio detail, not duplicated here.
- `+ 종목 추가` already had working handlers; the modal was opening behind `#ntv15Settings` because its z-index (9999) was below Settings (2147483400). V55 raises `#nt1230jModal` to 2147483600.
- Hide the duplicate `실제 보유 기준 관리` visual block inside Settings while preserving its underlying legacy data/sync runtime to avoid regression.
- Remove `사진 입력값 반영` badge, total/account input-cost summary cards, computed input-cost display and explanatory value-view note from the management card.
- Keep account-group lists because they are the edit/delete surface; keep `+ 종목 추가`, qty/avg(or amount) inputs, delete buttons and save.
- No HOME/nav/chart/market/ledger/AI investment logic changes.
- The table-form master DOCX remains Source of Truth; this V55 rule was appended to its existing `수동 입력·거래 원장·자동 계산` table and mirrored in the embedded App Guide.
- V55 manual sync additionally folds the confirmed 2026-09-24~26 baseline into the existing v1.2 tables (menu, HOME, input/ledger, market freshness, short/long engine, AI Evidence Package, Action Bell, data reliability, UI/quick-menu rules). This is a cumulative synchronization, not a new manual structure.


## 2026-09-26 V56 SETTINGS ADD COMPACT
- V55 실기기에서 `+ 종목 추가` modal은 정상적으로 위 레이어에 열렸지만 세로 입력 공간이 커 `추가 저장` 버튼이 공통 하단 메뉴 뒤로 내려가는 것을 확인했다.
- 공통 하단 메뉴는 V53 권위 템플릿이므로 크기·위치·safe-area를 변경하지 않는다.
- 신규 종목 추가 modal만 압축한다: 계좌+투자구분, 보유수량+평균단가는 2열; 입력방식·종목명은 전체 폭. 입력/select 40px, 라벨 14.5px, 본문/버튼 14~16px 수준으로 유지한다.
- modal은 Android 상단 inset과 하단 공통 nav/system inset을 예약하고 작은 화면에서는 modal 자체만 세로 스크롤한다.
- HOME/시장/장기/단기/밑밥/액션벨/AI/거래원장/백업/시세 로직은 변경하지 않는다.
- 테이블형 Master DOCX와 앱 가이드에 같은 내용을 누적 반영한다.
- versionCode 60097 / versionName `6.0.8-r9-v56-settings-add-compact`.

## V57 SETTINGS SAVE ROUTE CLOSE — 2026-09-27
- Base: V56 SETTINGS ADD COMPACT. Common bottom navigation size/geometry remains untouched.
- Fix new-asset save routing: the selected account (개별/연금/IRP/ISA/현금) is saved exactly as chosen; the selected investment category is written atomically with the asset metadata.
- New-asset save no longer uses the legacy full-page reload path. The settings holdings list and HOME/Long/Short routing are refreshed immediately, reducing the post-save "frozen" feeling.
- One-time correction for the user-reported KODEX 원자력 SMR entry (qty 168 / avg 18,608) that was saved to 개별 despite choosing 연금: move it to 연금 and set 장기 when the exact mistaken user-added record is found.
- Settings close controls: top-right X is forced visible from first entry and moved below Android status-bar inset; a large bottom `닫기` button is available above the common bottom navigation on every settings tab.
- Table-based master manual remains canonical and is updated in place; do not replace its table structure.
- versionCode 60098 / versionName `6.0.8-r9-v57-settings-save-route-close`.

## V58 SETTINGS TRANSACTION LEDGER — 2026-09-27
- Environment Settings → Account/Holdings is now transaction-aware rather than duplicate-name-blocking.
- `+ 종목/거래 추가`: same account + same normalized name appends a transaction instead of creating a duplicate asset.
- Positive quantity = buy/additional purchase; negative quantity = partial/full sell. Price field is treated as execution price.
- Current HOME/Long/Short holdings are recalculated from anchor + transaction history; buys update weighted average, sells reduce quantity while keeping remaining average. Oversell is blocked.
- Settings shows per-account input/trade history; deleting one history item recalculates holdings.
- Asset `삭제` is reserved for mistaken asset removal and deletes its linked transaction history; it is not a sell action.
- Existing direct quantity/average edit is kept as a correction path and resets the current anchor while preserving earlier history.
- Add/delete/correction actions do not call `location.reload()`, preventing the previous apparent freeze/navigation lock.
- Master table remains the Source of Truth and received the same V58 rule without structural redesign.


## V59 SETTINGS SINGLE OWNER HISTORY — 2026-09-27
- Base: V58 SETTINGS TRANSACTION LEDGER. V58 실기기에서 추가/저장과 삭제가 다시 먹통처럼 멈추는 회귀가 확인됐다.
- Root cause: NT1230I/NT1230J/V13의 과거 저장·삭제 이벤트 경로와 V58 거래원장 경로가 동시에 같은 버튼을 소유했고, 일부 레거시 경로는 `location.reload()`와 브라우저 `confirm()`에 의존했다.
- V59부터 환경설정의 open/cancel/save/correction/delete/history-delete/history-open/close는 V59 단일 이벤트 경로가 소유한다. V59 활성 시 과거 저장·삭제 핸들러는 해당 동작에 개입하지 않는다.
- Android WebView에서 확인창이 보이지 않거나 멈춘 것처럼 보이는 문제를 피하기 위해 종목 삭제와 거래이력 삭제는 브라우저 `confirm()` 대신 앱 내부 확인 모달을 사용한다.
- 상단 `+ 종목/거래 추가` 옆에 `거래 이력` 버튼을 추가해 전체 입력/매매 이력에 바로 접근한다. 계좌별 이력 펼치기는 그대로 유지한다.
- +수량은 선택 계좌 내 종목 존재 여부를 본다: 없으면 신규매수, 있으면 추가매수. 다른 계좌의 동일 종목은 독립 포지션이다. -수량은 부분/전량매도이며 초과매도는 차단한다.
- 추가매수는 가중평균단가 재계산, 부분매도는 잔여 평균단가 유지, 전량매도는 수량 0으로 처리한다. 0주 종목은 HOME/장기/단기 현재보유 화면에서 숨기고 환경설정 거래이력에는 남긴다.
- 종목 삭제는 오등록 정정용이며 확인 후 연결 거래이력을 함께 제거한다. 거래이력 개별 삭제는 확인 후 보유수량/평단을 재계산한다.
- 저장/삭제/정정 후 `location.reload()`를 사용하지 않고 설정 목록/연동 화면을 즉시 갱신한다.
- Node 기반 로직 테스트에서 신규매수, 동일계좌 추가매수, 부분매도, 전량매도, 타계좌 동일종목, 거래이력 삭제 재계산, 종목 삭제/연결이력 제거를 통과했다. 실기기 최종 검증은 사용자 확인으로 확정한다.
- Table-based Master DOCX remains the Source of Truth and V59 내용을 기존 표 구조에 누적 반영했다.
- versionCode 60100 / versionName `6.0.8-r9-v59-settings-single-owner-history`.

## V65 MARKET INDICATOR DETAIL (2026-09-27)
- 기준선: V64 MARKET OVERALL SCORE 위 최소 범위 수정.
- 시장환경 핵심 시장지표 카드 우측 동작을 `지표상세`로 통일.
- KOSPI/KOSDAQ/S&P500/NASDAQ/VIX/원달러/미10년/WTI 각각의 상세 그래프 모달을 연결.
- 상세 그래프: 일봉/주봉/월봉 + 1년/3년/10년을 독립 선택. 최초 진입은 일봉+1년.
- 상단에는 현재값/등락률/기준시각/장상태를 표시하고, 그래프 하단에 기간 시작/최근/기간등락/고가·저가를 표시.
- 실제 Yahoo chart 원자료만 사용하고 로딩 실패 시 임의 샘플값을 만들지 않음.
- 시장환경 카드/창의 세로 간격은 글자 크기를 줄이지 않고 기존 대비 약 30% 축소.
- 하단 공통 메뉴, V64 종합점수 및 기존 8개 지표 검증 로직은 변경하지 않음.
- 테이블형 NUNTANGI_Master_Manual_Scenario_v1_2_2026-09-24.docx와 앱 가이드를 V65까지 누적 동기화.


## V66 MARKET INDICATOR ROW DAILY — 2026-09-27
- Baseline: V65 MARKET INDICATOR DETAIL.
- 시장환경 상단의 중복 `시장환경 · 배경 위험 필터` 설명/상태/칩/동기화·바로가기 묶음은 제거하고 종합평가부터 시작한다.
- 핵심 시장지표는 카드형을 없애고 `차트심볼 | 제목 | 지수 | 일변동폭` 1행 리스트로 공통 적용한다.
- 기존 `지표상세` 텍스트 버튼은 제거하고 차트심볼 자체를 상세 차트 진입 버튼으로 사용한다.
- 상세 차트는 일봉으로 고정한다. 주봉/월봉 선택을 제거하고 조회 기간만 1년/3년/10년으로 전환한다.
- 상세 그래프는 Yahoo chart 실제 일별 종가 원자료만 사용하며 임의 샘플값을 만들지 않는다.
- V65의 세로 간격 30% 축소 원칙과 V64 종합평가/8개 지표 검증 로직, 하단 공통 메뉴는 유지한다.
- 테이블형 Master DOCX와 빠른 메뉴 App Guide를 V66 기준으로 같은 버전에서 동기화한다.
- versionCode 60107 / versionName `6.0.8-r9-v66-market-indicator-row-daily`.


## V67 MARKET CHART SHORTLIKE — 2026-09-27
- Baseline: V66 MARKET INDICATOR ROW DAILY.
- 실기기에서 차트심볼 터치 미동작과 차트 내 일/주/월 선택 누락이 확인됨. V66의 일봉 고정은 사용자 최신 지시로 폐기.
- 차트 상단 선택줄은 `일 | 주 | 월 | 1년 | 3년 | 10년` 한 줄 고정. 기본은 일 + 1년.
- 일별 실제 OHLC를 원본으로 사용하고 주봉/월봉은 동일 원본을 주/월 OHLC로 집계.
- 차트 표현/제스처는 단기투자 차트와 동일 계열: 캔들+거래량, 좌우 이동, pinch zoom, long-press crosshair/시고저종, 최신구간 복귀.
- 차트심볼은 inline direct open 경로 + delegated event 경로를 모두 사용하고 touch-action을 고정해 Android WebView 터치 누락을 보강.
- 차트 데이터는 Android에서 SnowballMarketData native async bridge 우선, browser fetch fallback.
- V66의 핵심지표 1행 구조와 시장환경 세로간격 30% 축소는 유지.
- 테이블형 Master DOCX 및 App Guide를 V67과 동기화.
- versionCode 60108 / versionName `6.0.8-r9-v67-market-chart-shortlike`.

## V68 MARKET DEFAULT WINDOW HISTORY — 2026-09-27
- Baseline: V67 MARKET CHART SHORTLIKE.
- 시장환경 지표 차트의 일/주/월 선택은 봉 단위와 최초 디스플레이 구간을 함께 정한다: 일봉=최근 3년, 주봉=최근 5년, 월봉=최근 10년.
- 별도 1년/3년/10년 기간 버튼은 제거하고 선택줄은 `일 · 3년 | 주 · 5년 | 월 · 10년` 1행으로 단순화한다.
- 위 기간은 최초 화면에 보이는 구간일 뿐 전체 데이터 제한이 아니다. 가능한 전체 일별 OHLC 원자료를 한 번 받아 보유하고, 주봉/월봉은 같은 원자료를 집계한다.
- 사용자는 좌우 드래그로 가능한 최초 데이터부터 현재까지 연속 탐색할 수 있고, `최신구간` 버튼은 선택 봉의 기본 표시구간(3/5/10년)으로 복귀한다.
- 단기투자형 캔들/거래량/좌우 드래그/pinch zoom/long-press crosshair는 V67 그대로 유지한다.
- 테이블형 Master DOCX와 빠른 메뉴 App Guide를 V68 기준으로 동기화한다.
- versionCode 60109 / versionName `6.0.8-r9-v68-market-default-window-history`.


## V69 STABILITY MEMORY GUARD — 2026-09-27
- 사용자 실기기 관찰: 특정 버튼이 아니라 앱을 연 뒤 시간이 지나면 먹통/흰 화면/종료가 발생하는 경향. 초기 버전부터 존재한 구조적 안정성 문제로 취급한다.
- Android lifecycle: onPause에서 JS/웹뷰 타이머와 갱신을 정지, onResume에서 복귀. onTrimMemory에서 JS 메모리 trim과 캐시 정리를 요청한다.
- 네이티브 시장데이터: 요청마다 new Thread 생성하던 경로를 bounded ThreadPoolExecutor(4~6 threads, queue 32)로 교체. 백그라운드 전환 세대(generation)가 바뀐 오래된 요청은 취소 결과로 반환한다.
- JS MutationObserver: V69 bootstrap에서 콜백을 60ms 단위로 묶고 hidden/paused 상태에서는 실행하지 않는다. 일부 전역 observer는 pageShort/pageHome/settings 범위로 직접 축소하고 실시간 가격 characterData 변화만으로 반복 보정되지 않게 한다.
- 시장환경 지표 차트: 상세 닫기/메모리 trim 시 큰 OHLC 배열, 캔버스, RAF, 포인터, 캐시를 정리하며 상세 캐시는 한 종목분만 유지한다.
- 완료 검증은 버튼 동작뿐 아니라 HOME/시장환경 10분·20분·30분 유휴 테스트와 화면 백그라운드 왕복을 포함한다.


## V70 ROUTE FLICKER GUARD — 2026-09-27
- Baseline: V69 STABILITY MEMORY GUARD. V69 memory/lifecycle protections remain unchanged.
- User-device observation: intermittent flicker remained on 시장환경·단기투자·액션벨·AI, especially immediately after tapping the common bottom navigation.
- Root cause found in route-time work: multiple legacy change handlers rewrote nav DOM and triggered repeated market/short/bell renders within the first few hundred milliseconds after a route change.
- Common nav: route selection now changes visual state through CSS only. V37/V53 no longer rewrite/reapply nav DOM for every route radio change.
- Market: show the already-built market DOM first; remove the pre-refresh full render and defer the network refresh after route paint. Market feed refresh is also deferred.
- Short: chart/data loop now runs only while rShort is actually selected; leaving the screen stops it immediately. The legacy chart MutationObserver is scoped to pageShort and repeated layout passes are coalesced.
- Action Bell: remove immediate 60ms promotion rerender; defer market confirmation work so the destination screen paints before data work begins.
- AI/global production cleanup: unrelated route-radio changes no longer trigger AI production cleanup jobs.
- WebView paint: common bottom nav is kept on a stable composited paint layer and root/page background color is pinned to avoid white flashes during route switch.
- versionCode 60111 / versionName `6.0.8-r9-v70-route-flicker-guard`.


## V71 LOCAL FLICKER GUARD — 2026-09-28
- Baseline: V70 ROUTE FLICKER GUARD. V69 memory/lifecycle protection and V70 market route behavior remain unchanged.
- User-device observation after V70: 시장환경 improved, but bottom-nav entry to 단기투자·액션벨·AI still flickered.
- Short: route re-entry no longer runs repeated forced fit passes or the legacy V8 560px stage-width rewrite. Existing transform/scale is cached; same viewport only refreshes wrapper height. Chart-focus structural work is coalesced and no longer triggered just by the rShort menu tap.
- Action Bell V3/V4: keep panel sections mounted. Do not remove/recreate the whole section during route-time refresh. V4 network progress changes only the small busy text; data rows are refreshed once when results actually change.
- AI: remove pageAI from the holdings-routing global MutationObserver so AI DOM changes do not schedule unrelated HOME/LONG/SHORT routing work.
- Regression guard: common bottom navigation geometry, Market screen, V69 long-run stability and all investment logic remain unchanged.
- versionCode 60112 / versionName `6.0.8-r9-v71-local-flicker-guard`.


## V72 DOM LOOP FLICKER GUARD — 2026-09-28
- User-device screenshots localized flicker to Short price/chart, AI 2x2 stats, and Action Bell promotion/base region. Short also shook continuously even without bottom-nav interaction.
- Root cause confirmed in source: v51 Short paint mutated #pageShort while a broad MutationObserver watched the same subtree and scheduled paint again; photo3 relayout and holdings routing had similar self-trigger opportunities.
- Short: remove broad paint/relayout observers, exclude #pageShort from holdings-routing observer, and guard price/chart/volume/flow/table DOM writes so identical content is not rewritten.
- AI: keep the four stat cards mounted and update only changed text values; remove global every-click refresh.
- Action Bell: keep base/promotion panels stable; valid 10-minute cache prevents route-time market rerun. Stale background checks are silent and only render/save when results actually change.
- Retains V69 lifecycle/memory guard, V70 Market route improvement, and V71 geometry/local route guard.
- versionCode 60113 / versionName `6.0.8-r9-v72-dom-loop-flicker-guard`.

## V73 PHOTO COMPACT DETAIL — 2026-09-28
- Baseline: V72 DOM LOOP FLICKER GUARD. V69~V72 stability/flicker protections are preserved; this release is a targeted screenshot-driven UI density/label correction.
- versionCode 60114 / versionName `6.0.8-r9-v73-photo-compact-detail`.
- Portfolio detail — quantity trend rows: keep typography/data logic unchanged and reduce only top/bottom whitespace by about 70%.
- Portfolio detail — return trend rows: keep typography/data logic unchanged and reduce only top/bottom whitespace by about 50%.
- Portfolio holding cards: keep current valuation amount at upper-right; move portfolio weight percentage to the right of the bottom meter and label the section `투자비중`. Weight math is unchanged.
- Portfolio header: `개별 / 연금 / IRP / ISA / 현금` is forced into one five-column row; summary label `입력원금/금액` becomes `투자금액`.
- HOME: compact only the vertical gaps of the five account rows and the five investment-status rows by roughly three quarters. Composite-score math is unchanged.
- Short-term screen: compact vertical whitespace of the relocated current-quote summary card only. Current-price refresh, chart, period, drag/zoom, volume and cumulative investor-flow logic are unchanged.
- Regression lock: do not undo V69 lifecycle/memory cleanup, V70 route paint guard, V71 local geometry guard, V72 DOM self-loop prevention, or the shared bottom-navigation geometry.

## 2026-09-28 · V74 LOCAL COMPACT DETAIL
- Base: V73 PHOTO COMPACT DETAIL. Latest device screenshots only; no broad UI redesign.
- Portfolio detail holding cards remove the visible `투자비중` text label while preserving the meter and percent. Current value and allocation math are unchanged; card vertical space is tightened.
- The duplicate `매도이력` selector is removed from `수익률 및 주식증감률 추이`. Trade/sell history data is preserved and remains accessible through HOME Quick Menu → Report and management/history flows.
- Portfolio detail modal reserves bottom safe-space so the final explanatory content can scroll above the persistent 7-item bottom nav. Bottom-nav geometry/ownership is not changed.
- Market Environment core-indicator rows are tightened; chart-symbol cells become wider and shorter, and indicator names are nudged right. Data validation/detail-chart behavior is unchanged.
- `숲의 상태 6축` display title becomes `시장환경`; six-axis item spacing is reduced without changing scores/evidence.
- HOME Quick Menu `리포트` remains a hidden auxiliary route, not a common bottom-menu item. Report gets an explicit HOME-return control so it can be closed/re-entered like an auxiliary screen. Report stays excluded from bottom nav and swipe order.
- Preserve V69-V72 stability guards plus V53/V70 single-owner bottom-nav geometry/route behavior.

## V96 — Short first-screen scale + cumulative investor flow linkage (2026-09-30)
- Baseline: V95 true rollback.
- User observation that unlocked the bug: only the first short-investment screen had the wrong scale; after selecting another stock the scale became normal.
- Root cause: legacy first-render scripts wrote inline `!important` widths (500px / 560px) onto `.ntb-stage`. A stock switch rebuilds that DOM and removes those stale inline values, so the later V51 responsive owner then works normally.
- Fix: under the V51 responsive owner, the old fitter/width lock no longer mutates stage geometry; first render now uses the same geometry as the verified post-stock-switch state.
- Investor flow: keep the existing visible-window cumulative recalculation. Fix historical coverage by advancing `startIdx` by the number of rows actually returned, rather than assuming the requested page size was returned. This prevents holes when an endpoint caps page size.
- Investor flow values remain real source values only. Expanded quantity-field aliases only; never derive or invent missing foreign/institution/personal values.


## 2026-09-30 · V97 SHORT UI CLEANUP
- Base: V96 `SHORT FIRST-SCALE FLOW LINK` (versionCode 60137).
- User approved visible cleanup of the short-investment screen. Removed from display only: top duplicate subnav, duplicate title/subtitle, short-held summary, section-tab row, chart tool-button row, duplicated support/resistance/target/invalid row, chart time-flow/session strip, duplicate personal trade-plan and supply/volume cards, and duplicate held/watch/global-context cards.
- `판단 근거 · 뉴스/공시` stays visible and full width. Stock selector, timeframe row, current quote/metrics, broker chart, AI current judgment, chart/data/flow engines, visible-window cumulative flow recalc, 5-second supported-session refresh target, Action Bell, account/ledger/backup, and fixed bottom navigation are unchanged.
- Implementation is final scoped CSS only; the hidden UI does not delete backing runtime/data.
- versionCode 60138 / versionName `6.0.8-r9-v97-short-ui-cleanup` / WebView cache `v=682`.

## 2026-09-30 — V100 ROUTE SOURCE REPAIR
- Baseline: V97 short UI cleanup; V98/V99 broad recovery patches were not trusted as the source for this repair.
- Root cause 1 (manual leak): V82~V90 master-manual HTML (`.nt-master-h2` / `.nt-master-table-wrap`) had been injected as direct `<body>` children instead of inside the Guide overlay. On short-content routes it appeared under the main screen. V100 removes those stray DOM nodes from `index.html`; the canonical manual documents and explicit App Guide remain intact.
- Root cause 2 (Market blank): `NOONTANGI_MARKET_ENV_V2_SCRIPT` called `chartIcon()` inside `corrRows()` but no `chartIcon` existed in that IIFE. `render()` therefore threw before committing `.ntme-wrap`, while a later V90 script still inserted the `주요지표` entry card; this exactly produced the observed card + blank screen. V100 defines the local chart icon helper and keeps the verified legacy `.market-stage` visible until the live renderer has successfully committed content (`html.ntme-ready`).
- Market root cleanup: the redundant V90 `주요지표 / 자체 화면 열기` intro card is no longer inserted on the main Market route. Dedicated major-indicator access is retained elsewhere.
- Long route recovery: choosing the common `장기투자` menu forces `lhHome` + `lsNone`, closes Guide state, and resets the document scroll to top on immediate/rAF/delayed passes. This prevents the page from reopening at the portfolio summary after a previous scroll/internal route.
- Install verification: top-right runtime badge now reads `V60.8 · V100`. If V100 is not visible, the device is not running this source/build.
- Version: versionCode 60141 / versionName `6.0.8-r9-v100-route-source-repair` / WebView cache v=685.


## 2026-10-01 — V101 CORR INDEX DETAIL
- Base: V100 `ROUTE SOURCE REPAIR`; no rollback of the V100 route/manual/market fixes.
- User screenshot correction: removed the redundant `최근 3개월 평균값 vs 현재값` kicker above the large correlation title. The dynamic `최근 3개월 평균 → 현재` value line remains because it is data, not the duplicated label.
- Added a compact `지수상세설명` button immediately beside the large title. It opens an in-modal scrollable guide and does not replace the existing `쉽게 보는 법` interpretation panel.
- Guide content is indicator-aware: rates/real rates/yield curve, FX/DXY/NDF/CNY, VIX/MOVE/options, liquidity/FCI/M2/Fed/TGA/RRP, credit/HYG/spreads, flow/derivatives/short/deposits/margin/institutions, macro/PMI/CPI/PCE/exports/EPS, breadth, commodities, and generic fallback.
- Credit/HYG guide explicitly distinguishes HYG price (proxy) from credit-spread direction and notes that USIG is investment-grade, while FALN/ANGL are fallen-angel strategies.
- Version: versionCode 60142 / versionName `6.0.8-r9-v101-corr-index-detail` / WebView cache v=686.


## V102 CORR TITLE SPACE NO COEFF (2026-10-01)
- Baseline: V101. Scope limited to the correlation-detail modal.
- Increased vertical breathing room in the title row, visually referencing the 36px close-button height.
- Optimized the `지수상세설명` button to a compact 32–34px height, one-line layout.
- Removed the dedicated correlation-coefficient result card below the chart. Pearson calculation remains internal because the existing explanatory text can still use it.
- Preserved V101 detailed-index guide and V100 route/source recovery behavior.

## 2026-10-01 · V103 CORR US10Y GUIDE
- Baseline: V102 CORR TITLE SPACE NO COEFF.
- `금리 상관`의 `지수상세설명`에 미국 10년물 국채(10-Year Treasury Note) 및 수익률의 역할을 상세 설명하는 전용 콘텐츠 추가.
- 설명 범위: 장기 무위험 수익률 벤치마크, 모기지/회사채/주식 할인율과의 관계, 금리 상승·하락의 주식시장 해석, 성장주 민감도, 2Y-10Y 수익률곡선 역전, 데이터 출처/기준시각, 눈탱이 내 경고·점검 활용.
- 과도한 단정은 보정: 금리와 주식은 국면에 따라 동행 가능하며, 장단기 역전은 경기위험 신호이지 침체 시점을 보장하지 않음.
- 자동매매/자동 리밸런싱은 추가하지 않음. AI는 위험 신호와 점검 항목만 제시하고 최종 투자 결정과 실행은 사용자에게 유지.
- versionCode 60144 / versionName 6.0.8-r9-v103-corr-us10y-guide / WebView cache v=688 / badge V60.8 · V103.


## 2026-10-01 V104 CORR ENCYCLOPEDIA
- Baseline: V103. versionCode 60145 / versionName `6.0.8-r9-v104-corr-encyclopedia` / WebView v=689 / badge `V60.8 · V104`.
- User quality rule: `지수상세설명` must read like an encyclopedia, not a short tooltip. Each guide covers definition, mechanics, economic meaning, transmission path, cross-asset links, caveats and data interpretation.
- Every detailed guide ends with a visible `투자 관련 의견` panel. The opinion is conditional on multiple signals and never auto-executes trades.
- US 10Y guide is expanded with Treasury Note structure, coupon/market pricing, price-yield inverse relationship, Fed-vs-long-rate distinction, term premium/supply-demand drivers, equity valuation, Korea/FX transmission, yield-curve regimes, misconceptions, companion indicators and data-source guidance.


## 2026-10-01 V105 CORR PRACTICAL AHA
- Baseline: V104 `CORR ENCYCLOPEDIA`; versionCode 60146 / versionName `6.0.8-r9-v105-corr-practical-aha` / WebView v=690 / badge `V60.8 · V105`.
- User quality lock strengthened: detailed index guides must first give a novice-friendly “한 줄로 이해하면” bridge so a non-expert can connect the concept to an intuitive mental model.
- Encyclopedia depth from V104 remains. No reduction of technical detail.
- Every guide ends with the exact practical question `그래프의 변동성을 보고 주식투자에 어떻게 활용해야 하나?` and a direct answer.
- The final practical block teaches five graph-reading checks: direction, speed/slope, inflection, co-movement/divergence versus S&P500/KOSPI/KOSDAQ, and short-vs-long period context.
- It then gives indicator-specific scenarios (rates, curve, credit, FX, volatility, liquidity, flow, macro/earnings, breadth, commodities) and the companion indicators that should confirm the interpretation.
- Final decision rule: one graph is never a buy/sell button. Increase conviction only when the indicator direction, the stock-index response, and at least two confirming signals tell the same story; otherwise remain observational or use staged exposure.


## 2026-10-01 V106 — FIREMOUTH QUICKMENU
- Base: V105 CORR PRACTICAL AHA. 하단 7개 route/시장환경/장기/단기/상관지표는 변경하지 않는다.
- HOME 빠른메뉴에서 `관심종목` 단축타일을 `불주댕이`로 교체했다. 관심종목 기능 자체(보유/관심 picker 등)는 삭제하지 않는다.
- 불주댕이는 매뉴얼 7장의 10단계 프레임을 실제 로컬 기록 UI로 구현한다: 원문/행동, 표면 의미, 당시 환경, 불만·손해·압박, 복수 가설, 결정권/영향 네트워크, 다음 행동, 행동·자금 검증, 파급경로/국내 종목, 선반영·반증·무효화/출구.
- 분석 대상 유형: 정책결정자/정부, 중앙은행, 기업/산업 리더, 금융기관, 국제기구, 기타. 행동 유형은 발언/리서치와 정책/예산/자산배분/ETF·펀드 흐름/채권·시장 포지션/CAPEX/계약·공급망 등을 구분한다.
- 공식 설명을 부정하거나 숨은 의도를 사실처럼 단정하지 않는다. 복수 가설과 반대근거를 함께 저장한다. 말보다 행동, 행동보다 실제 돈과 숫자에 더 높은 가중치를 둔다.
- 기존 `NOONTANGI_INFO_ENGINE`의 사건형 근거를 불주댕이 편집기로 가져올 수 있고, 검증할 가치가 있는 불주댕이 기록은 다시 밑밥 근거로 보낼 수 있다. 이후 기존 원문/독립교차/반대근거/투자영향 검증을 통과해야 Action Bell 후보가 된다.
- 실시간 원문 자동수집이 연결되지 않은 상태에서는 최신 발언/행동을 임의 생성하지 않는다. UI에 `수동 기록 + 기존 밑밥 근거 연결` 상태를 명시한다.
- 저장 키: `noontangi_v106_firemouth_records`.
- versionCode 60147 / versionName `6.0.8-r9-v106-firemouth-quickmenu` / WebView cache `v=691`.

## 2026-10-01 V107 — FIREMOUTH RECENT VOICES
- V106 불주댕이 quick-menu/10단계 기록 엔진을 유지한다.
- 불주댕이 진입 직후 상단에 `최근 영향력 인사 발언 · 행동` 브리핑을 표시한다. 사용자는 빈 입력 화면보다 먼저 실제 최근 공개 발언/행동, 표면 의미, 시장 해석 가설, 다음 확인 행동, 주식투자 연결을 본다.
- V107 내장 브리핑 기준일은 2026-10-01이다. 자동 실시간 원문 수집이 연결된 것으로 오인시키지 않으며 기준일 이후 항목은 자동 갱신되지 않는다고 화면에 명시한다.
- 내장 항목: Michael Barr(연준, 9/29), John Williams(뉴욕 연은, 9/29), Lisa Cook(연준, 9/28), Donald Trump(미국 대통령, 9/30), Jensen Huang(NVIDIA, 9/28). 출처·날짜를 함께 저장한다.
- 정치인/정책결정자 포함 모든 `속뜻`은 동기 단정이 아니라 `시장 해석 가설`로 표시한다. 복수 가설, 반대근거, 실제 확인행동을 함께 둔다.
- 각 최근 브리핑 카드의 `10단계 분석에 저장` 버튼을 누르면 기존 V106 편집기로 내용을 가져와 사용자가 수정·저장하고 밑밥 사건형 근거로 연결할 수 있다.
- 투자 연결은 단일 발언을 매수/매도 신호로 사용하지 않고 후속 정책·계약·예산·수급·금리·실적·시장가격으로 확인하는 구조를 유지한다.
- versionCode 60148 / versionName `6.0.8-r9-v107-firemouth-recent-voices` / WebView cache `v=692` / badge `V60.8 · V107`.


### V108 VOICE ACCOUNT CHART · 2026-10-01
- versionCode 60149 / versionName `6.0.8-r9-v108-voice-account-chart` / WebView cache `v=693` / badge `V60.8 · V108`.
- 모든 메인메뉴와 하위메뉴에 공통 `음성요청`/`음성읽기`를 제공한다. 음성요청은 현재 보이는 메뉴/버튼 실행과 메인 라우팅을 지원하고, 음성읽기는 현재 화면 또는 열린 상세창을 한국어 TTS로 읽는다. 화면 전환/정지 명령 시 읽기를 멈춘다.
- Android native SpeechRecognizer + TextToSpeech bridge를 사용한다. 한국어 음성을 우선하고 기기에 명시적 여성 음성이 있으면 우선 선택하며, 그 외 한국어 음성은 부드러운 속도/피치로 설정한다.
- 단기투자 종목선택에 `연금`, `IRP` 탭을 추가하고 계좌·보유관리의 실제 보유종목과 종목코드를 기존 실시간 차트 엔진에 연결한다. 이 기능은 계좌/투자구분을 변경하지 않고 차트 조회만 확장한다.
- V107 불주댕이 최근 영향력 인사 발언·행동 브리핑과 10단계 분석은 회귀 없이 유지한다.


## 2026-10-01 V109 — VOICE ACCOUNT FIREMOUTH FIX
- Base: V108 `VOICE ACCOUNT CHART`; no rollback of V107 recent-voices or V105 correlation guide.
- Global voice controls remain fixed across all main routes and open submenus/modals. Voice request routes by menu/button name and `음성읽기` reads the currently active screen/dialog using the native Android TTS bridge.
- Short-investment picker remains `보유 / 관심 / AI추천 / 연금 / IRP`; pension/IRP rows come from the manual account-holdings Source of Truth and only expand chart lookup.
- Firemouth visibility fix: recent influence-voice cards are rendered independently of saved 10-step records, the section shows an explicit `최근 N건` badge, and the KPI label is changed from `분석 기록` to `저장 분석` so 0 saved records is not misread as 0 recent briefings.
- Install check: `V60.8 · V109`. versionCode 60150 / versionName `6.0.8-r9-v109-voice-account-firemouth-fix` / WebView cache v=694.


## V110 · Conversational Voice + Local Read (2026-10-01)
- `음성요청`은 읽기 전용이 아니라 눈탱이 AI와의 대화 진입점이다. 현재 화면/선택 창/종목을 컨텍스트로 질문하고 기존 AI 투자비서 대화 이력에 질문과 답변을 저장한다. 음성 질문의 답변은 화면에 표시하고 TTS로 읽는다.
- 모든 메인/하위 화면의 주요 창/카드에는 국소 `🔊` 읽기 진입점을 둔다. 기본 `음성읽기`는 선택한/현재 중심 창만 읽고, `전체 읽어줘`처럼 명시적으로 요청한 경우에만 화면 전체를 읽는다.
- `속뜻만 읽어줘`, `투자 활용 부분 읽어줘`, `최근 발언 읽어줘`처럼 범위 지정을 우선한다.
- V109의 보유/관심/AI추천/연금/IRP 단기차트 소스와 불주댕이, 시장환경, 상관지표, 장기투자 로직은 회귀 금지한다.


## V111 · Flexible AI Dialogue (2026-10-01)
- `🎙 AI에게 묻기`를 `🎙 AI대화`로 변경한다.
- 음성/텍스트 AI대화는 정해진 질문 목록을 요구하지 않는다. 사용자는 자연어로 자유롭게 질문하고 후속 질문을 이어갈 수 있다.
- 현재 화면·선택 창·선택 종목·직전 대화를 컨텍스트로 사용한다. 화면 컨텍스트는 질문을 제한하는 명령어가 아니라 참고자료다.
- 로컬 AI가 기존 정형 intent에 맞지 않는 질문을 받으면 예시 질문 목록을 돌려주지 않고, 현재 화면과 대화 맥락에서 관련 문장을 찾아 직접 답한다.
- `방귀 차트→방금 차트`, `챠트→차트` 등 자주 생기는 음성인식 오차는 문맥 보정한다.
- 실시간 외부 데이터가 필요한 질문은 연결 범위를 구분하되, 대화 자체를 차단하지 않는다.
- V110의 국소 `🔊 선택읽기`와 명시적 전체읽기 원칙은 유지한다.


## V112 VOICE INTENT ROUTER (2026-10-01)
- `AI대화`는 음성 입력을 먼저 **화면/기능 실행 → 부분읽기 → 자유 AI 질문**으로 분류한다. `단기 투자하면 보여 줘`, `단기 투자 화면 보여줘`, `시장 환경 열어 줘`처럼 띄어쓰기/음성인식이 흔들려도 compact-normalization으로 화면 이동을 우선 실행한다.
- 자유질문은 사용자가 `이 화면/이 차트/여기/방금/아까` 등으로 현재 컨텍스트를 가리킨 경우에만 현재 카드 본문을 근거로 답한다. 그 외 질문에는 현재 화면을 억지로 읽지 않는다.
- `AI대화`와 `선택읽기`는 분리 유지. 전체 읽기는 명시적 전체읽기 요청만 허용한다.
- TTS 기본 피치를 0.94, 속도를 0.99로 조정해 고음을 줄이고 밝고 부드러운 여성 톤을 목표로 한다.


## V113 · Voice Dialogue No-Popup (2026-10-01)
- 음성 `AI대화`는 기본적으로 큰 답변창을 띄우지 않는다. 질문→답변→TTS만 수행하고 대화이력은 기존 AI 메뉴에 저장한다.
- 사용자가 `답변 보여줘`, `방금 내용 보여줘`처럼 명시했을 때만 마지막 AI 답변 텍스트 창을 연다.
- 현재 화면/카드 본문은 `이 화면`, `이 차트`, `여기`, `선택한 카드`처럼 사용자가 명시적으로 지칭할 때만 AI 컨텍스트로 사용한다. 후속질문이라는 이유만으로 현재 화면을 자동 주입하지 않는다.
- `설명 좀 해줘`처럼 대상이 없는 짧은 질문은 화면 내용을 임의로 설명하지 않고 무엇을 설명할지 짧게 되묻는다.
- 동일 음성인식 결과가 6초 안에 반복 전달되면 한 번만 처리해 중복 답변을 막는다.
- 화면 실행 명령 → 부분읽기 → AI질문 분리, V112의 여성 TTS 톤, 단기 5소스, 불주댕이/시장환경/상관지표/장기투자 기능은 유지한다.

## V114 · Continuous AI Dialogue / Semantic TTS / Read Audit (2026-10-01)
- Base: V113 `VOICE DIALOGUE NO POPUP`; 기존 단기투자 5소스, 불주댕이, 시장환경, 상관지표, 장기투자 로직은 유지한다.
- `AI대화`는 한 번 시작하면 질문 → 답변 → 자동 재청취를 반복하며, 사용자가 `대화 종료` 또는 버튼으로 명시적으로 끌 때까지 세션을 유지한다. 무음/NO_MATCH는 세션을 끊지 않고 재청취한다.
- 음성입력 라우팅 순서는 `화면/기능 실행 → 지정부분 읽기 → AI대화`를 유지한다. 화면 이동 명령도 대화 세션을 종료하지 않는다.
- AI 답변은 눈탱이 내부 데이터가 충분하면 즉시 내부 근거로 답한다. 최신 시세/뉴스/공시/발언/당일 원인처럼 외부 확인이 필요한 질문만 외부 공개자료를 조회한다.
- 외부 확인은 응답 지연을 무한정 늘리지 않는다. 약 2.4초 후 진행상태를 알리고 8초대 하드타임아웃 안에서 결과를 만든다. 단, 속도를 위해 검증 수준을 임의로 낮추지 않는다.
- 외부 뉴스는 Google News RSS 공개보도 집계를 사용하며 서로 다른 출처 수를 계산한다. 독립 출처가 부족하면 투자 원인/결론을 단정하지 않는다. 종목 현재가는 가능한 경우 NAVER 공개 시세 API를 함께 사용한다.
- TTS는 숫자를 문자 그대로 읽지 않는다. 날짜 `2026-09-30`→`2026년 9월 30일`, 시각 `14:30`→`14시 30분`, `+3.2%`→`3.2퍼센트 상승`, `-2.1%`→`2.1퍼센트 하락`, 금액/주식수는 한국어 수량 단위, `2Y-10Y`→`2년물과 10년물 금리차` 등 의미 기반 전처리를 거친다.
- 한국어 여성 TTS 기본 톤은 고음을 낮춘 pitch 0.92 / rate 1.00으로 조정한다. 기기에서 명시적 여성 한국어 음성이 노출되면 우선 선택한다.
- 읽기버튼은 전 메뉴/하위메뉴의 주요 제목/카드를 동적 스캔해 누락을 보완한다. 폼/조작 UI/버전/URL/차트축/기간버튼/중복 제목 등은 기본 낭독에서 제외한다.
- 카드 `🔊`는 화면 전체가 아니라 해당 카드의 핵심·현재상태·판단·투자활용·위험·결론 중심의 필요한 내용만 읽는다. 사용자가 `전체 읽어줘`라고 명시한 경우에만 전체 화면 낭독을 허용한다.
- Install check: `V60.8 · V114`. versionCode 60155 / versionName `6.0.8-r9-v114-continuous-ai-semantic-tts-read-audit` / WebView cache v=699.


## V115 · Voice Navigation Hard Guard (2026-10-01)
- Source: V114. Minimal patch to the voice intent router only.
- Main-route commands now use navigation-context ASR normalization, including `단계 화면` -> `단기 화면` only when it is clearly a screen/menu request.
- If a request contains navigation verbs but no route/button can be resolved, the router asks which screen to open instead of falling through to AI general chat.
- Continuous AI session, semantic TTS, scoped reading, external-data policy, short-term 5-source selector and Firemouth remain unchanged.
- Install check: `V60.8 · V115`. versionCode 60156 / versionName `6.0.8-r9-v115-nav-command-hard-guard` / cache v=700.


## V116 VOICE MULTICANDIDATE NAV CLICK (2026-10-01)
- 음성인식 1순위 후보만 사용하지 않는다. Android SpeechRecognizer가 반환한 최대 3개 후보를 모두 전달하고, 이 중 명확한 화면/메뉴 실행 의도가 있는 후보를 AI 일반대화보다 우선한다.
- 메인 화면 이동은 단순 checked 변경만 하지 않고 실제 #mainNav label 클릭 경로를 먼저 사용하여 기존 click/change 초기화 로직을 모두 재사용한다.
- 화면을 열라는 의도가 확인되면 일반 AI 답변으로 폴백하지 않는다.


## V117 VOICE PIPELINE SINGLE OWNER (2026-10-01)
- Four consecutive real-device regressions showed that alias-by-alias patches were insufficient. The full STT → intent → route → TTS → relisten pipeline is now treated as one owned state machine.
- Native SpeechRecognizer no longer calls cancel() immediately before every startListening(); intentional cancel errors are suppressed and only one recognition session is allowed at a time.
- Each native recognition session sends a monotonically increasing id plus up to five candidates. JS ignores stale/duplicate turns.
- Intent priority is locked: screen/function execution → scoped reading → AI dialogue. A navigation-like utterance is never allowed to fall through into generic AI encouragement/explanation.
- Screen execution is verified by radio state and target page visibility; the compact diagnostic shows recognized text, chosen intent, and execution result.
- AI conversation remains continuous and resumes after an explicit TTS cooldown to reduce self-listening/race behavior.


## V118 VOICE NAV FOLLOWUP STATE (2026-10-01)
- Screen-selection clarification is conversational state, not a stateless one-shot command.
- Do not enumerate all menu names in TTS. Ask only “어느 화면을 열까요?”.
- For 18 seconds after that prompt, bare answers such as “단기 투자”, “단기”, “단계”, “시장”, “장기”, “액션벨”, “밑밥”, “홈”, “불주댕이” are interpreted as the requested target screen.
- While screen selection is pending, generic AI answers are blocked; successful route execution clears the pending state.
- Direct commands such as “단기 투자 보여줘” continue to route immediately without clarification.


## V119 · Native Navigation Owner (2026-10-01)
- Root fix after repeated real-device failures: screen-open speech is now classified in Android `onResults()` before any JS AI handler.
- A recognized navigation command is consumed natively and cannot fall through to legacy routeCommand/genericClick/AI fallback.
- `단기 투자 보여줘`, `단계 화면 보여줘`, and bare `단기 투자` after clarification all execute `rShort` through the canonical `#mainNav` click path.
- Unknown navigation asks only `어느 화면을 열까요?`; no menu enumeration.
- Native route execution verifies the actual target page visibility and emits a compact `인식 → 의도 → 실행결과` diagnostic.


## V120 음성 부분인식/재질문 제거 (2026-10-01)
- SpeechRecognizer 부분결과를 활성화하고 한 턴의 partial+final 후보를 합쳐 화면이동 의도를 판단한다.
- 최종 인식에서 앞 단어가 잘려 `보여줘`만 남아도 partial에 `단기 투자`가 있으면 단기투자로 실행한다.
- 최종문장이 `단기투자 왜 중요한데`처럼 질문이면 partial의 bare 메뉴명을 화면이동으로 오판하지 않는다.
- 화면명을 못 잡은 경우 `어느 화면을 열까요?`를 음성으로 끼어들지 않고, 18초 pending 상태에서 조용히 다시 듣는다.
- TTS 종료 후 연속대화 재청취 간격을 약 0.32초로 줄여 첫 단어 유실을 줄인다.
- 음성 네비게이션은 native 우선이며 JS fallback도 재질문 대신 조용히 재청취한다.


## V121 STOCK VOICE PRIORITY — 2026-10-01
- 음성 우선순위: 종목 실행 → 메뉴 실행 → 부분읽기 → AI대화.
- `한온시스템 보여줄래` 같은 문장은 화면명 미확정으로 처리하지 않고 단기투자 종목선택을 실제 변경한다.
- 보유/관심/AI추천/연금/IRP의 현재 단기 종목선택 옵션을 음성 종목 카탈로그로 사용한다.
- `한온시스템 왜 올랐어?` 같은 질문형은 종목을 바꾸지 않고 AI대화로 유지한다.


## 2026-10-01 V121 rollback install R1
V121 STOCK VOICE PRIORITY is restored as the active functional baseline. V122/V123 GPT-Live experiments are not part of current use. A packaging-only rollback build uses versionCode 60165 and WebView cache v=709 so it can be installed over V122/V123 without uninstalling and without intentionally changing V121 behavior.

## 2026-10-02 — V121 R4 INTENT FIREMOUTH
- Baseline: V121 rollback, no GPT-Live paid API/server.
- Main-route transitions auto-close auxiliary overlays before/while changing route so successful navigation is not hidden behind IRP/pension/portfolio/settings/guide/detail overlays.
- Voice intent separation: explicit screen-open vs stock-show vs read vs explanation vs latest/current-info. Explanation/news/read phrases must not enter unresolved navigation prompting.
- Firemouth free refresh: 06:30 / 12:00 / 16:30 / 22:00 while app is alive, with boot/resume catch-up. Google News RSS via SnowballExternalInfo. Dedupe and 48h relevance filter. High-impact new items appear in Action Bell as initial, unverified signals and also enter the existing evidence pipeline; verification gates remain authoritative.


## 2026-10-02 — V121 R5 SHORT PRICE / AXIS LAYOUT
- Baseline: V121 R4 INTENT FIREMOUTH; short-term screen only.
- Keep the current-price summary card footprint. Daily change amount/rate is a separate line below the main price; font sizing is optimized only to prevent overlap with the right metric card.
- Delete the chart-top LIVE/status/gesture-hint text row and reclaim that vertical space.
- Preserve the previous price-axis interval and extend the upper axis by exactly two additional intervals. Crosshair uses the same expanded scale.
- No changes to live quote source, 5-second market refresh, timeframe/range mapping, pan/pinch, visible-window volume profile, cumulative investor flow, voice, Firemouth, or main navigation.
- Install check: versionCode 60169 / versionName `6.0.8-r9-v121-short-price-axis-r5` / WebView cache v=713.


## 2026-10-02 · V121 R6 / package V123
- 단기투자 요약 우측 `거래량·거래대금·52주 최고·52주 최저` 카드는 외곽 크기/테두리를 유지하고, 라벨과 값의 글자 계층·간격만 단순화한다.
- 단기 차트 가격축 상단 여유는 기존 축 간격을 보존한 **1단계 추가**로 고정한다. 가격축 라벨/그리드와 크로스헤어는 동일 스케일을 사용한다.
- HOME 빠른메뉴에서 여는 부가화면 및 주요 보조 오버레이에는 하단의 큰 `닫기` 버튼을 공통 적용한다.
- 부가화면이 열린 상태에서 하단 7개 메인메뉴를 누르면, 같은 한 번의 터치에서 `부가화면 닫기 → 선택 메뉴 활성화`까지 완료한다. 닫기만 되고 두 번째 터치를 요구하는 동작은 회귀로 본다.
- 배포 ZIP 파일명은 이번 요청에 따라 `SNOWBALL_CURRENT_V123.zip`을 사용한다.

## 2026-10-02 — V121 R6 MANUAL SYNC
- Canonical table master `NUNTANGI_Master_Manual_Scenario_v1_2_2026-09-24.docx` is synchronized through V121 R6/package V123 without restructuring the existing 1~20 sections; a recent-change integration section is appended and the existing change-management table gains the release-sync checklist.
- In-app App Guide is synchronized to the same recent-change baseline. R5 `+2 price-axis steps` is explicitly superseded by R6 `+1 step`.
- Release gate is now locked: BUILD_ID + PROJECT_HANDOFF + UI_STANDARD/SCENARIO_LOCK + canonical DOCX + in-app App Guide must move together for every functional package.

## 2026-10-02 · V121 R7 LEDGER CASH SYNC / package V123
- 매매실적 입력은 `+수량/-수량` 부호 방식이 아니라 `매수/매도`를 명시적으로 선택하고 수량은 양수로 입력한다.
- 보유수량 반영은 매수 `+수량`, 매도 `-수량`; 현금 반영은 매수 `-(수량×체결단가+수수료)`, 매도 `+(수량×체결단가-수수료)`다. 현재 입력 수수료는 0원이며 기존 fee 필드가 있으면 계산에 포함한다.
- 모든 새 주식 매매는 현금 자동반영 이력(`noontangi_v124_cash_history`)과 `refTradeId`로 연결한다. 자동반영 직후 사용자에게 현금 증감액과 현재 현금을 메시지로 표시한다.
- 주식매매 이외의 현금 변동은 `현금 + 금액만` 입력에서 `입금/출금`으로 직접 기록하고 현금 입출고 이력을 남긴다.
- 기존 매매 중 현금 기준값(anchor) 이후에 입력됐지만 현금 이벤트가 없는 거래는 1회 마이그레이션으로 자동보정한다. 현금 현재값 정정 이후보다 오래된 거래는 수정/삭제해도 현재 현금을 재변경하지 않아 이중반영을 막는다.
- 거래 이력은 `매매실적 수정/삭제` 화면과 리포트 각 행에서 수정/삭제할 수 있다. 수정 가능한 핵심값은 매수/매도 구분, 수량, 체결단가다. 수정/삭제 뒤 보유수량·평단을 거래기준(anchor) 이후 이력에서 다시 계산한다.
- 하위 거래입력/수정/삭제 확인창이 열리면 부모 환경설정의 하단 `닫기`는 숨긴다. 이미 자체 `닫기`가 있는 부가화면에는 R6 공통 닫기를 중복 삽입하지 않는다.
- Install/package: versionCode 60171 / versionName `6.0.8-r9-v121-ledger-cash-sync-r7` / WebView cache v=715 / distribution `SNOWBALL_CURRENT_V123.zip`.


## 2026-10-02 · V121 R8 JOURNAL OWNER / TOUCH LAYER · PACKAGE V124
- Touch/button priority is locked as: **AI대화·선택읽기 > 눈탱이 메인 심볼/헤더 > 부가·빠른메뉴 > 하단 메인메뉴**. Voice controls must remain selectable even when auxiliary surfaces overlap.
- HOME quick menu `AI 질문` is replaced by **매매일지**. This becomes the single user-facing owner for trade execution records, non-trade cash deposits/withdrawals, trade edit/delete, linked cash history, and per-trade journal/review.
- Settings no longer exposes transaction-history/action controls. Settings is reserved for account classification, current baseline corrections, operating variables, backup/restore, and app maintenance.
- V121 R7 buy/sell cash synchronization remains authoritative: Buy = qty + / cash -, Sell = qty - / cash +.
- Main-route one-tap handoff remains active through the global pointer owner even though the visual/touch z-order places auxiliary surfaces above the bottom menu.
- Install/package: versionCode 60172 / versionName `6.0.8-r9-v121-journal-layer-r8` / WebView cache v=716 / distribution `SNOWBALL_CURRENT_V124.zip`.

## 2026-10-02 · V121 R9 TOUCH OWNER / SETTINGS ROLE FIX · PACKAGE V125
- V124 실기기 확인에서 `매매일지` 교체만 눈에 보이고 R8 터치/환경설정 구조는 의도대로 반영되지 않은 회귀를 확인했다.
- 원인 1: R8이 사용자의 **터치 우선순위** 요구를 시각 z-index 순서로 그대로 구현해 메인 헤더가 부가창 위에 그려질 수 있었다. R9은 시각 레이어와 터치 소유권을 분리한다. 부가창은 메인 화면 위에 정상 표시하고 `AI대화/선택읽기`만 최상위 터치 소유자로 둔다.
- 원인 2: `매매일지`, `종목/거래 추가`, `매매 수정/삭제`, `삭제 확인`이 같은 레이어를 공유해 부모/자식 모달이 충돌할 수 있었다. R9은 `매매일지(base aux) < 거래입력/수정(child) < 삭제확인(confirm) < AI대화/선택읽기`로 분리한다.
- `AI대화/선택읽기` 고정 도크는 하단 메뉴 위 위치에서 화면 상단 헤더 하단 영역으로 이동한다. 모든 화면에서 최상위 터치권을 유지한다.
- 매매일지는 더 이상 환경설정의 숨겨진 `매매이력등록` 버튼을 대신 클릭하지 않는다. R7 원장 소유 API의 `openNewTrade()`를 직접 호출한다.
- 환경설정은 화면에 `계좌·기준값 / 운영 변수 / 백업·복원 / 앱 관리` 4개 탭을 명확히 표시한다. 계좌·기준값은 현재 수량·평단·현금의 오등록 정정만 담당하고, 실제 거래/현금 입출금/수정·삭제/복기는 매매일지가 단일 소유한다.
- 리포트의 거래이력은 조회용으로 유지하고 수정/삭제 버튼은 매매일지로 단일화한다.
- Install/package: versionCode 60173 / versionName `6.0.8-r9-v121-touch-settings-r9` / WebView cache v=717 / distribution `SNOWBALL_CURRENT_V125.zip`.


## 2026-10-02 · V121 R10 HEADER DOCK / AUX SPACE / FLICKER FIX · PACKAGE V126
- 사용자 확정 빨간 `눈탱이` 겨울 배너를 HOME 및 메인 하위화면의 공통 상부 심볼로 실제 asset 연결하고 상단 고정 기준으로 잠근다. 구형 CSS 눈탱이 글자/마스코트 중첩은 표시하지 않는다.
- `AI대화 / 선택읽기` 고정 도크는 콘텐츠 위가 아니라 눈탱이 심볼 영역 **최하단**으로 올린다. 두 버튼의 최상위 터치 소유권은 유지하되 부가 모달의 시각 레이어를 침범하지 않는다.
- R6의 공통 하단 큰 `닫기` footer 규칙은 폐기한다. 부가/빠른메뉴는 상단 X를 유지하고, 하단 7개 메인메뉴 선택 시 기존 R4의 `자동 닫힘 → 선택 화면 이동`을 같은 한 번의 터치로 사용한다.
- 상관지표를 포함한 부가 상세의 하단 설명 영역은 삭제된 footer 공간을 설명에 돌려준다. 설명은 세로 최소공간을 확대하고 길면 내부 스크롤한다.
- 깜빡임 원인으로 확인된 R7/R9의 body-wide `childList` MutationObserver + 동일 `innerHTML/textContent` 재기록 피드백을 제거한다. Settings/Quick patch는 최초/지연 1회만 실행하고 이후 child modal 상태 관찰은 `class/aria-hidden` 속성에 한정한다.
- 매매/현금 R7 원장, anchor 이중반영 방지, R4 메인메뉴 자동닫기, 차트·수급·시장데이터 로직은 변경하지 않는다.
- Install/package: versionCode 60174 / versionName `6.0.8-r9-v121-header-dock-r10` / WebView cache v=718 / distribution `Snowball current_v126.zip`.


## 2026-10-02 · V127 fixed common header
- HOME의 승인된 빨간 눈탱이 심볼 높이를 메인 하위화면과 같은 110 CSS px 기준으로 축소한다.
- HOME/시장환경/장기/단기/밑밥/액션벨/AI 및 빠른메뉴·부가화면은 viewport 소유 공통 헤더를 사용해 스크롤 시 상부 심볼이 움직이지 않는다.
- AI대화·선택읽기는 심볼 영역 우측 하단에 고정하며 터치 최우선 소유권을 유지한다.
- 빠른메뉴·부가화면 본문은 공통 헤더 아래에서 시작한다. 거래입력·수정·확인 child modal은 공통 헤더보다 위에 유지한다.


## 2026-10-02 · V121 R13 CORR HEADER SPACE · PACKAGE V130
- 금리/시장 상관지표 상세창 제목과 상단 정보가 V127 공통 눈탱이 헤더 뒤에 숨는 회귀를 수정했다. 직접 원인은 `corrLayout()`의 inline `top = android inset + 10px`가 공통 헤더용 CSS top을 덮어쓴 것이었다.
- 상관지표 overlay는 이제 `Android top inset + 공통 심볼 110px` 아래에서 시작한다. 눈탱이 공통 헤더와 `AI대화/선택읽기` 도크는 유지한다.
- 세로 공간 확보를 위해 기간/비교지수 버튼 높이·간격과 모달 padding만 축소했다.
- 차트 위 중복 범례(`미 10년 · S&P500` 등)는 숨기고 차트 내부 좌/우 축 제목만 유지한다.
- 차트 높이(214px box / 206px SVG), 실제 데이터 로딩, 양축, 상관 계산, 기간 선택은 변경하지 않는다. 회수한 공간은 `금리 상관 · 쉽게 보는 법` 설명 영역에 사용한다.
- Install/package: versionCode 60177 / versionName `6.0.8-r9-v121-corr-header-space-r13-v130` / WebView cache v=720 / distribution `Snowball current_v130.zip`.

## 2026-10-03 · V135~V138 누적수급 원천 재설계 / SOURCE STANDARD
- V135에서 단기차트의 `최근구간` 표시를 제거하고 우측 요약 글자 계층 및 가격축 여백을 정리했다. 누적수급은 검색기간에 연동하도록 보정했다.
- 실기기 확인 결과 1개월·3개월은 정상이나 6개월 이후부터 기간이 길수록 개인·기관·외국인 누적수급 선이 오른쪽에 몰렸다. V136~V137에서 NAVER 페이지 수와 저장 이력을 늘렸지만 1년·5년·10년 구간은 완전 해결되지 않았다.
- 최종 진단: 차트 X축 문제가 아니라 NAVER 개별종목 수급 원자료의 과거 범위 부족이 핵심이다. 가격 차트 기간은 길어지는데 실제 수급 행의 시작일이 최근에 머물러 오른쪽에 모여 보인다. **없는 수급 데이터를 화면 폭에 맞춰 임의로 늘리거나 가짜 날짜를 만들지 않는다.**
- 데이터 소스 표준을 다음 순서로 잠근다: **공식 원천/공식 API → 공공·무료 API → 온디바이스/오픈소스 → 포털/보조 fallback → 유료 서비스**. 구현 전에 제공 기간, 투자자 구분, 단위, 인증, 라이선스/이용조건, 안정성, 갱신시각, fallback을 함께 확인한다.
- 국내 주식 원천은 기능에 따라 KRX Data Marketplace/OPEN API, DART, 금융위·공공데이터 등 공식 원천을 우선 탐색한다. NAVER/Yahoo 등은 빠른 현재값·보조·fallback 용도로 취급한다.
- KRX Data Marketplace에는 `투자자별 거래실적(개별종목)` 일별추이(MDCSTAT02303)가 있고 기관 합계·개인·외국인 합계의 일별 순매수를 제공한다. KRX 공개 OPEN API 서비스 목록에는 동일 투자자별 개별종목 API가 현재 명시되어 있지 않아 V138은 **로그인된 Data Marketplace CSV 경로**를 별도 원천 어댑터로 사용한다.
- V138은 1개월 이상 누적수급에서 KRX `순매수 거래량(trdVolVal=1, askBid=3)`을 1차 원천으로 사용하고, NAVER 최근 데이터는 당일/보완 및 KRX 실패 시 fallback으로 유지한다. 수급선은 가격차트와 같은 실제 날짜축으로 그린다.
- KRX 연결은 환경설정 → 운영 변수에서 수행한다. KRX ID/PW는 네이티브 메모리에만 보관하며 localStorage/파일에 저장하지 않고 앱 완전 종료 시 제거한다. KRX 자체 계정이 없거나 연결하지 않으면 기존 NAVER fallback으로 동작한다.
- 배포/테스트 시 KRX 로그인 경로는 실제 사용자 계정으로 실기기 검증이 필요하다. 제공자 화면/인증 정책이 바뀌면 Data Marketplace 어댑터를 갱신하고, 숨겨진 데이터나 합성값으로 성공처럼 표시하지 않는다.
- 누적수급 안정화가 현재 최우선이다. 안정화 완료 후 음성지원 개선으로 넘어간다.
- 음성 단계의 소스/비용 우선순위는 **Android SpeechRecognizer/온디바이스 STT → Android TextToSpeech → whisper.cpp 등 로컬 오픈소스 STT → 로컬 intent/화면 컨텍스트 엔진 → 필요할 때만 외부 유료 AI**다. `유료 GPT-Live만 가능`을 기본 전제로 두지 않는다.
- V138 package: versionCode 60184 / versionName `6.0.8-r9-v121-krx-flow-source-r20-v138` / WebView cache v=727 / distribution `Snowball current_v138.zip`.

## 2026-10-03 · V139 KRX CSV FLOW / V138 연결방식 교정
- V138에서 설계했던 `KRX 계정 로그인 → 웹 경로 자동조회` 방식은 실제 네이티브 브리지 구현과 불일치했고, 현재 공식 KRX OPEN API 서비스 목록에서 동일한 `투자자별 거래실적(개별종목)` API를 확인하지 못한 상태였다. 따라서 V139에서 이 경로를 폐기한다.
- V139의 공식 원천은 KRX Data Marketplace의 `투자자별 거래실적(개별종목)` 화면에서 사용자가 직접 내려받은 CSV다. 권장 조건은 `일별추이 / 거래량 / 순매수 / 가능한 장기기간`이다.
- 앱의 환경설정 → 운영 변수에서 `현재 종목 KRX CSV 가져오기`를 실행한다. Android 파일선택기로 CSV를 선택하고, 앱은 일자·개인·기관·외국인 수급열을 검증한 뒤 현재 종목에 연결한다.
- 기관합계/외국인합계 열이 없는 상세형 CSV도 처리한다. 기관은 금융투자·보험·투신·사모·은행·기타금융·연기금 등 합산, 외국인은 외국인+기타외국인 합산으로 복원한다.
- KRX CSV는 종목별 최대 3400거래일을 보존한다. 로그인 ID/PW를 입력받거나 저장하지 않는다. 최근 데이터는 NAVER를 보완/fallback으로 사용한다.
- 가격차트와 실제 날짜가 겹치지 않는 수급 데이터는 억지로 화면 폭에 늘려 그리지 않는다. 없는 기간은 없는 것으로 표시한다.
- 공식 KRX OPEN API에 향후 동일 개별종목 투자자별 수급 항목이 확인되면 CSV 어댑터를 API 어댑터로 교체/병행한다. 그 전에는 숨은 endpoint·로그인 자동화·비공식 크롤링을 기본 구현으로 채택하지 않는다.
- 데이터 소스 우선순위는 `공식 원천/공식 API → 공공·무료 API → 온디바이스/오픈소스 → 포털 fallback → 유료 서비스`로 유지한다. 누적수급 안정화 후 음성지원 단계로 이동한다.
- V139 package: versionCode 60185 / versionName `6.0.8-r9-v121-krx-csv-flow-r21-v139` / WebView cache v=728 / distribution `Snowball current_v139.zip`.

## 2026-10-03 · V121 R22 FLOW SOURCE VISIBLE · PACKAGE V140
- V139 설치만으로 KRX 데이터가 자동 생성되는 것으로 오해하지 않도록 단기투자 누적수급 그래프에 **현재 사용 원천을 항상 표시**한다.
- 현재 종목에 KRX CSV가 있으면 `KRX 공식 CSV · N일`, 없으면 `NAVER 실제수급 · KRX 미등록`으로 표시한다.
- 이 표시는 상태 확인용이며 가격차트/누적수급 계산/실제 날짜축/NAVER fallback/KRX CSV 파서에는 영향을 주지 않는다.
- 장기수급 안정화의 검증 순서는 `원천 표시 확인 → KRX CSV 등록 → 6개월/1년/주봉/월봉 실제 날짜범위 확인`으로 잠근다.
- Install/package: versionCode 60186 / versionName `6.0.8-r9-v121-flow-source-visible-r22-v140` / WebView cache v=729 / distribution `Snowball current_v140.zip`.

## 2026-10-03 · V121 R23 FLOW SOURCE DIRECT IMPORT · PACKAGE V141
- V140 실기기에서 `NAVER 실제수급 · KRX 미등록` 문구가 정상 표시되어 배포/캐시 반영은 확인됐다.
- KRX 장기수급 등록 동선을 환경설정에만 두지 않는다. 단기투자 누적수급 우측 원천 문구 자체를 현재 종목 KRX CSV의 직접 진입점으로 사용한다.
- 미등록 상태 문구는 `KRX 미등록 · 눌러 불러오기`, 등록 상태는 `KRX 공식 CSV · N일 · 눌러 갱신`으로 표시한다.
- 원천 문구를 터치하면 Android 네이티브 파일선택기를 즉시 열어 현재 종목의 KRX CSV를 가져온다. 가져오기 완료 후 현재 종목의 수급 캐시를 비우고 누적수급을 재계산한다.
- 실제 날짜축, KRX CSV 파서/검증, 종목별 최대 3400거래일 저장, NAVER 최근 보완/fallback, 가격차트 및 5초 현재가 갱신은 변경하지 않는다.
- 장기 누적수급이 안정화된 뒤 음성지원 개선 단계로 넘어간다.
- 배포: Snowball current_v141.zip · versionCode 60187 · versionName `6.0.8-r9-v121-flow-source-direct-import-r23-v141` · WebView cache v=730.

## 2026-10-03 · V121 R24 AUTO LONG FLOW · PACKAGE V142
- 사용자 수동 회원가입/로그인/CSV 다운로드를 기본 경로에서 제거한다. 사용자 개입은 로그인·본인인증·약관 동의·결제·개인 계정 접근·실기기 확인처럼 AI가 대신할 수 없는 단계에만 요청한다.
- 장기 수급 원천 선정의 최우선 기준은 **지속가능성**이다. 정확성·공식성·제공기관 존속 가능성·과거 데이터 유지범위·API/정책 안정성·라이선스·장애/종료 위험을 함께 평가한다. 불안정해지면 교체 가능한 provider adapter 구조로 이전한다.
- KRX 공식 CSV가 이미 등록돼 있으면 계속 최우선 공식 override로 사용한다. 다만 사용자가 KRX CSV를 직접 받아야만 앱이 동작하는 구조는 기본값이 아니다.
- 1개월/3개월은 기존 NAVER 실제수급을 유지한다. **6개월 이상**은 인증 없는 공개 장기수급 API(`maedong.kr /api/v1/stock/{code}/flow`)를 자동 시도해 개인·기관·외국인 **순매수 수량**을 받고, NAVER 최근 구간으로 보완한다. 공개 장기원천 실패 시 기존 NAVER로 자동 fallback한다.
- 공개 장기수급 공급자는 독립 운영 서비스이므로 KRX와 동급의 영구 1차 원천으로 간주하지 않는다. 소스 상태/제공범위/라이선스를 재평가하고, 향후 KRX 공식 Open API 또는 더 지속가능한 공식 경로가 열리면 provider만 교체한다.
- 수급 데이터가 실제로 존재하지 않는 과거 날짜를 합성하거나 화면 전체폭에 맞춰 늘리지 않는다. 가격차트와 동일한 실제 날짜축에서만 누적한다.
- 누적수급 우측 원천표시는 실제 사용 provider를 보여준다: `KRX 공식`, `자동 장기수급`, `NAVER 수급`, `저장 수급`. 자동 provider에서는 사용자를 CSV 파일선택기로 보내지 않는다. KRX CSV는 환경설정의 선택형 공식 override로 남긴다.
- 배포: Snowball current_v142.zip · versionCode 60188 · versionName `6.0.8-r9-v121-auto-long-flow-r24-v142` · WebView cache v=731.


## 2026-10-03 · V121 R25 KRX DIRECT FLOW · PACKAGE V143
- V142의 독립 공개 장기수급 provider는 실기기에서 누적수급 선이 사라지는 회귀가 확인되어 제거한다.
- 6개월 이상은 KRX Data Marketplace 공식 통계 백엔드 `MDCSTAT02302`를 Android 네이티브 POST로 직접 조회한다. `finder_stkisu`로 종목코드→ISIN을 자동 해결한다.
- 조회조건은 일별추이/거래량/순매수이며 기관합계·개인·외국인합계를 사용한다. 720일 이하 청크로 분할해 1년·5년·10년까지 이어받는다.
- KRX 직접조회 실패 시 NAVER 실제수급으로 즉시 fallback하며 기존 수급선을 비우지 않는다. KRX CSV는 선택형 공식 override로 유지한다.
- 사용자의 회원가입·로그인·CSV 작업은 기본 경로에서 요구하지 않는다.
- 배포: Snowball current_v143.zip · versionCode 60189 · versionName `6.0.8-r9-v121-krx-direct-flow-r25-v143` · WebView cache v=732.

## 2026-10-03 · V121 R26 FLOW FAILSAFE · PACKAGE V144
- V143 실기기에서 주봉/장기 구간 누적수급 범례만 남고 외국인·기관·개인 선이 비는 회귀를 확인했다. V143은 실패 기준선으로 기록한다.
- 표시 안정성을 데이터 업그레이드보다 우선한다. 앱 시작/기간 전환 시 저장된 검증 수급과 NAVER 최근 실제수급을 먼저 즉시 표시하고, KRX 장기 조회는 백그라운드 업그레이드로 실행한다.
- KRX 장기 조회가 지연·실패·스키마 변경되어도 현재 보이는 수급선을 지우지 않는다. 성공했을 때만 동일 실제 날짜축의 KRX 데이터로 교체/보강한다.
- KRX 내부 웹 통계 요청은 익명 브라우저 세션 warm-up → 쿠키 유지 → `X-Requested-With: XMLHttpRequest` → outerLoader referer 순으로 요청한다. 401/403/500은 세션을 1회 재생성해 재시도한다.
- 사용자 ID/PW는 요청하거나 저장하지 않는다. KRX 내부 웹 백엔드는 공개 OPEN API와 동일한 영구 계약 API로 간주하지 않으며, 공식 승인형 API나 더 지속가능한 공식 원천 확보 시 provider를 교체한다.
- 장기 구간 상태문구는 KRX 보강 중/실패 fallback 여부를 구분해 실제 원천 상태를 숨기지 않는다.
- 배포: Snowball current_v144.zip · versionCode 60190 · versionName `6.0.8-r9-v121-flow-failsafe-r26-v144` · WebView cache v=733.

## 2026-10-03 · V121 R27 FLOW RESTORE + LONG RANGE · PACKAGE V145
- V144 real-device test still showed the weekly cumulative-flow area blank. V144 is therefore a failed baseline for flow visibility.
- Root correction: V144 long-range startup used only the recent mobile NAVER endpoints. V145 restores the previously proven `stock.naver.com/api/domestic/detail/{code}/trend` seed (plus mobile fallbacks) before any long-history upgrade. Long-source work must never delay or erase this visible baseline.
- The anonymous KRX internal-web runtime adapter is no longer the default automatic path. Current 2026-09+ KRX Data Marketplace behavior is treated as authenticated-session dependent. KRX CSV import remains an optional official override and no KRX ID/PW is requested by default.
- For 6 months or longer, a separate background adapter may query Toss Securities public web `fixed-trading-trend` in calendar-year chunks. It uses only real `baseDate` rows with available individual/foreigner/institution net-buy volume. Results earlier than the provider's actual history are not synthesized.
- Provider precedence: registered KRX CSV override > visible NAVER verified seed > successful long-range background augmentation. Failed/short/invalid background results never replace visible data.
- Toss public web data is a provisional large-provider adapter, not an official contracted Tier-1 API. Re-evaluate availability/terms/schema periodically and replace it when a more sustainable official no-user-work source is available.
- Package: versionCode 60191 / versionName `6.0.8-r9-v121-flow-restore-r27-v145` / WebView cache v=734 / `Snowball current_v145.zip`.

## V146 누적수급 렌더링 스코프 오류
- interactive chart와 main data engine이 서로 다른 IIFE/스코프에 있을 때 내부 변수(`state`, `wantedDays` 등)를 직접 참조하지 않는다.
- 화면 렌더러는 공개 브리지/API로만 데이터 엔진 상태를 읽는다.
- 범례만 보이고 수급선이 사라지는 경우 데이터 소스 문제로 단정하기 전에 렌더링 예외/스코프 오류를 먼저 확인한다.
- V146에서 `drawFlowBand`의 cross-scope ReferenceError를 제거했으며 원자료/수급 계산 로직은 변경하지 않았다.

## 2026-10-03 V147 — 조회기간 누적 기준 잠금
- 누적수급 기본 정의는 `조회기간 시작=0`이다. 기간 버튼을 바꾸면 외국인·기관·개인 모두 새 조회기간의 시작점에서 0으로 재기준화하고 실제 일별 순매수 수량을 이후 누적한다.
- 1개월/3개월/6개월/1년/5년/10년은 각각 독립 누적이며, 10년 뷰로 장기 누적 방향을 확인한다.
- 상장 이후 누적은 기본값으로 사용하지 않는다. 장기간 원자료 완전성·분류변경·증자/자사주 등의 영향으로 현재 보유량처럼 오해될 수 있기 때문이다.
- 기간 누적은 `현재 보유량`이 아니라 `선택기간 내 순매수 누적`이다.
- 다음 단계 AI 현재판단 확장은 V147 실기기 확인 후 별도 작업한다.


## 2026-10-03 · V121 R30 FLOW 10Y TRUTH · PACKAGE V148
- V147 실기기에서 1개월/3개월/6개월/1년/5년은 조회기간 시작점 0 기준으로 정상 확인됐다.
- 10년 월봉은 가격차트보다 장기 수급 원자료의 실제 시작일이 늦을 수 있다. V147처럼 가격 시작일부터 첫 수급일까지 색상선을 0으로 이어 그리면 데이터가 있는 것처럼 보이는 착시가 생긴다.
- V148은 공개 장기수급의 검증된 시작점을 2019-04-01로 취급한다. 실제 수급이 시작되기 전 날짜는 0/보간/역산/합성하지 않는다.
- interactive canvas와 legacy flow SVG 모두 첫 실제 수급일 직전에서 0을 시작한다. 조회 시작과 실제 수급 시작의 차이가 14일 이상이면 `실수급 YY.MM~`를 표시한다.
- 10년 장기보강의 연도별 요청은 병렬 처리해 월봉 진입 후 장기수급 완료 시간을 줄인다.
- KRX 원자료가 가장 권위 있는 Tier 1이지만 2026-09 이후 비로그인 내부 호출 거절 사례가 확인되어 사용자 로그인/개인정보 없이 자동 기본 provider로 강제하지 않는다. 공식 승인형 API/안정적 공식 경로가 생기면 provider adapter를 교체한다.
- AI 단기현재판단 확장 기능은 이번 패키지에 넣지 않는다. V148 실기기 확인 후 별도 단계로 진행한다.
- 배포: Snowball current_v148.zip · versionCode 60194 · versionName `6.0.8-r9-v121-flow-10y-truth-r30-v148` · WebView cache v=737.

## 2026-10-03 · V121 R31 FLOW MONTH GAP · PACKAGE V149
- V148의 10년 실제 수급 시작일/데이터 진실성 기준은 유지한다. V147로 롤백하지 않는다.
- 실기기 피드백은 "V147이 상대적으로 더 자연스러워 보인다"는 시각 품질 지적이며, 계산 기준이나 원천을 되돌리라는 의미가 아니다.
- 월봉 10년에서 실제 수급 시작 전 구간은 외국인/기관/개인 색상선이나 합성 0값을 그리지 않는다. 대신 옅은 회색 no-data 영역, 회색 점선 기준선, `수급자료 없음` 문구로 구분한다.
- 첫 실제 수급일에 세로 점선 경계를 두고, 세 색상 누적선은 실제 수급 시작점의 0부터 시작한다.
- 1개월/3개월/6개월/1년/주봉의 데이터원천·누적계산·기간연동·표시는 변경하지 않는다.
- AI 단기현재판단 확장은 월봉 표시 실기기 확인 후 다음 단계에서 진행한다.
- 배포: Snowball current_v149.zip · versionCode 60195 · versionName `6.0.8-r9-v121-flow-month-gap-r31-v149` · WebView cache v=738.

## V150 controlled V147 runtime restore (2026-10-03)
- User requested using the exact earlier program rather than recreating the preferred monthly graph.
- Runtime chart/data code is restored from V147 exactly; V148/V149 monthly no-data visualization experiments are rolled back from runtime.
- V147 cumulative-flow rule remains locked: each selected period starts cumulative net buy at 0 and accumulates only that selected period's actual daily net-buy values.
- This is a controlled forward-version package (versionCode 60196) so it installs over later builds without uninstalling or clearing local app data.
- AI current-judgment expansion remains a separate next step after real-device confirmation.

## 2026-10-03 · V151 SHORT ACCUMULATION AI
- Base is V150 controlled V147 runtime restore. The cumulative-flow graph/data runtime is frozen; this version changes the AI short-current-judgment layer only.
- `AI 단기 현재 판단` now follows the selected period and computes dominant accumulator, cumulative net-buy quantity, recent cumulative slope, positive-net-buy day ratio, price change, and period-turnover absorption proxy.
- The absorption proxy is explicitly **not** issued-share/free-float ownership percentage.
- The card combines `NOONTANGI_INFO_ENGINE` evidence with cached public-news cross-checks from the existing native ExternalInfo bridge. It classifies company/theme, new-business expansion, turnaround/profit improvement, demand/order growth, and risk/counterevidence.
- `최신자료 포함 재분석` refreshes external public evidence; automatic refresh is limited to once per six-hour bucket per stock.
- Buyer intent is shown as hypotheses only: rising-expectation accumulation, medium-term inventory/position build, event-led expectation, short-term trading flow, or insufficient evidence. Manipulation/price-rigging is never asserted from flow alone.
- Voice/local AI fast path now answers accumulation-meaning/intent questions from `window.NOONTANGI_SHORT_ACCUM_AI.snapshot()`.
- Regression lock: do not modify V150/V147 chart geometry, flow providers, selected-period cumulative calculation, or monthly visual baseline while iterating on this AI card.

## 2026-10-04 V152 — 불주댕이 국내주식 중심 + 글로벌 전달경로
- 사용자의 실제 투자 무대는 국내 개별주식이므로 불주댕이의 기본 관점을 `한국 투자자/국내주식`으로 고정한다.
- 다만 한국 증시는 수출·환율·외국인 수급·글로벌 산업사이클 민감도가 높으므로 미국/중국/글로벌 정보를 줄이는 것이 아니라 `글로벌 원인 → 한국시장 전달경로 → 업종 → 개별종목`으로 연결해 우선순위를 매긴다.
- 특정 인물 이름을 하드코딩하지 않고 직위·기관·행동을 추적한다. 중앙은행/정부/규제기관/기업경영진의 1차 발언·공식행동을 코어로 두고, 정책의도를 전달하는 특급 메신저·Top-tier 하우스뷰는 보조 범위로 둔다.
- 자동탐지 쿼리는 6개 영역으로 분리한다: 국내 거시/금융정책, 국내 산업정책, 국내 기업행동, 미국→한국, 중국/아시아→한국, 메신저/하우스뷰.
- `넓게 수집 → 후단 랭킹`으로 변경한다. 제목 단계에서 과도하게 버리지 않고 국내 영향도, 출처 신뢰도, 1차행동성, 신선도, 섹터 연결성을 기준으로 우선순위를 정한다.
- 자동카드는 역할/국내직접·글로벌→한국/채널/테마/제목기반 어조변화/AI 1차 이면가설/한국시장 전달경로/다음 검증 포인트를 표시한다. 제목·RSS 설명 기반 분석은 낮은 확신의 가설이며 원문·직전 발언·예산/계약/자금/수급 확인 전 사실로 승격하지 않는다.
- 수집 상태(마지막 시각, 쿼리 성공수, 원수집/선별, 국내/글로벌, 공식기관, 메신저)를 화면에 표시하고 `지금 재확인`을 제공한다.
- 앱 포그라운드에서는 약 30분 간격으로 보강하고 기존 06:30/12:00/16:30/22:00 기준점도 유지한다. 앱 완전 종료 중에는 서버 백그라운드 감시를 가장하지 않고 다음 실행/복귀 때 보충한다.
- V151 단기 누적수급/AI 현재판단 및 V150의 V147 수급 런타임은 변경하지 않는다.
- 배포 기준: versionCode 60198 / versionName `6.0.8-r9-v121-firemouth-kr-global-r34-v152` / WebView cache `v=741`.

## 2026-10-04 · V153 FIREMOUTH LIST + NATURAL SELECTED READ
- 불주댕이 최근 항목의 첫 화면은 `날짜 + 핵심 내용 한 줄`만 표시한다. 발언자/기관/출처/분류/가설/한국시장 전달경로/다음 확인/원문은 항목을 탭한 뒤 펼쳐지는 상세 영역에 둔다.
- 자동탐지 항목이 하나라도 있으면 내장 기본 브리핑은 첫 목록에서 숨기고 자동데이터를 우선한다. 자동데이터가 없을 때만 기본 브리핑을 fallback으로 사용한다.
- 하루 5건은 최소 목표 성격의 운영값이며 고정 quota가 아니다. 최근 72시간 후보 중 품질 기준을 우선하고, 오늘 고품질 후보가 5건 미만일 때만 동일 날짜의 중간 중요도 후보까지 단계적으로 완화한다. 신뢰도/중복/한국시장 연결 기준은 유지하며 저품질 콘텐츠로 숫자를 채우지 않는다.
- 수집축은 국내 한국은행, 국내 금융정책, 국내 산업정책, 국내 기업행동, 국내 정책결정의 5축과 미국→한국, 중국→한국, 메신저/하우스뷰를 합친 8축으로 세분화한다. 발견 RSS는 최근 3일 조건을 사용하고 쿼리당 최대 10건을 읽는다.
- `선택읽기`는 화면 문자를 그대로 낭독하지 않는다. `원문`, `출처`, `가설 A/B/C`, `표면적 의미`, `판단 한계` 같은 UI 라벨을 제거하고 핵심 내용·가능성·확인사항을 자연스러운 문장으로 재구성한다.
- 선택읽기 마지막에는 해당 내용이 투자에 주는 시사점을 1~3문장으로 덧붙인다. 매수/매도 단정 대신 확인할 지표, 한국시장 전달경로, 관련 업종/종목, 실적/수급/공시 확인과 주가 선반영 여부를 안내한다.
- Regression lock: V150/V147 누적수급 런타임 및 V151 `AI 단기 현재 판단` 계산 로직은 변경하지 않는다.
- 배포: Snowball current_v153.zip · versionCode 60199 · versionName `6.0.8-r9-v121-firemouth-list-voice-r35-v153` · WebView cache `v=742`.


## 2026-10-04 · V154 FIREMOUTH FINAL OWNER FIX
- V153 실기기 피드백을 기준으로 `반영 완료` 판정을 취소하고 미반영 회귀로 처리한다. V153 소스에는 목록/자연읽기 코드가 있었지만, 기존 렌더러가 recent list를 다시 그리거나 선택읽기가 이전 focus를 유지할 경우 실제 화면에서 새 동작이 보장되지 않는 구조였다.
- 불주댕이 목록은 최종 렌더 뒤에도 final owner가 `#fm107RecentList`를 감시한다. 구형 `article.fm107-recent`가 다시 생성되면 즉시 `details` 목록으로 변환하고, 닫힌 행에서는 `날짜 + 핵심 한 줄` 이외의 상세를 강제 숨김한다.
- 항목을 열면 다른 항목은 닫아 한 번에 하나의 상세만 펼친다. 상세 데이터 자체는 삭제/축약하지 않는다.
- 선택읽기는 현재 active surface 밖의 과거 focused card를 사용하지 않는다. 불주댕이에서는 열린 상세 행을 최우선, 없으면 화면 중앙에 가장 가까운 목록 행을 읽는다. 핵심 내용/가능성/확인사항을 자연어로 읽고 마지막 투자 활용 포인트를 유지한다.
- V150/V147 누적수급 런타임과 V151 AI 단기현재판단 계산은 변경하지 않는다.
- 배포: Snowball current_v154.zip · versionCode 60200 · versionName `6.0.8-r9-v121-firemouth-owner-fix-r36-v154` · WebView cache `v=743`.

## V155 2026-10-04 — 불주댕이 렌더 소유자 재수정
- V154는 소스상 목록화 코드가 존재했지만 실기기에서 기존 상세카드와 거의 동일하게 보였으므로 실패로 판정한다.
- V155부터 `최근 영향력 인사 발언·행동`의 실제 생성 함수가 처음부터 `날짜 + 핵심 한 줄` 버튼행을 생성한다. `<details>` 기본동작이나 사후 DOM 변환에 의존하지 않는다.
- 상세 분석 DOM은 별도 `v155-fire-detail`로 생성하고 CSS에서 기본 `display:none !important`로 잠근다. 사용자가 목록행을 탭한 경우에만 `.is-open`을 부여해 상세를 보인다. 한 번에 하나만 연다.
- 선택읽기는 UI 라벨/가설 A·B·C 표기를 읽지 않고 핵심 내용→의미→가능성→확인사항→투자 활용 순으로 문장을 재구성한다.
- V150/V147 누적수급 런타임 및 V151 AI 단기현재판단 계산은 변경하지 않는다.

### V156 Firemouth list-only first screen (2026-10-04)
실기기에서 V154/V155가 여전히 기존 대형 설명 블록을 먼저 보여 사용자가 "그대로"라고 판정했다. 원인은 최근 목록 렌더만 축약하고 부모 `panelHtml()`의 hero/status/KPI/analysis sections를 첫 화면에 계속 남겨둔 것이었다. V156은 불주댕이의 랜딩 뷰 소유권을 명확히 분리해, 고정 불주댕이 헤더 아래에는 `날짜 + 핵심 한 줄` 목록만 보이게 한다. 정적 철학/수집상태/분석기록/10단계/기관공통행보/투자안내 블록은 DOM 호환성을 위해 유지하되 랜딩 뷰에서는 숨긴다. 행을 누르면 기존 상세 분석만 해당 행 내부에서 펼친다. 재진입 시 모든 행은 닫힌 상태로 초기화한다. versionCode 60202 / versionName `6.0.8-r9-v121-firemouth-list-only-r38-v156` / WebView cache v745.

## 2026-10-04 · V157 FIREMOUTH 10-STEP CLOSE + SOFTER VOICE
- 실기기 스크린샷에서 `10단계 기록으로 저장`으로 연 편집창의 자체 헤더/닫기 버튼이 공통 설산 헤더 뒤로 들어가 사용자가 닫는 경로를 찾기 어려운 것을 확인했다.
- V157은 10단계 편집 레이어를 공통 설산 헤더 아래, 하단 내비게이션 위의 실제 사용 가능 영역에 고정한다. 편집창 내부 상단 `닫기`와 하단 `닫기 / 저장 후 닫기`를 sticky로 유지해 스크롤 위치와 무관하게 종료 경로를 보장한다.
- 최근 발언 상세에서 `10단계 기록으로 저장`을 실행한 경우 저장 성공 후 편집창을 닫고, 원래 선택했던 불주댕이 상세 행을 다시 펼쳐 사용자가 문맥을 잃지 않게 한다. 새 분석/기존 분석 수정은 기존 흐름을 유지한다.
- 선택읽기/AI대화의 로컬 Android TTS는 음색 엔진 자체를 교체하지 않고, 가능한 한국어 여성·로컬·고품질 음성을 우선 선택한 다음 prosody를 적용한다. 순서를 `voice 선택 → speechRate 0.96 → pitch 0.88`로 바꿔 일부 엔진의 voice 설정 후 prosody 초기화를 피하고, 기존보다 약간 느리고 낮은 톤으로 고역 자극을 줄인다.
- V153 이후의 `UI 라벨을 읽지 않고 핵심을 자연어/라디오식으로 재구성 + 투자 활용 포인트` 규칙은 그대로 유지한다.
- Regression lock: V156 불주댕이 첫 화면 리스트 전용 구조, V150/V147 누적수급 런타임, V151 `AI 단기 현재 판단` 계산은 변경하지 않는다.
- 배포 기준: Snowball current_v157.zip · versionCode 60203 · versionName `6.0.8-r9-v121-firemouth-close-voice-soft-r39-v157` · WebView cache `v=746`.


## 2026-10-05 · V158 REFERENCE VOICE CADENCE
- 2026-10-05 사용자가 직접 녹음해 제공한 약 30초 여성 음성을 선택읽기/AI대화의 우선 레퍼런스로 삼는다. 목표는 특정 화자 복제가 아니라, 밝고 또렷하지만 귀를 찌르지 않는 독립적인 로컬 여성 TTS의 분위기와 리듬을 맞추는 것이다.
- V157의 `voice 선택 → prosody 적용` 순서는 유지한다. 한국어 여성·로컬·고품질 음성 우선 선택도 그대로 유지한다.
- speechRate는 0.96에서 0.95로 아주 소폭 느리게 조정하고 pitch 0.88은 유지한다. 피치를 더 과하게 낮추기보다 문장 호흡과 출력 자극을 다듬는 쪽을 우선한다.
- 한 번에 긴 문단 전체를 읽던 TTS를 문장 우선 최대 약 260자 단위로 나눠 큐에 넣고, 문장 사이에 85ms의 짧은 무음 간격을 둔다. UI 줄바꿈/문단 경계도 음성 경계로 보존해 문장 끝이 급하게 붙는 느낌을 줄인다.
- 각 TTS utterance의 내부 볼륨 파라미터를 0.94로 설정해 휴대폰 스피커에서 전진하는 고역 자극을 약간 낮춘다. 시스템 미디어 볼륨 자체는 변경하지 않는다.
- 회귀 잠금: V157 10단계 기록 닫기/저장 후 원상복귀, V156 불주댕이 리스트 전용 첫 화면, V150/V147 누적수급 런타임, V151 AI 단기현재판단 계산은 변경하지 않는다.
- 배포 기준: Snowball current_v158.zip · versionCode 60204 · versionName `6.0.8-r9-v121-reference-voice-r40-v158` · WebView cache `v=747`.


## 2026-10-05 · V159 REFERENCE VS CURRENT VOICE SOFT-LOW RECALIBRATION
- V158 실기기 피드백에서 선택읽기/AI대화 음성이 여전히 강하고 귀에 거슬린다고 판정했다. 따라서 0.01 단위 미세조정을 반복하지 않고, 참고 음성과 현재 프로필의 차이를 기준으로 엔진·음성 후보·prosody·호흡을 한 번에 재조정한다.
- 사용자가 제공한 약 30초 참고 음성은 밝고 또렷한 여성 톤이지만 고역 에너지와 문장 끝 압박이 과하지 않은 방향으로 사용한다. 분석 기준값은 F0 중앙값 약 262Hz, 유성구간 10~90% 약 213~343Hz이며, 이는 특정 화자 복제가 아니라 목표 분위기/리듬 비교용 수치다.
- 갤럭시에서는 Samsung 로컬 TTS(`com.samsung.SMT`)를 먼저 시도한다. 기기/펌웨어에서 해당 엔진을 사용할 수 없으면 시스템 기본 TTS로 1회 자동 fallback해 읽기 기능 자체가 깨지지 않게 한다.
- 한국어 voice 선택은 단순 최고 quality 우선에서 벗어나, 가능한 경우 로컬 여성 + 차분/저음 힌트 + 두리/voice-1 계열을 우선한다. 지우/voice-5 계열은 fallback으로 남기되 차분한 후보보다 강제로 앞세우지 않는다.
- prosody를 `speechRate 0.90 / pitch 0.78 / utterance volume 0.86`으로 크게 재조정한다. V158 대비 속도·피치·출력을 모두 의미 있게 낮춰 S23 Ultra 스피커에서의 전진감·금속성·치찰 자극을 줄이는 것이 목적이다.
- 긴 읽기는 문장/절 우선 약 190자 이하로 나누고 구간 사이 140ms 호흡을 둔다. 너무 긴 문장과 급하게 붙는 말끝을 함께 줄인다.
- 선택읽기의 의미 재구성(라벨 제거, 핵심→가능성→확인사항→투자 활용)과 AI대화의 문맥 연결은 변경하지 않는다.
- 회귀 잠금: V157 10단계 기록 닫기/저장 후 원상복귀, V156 불주댕이 리스트 전용 첫 화면, V150/V147 누적수급 런타임, V151 AI 단기현재판단 계산은 변경하지 않는다.
- 배포 기준: Snowball current_v159.zip · versionCode 60205 · versionName `6.0.8-r9-v121-voice-softlow-r41-v159` · WebView cache `v=748`.

## 2026-10-05 · V160 USER-OWNED AI VOICE TUNER
- 음성 개선은 더 이상 `새 APK에서 고정 pitch/rate를 조금씩 변경 → 실기기 재확인`을 반복하는 방식으로 운영하지 않는다. 환경설정에서 사용자가 직접 듣고 조절하는 구조를 기본으로 한다.
- 환경설정의 첫 번째 메뉴는 `AI 목소리`이며, 기존 `계좌·기준값 / 운영 변수 / 백업·복원 / 앱 관리`는 뒤에 유지한다.
- 음성 프로필은 여성 3종(`여성 1 · 부드러운 저음`, `여성 2 · 차분하고 낮게`, `여성 3 · 또렷하고 자연스럽게`)과 남성 2종(`남성 1 · 차분한 중저음`, `남성 2 · 낮고 굵은 톤`)을 제공한다.
- 사용자가 직접 조절하는 값은 `속도 / 높낮이 / 톤(따뜻·차분↔밝고 선명) / 목소리 굵기(얇음↔굵음) / 부드러움`이다. 변경값은 기기 SharedPreferences에 즉시 저장한다.
- `미리듣기`는 동일한 고정 샘플 문장을 사용해 프로필과 슬라이더를 반복 비교하도록 한다. `기본값 복원`은 V159 soft-low 기준에 가까운 여성1·속도0.90·높낮이0.78·차분톤·약간 굵게·부드러움72로 복귀한다.
- Android TextToSpeech가 직접 노출하는 것은 주로 rate/pitch/voice/utterance volume이므로 `톤/굵기/부드러움`은 음성 후보 선택 + pitch/rate + utterance 출력 + 구간 길이/호흡을 조합해 근사한다. 향후 신경망 TTS 엔진으로 교체하더라도 동일한 설정 UI/사용자 프리셋 계약을 유지한다.
- Samsung 로컬 TTS 우선 + 시스템 기본 TTS fallback은 유지한다. 기기에서 노출되는 한국어 voice 이름/패키지가 다를 수 있으므로 프로필은 특정 voice가 없을 때도 prosody offset으로 차이를 유지한다.
- 회귀 잠금: V157 10단계 기록 닫기/저장 후 복귀, V156 불주댕이 리스트 전용 첫 화면, V150/V147 누적수급 런타임, V151 AI 단기 현재판단은 변경하지 않는다.
- 배포: `Snowball current_v160.zip` · versionCode 60206 · versionName `6.0.8-r9-v121-voice-tuner-r42-v160` · WebView cache v749.


## 2026-10-05 · V162 FIREMOUTH NEWS-LIST REFERENCE
- User supplied a finance-news list screenshot as the visual reference for the Firemouth first screen. The goal is faster scanning, not copying another service or changing the analysis engine.
- The landing list is now a flat news-style feed: headline (up to 2 lines) + source/time + scope metadata. The old large left date column and separate rounded card for every item are removed in favor of thin separators.
- Add four compact filters: `주요 이슈`, `최신`, `국내 직접`, `글로벌→한국`. `주요 이슈` preserves the existing Firemouth priority ranking. The other views sort/filter the same collected evidence without changing collection or scoring.
- Feed items without a real source thumbnail do not receive fabricated images.
- Tapping a row still opens the V155/V156 detailed analysis. V157 10-step editor close/save-return, selected reading, AI dialogue context, V152 collection/quality rules, V150/V147 cumulative flow and V151 short-term AI judgment remain regression-locked.
- Distribution: Snowball current_v162.zip · versionCode 60208 · versionName `6.0.8-r9-v121-firemouth-newslist-r44-v162` · WebView cache v=751.


## 2026-10-05 · V163 불주댕이 최신수집 정상화
- V162 실기기에서 최신자료가 나오지 않고 9월 말 기본 브리핑이 보이던 직접 원인은 `renderFiremouthAuto()`가 호출하는 `fireDisplayItems`와 `ensureFireStatus` 보조함수가 실제 배포 코드에 누락되어 자동수집 부팅 경로가 중단된 것이었다. V163은 두 함수를 복구하고 자동수집 실패가 UI fallback 자료로 가려지지 않게 한다.
- 첫 화면의 라이브 목록은 최근 24시간을 최신성 기준으로 보고 최대 72시간까지 품질 fallback을 허용한다. 72시간 밖 자료와 날짜를 파싱할 수 없는 항목은 라이브 목록에서 제외한다.
- 자동수집 데이터가 0건이면 9/28~9/30 정적 기본 브리핑을 최신자료처럼 다시 보여주지 않는다. 대신 `최신 자동수집 자료 없음`과 재확인 경로를 명확히 표시한다.
- 상단 상태줄에 `마지막 성공 업데이트 / 최근24시간 건수 / 성공 수집영역 / 누락·stale 감지 / 재확인`을 작게 노출한다. 일부 쿼리 실패는 `일부 누락`, 전체 실패는 `수집 실패`, 성공했지만 24시간 후보가 없으면 `새 후보 없음`으로 구분한다.
- 앱 업데이트 후 V163 스키마 최초 실행에서는 이전 성공시각을 재사용하지 않고 한 번 즉시 재확인한다. 이후에는 기존 기준시각 + 약 30분 주기 + 화면 진입/복귀 시 stale 검사로 갱신한다.
- Google News RSS 질의는 과도한 AND 나열 대신 OR 기반 그룹으로 바꾸고, 한 질의당 최대 18개 결과를 읽어 최신자료 회수율을 높인다.
- V162 `최신` 필터는 화면의 지역화 날짜 문자열을 다시 파싱하지 않고 항목 원 timestamp를 사용해 실제 최신순으로 정렬한다. 출처도 `공식/기관` 같은 등급명이 아니라 실제 매체/기관명을 표시한다.
- 회귀 잠금: V162 뉴스형 목록, V157 10단계 기록 닫기/저장 후 원래 상세 복귀, V161 실제 남녀 음성 분리·사용자 튜너, V150/V147 누적수급, V151 AI 단기현재판단.

## 2026-10-05 · V164 FIREMOUTH DEEP READ / AI OWNS THE RESEARCH
- 수정 전 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`, V163 마스터 DOCX를 먼저 리뷰하고 V162 뉴스형 첫 화면, V163 최신수집, V157 10단계 복귀, V161 음성, V150/V147 누적수급, V151 단기 AI 잠금을 확인한 뒤 수정했다.
- 불주댕이의 최상위 목적은 `AI 정보수집 → 기사를 전부 다 정독하고 반영 → 핵심 요약 → 해설·복수가설 → 외부자료 자동 교차검증 → 가장 가능성 높은 결론/신뢰도/반대근거 → 한국시장 투자 연결 컨설팅`이다.
- `기사를 전부 다 정독하고 반영`은 제목·RSS 설명만 보는 것을 금지한다는 뜻이다. 접근 가능한 기사/원문 전체에서 문맥, 수치, 인용, 전제, 반론, 조건, 뉘앙스를 읽어 분석에 반영한다. 원문 전체 접근이 막히면 전체를 읽은 것처럼 가장하지 않고 `원문 일부 접근` 또는 `원문 전체 접근 불가`를 표시하고, RSS·공식자료·독립보도 등 대체 경로를 AI가 자동으로 교차검증한다.
- 상세 기본 순서는 ① 기사 전체 정독·핵심 요약 ② 해설 및 가설 ③ AI 외부자료 검증 ④ AI 결론(신뢰도 포함) + 반대근거/무효화 조건 ⑤ 투자 연결 컨설팅이다.
- `다음 확인`, `원문을 직접 확인`, `실제 금리/환율 반응을 확인해야 한다`처럼 조사 책임을 사용자에게 넘기는 문구를 불주댕이 상세의 기본 흐름에서 제거한다. 필요한 확인은 AI 자동검증 항목으로 전환하고, 접근 불가 자료만 상태로 명시한다.
- 제목/기관 키워드만으로 고정 템플릿을 붙이는 분석을 금지한다. 특히 `한국은행`이라는 단어만으로 금리·유동성으로 분류하지 않는다. 본문에서 금 매입/보유·외환보유액이 주제라면 `금·외환보유`로 분류하고 그 주제에 맞는 증거와 가설을 사용한다.
- Android native `SnowballExternalInfo.fetchArticle()`를 추가해 공개 기사 HTML 원문 접근을 먼저 시도하고, 전체/부분/접근불가 상태를 구분한다. 심층분석은 상위 이슈를 백그라운드에서 미리 처리하고, 사용자가 상세를 열 때 해당 건을 즉시 보강한다.
- 교차검증은 같은 제목 반복이 아니라 실제 출처를 중복 제거해 독립 출처 수를 계산하고, 본문 정독 내용과 충돌하는지까지 반영한다. 결론은 원문 접근 수준과 독립 출처 수에 따라 신뢰도를 낮추거나 높인다.
- 선택읽기는 V164 상세에서 `핵심요약 → 해설/가설 → 외부자료 검증 결과 → AI 결론/반대근거 → 투자 연결` 순서로 읽는다. UI 라벨 자체를 기계적으로 읽지 않는다.
- 배포: `Snowball current_v164.zip` · versionCode 60210 · versionName `6.0.8-r9-v121-firemouth-deepread-r46-v164` · WebView cache v=753.
- 회귀 잠금: V162 뉴스형 목록/필터, V163 최신수집, V157 10단계 저장 후 원래 상세 복귀, V161 실제 남녀 음성/사용자 튜너, V150/V147 누적수급, V151 AI 단기현재판단은 변경하지 않는다.

## 2026-10-05 · V165 FIREMOUTH RECOVERY GUARD
- 수정 전 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`, V164 마스터 DOCX를 다시 리뷰하고 V162 뉴스형 첫 화면, V163 최신수집, V164 기사 정독/외부검증, V157 10단계 복귀, V161 음성, V150/V147 누적수급, V151 단기 AI 잠금을 확인한 뒤 수정했다.
- V164 실기기에서 심층분석 추가 후 첫 화면이 `표시할 불주댕이 이슈가 없습니다.`로 비는 회귀를 확인했다. V165은 원인 하나를 가정해 임시 덮어쓰기하지 않고, 목록 렌더·timestamp·버전이행·수집예외의 모든 단일 실패지점을 방어한다.
- 기존 `FIRE_STORE` 최신수집 저장값을 버전업 때 삭제하지 않는다. V165 최초 실행은 기존 목록을 먼저 표시하고 백그라운드에서 재수집한다. 성공시각/시도시각을 지워 화면을 공백 상태로 만드는 버전이행을 금지한다.
- live item의 `ts`가 없거나 비정상이면 `pubDate → collectedAt` 순서로 복구하고, 지역/시간대 표기 오차를 고려해 소폭 미래시각을 허용한다. 최신성 기본은 여전히 최근 24시간, 최대 72시간 보완이다.
- 한 항목의 상세 카드 생성이 실패해도 전체 `.map()`이 중단되지 않도록 행 단위 예외격리를 적용한다. 실패 항목은 제목·출처·시각이 남는 `자료 복구` 최소행으로 표시하고 다음 수집/심층분석에서 자동 보강한다.
- 상단 수집상태는 항목 렌더보다 먼저 생성한다. 수집 Promise 내부 예외도 `FIRE_STATS.error`와 상태표시에 기록해 조용히 사라지지 않는다.
- V164 최상위 철학 `AI 정보수집 → 기사를 전부 다 정독하고 반영 → 요약 → 해설/복수가설 → 외부자료 자동검증 → AI 결론/반대근거 → 투자 연결 컨설팅`은 그대로 유지한다.
- 배포: `Snowball current_v165.zip` · versionCode 60211 · versionName `6.0.8-r9-v121-firemouth-recovery-r47-v165` · WebView cache v=754.


## 2026-10-05 · V166 FIREMOUTH PRIORITY RESTORE
- 수정 전 V165 기준 PROJECT_HANDOFF / UI_STANDARD / SCENARIO_LOCK / 마스터 DOCX를 재리뷰했다.
- V165 실기기에서 `상태줄 빈 껍데기 + 표시할 불주댕이 이슈가 없습니다`가 계속되는 증상을 코드와 V163 정상 기준으로 비교했다.
- 실제 원인은 V164 심층분석 패치 과정에서 `firePriority()` 정의가 누락됐는데 V165의 `fireDisplayItems`, `mergeFire`, `collectFire`, `renderFireBell`, `ingestFireToEngine`가 계속 호출해 ReferenceError가 발생한 것이다.
- V163의 단일 우선순위 소유자 로직을 복원하고 timestamp는 `fireRepairTs()` 결과를 사용한다. 기존 `FIRE_STORE`는 보존하고 V166 schema 전환 때 1회 강제 재수집한다.
- V164의 `기사를 전부 다 정독하고 반영 → 핵심요약 → 해설/복수가설 → AI 외부자료 자동검증 → AI 결론/반대근거 → 투자 연결 컨설팅`은 변경하지 않는다.
- 배포: `Snowball current_v166.zip` · versionCode 60212 · versionName `6.0.8-r9-v121-firemouth-priority-r48-v166` · WebView cache v=755.

## 2026-10-05 · V168 FIREMOUTH FIRST-OPEN AUTO REFRESH / SIMPLE EXPLAIN
- 수정 전 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`, `NOONTANGI_DATA_SOURCE_STANDARD_V1.md`, V167 마스터 DOCX를 선리뷰했다.
- 불주댕이는 앱 실행 후 **처음 열리는 1회에 한해** 사용자가 `재확인`을 누른 것과 같은 최신수집을 자동 실행한다. 같은 앱 실행 세션에서 두 번째 진입부터는 기존 stale/주기 기준을 사용하고, 수동 `재확인` 버튼은 계속 유지한다.
- V167의 6개 설명칸은 과도하게 나뉘고 내용이 반복되는 것으로 판단해 사용자 화면을 `기사 내용과 뜻 / AI 의견 / 투자에 연결하면` 3개 구역으로 단순화한다.
- `기사 내용과 뜻`은 접근 가능한 기사를 전부 다 정독하고 반영한 요약과 쉬운 설명을 중복 제거해 한 흐름으로 보여준다.
- `AI 의견`은 외부자료 자동 교차검증·AI 결론·주의할 반대근거를 자연스럽게 합쳐 보여준다. 근거가 없으면 숨은 의도를 억지로 만들지 않고 `추가로 단정할 근거가 없다`는 쪽을 선택한다. 사용자 화면에서 `가설 A/B/C` 같은 참고서식 표현을 쓰지 않는다.
- 기사에서 확인된 사실, 회사가 밝힌 목표/추진계획, 외부자료로 확인된 사실을 구분한다. `상장 목표/추진`을 `상장 확정/승인`으로 바꾸지 않는다.
- V167 이전 심층분석 캐시는 V168의 최종 문구로 재사용하지 않는다. 상세를 열면 `deepVersion=V168` 기준으로 기사 정독·교차검증을 다시 수행해 새 3단 구조로 갱신한다.
- 선택읽기는 `기사 내용과 뜻 → AI 의견 → 투자에 연결하면` 세 부분을 자연스럽게 이어 읽고 UI 라벨을 기계적으로 반복하지 않는다.
- V164의 `기사를 전부 다 정독하고 반영` 및 AI 조사책임 원칙, V163/V166 최신수집·우선순위, V157 10단계 저장 후 복귀, V161 음성튜너, V150/V147 누적수급, V151 단기 AI 판단은 회귀 금지한다.


## 2026-10-05 · V171 V168 BASELINE RESTORE
- 수정 전 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`, `NOONTANGI_DATA_SOURCE_STANDARD_V1.md`, V168 마스터 DOCX를 선리뷰했다.
- 실기기에서 V169~V170 이후 불주댕이가 기사 목록을 최초부터 불러오지 못하고 `수집 준비/재확인 중`에 머무는 회귀를 확인했다.
- 사용자 지시에 따라 런타임은 `Snowball current_v168.zip`을 기준으로 정확히 되돌린다. V169/V170의 불주댕이 런타임 변경은 이번 패키지에 포함하지 않는다.
- Android 설치 업데이트를 위해 버전만 전진시킨다: versionCode 60217 / versionName `6.0.8-r9-v121-v168-restore-r53-v171` / WebView cache `v=760`. 앱 데이터 삭제나 재설치를 요구하지 않는다.
- V168 기준 기능: 앱 실행 세션당 최초 불주댕이 진입 1회 자동 재확인, `기사 내용과 뜻 / AI 의견 / 투자에 연결하면` 3단 상세, 기사 정독·외부자료 교차검증, 근거 없는 억지 가설 금지.
- 이후 수정은 이 V171(V168 runtime restore)을 새 기준선으로 삼고 실기기에서 기사 목록 자동수집이 정상임을 확인한 뒤 진행한다.


## 2026-10-05 · V172 FIREMOUTH ARTICLE READER / PORTFOLIO TABS
- 수정 전 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`, `NOONTANGI_DATA_SOURCE_STANDARD_V1.md`, V171 마스터 DOCX를 선리뷰했다. V171 실기기에서 기사 목록 최초 표시가 정상임을 확인한 뒤 이 기준선 위에서만 수정한다.
- 불주댕이 상세의 AI 분석 기능은 이번 단계에서 중단한다. 기사 원문 접근이 가능하면 전부 정독하고 `내용 요약`과 `기자가 전달하려는 핵심`만 사용자에게 보여준다. AI 의견·투자 연결·숨은 의도·가설·외부교차검증 결론 UI는 삭제하며 AI 분석은 향후 별도 단계에서 다시 설계한다.
- 원문 전체 접근이 막히면 전체 정독으로 가장하지 않고 공개된 기사 요약 범위만 정리했다고 짧게 표시한다.
- 첫 화면 분류는 `주요 이슈 / 보유종목 / 관심종목 / AI추천 / 글로벌` 5개로 고정한다. `주요 이슈`는 기존 우선순위를 그대로 유지한다.
- `보유종목`은 실제 `noontangi_v1230i_account_holdings` 보유자산을 사용하고, `관심종목`은 `noontangi_photo3_watchlist`, `AI추천`은 기존 단기 종목선택 AI추천 목록을 사용한다. 각 분류는 종목명/코드 직접기사뿐 아니라 공시·분기실적·매출·영업이익·수주·계약·증설·투자와 해당 종목 연관 테마 기사도 함께 수집/필터한다.
- 기존 `글로벌→한국` 탭은 `글로벌`로 이름과 의미를 단순화한다.

## 2026-10-06 · V173 FIREMOUTH ARTICLE READER / AI RECOMMEND SYNC
- 수정 전 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`, `NOONTANGI_DATA_SOURCE_STANDARD_V1.md`, V172 마스터 DOCX를 선리뷰했다. V171의 기사 목록 최초 표시 정상 동작과 V172의 5개 분류 탭을 회귀 기준으로 유지한다.
- `AI추천`은 이름만 AI추천이 아니라 **단기투자 화면의 실제 AI 추천 종목 목록**과 동일한 종목군만 사용한다. 실제 추천 목록을 읽지 못한 경우 임의의 고정 종목을 대신 넣지 않는다.
- `AI추천` 기사 수집은 해당 추천 종목의 기업공시, 분기 실적, 매출, 영업이익, 순이익, 수주, 계약, 증설, 투자, 신규사업, 업황 기사와 해당 종목에 연결된 테마/산업 기사를 별도 검색해 포함한다.
- 기사 상세의 `내용 요약`과 `기자가 전달하려는 핵심`을 따로 나누지 않고 `기사 정리` 한 문단으로 자연스럽게 연결한다. 제목을 그대로 복사해 요약처럼 보여주는 것을 금지한다.
- 원문 본문을 충분히 가져오지 못한 경우 제목을 재진술하지 않고, 원문 접근이 가능해지면 다시 읽어 정리한다는 상태만 표시한다.
- AI 심층분석·투자 의견 기능은 V172 기준대로 계속 보류한다. 현재 상세은 기사 정독과 기사 자체의 핵심 정리까지만 수행한다.
- 배포: `Snowball current_v173.zip` · versionCode 60219 · versionName `6.0.8-r9-v121-firemouth-reader-r55-v173` · WebView cache v=762.

## 2026-10-06 · V174 FIREMOUTH CLEAN COLLECT / STRICT AI RECOMMEND / ARTICLE RESOLVE
- 수정 전 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`, `NOONTANGI_DATA_SOURCE_STANDARD_V1.md`, V173 마스터 DOCX를 선리뷰했다. V171에서 실기기 확인된 기사 목록 최초 표시와 V173의 `기사 정리` 단일 흐름은 회귀 기준으로 유지한다.
- V173 실기기에서 사용자 화면에 `수집 0/22`, 내부 query ID, TIMEOUT 목록이 그대로 노출된 것을 잘못된 진단 UI로 판단한다. V174부터 내부 수집 통계/실패 ID는 사용자 기본화면에 표시하지 않고 `최신 기사 확인 중 / 최신 확인 완료 / 일부 기사 연결 지연`과 마지막 확인시각, `재확인`만 간단히 보여준다.
- 종목형 검색이 늘면서 20개가 넘는 RSS 요청을 한꺼번에 실행해 수집이 모두 TIMEOUT으로 무너지는 회귀를 막기 위해 수집 동시실행을 최대 4개로 제한한다. 보유·관심·AI추천 검색도 종목별 다중 쿼리가 아니라 각 버킷의 종목/테마를 묶은 대표 검색으로 축소한다.
- 국내 검색이 성공했더라도 글로벌 결과가 0건이면 글로벌 fallback을 별도로 실행한다. `글로벌`은 한국 전달경로가 필수인 `글로벌→한국`이 아니라 연준/ECB/BOJ/PBOC, 글로벌 정책·무역, 빅테크·반도체, 원유·금·달러·국채·월가 등 글로벌 시장 자체의 주요 기사를 수집·표시한다.
- `AI추천`은 단기투자 AI 추천목록의 실제 종목명/코드 직접 일치를 최우선으로 한다. 직접 일치가 없는 테마 기사는 AI추천용 검색 버킷에서 추천종목의 연관 테마가 2개 이상 함께 확인되는 경우만 허용해 `방산`, `반도체` 같은 단일 일반 키워드 기사 오분류를 줄인다. `투자분석 20xx`, `주말`, 일반 종목분석 페이지는 기사 목록에서 제외한다.
- 기사 상세은 AI 분석을 다시 켜지 않는다. 원문 URL 직접 접근 → 언론사 홈페이지 제목 매칭 → 공개 뉴스검색 제목 매칭 순으로 실제 기사 URL을 복구한 뒤 그 기사 본문을 읽어 `기사 정리`를 만든다. 검색결과 snippet 자체를 기사 요약 근거로 사용하지 않는다.
- 배포: `Snowball current_v174.zip` · versionCode 60220 · versionName `6.0.8-r9-v121-firemouth-reader-r56-v174` · WebView cache v=763.

## 2026-10-06 · V175 FIREMOUTH FAST OPEN / ARTICLE LANE
- 수정 전 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`, `NOONTANGI_DATA_SOURCE_STANDARD_V1.md`, V174 마스터 DOCX를 다시 리뷰했다. V171의 `첫 진입부터 기사 목록 표시`, V172~V174의 `주요 이슈 / 보유종목 / 관심종목 / AI추천 / 글로벌`, V173의 `기사 정리` 단일 흐름을 회귀 금지 기준으로 유지한다.
- V174 실기기에서 앱 업데이트 직후 불주댕이를 열면 `최신 확인 중`이 오래 지속되고, 사용자가 재확인을 눌러야 목록이 갱신되며, 같은 시점에 상세 기사를 열면 원문 정독도 `원문 연결 제한`으로 끝나는 문제를 확인했다.
- 직접 원인은 두 가지가 겹친 구조다. 앱 부팅/복구 guard가 불주댕이를 열기 전부터 전체 뉴스검색을 시작했고, 보유·관심·AI추천을 포함한 다수 RSS 검색과 기사 원문 정독이 동일한 `marketExecutor` 대기열을 공유해 사용자가 연 기사 작업이 뉴스검색 뒤로 밀렸다.
- V175부터 앱 시작 시에는 네트워크 수집을 시작하지 않는다. 저장된 `FIRE_STORE`/visible cache를 먼저 즉시 표시하고, 불주댕이를 실제로 처음 여는 시점에 `주요 이슈` 8개 기본축만 1회 갱신한다. V165 recovery guard는 렌더 복구만 담당하고 네트워크 수집을 직접 시작하지 않는다.
- `보유종목 / 관심종목 / AI추천` 수집은 해당 탭을 앱 실행 세션에서 처음 눌렀을 때만 별도 실행한다. `글로벌`은 글로벌 기본축만 별도 갱신한다. 이로써 최초 진입에서 20개 이상 쿼리를 한꺼번에 기다리는 구조를 제거한다.
- 기사 원문 정독은 RSS 뉴스검색과 분리된 `articleExecutor` 전용 스레드풀을 사용한다. 기사 탭을 사용자가 눌렀을 때 뉴스수집이 진행 중이어도 원문 fetch가 검색 대기열 뒤로 밀리지 않는다. 백그라운드 선행정독도 상위 1건만 수행해 사용자 탭 우선권을 보장한다.
- 기사 HTML에서 일반 `<article>/<main>` 추출 전에 JSON-LD `articleBody`를 우선 확인하고, 220자 이상 확보된 실제 본문은 부분정독 자료로 인정한다. 첫 원문 복구가 실패하면 같은 기사에 대해 한 번 자동 재시도한다. 제목/RSS snippet만으로 기사 정리를 완료 처리하지 않는 기준은 유지한다.
- 수동 `재확인`은 현재 탭 기준으로 실행한다. 다른 수집이 이미 진행 중이면 사용자 요청을 버리지 않고 해당 탭 재확인을 1회 예약해 현재 작업 직후 실행한다.
- 배포: `Snowball current_v175.zip` · versionCode 60221 · versionName `6.0.8-r9-v121-firemouth-fastopen-r57-v175` · WebView cache v=764.

## 2026-10-06 · V176 FIREMOUTH QUICK FEED / ARTICLE RESOLVE
- V175 실기기에서 불주댕이 첫 진입이 저장목록이 없을 때 `기사 연결 지연/최신자료 자동수집` 화면으로 오래 머물고, 목록이 뒤늦게 생긴 뒤에도 기사 상세가 원문 정독 대기/재확인 문구에 머무는 문제를 확인했다.
- 최초 진입에 표시 가능한 저장목록이 없으면 국내 광역 2개 검색을 `quick feed`로 먼저 실행해 결과가 생기는 즉시 목록을 만들고, 그 다음 전체 주요이슈 8개 축 갱신을 이어간다. 표시 가능한 기존 자료가 있으면 네트워크 완료를 기다리지 않고 즉시 보여준다.
- 수집 중에는 72시간 기준에 새 항목이 없어도 최대 7일 안의 마지막 정상 저장목록을 임시 표시할 수 있게 해 빈 화면보다 기존 목록을 우선한다.
- 자동 `preEnrichFire` 기사 선읽기를 중단한다. 기사 원문 연결은 사용자가 실제로 펼친 기사만 articleExecutor에서 처리해 숨은 백그라운드 원문 요청이 사용자의 탭을 방해하지 않게 한다.
- Google News RSS wrapper URL은 그대로 기사본문으로 취급하지 않는다. 제목을 Google News 검색/Naver 뉴스검색에서 매칭해 실제 언론사 기사 URL을 복구한 뒤 본문을 추출하고, 언론사 홈페이지 제목매칭은 후순위 fallback으로 사용한다.
- 원문 전체 연결에 실패한 경우 `자동 재확인 중`을 무한 반복하지 않고 `원문 전체를 불러오지 못해 기사 정리를 보류했습니다`로 끝내며 원문 보기 링크는 유지한다.
- 배포: `Snowball current_v176.zip` · versionCode 60222 · versionName `6.0.8-r9-v121-firemouth-quickfeed-r58-v176` · WebView cache v=765.

- V176 최종 안정화에서 검색 네이티브 timeout(3.0s connect + 4.5s read)과 JS 대기시간(quick 10s / 일반 11s)을 일치시켜, 네이티브 응답이 정상 범위인데 JS가 먼저 TIMEOUT 처리하던 경쟁조건을 제거한다. quick feed 쿼리도 OR 중심 광역식으로 완화한다.
- 기사 URL 복구는 모바일에서 한 탭이 무한 대기하지 않도록 한 번에 하나의 뉴스검색 포털만 사용하고, 실제 후보 URL을 찾으면 해당 기사 fetch 1회로 종료한다. article fetch는 3.2s connect + 4.8s read, resolver HTML fetch는 2.4s + 3.2s로 제한하며 JS 기사 대기는 24s로 둔다. 실패 시 다음 느린 체인을 계속 이어가지 않고 유한 종료한다.
- 수동 재확인이 quick feed와 겹치면 요청을 버리거나 동시 폭주시키지 않고 현재 quick 작업 뒤에 1회 큐잉한다. 최신 수집 중에도 저장된 7일 이내 마지막 정상 목록은 항상 화면 fallback으로 사용할 수 있다.

## 2026-10-06 · V177 FIREMOUTH STABLE LIST / EXPLICIT REFRESH
- 수정 전 `PROJECT_HANDOFF.md`, `NOONTANGI_UI_STANDARD_V1.md`, `NOONTANGI_SCENARIO_LOCK_V1.md`, `NOONTANGI_DATA_SOURCE_STANDARD_V1.md`, V176 마스터 DOCX를 다시 리뷰했다. V176 quick feed, user-tap-only article fetch, bounded article resolver, 5개 분류 탭은 그대로 유지한다.
- V176 실기기에서 기사 목록이 정상 표시된 뒤 HOME/다른 화면 이동·복귀 같은 화면 변경만으로 다시 `최신 자료를 자동 수집하고 있습니다` 상태가 나타나고 기존 기사 목록이 사라졌다가 몇 분 뒤 재등장하는 회귀를 확인했다.
- 직접 원인은 `fireDue()`가 06:30/12:00/16:30/22:00 슬롯, 1분 timer, focus/visibility/native resume, 불주댕이 재진입 stale 검사와 연결되어 첫 진입 이후에도 숨은 네트워크 수집 owner로 남아 있던 것이다. 특히 슬롯값이 현재 세션에 기록되지 않은 상태에서는 첫 수집 후 일정 시간이 지나면 timer가 다시 수집을 시작할 수 있었다.
- V177부터 **화면 이동 / 불주댕이 재진입 / 앱 focus·visibility / Android onResume / 주기 timer·slot**은 렌더와 캐시 복구만 수행하며 RSS 네트워크 수집을 시작하지 않는다.
- 자동 네트워크 수집 owner는 세션 최초 진입으로 제한한다. `주요 이슈`는 불주댕이 첫 실제 진입 1회, `보유종목 / 관심종목 / AI추천 / 글로벌`은 해당 탭 첫 실제 진입 1회만 lazy 수집한다. 이후 새 수집은 사용자가 누른 `재확인`만 허용한다.
- 수집 중 이미 기사행이 화면에 있으면 `renderFiremouthAuto()`가 그 행 DOM을 제거·재생성하지 않는다. 현재 기사 목록을 유지하고 상단 상태만 `업데이트 중`으로 바꾼다. 수집이 끝나 FIRE_STORE merge가 완료된 뒤 새 목록으로 한 번에 교체한다.
- 통계와 저장목록이 어긋나는 경우도 숨은 `stats-store mismatch recovery` 네트워크 재수집을 하지 않는다. 로컬 저장자료/visible cache 표시와 `재확인` 경로로만 복구한다.
- 배포: `Snowball current_v177.zip` · versionCode 60223 · versionName `6.0.8-r9-v121-firemouth-stablelist-r59-v177` · WebView cache v=766.

## 2026-10-06 · V179 FIREMOUTH V106 SINGLE-MODULE UI / V121 DATA SERVICE
- V178 실기기에서 불주댕이 헤더와 닫기 버튼만 보이고 탭·상태·기사목록 본문이 완전히 비는 회귀를 확인했다. V178은 사용 중단 기준으로 본다.
- 직접 원인은 V178이 UI 생명주기를 여전히 둘로 나눈 데 있다. V106의 capture 클릭 핸들러가 불주댕이 열기 이벤트에서 `stopPropagation()`한 뒤 V121R4의 별도 open listener가 실행되기를 기대해, 실기기에서는 패널 생성 후 기사 UI가 mount되지 않았다.
- V179은 패널을 실제 생성하는 V106을 불주댕이 UI/생명주기 단일 owner로 확정한다. V106의 `openPanel -> render -> renderRecent` 한 흐름에서 탭, 상태줄, 저장기사 목록, 행 펼침/접힘, 재확인 UI를 모두 처리한다.
- V121R4는 기사 데이터 서비스로만 남긴다. `list/status/running/refresh/read` 인터페이스를 제공하고, `#fm107RecentList` DOM을 직접 생성·삭제·교체하지 않는다. 데이터 변경 알림은 V106 `renderRecent()`에 위임한다.
- 불주댕이 재진입, HOME/다른 메뉴 이동 후 복귀, focus/visibility 변화, 탭 변경은 네트워크 수집을 시작하지 않는다. 저장기사가 하나도 없는 최초 진입에서만 1회 `first-empty` 수집을 허용하고, 이후 수집은 사용자가 누른 `재확인`만 허용한다.
- 기사 원문 읽기는 `원문 보기`와 동일한 실제 URL을 기사 전용 WebView에 로드하고 DOM 본문을 추출하는 단순 경로를 유지한다. URL 추정·다단 검색 체인을 다시 추가하지 않는다.
- 정적/헤드리스 검증: inline JavaScript 93개 전부 `node --check` 통과. 저장기사 1건 smoke에서 첫 진입 1건/닫기 후 재진입 1건 유지, 진입·재진입·탭 변경 중 불주댕이 뉴스검색 호출 0건, 기사 읽기 bridge에는 `원문 보기`와 동일 URL 전달을 확인했다. 빈 저장소 smoke에서도 5개 탭·상태줄·빈목록 UI가 먼저 생성되고 최초 수집이 시작됨을 확인했다.
- 배포: `Snowball current_v179.zip` · versionCode 60225 · versionName `6.0.8-r9-v121-firemouth-singlemodule-r61-v179` · WebView cache v=768.

# V180 handoff addendum — 2026-10-06
- Current build: V60.8 · V121 / V180 FIREMOUTH SPEECH MONITOR / PRE-READ SUMMARY / versionCode 60226 / `6.0.8-r9-v121-firemouth-speech-preread-r62-v180` / WebView cache v=769.
- V180 supersedes the older V152~V179 Firemouth collection scope where they conflict. Firemouth is no longer a general market-news bucket. Its sole current purpose is to monitor **actual remarks by influential domestic/global people or institutions** in politics, economics and finance.
- Admission gate: a candidate must identify an influential speaker/role and contain evidence of an actual remark, speech, interview, press conference, official answer/testimony or equivalent. General market moves, earnings, incidents and ordinary industry news are excluded even when important; those are reserved for a future separate `주요기사` Quick Menu.
- Before any row is shown, the app opens the same URL used by `원문 보기` in the hidden rendered WebView, finds the RSS/original headline in the rendered DOM, extracts the article body below that title while excluding header/promotion/recommendation noise, verifies that the body actually contains the speaker/remark, and prepares the summary. A row that fails this pre-read gate is not uploaded to Firemouth.
- The prepared explanation is written as one natural sentence/short single-paragraph flow rather than `누가/언제/어디서/...` labels. It preserves enough detail to cover, where the source supports it, who said it, when/where, what was said, why, and how/what action follows. It must not over-compress the original remarks or invent missing six-W facts.
- Clicking a Firemouth row is display-only: it opens the already prepared summary immediately and must not start article fetching, re-reading or summarization. Hidden-intent analysis (`그 속내는 뭘까`) remains postponed.
- Voice/selection reading reads the prepared natural-language summary only. Date, source, category labels, buttons, loading text, duplicate title and other UI metadata are not spoken.
- Keep the V179 single-owner runtime: V106 owns Firemouth UI; V121R4 is data/pre-read service only. Do not reintroduce multiple render owners, focus/visibility refresh, or click-time reading.
- Filtering refinement LOCK: generic `대표/CEO/사장` titles alone do not qualify. Corporate remarks require a recognized major domestic/global organization or a separately recognized high-impact speaker; ordinary company-executive articles stay out of Firemouth. Top policy/central-bank/regulatory roles remain eligible when the article contains real speech evidence.
- V180 removes the older five-lane Firemouth browsing concept from the current UI. `보유종목/관심종목/AI추천/글로벌` news lanes are historical Firemouth behavior and must not be reintroduced into this speech-monitor screen. General important news is reserved for the future separate `주요기사` Quick Menu.


## V181 FIREMOUTH INVESTMENT VOICE FILTER (2026-10-06)
- Current build: V60.8 · V121 / V181 FIREMOUTH INVESTMENT VOICE FILTER / versionCode 60227 / `6.0.8-r9-v121-firemouth-investvoice-r63-v181` / WebView cache v=770.
- 불주댕이는 순수 정치뉴스를 제외하고 투자와 연결되는 영향력 인사 발언만 수집한다. 정치인의 발언도 금리·환율·재정·세금·통상·산업·규제·보조금·에너지·방산·AI·반도체·노동·생산성 등 투자 영향이 명확할 때만 포함한다.
- 중복 제거는 제목/URL이 아니라 `발언자 + 날짜 + 핵심주제` 이벤트 단위이며 같은 이벤트는 대표 기사 1건만 유지한다.
- 글로벌 정책/중앙은행/빅테크·금융권 경영진 발언은 국내와 독립 검색 lane으로 확보하고 표시 목록도 국내/글로벌을 균형 있게 배치한다.
- 기사 등록 전 원문 사전정독·육하원칙 기반 자연어 요약 원칙은 유지한다. 요약/선택읽기에서는 기자명, 괄호 보충설명, 따옴표 기호, `전체 맥락을 이해하려면 기사 본문을 함께 확인...` 같은 상투문구를 제거한다.


## V182 FIREMOUTH SPEECH EVENT WIDE DISCOVERY (2026-10-07)
- Current build: V60.8 · V121 / V182 FIREMOUTH SPEECH EVENT WIDE DISCOVERY / versionCode 60228 / `6.0.8-r9-v121-firemouth-speechevent-r64-v182` / WebView cache v=771.
- 불주댕이 목적은 `좋은 기사`가 아니라 `투자에 중요한 발언을 놓치지 않는 것`으로 고정한다. 일반 중요기사는 향후 별도 빠른메뉴로 분리한다.
- UI는 `국내 / 글로벌` 두 lane만 제공한다. 저장된 V181 준비완료 자료를 버전 변경 때 지우지 않고 즉시 표시하고, 새 검색·사전정독·요약은 뒤에서 실행한다.
- 검색 단계는 영향력 인물/기관 후보를 넓게 모은다. 제목/RSS에 투자 키워드와 명시적 발언 표현이 모두 있어야 한다는 V181 앞단 하드필터를 제거하고, 원문을 읽은 뒤 실제 발언 + 투자 연관성 + 순수 정치 제외를 최종 판정한다.
- 국내 lane은 정책/금융/주요기업 경영진 외에 경제·투자방송 보도 검색을 추가한다. 글로벌 lane은 영어 Google News locale을 사용해 Fed/ECB/BOJ/PBOC, 미국·중국·EU 정책결정자, 빅테크·금융 경영진을 국내와 독립적으로 검색한다.
- 같은 발언은 V181의 `발언자 + 날짜 + 핵심주제` 이벤트 단위 중복제거를 유지한다. 노출 전 사전정독·육하원칙 자연어 요약·읽기 정제 원칙도 유지한다.
- V182 breadth lock: discovery queries intentionally do not require explicit speech verbs; current role/institution names are searched broadly and the rendered original article decides whether a real investment-relevant remark exists.
- V182 dual background monitor: opening Firemouth renders cache first, then schedules both domestic and global lane refreshes in the background. Switching lanes is display-first and does not wait for collection.


## V183 FIREMOUTH ECON SPEECH CLEAN (2026-10-07)
- Current build: versionCode 60229 / `6.0.8-r9-v121-firemouth-econspeech-r65-v183` / WebView cache v=772.
- 국회·국감·청문회·의원 질의·대정부질문·상임위/위원회 정치 절차성 자료는 경제 키워드가 있어도 불주댕이에서 하드 제외한다. 포토·주요일정/캘린더도 발언 이벤트가 아니므로 제외한다.
- 불주댕이는 한국은행/통화정책, 금리·물가·환율·금융, 재정·세금·통상, 산업·에너지·반도체, 주요기업 투자·수주·생산 등 투자에 직접 연결되는 경제/금융/산업 발언을 우선한다.
- 원문 정독 시 관련기사/추천기사/영상/숏폼/제보/광고/댓글/푸터 꼬리를 제거하고 발언자와 실제 발언 앵커 주변 문장만 자연어 요약에 사용한다.
- TTS 완료 idle 이벤트를 선택읽기 컨트롤러에도 전달해 읽기 완료 후 버튼을 `선택읽기`로 자동 복원한다.
- 패널은 먼저 즉시 열고 저장목록을 렌더한 뒤 백그라운드 수집을 1.2초/2.4초 후 시작한다.
- V183 final filter tightening: Korean `국회` context itself is a hard exclusion together with 국감/청문회/의원 질의·답변/상임위. `주요일정/캘린더/포토` and non-investment sports/구단주·직관 content are also excluded before display.
- V181/V182 prepared cache is not discarded on upgrade. If stored articleText exists, V183 locally rebuilds the display summary through the new speaker-anchor/cleanup path without network access; this keeps first-open instant while preventing older polluted summaries from being shown unchanged.
- V183 recall guard: a concise rendered article can pass body verification from 150 characters when the same URL/headline candidate already has a verified influential actor and the body contains both investment relevance and speech evidence. This reduces false negatives from short official statements.

## 2026-10-07 · V184 FIREMOUTH BODY-FIRST SPEECH FILTER
- V183 실기기 피드백 후 사용자 승인 전에는 수정하지 않는 절차를 적용했다. 이번 V184는 사용자 확인을 받은 범위만 수정하며 V179 이후 단일모듈 UI, 국내/글로벌 2버튼, 첫 화면 즉시표시, 읽기 완료 버튼 복원은 건드리지 않는다.
- 국내 lane은 국회·국감·청문회·의원 질의/답변 같은 정치 절차를 계속 하드 제외하고, 제목 자체가 만찬·오찬·조찬·간담회/간담·참석·접견·환담·기념식·협약식·인사/선임/취임/임명·사업총괄 같은 행사·인사성 내용이면 후보 단계에서 제외한다.
- 중복은 `발언자 + 날짜 + 핵심주제`에 더해 제목 핵심어 유사도를 함께 사용한다. 같은 날짜의 같은 발언을 여러 매체가 재작성한 경우 사전정독 전에 대표 기사 1건으로 축소해 원문 읽기 낭비와 목록 중복을 동시에 줄인다.
- 원문 사전정독은 `원문 보기`와 동일 URL WebView를 유지하되, 원제목과 가장 가까운 article/body 컨테이너를 찾고 그 안의 본문 문단만 순서대로 추출한다. 관련기사·추천기사·인기뉴스·영상/숏폼·제보·댓글·광고·푸터를 만나면 본문 수집을 중단한다.
- 요약은 문장 종결을 억지로 `~했고/~이며/이어서`로 이어붙이지 않는다. 실제 본문에서 발언자, 핵심 발언, 배경/이유/계획에 해당하는 3~5개 문장을 원래 순서대로 선택해 한 호흡의 자연스러운 단락으로 저장한다. 기자명·괄호·따옴표·입력/수정시각·URL·관련콘텐츠 꼬리는 제거한다.
- V181~V183 캐시는 즉시표시 원칙을 유지한다. 저장 articleText가 있으면 V184 요약기로 로컬 재정리해 이전 오염 요약을 그대로 재사용하지 않는다.
- 재확인은 기존 목록을 유지하면서 현재 lane만 갱신한다. 검색 대기 11초→9초, 기사 원문 대기 22초→15초, 사전정독 후보 16→12건으로 줄이고 사전 중복제거를 먼저 수행해 체감시간을 단축하되 수집 범위를 다시 좁히는 하드필터는 추가하지 않는다.
- 배포: `Snowball current_v184.zip` · versionCode 60230 · versionName `6.0.8-r9-v121-firemouth-bodyfirst-r66-v184` · WebView cache v=773.

## 2026-10-07 · V185 FIREMOUTH TRUSTED BODY / SPEECH GATE
- V184 실기기에서 `관련기사/광고/공유 UI`가 상세에 남고, 한국은행 인사·경제6단체장 만남·컨퍼런스/기조연설 같은 비발언 이벤트가 계속 통과한 것을 실패 사례로 고정했다. V185는 이 실패 유형을 직접 차단한다.
- 화면/생명주기는 건드리지 않는다. V179의 `V106 UI 단일 owner + V121R4 data service`, V183의 빠른 첫 화면, 국내/글로벌 2버튼, 읽기 완료 버튼 복원은 유지한다.
- 원문 본문은 `원문 보기`와 동일 URL을 렌더한 WebView에서만 얻는다. JSON-LD `articleBody`, 명시적 기사본문 DOM, 또는 원제목과 충분히 매칭된 headline 근처 article/container만 신뢰한다. 페이지 전체/가장 긴 텍스트 fallback은 금지한다.
- 기사본문 clone에서 related/recommend/popular/ranking/comment/reply/advert/banner/promotion/sidebar/share/social/outbrain/taboola/cluster/webstory 영역을 먼저 제거하고 p 문단만 순서대로 읽는다. `Flipboard/Pocket/custom_chain/webstory/korean_weather/VIDEOplay/AD` 등 UI 토큰이 나오면 본문 꼬리로 보고 중단한다.
- 제목이 국회/국감/청문회/의원 질의·답변, 만찬/간담/만남/참석/방문, 컨퍼런스/기조연설/행사, 인사/선임/개편/임명/승진 등인 경우 Firemouth 후보에서 제외한다. 일반 기업 수주/계약 기사에 경영진의 의례적 한마디만 붙은 경우도 제외한다.
- 최종 통과는 `신뢰 본문 + 영향력 actor + 실제 발언 표현 + 투자 연관 문장`이 모두 확인되어야 한다. 요약은 해당 발언 앵커 주변의 검증된 3~5문장만 사용하고, 기사 뒤쪽의 무관한 제목/광고를 요약 재료로 쓰지 않는다.
- V181~V184의 `deepSummary`는 V185에서 표시용 준비요약으로 재사용하지 않는다. `deepVersion=V185`와 `trustedBody=true`인 결과만 상세/목록 준비완료로 인정한다.
- 중복은 같은 날짜의 `기관/발언자 + 핵심주제 + 제목 유사도`를 함께 비교한다. 한국은행 인사처럼 한 기사에는 기관, 다른 기사에는 개인명이 잡혀도 같은 이벤트면 하나로 합친다.
- 글로벌 원제목이 영어뿐이고 준비된 요약이 한국어인 경우 첫 화면 제목은 준비요약의 한국어 lead를 사용한다. 원문 링크는 그대로 유지한다.
- 실기기 성공 전에는 해결 완료로 단정하지 않는다. 확인 포인트는 ① 정치/인사/행사 비발언 제거 ② 무관 꼬리/광고 0건 ③ 발언 중심 3~5문장 요약 ④ 같은 이벤트 1건 ⑤ 실제 경제정책 발언은 유지다.
- 배포 메타: versionCode 60231 / `6.0.8-r9-v121-firemouth-trustedbody-r67-v185` / WebView cache v=774.


### V186 FIREMOUTH PRIORITY / HISTORY
- V185 trusted-body 구조와 V179 단일 UI owner는 유지.
- 제목 중심 actor와 실제 핵심 발언자 일치가 모든 인물/기관의 최종 gate.
- 국내/글로벌 100점 중요도 모델 적용. 정렬은 score → actual action/policy change → time → source reliability.
- current full record는 7일/최대100, compact history는 30일/최대240. history에는 articleText를 넣지 않아 localStorage 용량을 제한한다.
- V185 준비완료 캐시는 articleText와 actor 일치 조건을 재통과한 항목만 V186 history로 이관.
- 육하원칙은 when/where context + speaker/what + why + how/follow-up 문장을 가능한 경우 우선 선택하되 라벨은 노출하지 않는다.

## V187 FIREMOUTH MEANING-FIRST / KO GLOBAL — 2026-10-07
- Build: versionCode 60233 / `6.0.8-r9-v121-firemouth-meaningko-r69-v187` / WebView cache v=776.
- V179 single UI owner, fast cached first-open, domestic/global two-lane UI, V186 priority/history are locked and retained.
- Admission is meaning-first: influential name alone is insufficient. Generic cooperation/partnership/greeting/platitude remarks are rejected unless a concrete policy, number, condition, forecast, or action change makes the statement investment-relevant.
- Korean National Assembly/inspection/hearing/question-answer context is a hard exclusion in both headline metadata and trusted article body, even if the quote itself is economic.
- Title actor must equal the actual key speaker for every person/institution. Reporter commentary or unrelated market background is not part of the Firemouth speech summary.
- Six-W is an internal coverage check only. Use available when/where + who/what + why/how once, naturally, without inventing missing facts or repeating event description.
- Global source text and URL remain original. Only rows with prepared Korean display summary/title are exposed as ready; translation failure does not fall back to raw English ready text.
- Event dedupe includes a `green-industrial` topic so President/K-GX/green-transition headlines from the same day/event collapse to one representative row.
- Regression examples: Trump tariff concession-for-investment = pass; Cathie Wood concrete BTC 2030 target = pass; Lisa Su generic partner/cooperation remark = fail; economic remark inside National Assembly audit = fail.
- Static validation: 93/93 inline JS parse, V187 self-test, generic/tariff/crypto examples, K-GX green-event dedupe. Android SDK is absent locally; GitHub Actions remains the final APK compile gate.

## V188 FIREMOUTH TAIL BOUNDARY / TRANSLATION RESTORE — 2026-10-07
- Build: versionCode 60234 / `6.0.8-r9-v121-firemouth-tailtranslate-r70-v188` / WebView cache v=777.
- Scope is intentionally narrow: preserve V179/V187 Firemouth architecture and fix only (1) article-body tail contamination and (2) the global Korean-translation regression.
- Rendered article extraction keeps JSON-LD/explicit-body/headline-anchored trusted sources but stops when DOM moves into related/recommend/popular/cluster/chain/next-article/list/link-heavy blocks. After a real body is established, short headline-like unrelated lines terminate extraction instead of being cleaned one by one later.
- Page-wide/longest-text fallback remains prohibited. V187 polluted summaries do not become V188 prepared rows unless they pass current trusted-body/safety gates.
- Global speech is filtered on the original language, then the selected speech summary is translated to Korean. Translation reuses the prior single-request public translation path on a dedicated executor, with one retry, so it is not starved behind market/news search work. Original source text/URL remains intact.
- Global ready UI still requires Korean prepared title/summary; no raw-English fallback is presented as a completed Korean card. Existing cached UI renders immediately and refresh remains explicit/background as before.
- Retained locks: meaning-first gate, National Assembly/audit/hearing exclusion, title actor == actual speaker, six-W natural summary, event dedupe, domestic/global importance ranking, 7-day current + 30-day compact history.
- Validation gate: 93 inline scripts must pass `node --check`; V188 logic regression must cut the reported entertainment/recommendation tail, keep National Assembly hard exclusion, keep Trump/Cathie meaningful examples, require Korean global prepared story, and pass V188 Firemouth self-test. ZIP integrity + master DOCX render QA required. APK compile remains GitHub Actions gate because the local source has no runnable Gradle wrapper/Android SDK.


## V189 FIREMOUTH ASYNC KO / STRICT BODY — 2026-10-08
- Build: versionCode 60235 / `6.0.8-r9-v121-firemouth-asyncko-r71-v189` / WebView cache v=778.
- Root cause fixed for global 0-row regression: `extTranslateKo()` previously created `v188ext_ko_*` IDs while the installed resolver only owned `v121r4ext_*`; V189 uses the resolver-owned namespace.
- Global event lifecycle is split: original-language trusted speech event is saved first; Korean translation is a separate asynchronous state. Translation timeout/failure no longer returns `null` from `preReadFireItem()` and therefore no longer deletes the global candidate.
- Pending global rows remain visible with a translation-pending message. Translation retries separately (bounded), and successful Korean summary/title is cached by eventKey for 30 days and reused immediately.
- V188 cache is not blindly trusted: V189 rebuilds from stored articleText and current gates; legacy history without articleText is not promoted.
- Article reader no longer enumerates all descendant `<p>` nodes inside a large container. It walks DOM order after the matched headline and stops when the tree enters related/recommend/link-dense/standalone-link/list boundaries. Headline-like off-topic tail lines also terminate extraction.
- Regression test: synthetic article body + dense linked recommendation block and plain unlinked entertainment headline tail must both stop before the tail.
- Retained locks: V179 single UI owner, fast first-open, V187 meaning-first/National Assembly hard exclusion/title actor equality, V186 priority + 7-day current + 30-day compact history.

## V190 — GLOBAL WIDE / ARTICLE MONITOR (2026-10-08)
- Build: versionCode 60236 / `6.0.8-r9-v121-firemouth-globalwide-article-r72-v190` / WebView cache v779.
- Firemouth global: `fireMeaningScore` is no longer a hard deletion threshold for GLOBAL. Verified speaker/body/investment relevance remain required; score is used for ranking.
- Global discovery expanded across regional Fed, global finance/asset management, macro investors, AI/chip, energy leaders. Candidate pre-read widened to 28 and continues past early failures until up to 12 prepared items.
- New HOME quick-menu `기사모니터`: separate store/UI from Firemouth. Domestic/Global tabs; article candidates are read from the original article URL before display, deduped, summarized with 5W1H-style facts, reporter's core point, and an investment-use link.
- Reporter priority is based on specialist-domain fit, source reliability, first-hand/evidence signals, and accumulated local profile. Reporter score is ranking/representative selection weight, not a hard deletion filter.
- Reporter track-record schema records items for later 1-week/1-month/3-month checks. Until price/earnings data are connected, the UI explicitly marks market-impact verification as pending rather than inventing accuracy.
- Preserve V179 Firemouth single UI owner and V189 body-boundary/translation behavior.

## V191 ARTICLE TRACK EVIDENCE / BUILD CONSISTENCY — 2026-10-09
- V190 baseline retained. `app/build.gradle` code 60237 and name `6.0.8-r9-v121-article-track-evidence-r73-v191`; `MainActivity` cache `v=780` and `CURRENT_BUILD.txt` updated together.
- Article history now retains 130 days, while the default prepared-list still shows 7 days. Reporter profiles are recomputed by stable article id; refreshing and translating the same article cannot inflate a journalist's reporting record.
- The article monitor includes a separate `사후검증(130일)` view per domestic/global lane.
- Only articles with clearly identified exchange/ticker code are linked to market price series; KOSPI/KOSDAQ/S&P 500 benchmarks selected accordingly. Observation windows 7/30/90 days are tracked with benchmark-relative returns and explicit pending/unavailable statuses.
- Observed post-publication price movements do not prove article accuracy, journalist causal impact, government policy execution, or real-world contract/revenue realization. Verified direction and real-world outcomes are still a future source-validation task.
- Tests: 93/93 inline JavaScript syntax checks; 15 targeted runtime assertions for ticker matching, article id deduplication, time-window observation, missing-data protection, and neutral-track safeguards. ZIP CRC and DOCX rendering verified locally. Android SDK unavailable: do not claim APK/phone validation.

## V203 (2026-10-10): Android OS navigation floor and per-article speech completion
- Preserve original design/ledger/market and V202 major indicators defaults; change only reported auxiliary-layer and speech ownership paths.
- Android navigation/gesture region is native owner; a fixed WebView guard prevents overlays from drawing/scroll gestures in the reserved `--android-bottom-inset`, while 7-item app nav stays above it.
- Successful spoken article in major news/firemouth collapses *only that article*. Do NOT auto-close article list overlay or navigate to HOME on completion. Explicit close of firemouth or reopen resets `FIRE_OPEN_ID` and all `.is-open` states.
- TTS final-utterance session ID must match, and the latest voice object must be patched after replacement during boot. Old completion/stop/error must not close new popup.
- Validation status: 99 JS syntax checks, isolated and whole-app Chromium mocked native voice tests, 412×915 viewport layout rectangles. Android APK compile and actual Samsung system navbar and TTS callbacks remain unverified.
- Package `SNOWBALL_CURRENT.zip` (V203) with docx manual `NUNTANGI_Master_Manual_Scenario_v1_2_V203.docx`, versionCode 60249, cache v792.


### V205 current update (2026-10-10)
- Source file: app/src/main/assets/index.html
- Build 60251; cache v794. Manual: NUNTANGI_Master_Manual_Scenario_v1_2_V205.docx
- Global header/navigation responsive geometry and compact mobile widths; V204 duplicated holdings-editor pane bug fixed; chart MA and disparity incl percentage inputs; HOME trend day/week/month/quarter/half/year with real-data missing-state.
- Regression QA by local Chromium viewport 360/412/540 and JavaScript syntax 106 scripts. Android OS nav/TTS and APK compilation not verified.


### V206 · 2026-10-10
# V206 — DENSITY / FLICKER / HOME TRENDS REPAIR

Baseline: V205. Generated 2026-10-10. App versionCode 60261, versionName `6.0.8-r9-v121-news-routing-journal-ui-r88-v206`, WebView cache `v=795`.

## Fixed / adjusted
- Short-term investment: compact stock search, typography reductions, hide duplicate code/market and OHLC chart heading; settings and active MA legends share a header. Dotted live-price line preserved, large red price rectangle removed, smaller price-axis margin with latest-candle space. Disparity separate strip removed; render bottom reference -10/-20/-30% in candle chart, selected MA base, and keep user selection. No auto trades.
- Journal: compact tool buttons, buy/sell/review summaries in three columns and smaller title/number typographic hierarchy; broaden holdings editor list for share records that contain `amount:0` placeholder; no mutation to old trade/cash ledger.
- HOME: `수익률 · 주식수 증감률 추이` entry restored on main portfolio card; trend controls and graph placed before holdings in portfolio detail. Six periods kept, no invented historical prices.
- Flicker root cause: old V46 `totalInvestClean()` wrote identical text on each MutationObserver-triggered pass, causing a feedback loop; change only when text differs. V21 no longer writes an already-present class to DOM. HOME portfolio + radar skip repeat redraw for identical data.
- Existing navigation, accounts, news pipelines and manual trade principle preserved.

## QA performed
- JavaScript syntax parsed 108 or 109 inline scripts, zero errors (final check after guide insertion pending).
- Browser `set_content` responsive checks 360/412/540 px: no horizontal page overflow, chart/settings present, MA/disparity legend visible.
- Chart -20% selection persisted in in-memory storage and changed legend; holdings editor displayed test holding 17 shares with `amount:0`; HOME trend button opened modal and all six periods shown.
- Independent 412px page idle DOM mutation count measured over 3.5s: V205 127, V206 21. Counts indicate reduced redundant DOM writes, **not proof that every Galaxy flicker disappeared**.
- External quote feeds, WebView/device runtime, native build unverified. No falsely asserted real-device success.



V207: See BUILD_ID_V207_QUIET_ACCUMULATION.md. Accumulation only supplemental to approved evidence, real daily rows only.


## V216 성장테마 기사 목록·선택읽기 (2026-10-14)
- 승인 내용: 7항목 + 두 번째 줄 날짜 추가. 상세는 요약 한 문단만 읽고 원문/출처 메타정보를 낭독하지 않는다.
- 목록: 첫 줄 제목, 둘째 줄 날짜·신문사·하트·쓰레기통. 앱 가이드 최신 V216 동기화.
- 버전코드 60297, 기존 589건 원본 보존, 보수적 중복 표시 통합, AI 검증/필터 비활성 유지.
- 상세한 변경·검증 및 실기기 한계는 BUILD_ID_V216_GROWTH_TWO_ROW_SUMMARY_ONLY.md 참조.
