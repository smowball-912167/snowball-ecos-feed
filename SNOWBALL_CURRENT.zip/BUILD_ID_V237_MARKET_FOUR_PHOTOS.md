# V237 · Approved two market environment reference photos

User-approved original content: four rows of policy/rates, business cycle, inflation, sentiment/flows; four investment application implications. Applied to market dashboard accordions, in-app guide, and V237 DOCX. No automatic inference of unconnected indicators. Styling: market one-line thinner; market article detail title smaller and lighter.

versionCode 60318 · versionName 6.0.8-r9-v237 · appId and signing config unchanged. No installed-data migration. GitHub Actions build and Galaxy update-install not yet tested.
