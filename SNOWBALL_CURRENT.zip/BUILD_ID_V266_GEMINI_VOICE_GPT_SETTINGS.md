# V266 — Gemini speech / existing ChatGPT voice

- The app retains ONE AI conversation button. ChatGPT handles Snowball app context; Gemini handles other conversations.
- **ChatGPT replies always use the existing Snowball TTS `speak()` method with the user-selected voice.** Do not replace it with OpenAI TTS or a new voice.
- **Gemini replies use Gemini API TTS** only after authorized HTTPS gateway and user opt-in; on TTS error, fall back to the existing voice.
- Preserve V265 one-shot microphone recognition check and guard against automatic microphone listening without a connected gateway. Speaker biometric enrollment is not implemented.
- Preserve market environment, all ECOS and finance code including pending public-redistribution permissions.
- Release metadata: versionCode 60344; versionName 6.0.8-r9-v266; S1 3 hashes updated.
- Node gateway mock checks and focused JS syntax checks required. No live Gemini/OpenAI API call or Galaxy/APK build asserted.
