# V267 — AI reply audible fallback

- Fix V266 silent branch: when the AI gateway is unavailable, stop the microphone before speaking the notice using the existing configured Snowball TTS. No fake AI reply.
- Text-submitted chat replies now speak by default, except explicit `voice:false` callers.
- Gemini provider audio playback failures call fallback even without active voice recognition; release stale callbacks on successful playback.
- Gemini still uses its provider voice on a working deployed gateway; ChatGPT keeps selected Snowball TTS.
- Preserve V265 one-shot STT check, ECOS, finance and KRX rights guard.
- versionCode 60345 / V267. No real phone or live API verification.
