import importlib.util, datetime as dt, json, os, unittest
from pathlib import Path
p=Path(__file__).with_name('ecos_private_collector.py')
spec=importlib.util.spec_from_file_location('ecos',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
T=dt.datetime(2026,10,18,tzinfo=dt.timezone.utc)

def specimen(mid='kr03y', value='3.05', d='20261016', item=None,table=None,unit='연리%'):
 s=mod.SPECS[mid]
 return {'StatisticSearch':{'list_total_count':1,'row':[{'STAT_CODE':table or s['table'],'ITEM_CODE1':item or s['item'],'ITEM_NAME1':s['name'],'ITEM_NAME2':'','UNIT_NAME':unit,'TIME':d,'DATA_VALUE':value}]}}

class TestECOS(unittest.TestCase):
 def test_three_year(self):
  v=mod.parse_ecos(specimen(), 'kr03y', T)
  self.assertEqual(v['id'],'kr03y');self.assertEqual(v['value'],3.05);self.assertEqual(v['period'],'2026-10-16');self.assertTrue(v['verified'])
 def test_policy(self):self.assertEqual(mod.parse_ecos(specimen('krRate','2.50'),'krRate',T)['value'],2.5)
 def test_name_punctuation_normalized(self):
  val=specimen(); val['StatisticSearch']['row'][0]['ITEM_NAME1']='국고채(3년)'
  self.assertEqual(mod.parse_ecos(val,'kr03y',T)['value'],3.05)
 def test_wrong_code_rejected(self):
  with self.assertRaises(mod.DataError): mod.parse_ecos(specimen(item='WRONG'),'kr03y',T)
 def test_wrong_table_rejected(self):
  with self.assertRaises(mod.DataError): mod.parse_ecos(specimen(table='718Y001'),'kr03y',T)
 def test_wrong_unit(self):
  with self.assertRaises(mod.DataError): mod.parse_ecos(specimen(unit='지수'),'kr03y',T)
 def test_stale(self):
  with self.assertRaises(mod.DataError): mod.parse_ecos(specimen(d='20260901'),'kr03y',T)
 def test_future(self):
  with self.assertRaises(mod.DataError): mod.parse_ecos(specimen(d='20261101'),'kr03y',T)
 def test_empty(self):
  with self.assertRaises(mod.DataError): mod.parse_ecos({'RESULT':{'CODE':'INFO-200'}},'kr03y',T)
 def test_zero_zero_accept(self):
  self.assertEqual(mod.parse_ecos(specimen(value='0'),'kr03y',T)['value'],0.0)
 def test_url_rejects_bad_key(self):
  with self.assertRaises(mod.DataError): mod.build_url(mod.SPECS['kr03y'],'bad/key','20261001','20261018')
 def test_no_key(self):
  old=os.environ.pop('ECOS_API_KEY',None)
  try:
   with self.assertRaises(mod.DataError):mod.collect(now=T)
  finally:
   if old is not None:os.environ['ECOS_API_KEY']=old
if __name__=='__main__':unittest.main()
