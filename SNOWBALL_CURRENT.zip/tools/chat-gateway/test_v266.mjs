import assert from 'node:assert/strict';
process.env.CHAT_CLIENT_TOKEN='sample-long-only-for-unit-test-not-secret';
process.env.GEMINI_API_KEY='mock-google';
process.env.OPENAI_API_KEY='mock-openai';
process.env.CHAT_HOURLY_LIMIT='20';
const seen=[];
const fetchReal = globalThis.fetch;
globalThis.fetch=async (url,options)=>{
 seen.push({url:String(url),body:JSON.parse(options.body)});
 if(String(url).includes('gemini-3.8-flash-lite-tts'))return new Response(JSON.stringify({candidates:[{content:{parts:[{inlineData:{mimeType:'audio/wav',data:Buffer.alloc(500,0x46).toString('base64')}}]}}]}),{status:200,headers:{'content-type':'application/json'}});
 if(String(url).includes('/v1/responses'))return new Response(JSON.stringify({output:[{content:[{type:'output_text',text:'눈탱이 앱 관련 답변'}]}]}),{status:200,headers:{'content-type':'application/json'}});
 return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'편안하게 대화해요.'}]}}]}),{status:200,headers:{'content-type':'application/json'}});
};
const {server}=await import('./server.mjs'); await new Promise(r=>server.listen(0,'127.0.0.1',r));
const host='http://127.0.0.1:'+server.address().port;const auth={authorization:'Bearer '+process.env.CHAT_CLIENT_TOKEN,'content-type':'application/json'};
async function post(path,body,headers=auth){return fetchReal(host+path,{method:'POST',headers,body:JSON.stringify(body)});}

try{
let x=await post('/chat',{message:'반가워',route:'gemini'},{});assert.equal(x.status,401);
x=await post('/chat',{message:'반가워',route:'gemini'});assert.equal(x.status,200);assert.equal((await x.json()).route,'gemini');
x=await post('/chat',{message:'눈탱이 버전은?',route:'openai'});assert.equal(x.status,200);assert.equal((await x.json()).route,'openai');
x=await post('/speak',{text:'반가워요!',route:'gemini'});assert.equal(x.status,200);assert.match(x.headers.get('content-type'),/wav/);assert.equal((await x.arrayBuffer()).byteLength,500);
x=await post('/speak',{text:'앱 업데이트 확인',route:'openai'});assert.equal(x.status,400);assert.equal((await x.json()).error,'GEMINI_ONLY_SPEECH');
x=await post('/speak',{text:'',route:'gemini'});assert.equal(x.status,400);
assert(seen.some(x=>x.url.includes('gemini-3.8-flash-lite-tts')));assert(!seen.some(x=>x.url.includes('/v1/audio/speech')));
console.log('PASS 7 gateway checks: auth/chat routes/Gemini voice/ChatGPT uses existing selected voice/empty input');
}finally{await new Promise(r=>server.close(r));}
