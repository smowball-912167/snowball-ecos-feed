// SNOWBALL V269 dual-provider chat gateway (bounded Gemini retry/timeout). Node.js >= 20. No third-party packages.
// Deploy behind HTTPS and access controls. Never put provider API keys in the APK.
import http from 'node:http';

const PORT = Number(process.env.PORT || 8080);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-4.1-mini';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
const GEMINI_TTS_MODEL = process.env.GEMINI_TTS_MODEL || 'gemini-3.8-flash-lite-tts';
const GEMINI_VOICE = process.env.GEMINI_VOICE || 'Kore';
const ALLOWED_ORIGIN = process.env.CHAT_ALLOWED_ORIGIN || '';
const CLIENT_TOKEN = process.env.CHAT_CLIENT_TOKEN || '';
const MAX_PER_HOUR = Math.min(100, Math.max(1, Number(process.env.CHAT_HOURLY_LIMIT || 20)));
// Keep upstream work inside the existing Android 105-second read / 115-second UI limit.
// A free Render cold start may consume ~50 seconds before this request is handled.
function boundedMillis(value, fallback, low, high) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? Math.min(high, Math.max(low, Math.round(n))) : fallback;
}
const CHAT_PROVIDER_TIMEOUT_MS = boundedMillis(process.env.CHAT_PROVIDER_TIMEOUT_MS, 48000, 20000, 65000);
const GEMINI_ATTEMPT_TIMEOUT_MS = boundedMillis(process.env.GEMINI_ATTEMPT_TIMEOUT_MS, 21500, 150, 30000);
const GEMINI_RETRY_DELAY_MS = boundedMillis(process.env.GEMINI_RETRY_DELAY_MS, 800, 100, 1600);
const counts = new Map();
function json(res, status, data) { res.writeHead(status, {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}); res.end(JSON.stringify(data)); }
function compact(value, limit) { return String(value ?? '').slice(0, limit).trim(); }
function permitted(req) {
  if (ALLOWED_ORIGIN && req.headers.origin && req.headers.origin !== ALLOWED_ORIGIN) return false;
  if (!CLIENT_TOKEN) return false; // require a deployment-layer client token
  const auth = req.headers.authorization || '';
  return auth === `Bearer ${CLIENT_TOKEN}`;
}
function limit(ip) {
  const now=Date.now(), bucket=counts.get(ip)||{start:now,n:0};
  if(now-bucket.start>=3600000){bucket.start=now;bucket.n=0;}
  bucket.n++;counts.set(ip,bucket);return bucket.n<=MAX_PER_HOUR;
}
function read(req){return new Promise((resolve,reject)=>{let raw='';req.on('data',chunk=>{raw+=chunk;if(raw.length>15000){reject(new Error('TOO_LARGE'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(raw));}catch{reject(new Error('INVALID_JSON'));}});req.on('error',reject);});}
const shared = '자연스러운 한국어 대화. 어떤 주제든 선입견이나 훈계 없이 대화한다. 정해진 질문 형식을 요구하지 않는다. 짧은 질문에도 맥락을 이해해 답한다. 불확실한 정보는 추정이라고 밝힌다. 사용자의 휴대폰이나 앱을 직접 제어할 수 있다고 주장하지 않는다. API 요금·개인정보에 주의한다.';
const appPrompt = `${shared} 너는 눈탱이(SNOWBALL) 앱 개발/사용 담당이다. 앱 오류, 설치, 버전, 메뉴, 시장환경, ECOS 연결과 금융·수급 공급부 등의 질문에 답한다. 서버에 실제 앱 소스·실시간 지표를 가져오는 도구는 없으므로 제공되지 않은 파일이나 실행 결과를 보았다고 주장하지 않는다. 금융 숫자를 임의로 만들지 않고 작업 지시는 구체적으로 제시한다. 요청 없이 앱 설정이나 거래를 변경하지 않는다.`;
const generalPrompt = `${shared} 너는 일상 대화·과학·문화·생활·일반 지식 등 광범위한 주제를 다루는 친근하고 깊이 있는 대화 상대다. 자유로운 화제 전환, 이어지는 질문, 짧은 농담과 감정적 맥락을 자연스럽게 반영한다. 확신이 없는 최신 사실은 확인이 필요함을 알려준다.`;
function history(input) {
  return (Array.isArray(input)?input:[]).slice(-10).filter(x=>x && (x.role==='user'||x.role==='assistant')).map(x=>({role:x.role,text:compact(x.text,1000)})).filter(x=>x.text);
}
async function callOpenAI(message,past,screen,signal){
  if(!OPENAI_API_KEY) throw new Error('OPENAI_NOT_CONFIGURED');
  const input=[{role:'developer',content:appPrompt+`\n앱 화면 이름(사용자 제공): ${compact(screen,50)}`}];
  for(const m of past)input.push({role:m.role,content:m.text});
  input.push({role:'user',content:message});
  const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',signal,headers:{'authorization':`Bearer ${OPENAI_API_KEY}`,'content-type':'application/json'},body:JSON.stringify({model:OPENAI_MODEL,input,max_output_tokens:650})});
  if(!r.ok) throw new Error('UPSTREAM_OPENAI_'+r.status);
  const data=await r.json();
  return compact((data.output||[]).flatMap(o=>o.content||[]).filter(c=>c.type==='output_text').map(c=>c.text).join('\n'),6000);
}
async function callGemini(message,past,signal){
  if(!GEMINI_API_KEY) throw new Error('GEMINI_NOT_CONFIGURED');
  const contents=past.map(m=>({role:m.role==='assistant'?'model':'user',parts:[{text:m.text}]}));
  while(contents.length&&contents[0].role!=='user')contents.shift();
  contents.push({role:'user',parts:[{text:message}]});
  const endpoint=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`;
  const body=JSON.stringify({systemInstruction:{parts:[{text:generalPrompt}]},contents,generationConfig:{maxOutputTokens:4096,temperature:0.75,thinkingConfig:{thinkingLevel:'low'}}});
  // Retry at most once and only for transient timeouts, network errors, or 408/5xx.
  // Never retry 400/401/403/404/429: authentication, model, billing and quota
  // problems must not generate repeated paid requests.
  for(let attempt=0;attempt<2;attempt++){
    if(signal.aborted)throw new Error('PROVIDER_TIMEOUT');
    const perAttempt=new AbortController();
    const onCancel=()=>perAttempt.abort();
    signal.addEventListener('abort',onCancel,{once:true});
    let attemptTimedOut=false;
    const timer=setTimeout(()=>{attemptTimedOut=true;perAttempt.abort()},
      Math.min(GEMINI_ATTEMPT_TIMEOUT_MS,CHAT_PROVIDER_TIMEOUT_MS));
    try{
      const r=await fetch(endpoint,{method:'POST',signal:perAttempt.signal,headers:{'x-goog-api-key':GEMINI_API_KEY,'content-type':'application/json'},body});
      if(!r.ok)throw new Error('UPSTREAM_GEMINI_'+r.status);
      const data=await r.json();
      const answer=compact(data.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('')||'',6000);
      if(!answer)throw new Error('EMPTY_GEMINI_RESPONSE');
      return answer;
    }catch(e){
      if(signal.aborted)throw new Error('PROVIDER_TIMEOUT');
      const raw=String(e?.message||'');
      const temporary=/^UPSTREAM_GEMINI_(?:408|500|502|503|504)$/.test(raw);
      const network=e?.name==='TypeError';
      if(attempt===0&&(temporary||attemptTimedOut||network)){
        const code=temporary?raw:attemptTimedOut?'GEMINI_ATTEMPT_TIMEOUT':'GEMINI_NETWORK_ERROR';
        console.warn('[chat] provider=gemini retry=1 reason='+code);
      }else if(attemptTimedOut)throw new Error('PROVIDER_TIMEOUT');
      else if(network)throw new Error('PROVIDER_NETWORK_ERROR');
      else throw e;
    }finally{
      clearTimeout(timer);
      signal.removeEventListener('abort',onCancel);
    }
    // Bounded backoff; the outer abort deadline still applies during the pause.
    await new Promise(resolve=>setTimeout(resolve,GEMINI_RETRY_DELAY_MS));
  }
  throw new Error('PROVIDER_UNAVAILABLE');
}
async function sayWithGemini(text, signal) {
  if (!GEMINI_API_KEY) throw new Error('GEMINI_NOT_CONFIGURED');
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_TTS_MODEL)}:generateContent`;
  const body = {contents:[{role:'user',parts:[{text, speech_metadata:{style:'한국어로 친근하고 자연스럽게, 너무 빠르지 않게 말한다.'}}]}],generationConfig:{responseModalities:['AUDIO'],speechConfig:{voiceConfig:{voice:GEMINI_VOICE}}}};
  const result=await fetch(endpoint,{method:'POST',signal,headers:{'x-goog-api-key':GEMINI_API_KEY,'content-type':'application/json'},body:JSON.stringify(body)});
  if(!result.ok) throw new Error('GEMINI_TTS_'+result.status);
  const data=await result.json();
  const audioPart=data.candidates?.[0]?.content?.parts?.find(p=>p.inlineData?.data);
  if(!audioPart)throw new Error('NO_AUDIO');
  if(audioPart.inlineData.data.length>3500000)throw new Error('AUDIO_TOO_LARGE');
  return {mime:'audio/wav',buffer:Buffer.from(audioPart.inlineData.data,'base64')};
}
export const server = http.createServer(async (req,res)=>{
  if(req.url==='/health'&&req.method==='GET')return json(res,200,{status:'up',providersConfigured:{openai:!!OPENAI_API_KEY,gemini:!!GEMINI_API_KEY}});
  if(!['/chat','/speak'].includes(req.url)||req.method!=='POST')return json(res,404,{error:'NOT_FOUND'});
  if(!permitted(req))return json(res,401,{error:'UNAUTHORIZED'});
  const ip=req.socket.remoteAddress||'unknown';
  if(!limit(ip))return json(res,429,{error:'RATE_LIMIT'});
  let data;try{data=await read(req)}catch(e){return json(res,400,{error:'BAD_REQUEST'})}
  const route=data.route==='openai'?'openai':'gemini';
  if(req.url==='/speak'){
    // ChatGPT deliberately uses the pre-existing device voice; no OpenAI TTS endpoint.
    if(route!=='gemini')return json(res,400,{error:'GEMINI_ONLY_SPEECH'});
    const phrase=compact(data.text,850);
    if(!phrase)return json(res,400,{error:'EMPTY_TEXT'});
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),25000);
    try{
      const audio=await sayWithGemini(phrase,controller.signal);
      if(audio.buffer.length<100||audio.buffer.length>2500000)return json(res,502,{error:'INVALID_AUDIO_SIZE'});
      res.writeHead(200,{'content-type':audio.mime,'content-length':audio.buffer.length,'cache-control':'no-store','x-content-type-options':'nosniff'});
      return res.end(audio.buffer);
    }catch(e){const raw=String(e?.message||'');const safe=/^(?:GEMINI_TTS_[0-9]{3}|NO_AUDIO|AUDIO_TOO_LARGE|GEMINI_NOT_CONFIGURED)$/.test(raw)?raw:(e?.name==='AbortError'?'SPEECH_TIMEOUT':'SPEECH_UNAVAILABLE');console.error('[speak] provider=gemini error='+safe);return json(res,502,{error:'SPEECH_UNAVAILABLE'});}finally{clearTimeout(timeout)}
  }
  const message=compact(data.message,1500),past=history(data.history),screen=compact(data.screen,50);
  if(!message)return json(res,400,{error:'EMPTY_MESSAGE'});
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),CHAT_PROVIDER_TIMEOUT_MS);
  try{
    const answer=route==='openai'?await callOpenAI(message,past,screen,controller.signal):await callGemini(message,past,controller.signal);
    if(!answer){console.error('[chat] provider='+route+' error=EMPTY_PROVIDER_RESPONSE');return json(res,502,{error:'EMPTY_PROVIDER_RESPONSE'});}
    return json(res,200,{text:answer,route});
  }catch(e){
    const raw=String(e?.message||'');
    const safe=/^(?:UPSTREAM_(?:OPENAI|GEMINI)_[0-9]{3}|OPENAI_NOT_CONFIGURED|GEMINI_NOT_CONFIGURED)$/.test(raw)?raw:
      (e?.name==='AbortError'||raw==='PROVIDER_TIMEOUT')?'PROVIDER_TIMEOUT':
      (raw==='EMPTY_GEMINI_RESPONSE'||raw==='PROVIDER_NETWORK_ERROR')?raw:'PROVIDER_UNAVAILABLE';
    console.error('[chat] provider='+route+' error='+safe);
    return json(res,502,{error:safe});
  }finally{clearTimeout(timeout)}
});
if(import.meta.url===`file://${process.argv[1]}`)server.listen(PORT,()=>console.log(`Snowball chat gateway listening on :${PORT}`));
