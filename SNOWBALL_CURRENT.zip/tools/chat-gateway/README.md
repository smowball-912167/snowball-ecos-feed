# V264 AI Chat Gateway — deployment needed

The Android app includes **one AI chat button**, a foregound auto-conversation opt-in, and provider routing. Real model replies require deploying this gateway on an HTTPS domain with a secure access layer.

## Run privately (Node.js >=20)

Environment variables on **the server only**:
- `OPENAI_API_KEY`: OpenAI API key for app maintenance questions.
- `GEMINI_API_KEY`: Gemini API key for general chat.
- `CHAT_CLIENT_TOKEN`: required random client access token, to be used only through an authenticated service. Do **not** bake any secret into the APK.
- `OPENAI_MODEL`, `GEMINI_MODEL`: optional model overrides.
- `CHAT_HOURLY_LIMIT`: default 20 requests/IP/hour. Use a production-grade rate limiter before exposing publicly.
- `CHAT_ALLOWED_ORIGIN`: optional for web apps, native file-origin requests may not have Origin.

Start: `node server.mjs` then put it behind TLS and stronger session-based authentication. The gateway intentionally denies all `/chat` requests unless the client sends `Authorization: Bearer ...` matching `CHAT_CLIENT_TOKEN`; the V264 Android UI can save an access code in Android Keystore (not in JavaScript localStorage); after a secure gateway deployment, configure its HTTPS URL, add the gateway access code, and opt in to sending conversation content. Out-of-the-box Gemini/OpenAI chat is **not yet connected**. Do not weaken the server requirement just to enable the UI.

`POST /chat` request body `{message, route: "openai"|"gemini", history: [{role,text}], screen}`.
Response `{text, route}`. Endpoint `/health` can report configured-provider booleans; do not publicly expose this in production unless needed.

## Privacy and truth-in-feature constraints
- User must explicitly opt in to sending a question and up to 10 prior conversation messages to the provider; no accounts or financial holdings are included automatically.
- No API keys, recordings, or voice fingerprints in the APK.
- Foreground auto-conversation is **not** background hotword listening; Android limits microphone access in background.
- Voice speaker identification/learning requires a vetted on-device speaker-recognition model and is not available yet.
- Existing offline local assistant remains available for some app-data queries; general AI chat clearly reports when the service is not connected.

## V267 audible speech + selected voice policy
- Gemini replies: use Gemini speech from the HTTPS gateway, when connected.
- ChatGPT replies: **retain the user's existing Snowball voice setting**; the app uses its existing Android text-to-speech method and does not call OpenAI speech APIs.
- If Gemini TTS fails: fall back to the user's existing Snowball voice.
- Actual AI-provider answers still require a deployed gateway and API keys. Without them the app uses the selected device voice to read a clear connection notice; it never misrepresents that notice as an AI answer.
- Text chat responses are audible by default; callers that intentionally request silent output can pass `voice:false`.

## V269: Gemini retry and timeout handling
`/chat` permits up to 48s upstream work on Render to allow transient Gemini latency (the Android V268 app permits a 105s network read). Gemini text calls use at most two 21.5s attempts with one short backoff for timeouts, network errors or HTTP 408/5xx. HTTP 429/401/403 and invalid requests are never automatically retried to avoid spending more quota. Server logs keep only provider status codes and not secret keys or message text. `CHAT_PROVIDER_TIMEOUT_MS`, `GEMINI_ATTEMPT_TIMEOUT_MS` and `GEMINI_RETRY_DELAY_MS` are optional settings. Do not deploy with hardcoded credentials.
