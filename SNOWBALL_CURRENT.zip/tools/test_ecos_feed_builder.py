import sys,unittest,datetime as dt,os,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import ecos_feed_builder as b
class Test(unittest.TestCase):
 def test_catalog(self):
  self.assertEqual(len(b.SPECS),19)
  self.assertEqual(sum(s['cycle']=='D' for s in b.SPECS.values()),8)
  self.assertEqual(sum(s['cycle']=='M' for s in b.SPECS.values()),11)
 def test_fail_closed(self):
  with self.assertRaises(b.DataError):b.produce(dt.date(2026,10,18),lambda spec,now: (_ for _ in ()).throw(b.DataError('offline')))
 def test_manifest_and_no_secret(self):
  root=Path(__file__).resolve().parents[1];p=root/'app/src/main/assets/s1_manifest.json';m=json.loads(p.read_text())
  import hashlib
  checks={'assetSha256':'app/src/main/assets/index.html','gradleSha256':'app/build.gradle','mainActivitySha256':'app/src/main/java/com/snowball/noontangi/MainActivity.java'}
  for k,v in checks.items():self.assertEqual(m[k],hashlib.sha256((root/v).read_bytes()).hexdigest())
  self.assertNotIn('ECOS_API_KEY=',(root/'app/src/main/assets/ntv245_ecos_live.js').read_text())
if __name__=='__main__':unittest.main()
