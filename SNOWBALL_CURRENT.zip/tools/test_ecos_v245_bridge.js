'use strict';
const assert=require('assert');const fs=require('fs');const path=require('path');
const ROOT=path.resolve(__dirname,'..');const URL='https://smowball-912167.github.io/snowball-ecos-feed/ecos/feed.json';
const native=fs.readFileSync(path.join(ROOT,'app/src/main/java/com/snowball/noontangi/MainActivity.java'),'utf8');
assert(native.includes(`if (address.equals("${URL}")) return true;`),'native whitelist must include the exact confirmed feed URL');
assert(!native.includes('github.io/Snowball-apk/ecos/feed.json'),'stale forbidden endpoint remains');
const domEvents={};global.document={addEventListener:(name,handler)=>{domEvents[name]=handler;}};
const store={};global.localStorage={getItem:(k)=>store[k]??null,setItem:(k,v)=>{store[k]=v;}};
global.window=global;global.window.dispatchEvent=()=>true;global.NOONTANGI_FOUR_FACTORS={official:()=>null,ingest:(items)=>{assert(items.length===5);return items.length}};
let endpoint=null,callbackId=null;
global.SnowballMarketData={getAsync:(url,id)=>{endpoint=url;callbackId=id;}};
const client=require('../app/src/main/assets/ntv245_ecos_live.js');
assert.strictEqual(client.endpoint,URL);
const now=new Date();const day=now.toISOString().substring(0,10).replace(/-/g,'');
const mdate=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth()-1,1));
const month=`${mdate.getUTCFullYear()}${String(mdate.getUTCMonth()+1).padStart(2,'0')}`;
const previous=String(mdate.getUTCFullYear()-1)+month.slice(4);
const d=(v)=>({cycle:'D',unit:'연%',latest:day,value:v,history:[[day,v]]});
const m=(unit,v)=>({cycle:'M',unit,latest:month,value:v,history:[[previous,v/1.03],[month,v]]});
const feed={schema:'NT_ECOS_LIVE_V245',generatedAt:new Date().toISOString(),sourceCount:5,sources:{
 kr_base_d:d(3),kr_treasury_3y_d:d(3.2),kr_cpi_m:m('2020=100',115),ppi_m:m('2020=100',120),exports_m:m('천불',122000)
}};
(async()=>{
 const p=client.refresh(true);
 assert.strictEqual(endpoint,URL,'bridge requested incorrect URL');
 assert(callbackId.startsWith('ntv245ecos_'));
 global.__SnowballNativeAsyncResolve(callbackId,JSON.stringify(feed));
 const result=await p;
 assert.strictEqual(result.status,'received');assert.strictEqual(result.added,5);
 assert(client.state().ok);assert.strictEqual(client.state().sourceCount,5);
 console.log('V245 PUBLIC FEED bridge URL, callback, ingestion, status PASS');
})().catch(err=>{console.error(err);process.exitCode=1});
