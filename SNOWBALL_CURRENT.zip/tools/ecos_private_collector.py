#!/usr/bin/env python3
"""V243: secure, server-side Bank of Korea ECOS statistics collector.

This tool DOES NOT run in the Android app. It requires ECOS_API_KEY in the
server environment, never stores credentials in source, APK or output JSON.
It does not publish any feed; hosting/delivery needs separate approval.
Only explicitly verified table+item combinations are accepted.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone, timedelta
import json, os, re, sys
from pathlib import Path
from urllib.request import build_opener, HTTPRedirectHandler, Request

# Korea's official policy rate and 3-year government bond yield. No invented
# ECOS codes for PPI/import prices; item validation remains pending.
SPECS = {
    "kr03y": dict(table="817Y002", cycle="D", item="010200000", name="국고채 3년", limit=12, minimum=0, maximum=30, period="일별 금리", unit="%"),
    "krRate": dict(table="722Y001", cycle="D", item="0101000", name="한국은행 기준금리", limit=35, minimum=0, maximum=30, period="기준금리 공시일", unit="%"),
}
KEY_NAME = "ECOS_API_KEY"
class DataError(ValueError):
    pass

def safe_number(s):
    if s is None or s == "":
        return None
    try:
        v = float(str(s).replace(",", ""))
        return v if 0 <= v < 1000000 and v == v else None
    except (TypeError, ValueError):
        return None

def build_url(spec, key, start, end):
    if not re.fullmatch(r"[A-Za-z0-9_-]{8,128}", key):
        raise DataError("ECOS 키 형식 오류 (키 내용은 출력하지 않음)")
    if not (re.fullmatch(r"\d{8}", start) and re.fullmatch(r"\d{8}", end) and start <= end):
        raise DataError("날짜 형식 또는 범위 오류")
    return ("https://ecos.bok.or.kr/api/StatisticSearch/" + key + "/json/kr/1/180/" + spec["table"] + "/" + spec["cycle"] + "/" + start + "/" + end + "/" + spec["item"])

def parse_ecos(payload, metric_id, now=None):
    spec = SPECS[metric_id]
    now = now or datetime.now(timezone.utc)
    doc = payload.get("StatisticSearch") if isinstance(payload, dict) else None
    if not isinstance(doc, dict) or not isinstance(doc.get("row"), list):
        raise DataError("ECOS 통계 데이터 없음 또는 공식 응답 오류")
    rows = doc["row"]
    parsed=[]
    for row in rows:
        if not isinstance(row, dict):
            continue
        if row.get("STAT_CODE") != spec["table"] or row.get("ITEM_CODE1") != spec["item"]:
            continue
        unit = str(row.get("UNIT_NAME","")).replace(" ","")
        if not ("%" in unit or "퍼센트" in unit):
            continue
        normalize = lambda z: re.sub(r"[^가-힣A-Za-z0-9]", "", str(z))
        if not (normalize(spec["name"]) in normalize(row.get("ITEM_NAME1", "")) or normalize(spec["name"]) in normalize(row.get("ITEM_NAME2", ""))):
            # Some historical ECOS tables have a blank or generic item label; no guessing.
            continue
        ymd = str(row.get("TIME", ""))
        if not re.fullmatch(r"20\d{6}", ymd):
            continue
        try:
            date = datetime.strptime(ymd, "%Y%m%d").replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        value=safe_number(row.get("DATA_VALUE"))
        if value is None or not (spec["minimum"] <= value <= spec["maximum"]):
            continue
        if date > now + timedelta(days=1) or date < now - timedelta(days=365):
            continue
        parsed.append((date,value))
    if not parsed:
        raise DataError("표/항목/단위 일치하는 관측값 없음")
    parsed.sort(key=lambda z:z[0]); latest=parsed[-1]
    if now-latest[0] > timedelta(days=spec["limit"]):
        raise DataError("ECOS 관측값 오래됨")
    # Different historical rows on the same day are deduplicated deterministically.
    distinct={d.strftime('%Y-%m-%d'):val for d,val in parsed}
    return {
        "id":metric_id,
        "value":latest[1],
        "asOf":latest[0].strftime('%Y-%m-%dT12:00:00Z'),
        "period":latest[0].strftime('%Y-%m-%d'),
        "source":"한국은행 ECOS · "+spec["table"]+"/"+spec["item"]+" · "+spec["period"],
        "verified":True,
        "history":[{"asOf":d+"T12:00:00Z","value":distinct[d]} for d in sorted(distinct)[-36:]],
    }

def collect(now=None):
    key=os.environ.get(KEY_NAME, "")
    if not key:
        raise DataError("환경 변수 ECOS_API_KEY 미설정 (키 자체는 전달하거나 기록하지 마세요)")
    now=now or datetime.now(timezone.utc)
    start=(now-timedelta(days=100)).strftime('%Y%m%d')
    end=now.strftime('%Y%m%d')
    class NoRedirect(HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            raise DataError("ECOS 리다이렉트 거부")
    opener=build_opener(NoRedirect)
    obs=[];errors={}
    for mid,spec in SPECS.items():
        try:
            url=build_url(spec,key,start,end)
            # Do not log URLs, request objects or urllib exceptions: URL contains secret.
            req=Request(url,headers={"Accept":"application/json","User-Agent":"SNOWBALL-ECOS-private-server/1.0"})
            with opener.open(req,timeout=12) as res:
                if res.geturl()!=url or res.status!=200:
                    raise DataError("ECOS HTTPS 응답 이상")
                blob=res.read(950001)
            if len(blob)>950000:
                raise DataError("ECOS 응답 허용 크기 초과")
            data=json.loads(blob)
            obs.append(parse_ecos(data,mid,now=now))
        except Exception:
            errors[mid]="데이터 응답·코드·최신성 검사 실패" # no raw URL/secret/error output
    return obs,errors

def main():
    ap=argparse.ArgumentParser(description="Authenticated ECOS server-only test collector")
    ap.add_argument("--out",required=True,help="Private local output JSON path; do not upload to a public repo without approval")
    args=ap.parse_args()
    try:
        obs,errors=collect()
        if not obs:
            print("ECOS 인증 또는 수집 검증 실패; 기존 확인자료 유지",file=sys.stderr)
            return 2
        out=Path(args.out).resolve(); out.parent.mkdir(parents=True,exist_ok=True)
        result={"schema":"NT_ECOS_VERIFIED_V1", "generatedAt":datetime.now(timezone.utc).isoformat(),"indicators":obs,"unconnected":sorted(set(SPECS)-{x['id'] for x in obs}),"errors":errors}
        tmp=out.with_suffix(out.suffix+".tmp")
        with open(tmp,"w",encoding="utf-8") as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write("\n")
        os.chmod(tmp,0o600);os.replace(tmp,out)
        print("검증된 ECOS 자료 저장:",len(obs),"개 (개인 서버 로컬 파일)")
        return 0
    except DataError as ex:
        print(str(ex),file=sys.stderr);return 2
if __name__=='__main__':
    raise SystemExit(main())
