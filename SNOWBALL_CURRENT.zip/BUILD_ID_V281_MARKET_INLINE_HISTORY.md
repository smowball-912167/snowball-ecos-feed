# V281 · MARKET FOUR FACTOR VISIBLE INLINE CHART
versionCode=60358
versionName=6.0.8-r9-v281
scope=Move existing V279 historical trend chart directly under currently selected four-factor indicator instead of after entire real-data list; preserve seven periods and documented guides; keep V279 selected-read fix and stable GitHub signing identity.
validation=LOCAL_SOURCE_AND_BROWSER_ONLY; APK_AND_GALAXY_PENDING
