# V280 — 설치 호환성 재시도 (2026-10-25)

- 이전 V279 GitHub APK 빌드 #508은 PASS였으나 Galaxy 설치에서 `앱이 설치되지 않음` 발생.
- 설치 원인은 아직 확정되지 않음: Android Package Installer의 정확한 실패 코드 / 기존 설치 앱의 서명·버전 정보 미확보.
- APK의 `versionCode` 60356→60357, `versionName` 6.0.8-r9-v279→6.0.8-r9-v280으로 단독 상승.
- 기존 package identity `com.snowball.noontangi.v60isolated`를 변경하지 않음.
- 기존 GitHub secret 기반 고정 signing config를 그대로 유지 (키 변경·대체 생성 금지).
- V279 선택읽기 TTS 고립/4대 시장환경 지표 차트, ECOS·거래원장·설정 등 모든 기능 파일을 보존.
- `s1_manifest.json` v208 진단 식별값과 3개 SHA256 소스 검증 규칙 유지.
- GitHub 검증용 소스 ZIP 제공; 실제 서명된 APK 빌드 및 휴대폰 덮어쓰기 설치 성공은 미검증.
- V280도 실패하면 재시도 반복보다 기존 설치 앱 versionCode/서명과 `verification.json`, 가능하면 Android PACKAGE_MANAGER 실패 코드 비교 필요.
- **기존 눈탱이 앱 삭제·데이터 초기화 금지**.
