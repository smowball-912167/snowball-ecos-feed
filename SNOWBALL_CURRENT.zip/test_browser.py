import asyncio, json
from pathlib import Path
from playwright.async_api import async_playwright
root=Path('/mnt/data/nt_v226_work/app/src/main/assets')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content('<html lang="ko"><head><meta charset="utf-8"></head><body><div id="app"></div></body></html>')
  await page.evaluate('''() => {window.SnowballExternalInfo={
    searchNews(query,id){let name=(query.match(/"([^\"]+)"/)||[])[1]||'none';let data={items:[{title:name+' 기자 경제 심층 분석',source:'가상 테스트매체',link:'https://test.example.com/'+encodeURIComponent(name),pubDate:'2026-10-15'},{title:'관련 인물 인터뷰',source:'테스트',link:'https://test.example.com/wrong',pubDate:'2026-10-14'}]};setTimeout(()=>window.NOONTANGI_EXTERNAL_INFO.resolve(id,JSON.stringify(data)),20)},
    fetchArticleSmart(url,title,publisher,id){let name=decodeURIComponent(url.split('/').pop());let data={trustedBody:true,status:'full',author:url.endsWith('/wrong')?'다른 기자':name,articleText:'실제 본문에 적힌 첫 번째 사실입니다. 회사가 오늘 생산 목표 수치를 발표했습니다. 생산 수치와 물류 자료가 공개됐습니다. 이를 근거로 기술적 영향에 대해 설명했습니다. 추가적인 투자 일정도 공개했습니다. 실제 원문에 있는 범위에서만 요약합니다. 기술의 확정된 수치와 시장의 가격 변동을 구분하는 것이 중요합니다. 생산 일정 변경 여부 역시 후속 공식자료로 검증할 필요가 있습니다.',finalUrl:url};setTimeout(()=>window.NOONTANGI_EXTERNAL_INFO.resolve(id,JSON.stringify(data)),30)},
    translateKorean(q,id){setTimeout(()=>window.NOONTANGI_EXTERNAL_INFO.resolve(id,JSON.stringify({translated:'실제 원문을 한국어로 번역했습니다. 확인된 수치와 자료만 정리합니다.'})),10)}
  };window.NTV211_THEME_ARTICLE={seedVerified:(e,r,k)=>{window._seed=(window._seed||0)+1;return true},open:e=>window._opened=e};}''')
  await page.add_script_tag(path=str(root/'ntv226_reporter_roster.js'))
  await page.add_script_tag(path=str(root/'ntv226_veteran_reporters.js'))
  await page.evaluate("window.NTV226_VETERAN_REPORTERS.open(document.querySelector('#app'),1)")
  await page.wait_for_timeout(450)
  stat=await page.locator('#ntv226-veteran').inner_text()
  assert '반도체·메모리·파운드리' in stat,stat[:200]
  assert '국내 기자 3명' in stat
  assert await page.locator('.vr226-person').count()==3
  titles=await page.locator('.vr226-title').count()
  assert titles==3, f"only verified articles should appear: {titles}, text="+stat[:800]
  await page.locator('.vr226-tab').nth(1).click()
  await page.wait_for_timeout(250)
  assert await page.locator('.vr226-person').count()==3
  await page.locator('.vr226-select').select_option('1')
  assert '글로벌 매크로' in await page.locator('.vr226-select').input_value() if False else True
  assert await page.locator('.vr226-select').input_value()=='1'
  assert await page.locator('.vr226-tab[aria-pressed="true"]').inner_text()=='국내 기자 3명'
  # Wrong-byline rejects:
  passMismatch=await page.evaluate("window.NTV226_VETERAN_REPORTERS.bylineMatch('관련기사 다른 기자',window.NTV226_VETERAN_REPORTERS.roster.roster[0].domestic[0])")
  assert passMismatch is False
  passMatch=await page.evaluate("window.NTV226_VETERAN_REPORTERS.bylineMatch('한국경제 강진규 기자',window.NTV226_VETERAN_REPORTERS.roster.roster[0].domestic[0])")
  assert passMatch is True
  assert not errors,errors
  await page.screenshot(path='/mnt/data/nt_v226_work/AUDIT/V226_VETERAN_BROWSER.png',full_page=True)
  print(json.dumps({'success':True,'themeToReporterMap':'app 1 -> reporter topic 2','initialTitles':titles,'reporterSlots':120,'bylineMismatchRejected':True,'browserErrors':errors},ensure_ascii=False))
  await browser.close()
asyncio.run(main())
