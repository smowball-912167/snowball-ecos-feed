# V206 — DENSITY / FLICKER / HOME TRENDS REPAIR

Baseline: V205. Generated 2026-10-10. App versionCode 60261, versionName `6.0.8-r9-v121-news-routing-journal-ui-r88-v206`, WebView cache `v=795`.

## Fixed / adjusted
- Short-term investment: compact stock search, typography reductions, hide duplicate code/market and OHLC chart heading; settings and active MA legends share a header. Dotted live-price line preserved, large red price rectangle removed, smaller price-axis margin with latest-candle space. Disparity separate strip removed; render bottom reference -10/-20/-30% in candle chart, selected MA base, and keep user selection. No auto trades.
- Journal: compact tool buttons, buy/sell/review summaries in three columns and smaller title/number typographic hierarchy; broaden holdings editor list for share records that contain `amount:0` placeholder; no mutation to old trade/cash ledger.
- HOME: `수익률 · 주식수 증감률 추이` entry restored on main portfolio card; trend controls and graph placed before holdings in portfolio detail. Six periods kept, no invented historical prices.
- Flicker root cause: old V46 `totalInvestClean()` wrote identical text on each MutationObserver-triggered pass, causing a feedback loop; change only when text differs. V21 no longer writes an already-present class to DOM. HOME portfolio + radar skip repeat redraw for identical data.
- Existing navigation, accounts, news pipelines and manual trade principle preserved.

## QA performed
- JavaScript syntax parsed 108 or 109 inline scripts, zero errors (final check after guide insertion pending).
- Browser `set_content` responsive checks 360/412/540 px: no horizontal page overflow, chart/settings present, MA/disparity legend visible.
- Chart -20% selection persisted in in-memory storage and changed legend; holdings editor displayed test holding 17 shares with `amount:0`; HOME trend button opened modal and all six periods shown.
- Independent 412px page idle DOM mutation count measured over 3.5s: V205 127, V206 21. Counts indicate reduced redundant DOM writes, **not proof that every Galaxy flicker disappeared**.
- External quote feeds, WebView/device runtime, native build unverified. No falsely asserted real-device success.
