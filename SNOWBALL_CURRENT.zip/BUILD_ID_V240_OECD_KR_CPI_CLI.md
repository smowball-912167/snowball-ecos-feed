V240: Korea CPI monthly YoY + Korean OECD CLI observed via narrowly scoped OECD SDMX. No new scores. Prior US collectors and rest of app untouched. Device live API not verified.
