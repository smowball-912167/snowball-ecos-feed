# V226 · Verified veteran byline, multi-theme article links
- 20 sets × 6 candidate byline slots (120 roster slots), per article byline validation.
- Original article title+body conservative classification to any number of growth themes; menu origin never used as tag.
- One canonical article, multiple theme refs, separate veteran article cache; missing theme -> unclassified shelf (no deletion).
- Legacy V226 menu-derived tags are invalidated and queued for reclassification.
- App theme/detail/routing, guide and DOCX synchronized.
- Static and mock browser tests passed; actual publisher and mobile APK remain unverified.
