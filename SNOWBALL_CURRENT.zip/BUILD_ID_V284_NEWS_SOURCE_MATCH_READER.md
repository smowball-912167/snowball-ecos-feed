# V284 NEWS SOURCE MATCH READER (2026-11-02)

- V283 baseline; no change to APK signing identity or install package ID.
- Native WebView article collector: fix cloned-DOM headline gating that dropped valid paragraphs; require matched page headline for JSON-LD/body extraction to avoid cross-article text.
- Major News: source-only sentence extraction, preserve decimals and full sentences, remove unsupported fallback cut at 850 characters.
- Selection reading: read exactly the opened article title and verified summary; skip parentheticals and symbols. Never read UI status/links or fabricate article content.
- Title-only articles: short status; on opening, retry source once per 2 minutes with saved URL. Existing V283 cached summaries are hidden until new source validation; original article references are preserved.
- Keep opened item and scrolling stable when fetch or translation re-renders the list.
- Device/network verification required for publisher-blocked sites and voice.
