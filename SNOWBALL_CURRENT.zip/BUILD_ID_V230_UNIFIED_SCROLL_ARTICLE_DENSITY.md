# V230 / 60311 · Unified scroll and article title density

- Single user requirement: first through twentieth theme always reachable, no top/bottom clipping against fixed banner and Galaxy navigation.
- Scrolling is independent of fixed menu, with measured header and nav locations. Restore theme list scroll after returning from theme detail.
- Compact title/date/publisher, dynamic card height and 8px between article cards.
- Preserve article reaction row at end of detail, with safe scroll bottom inset.
- All 20 themes and existing articles, veteran reporter and source URLs remain unchanged.
- Browser mock: first/last theme screenshots and compact article title checks. Actual device remains to be checked after APK build.
