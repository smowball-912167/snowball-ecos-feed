from pathlib import Path
import json,hashlib,re
root=Path('/mnt/data/voice_work')
java=root/'app/src/main/java/com/snowball/noontangi/MainActivity.java'
p=java.read_text()
def once(src,old,new):
    n=src.count(old)
    if n!=1: raise RuntimeError(f'expected one match, found {n}: {old[:130]}')
    return src.replace(old,new,1)
p=once(p,'private boolean voiceRecognizerActive = false;', '''private boolean voiceRecognizerActive = false;
    // V265: one-shot STT check is isolated from navigation and AI routing. No audio is stored.
    private boolean voiceCheckOnce = false;''')
p=once(p,'''                        if (now < voiceIgnoreErrorsUntilMs &&''','''                        if (voiceCheckOnce) {
                            voiceCheckOnce = false;
                            notifyVoiceCheckResult("", "음성을 인식하지 못했습니다 (" + error + "). 다시 한 번 짧게 말씀해 보세요.");
                            return;
                        }
                        if (now < voiceIgnoreErrorsUntilMs &&''')
p=once(p,'''                        ArrayList<String> turnCandidates = mergeVoiceTurnCandidates(voiceListenSerial, finals);
                        // V120''','''                        ArrayList<String> turnCandidates = mergeVoiceTurnCandidates(voiceListenSerial, finals);
                        if (voiceCheckOnce) {
                            voiceCheckOnce = false;
                            String heard = (finals != null && !finals.isEmpty()) ? finals.get(0) :
                                    (turnCandidates.isEmpty() ? "" : turnCandidates.get(0));
                            clearVoicePartialHistory();
                            notifyVoiceCheckResult(heard, heard.isEmpty() ? "인식 결과가 없습니다." : "");
                            return; // Never navigate, dispatch an AI question, or speak during STT check.
                        }
                        // V120''')
p=once(p,'''                i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 950L);
                i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 550L);''','''                i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1450L);
                i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L);''')
p=once(p,'''    private void notifyVoiceError(String message) {''','''    private void notifyVoiceCheckResult(String text, String error) {
        if (webView == null) return;
        String heard = JSONObject.quote(text == null ? "" : text);
        String detail = JSONObject.quote(error == null ? "" : error);
        webView.post(() -> webView.evaluateJavascript(
                "window.SNOWBALL_NATURAL_CHAT&&window.SNOWBALL_NATURAL_CHAT.onSpeechCheckResult(" +
                heard + "," + detail + ");", null));
    }

    private void notifyVoiceError(String message) {''')
p=once(p,'''        stopVoiceNative();
        notifyJsLifecycle("window.SNOWBALL_NATURAL_CHAT''','''        voiceCheckOnce = false;
        stopVoiceNative();
        notifyJsLifecycle("window.SNOWBALL_NATURAL_CHAT''')
p=once(p,'''        @JavascriptInterface public void listen() { startVoiceListen(); }
        @JavascriptInterface public boolean ready()''','''        @JavascriptInterface public void listen() { startVoiceListen(); }
        @JavascriptInterface public void checkSpeech() {
            runOnUiThread(() -> {
                voiceCheckOnce = true;
                if (voiceRecognizerActive) {
                    voiceCheckOnce = false;
                    notifyVoiceCheckResult("", "음성 대화가 실행 중입니다. 먼저 대화를 종료해 주세요.");
                    return;
                }
                startVoiceListen();
            });
        }
        @JavascriptInterface public boolean ready()''')
p=once(p,'''        else { pendingVoiceListen = false; notifyVoiceError("마이크 권한이 필요합니다. 설정에서 마이크 권한을 허용해 주세요."); }''','''        else {
            pendingVoiceListen = false;
            if (voiceCheckOnce) {
                voiceCheckOnce = false;
                notifyVoiceCheckResult("", "마이크 권한이 필요합니다. 휴대폰 설정에서 허용해 주세요.");
            } else notifyVoiceError("마이크 권한이 필요합니다. 설정에서 마이크 권한을 허용해 주세요.");
        }''')
java.write_text(p)
html=root/'app/src/main/assets/index.html'
h=html.read_text()
h=once(h,'''#ntv264NaturalSettings button{min-height:34px''','''#ntv265SpeechCheck{margin:8px 0 4px;line-height:1.5;font-weight:700;color:#184d73;white-space:pre-wrap;overflow-wrap:anywhere}
#ntv264NaturalSettings button{min-height:34px''')
h=once(h,'''function validEndpoint(endpoint){''','''function readyForChat(){try{return config.share&&validEndpoint(config.endpoint)&&!!(window.SnowballChat&&window.SnowballChat.hasAccessCode&&window.SnowballChat.hasAccessCode())}catch(_e){return false}}
function validEndpoint(endpoint){''')
h=once(h,'''return announce(q,'지금은 자유대화 서버가 연결되지 않았어요. 환경설정의 AI 대화에서 서버 주소와 전송 동의를 설정하면 ChatGPT·Gemini로 자연스럽게 이어갈 수 있어요.','notice',voice)}''','''var message='말씀하신 내용은 들었어요. 다만 ChatGPT·Gemini 서버가 아직 연결되지 않아 실제 답변은 할 수 없습니다. 환경설정에서 서버 연결 후 대화를 사용할 수 있습니다.';
if(voice){display(q,message,true);addRecord(q,message,'notice',true);setTimeout(stopVoice,0);return {text:message,src:'서버 미연결'}}
return announce(q,message,'notice',false)}''')
h=once(h,'''function startAuto(){if(isPaused||config.mode!=='auto')return;var v=voice();''','''function startAuto(){if(isPaused||config.mode!=='auto')return;
if(!readyForChat()){setStatus('서버 연결 전에는 상시 마이크가 자동으로 켜지지 않습니다. 음성인식 확인은 아래 버튼을 사용하세요.');return}
var v=voice();''')
h=once(h,'''function modeChanged(m){config.mode=m==='auto'?'auto':'button';save();if(config.mode==='auto'){isPaused=false;startAuto()}else{stopVoice();setStatus('버튼을 누르면 대화 시작')}}''','''function modeChanged(m){config.mode=m==='auto'?'auto':'button';save();if(config.mode==='auto'){isPaused=false;if(readyForChat())startAuto();else{stopVoice();startAuto()}}else{stopVoice();setStatus('버튼을 누르면 대화 시작')}}''')
h=once(h,'''setStatus(config.share&&validEndpoint(config.endpoint)&&window.SnowballChat&&window.SnowballChat.hasAccessCode&&window.SnowballChat.hasAccessCode()?'AI 연결 준비됨 · 첫 질문에서 확인':'AI 대화 서버·접속코드 연결 필요')}''','''setStatus(readyForChat()?'AI 연결 준비됨 · 첫 질문에서 확인':config.mode==='auto'?'서버 미연결 · 상시 마이크 자동 시작 보류':'AI 대화 서버·접속코드 연결 필요')}''')
h=once(h,'''<div id="ntv264ChatStatus" role="status"></div><hr /><h3>🎙 내 목소리 학습</h3>''','''<div id="ntv264ChatStatus" role="status"></div><hr /><h3>🎙 음성인식 확인</h3><p>AI 서버 없이 한 번만 음성을 인식합니다. 인식된 문장을 아래에 표시하고 앱 메뉴를 실행하거나 AI로 보내지 않습니다. 음성처리는 휴대폰의 음성인식 서비스가 담당하며 서비스 설정에 따라 네트워크를 이용할 수 있습니다.</p><button type="button" id="ntv265SpeechButton">🎙 한 문장 인식해 보기</button><div id="ntv265SpeechCheck" role="status" aria-live="polite">대기 중 · 녹음파일 저장 안 함</div><hr /><h3>🎙 내 목소리 학습</h3>''')
h=once(h,'''if(e.target.id==='ntv264SaveCode'){''','''if(e.target.id==='ntv265SpeechButton'){beginSpeechCheck();return;}
if(e.target.id==='ntv264SaveCode'){''')
h=once(h,'''setStatus(ok?'서버 접속코드를 기기 보안저장소에 저장했습니다.':'저장 실패 · 12자 이상 코드와 연결을 확인하세요');}''','''setStatus(ok?'서버 접속코드를 기기 보안저장소에 저장했습니다.':'저장 실패 · 12자 이상 코드와 연결을 확인하세요');if(ok&&config.mode==='auto')startAuto();}''')
h=once(h,'''setStatus('서버 접속코드를 삭제했습니다');}''','''stopVoice();setStatus('서버 접속코드를 삭제했습니다');}''')
h=once(h,'''if(el.id==='ntv264Share'){config.share=el.checked;save();sync()}''','''if(el.id==='ntv264Share'){config.share=el.checked;save();if(!readyForChat())stopVoice();sync();if(readyForChat()&&config.mode==='auto')startAuto()}''')
h=once(h,'''config.endpoint=u;save();sync()}''','''config.endpoint=u;save();if(!readyForChat())stopVoice();sync();if(readyForChat()&&config.mode==='auto')startAuto()}''')
h=once(h,'''function onAppPause(){isPaused=true;stopVoice()}''','''var speechCheckTimer=0;
function onSpeechCheckResult(text,error){clearTimeout(speechCheckTimer);speechCheckTimer=0;
var t=document.getElementById('ntv265SpeechCheck');if(!t)return;
t.textContent=error?'인식 실패: '+String(error).slice(0,220):'인식된 문장: '+String(text||'').slice(0,450);
setStatus('음성인식 확인 완료 · AI 서버 전송 없음');}
function beginSpeechCheck(){
if(speechCheckTimer){setStatus('이미 음성인식을 확인하고 있습니다.');return}
var b=window.SnowballVoice;if(!b||typeof b.checkSpeech!=='function'){setStatus('이번 앱 버전에서는 음성확인 기능을 사용할 수 없습니다.');return}
stopVoice();var t=document.getElementById('ntv265SpeechCheck');if(t)t.textContent='마이크 준비 중…';
speechCheckTimer=setTimeout(function(){speechCheckTimer=0;try{b.stop()}catch(_e){};if(t)t.textContent='인식 시간 초과 · 다시 시도할 수 있습니다.'},17000);
setTimeout(function(){try{b.checkSpeech();if(t)t.textContent='한 문장을 자연스럽게 말해 보세요.'}catch(e){onSpeechCheckResult('','마이크를 시작하지 못했습니다.')}},850);
}
function onAppPause(){isPaused=true;clearTimeout(speechCheckTimer);speechCheckTimer=0;stopVoice()}''')
h=once(h,'''onAppResume:onAppResume,settings:function()''','''onAppResume:onAppResume,onSpeechCheckResult:onSpeechCheckResult,settings:function()''')
h=once(h,'''version:'V264 natural chat (API-gated)' ''','''version:'V265 voice check and auto listen guard (API-gated)' ''') if '''version:'V264 natural chat (API-gated)' ''' in h else h.replace("version:'V264 natural chat (API-gated)'","version:'V265 voice check and auto listen guard (API-gated)'")
# update app guide section and make version distinction explicit
h=once(h,'''<h3>V264 · 자연대화·상시대화 설정</h3>''','''<h3>V265 · 음성인식 확인·상시대화 보호</h3>''')
h=once(h,'''상시 청취 시 마이크 권한이 필요하며 앱 종료·백그라운드 진입 시 음성을 중지합니다. 목소리 본인 식별은''','''상시 청취는 AI 서버가 실제 설정된 경우에만 자동 시작합니다. 환경설정의 한 문장 인식 확인은 서버 없이 STT 결과만 보여주고 앱 동작이나 AI 서버에 전달하지 않습니다. 마이크 권한이 필요하며 앱 종료·백그라운드 진입 시 음성을 중지합니다. 목소리 본인 식별은''')
html.write_text(h)
# Android version; keep existing app identity
build=root/'app/build.gradle'
b=build.read_text();b=once(b,'versionCode 60342','versionCode 60343');b=once(b,"versionName '6.0.8-r9-v264'","versionName '6.0.8-r9-v265'");build.write_text(b)
manifest=root/'app/src/main/assets/s1_manifest.json'
m=json.loads(manifest.read_text());m['assetSha256']=hashlib.sha256(html.read_bytes()).hexdigest();m['mainActivitySha256']=hashlib.sha256(java.read_bytes()).hexdigest();m['gradleSha256']=hashlib.sha256(build.read_bytes()).hexdigest();m['versionCode']=60343;m['versionName']='6.0.8-r9-v265';m['scope']='V265 one-shot Android STT test and unconfigured auto-mic guard; V264 dual-provider gateway remains API-gated, speaker verification not implemented; V262 market/finance unchanged.'
manifest.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
with (root/'BUILD_ID_V265_VOICE_RECOGNITION_SAFE_DIAGNOSTIC.md').open('w') as f:
 f.write('''# V265 — Native STT confirmation and auto-mic guard (2026-10-23)\n\n- Microphone in automatic chat mode starts only when HTTPS gateway, secure client access code and consent are configured.\n- Add a one-shot Android STT diagnostic in Settings > AI voice: shows recognized phrase, does not route a menu command, launch provider request, keep audio recordings or collect voice biometrics.\n- Prevent repeating spoken \"server not connected\" prompts when the gateway is missing. The unavailable message displays once and the active voice session stops.\n- Slightly relax the Android speech endpoint pauses (recognizers may ignore these hints).\n- Preserve V264 ChatGPT/Gemini routing and all market/finance/data processing. Do not claim speaker verification or live AI connection.\n- Recalculate 3 S1 source hashes and versionCode 60343. APK build and Galaxy physical test NOT performed in this environment.\n- Note: Android speech service may process audio on network according to device configuration.\n''')
with (root/'V265_설치전_안내.txt').open('w') as f:
 f.write('''눈탱이 V265 음성인식 보완 안내\n\n1. 환경설정 > AI 목소리 > 한 문장 인식해 보기: AI 서버 연결 없이 휴대폰의 음성인식 결과를 화면에서 확인. 녹음 파일 저장·AI 서버 전송 없음. 앱 명령 실행 없음.\n2. 상시 대화 선택 상태여도 HTTPS AI 서버·접속코드·데이터 전송 동의가 없으면 마이크 자동 시작을 보류.\n3. 기존 서버 미연결 안내를 반복 음성으로 내보내는 동작 중단.\n4. 사용자 목소리 학습 및 본인 식별 미구현. 실제 Gemini·ChatGPT API 서버 연결도 미완료.\n5. 기존 V264 시장환경·ECOS·금융 데이터·페이지·선택읽기 기능 유지.\n6. S1 해시 일치 및 JavaScript 구문 테스트 가능. 실제 GitHub 빌드/갤럭시 시험은 업로드 후 확인 필요.\n\nIMPORTANT: 이 업데이트는 음성 인식 동작의 결과 확인 및 마이크 루프를 고친 것이지 Gemini/ChatGPT 서버를 배포한 것은 아닙니다.\n''')
print('patched: Java/HTML/Gradle/S1')
