# V205 — RESPONSIVE LAYOUT, JOURNAL EDITOR, CHART INDICATORS, HOME TRENDS

2026-10-10; baseline V204. App code `versionCode 60251`, `versionName 6.0.8-r9-v121-news-routing-journal-ui-r87-v205`, WebView cache `v=794`.

1. Unified layout: header bottom and main app navigation top form strict viewport boundaries on 360/412/540px layouts. Runtime layout measurement complements CSS fallbacks, keeping Galaxy OS system navigation out of popup hit regions. Mobile left/right edge gaps use dynamic clamp; price charts scale by viewport.
2. Journal defect: V204 editor duplicated when `shell()` looked inside `.ntv125-body` after the modal pane was moved outside it. V205 finds/reuses the existing `.v204-holdings-pane` under the journal shell, avoiding old form writes. Persisted qty/avg and anchor values are checked. Historical trades and cash entries remain unchanged; no automatic trading.
3. Short-term chart: right chart price-label gutter reserved 78px to avoid latest candle overlap; settings button supports moving average (MA5/20/60/120), optional independent disparity band, selectable base average and custom upper/lower percentages (defaults 110%, 90%). Options stored locally; stop-profit/stop-loss labels suppressed in the chart. Indicator is not a trading instruction.
4. Selected stock UI: name and six-digit code render on the same responsive line; hide duplicate localized speaker buttons and keep common fixed AI conversation / Select Read controls.
5. Actual portfolio history modal: returns / quantity-change chart period options day/week/month/quarter/half-year/year; no fabricated historical market quotes for empty time buckets. Original manual trading flows preserved.
6. QA: parsed 106 inline scripts, Node syntax 0 errors. Browser 360/412/540px confirmed overlay top 134 and nav start 795 in 915px test viewport, chart settings percentages persistence, six HOME units. Browser journal demo persisted 20->37 shares and avg 12000->11780; redraw preserved editor. Some whole-page runtime errors remain due no storage permissions/file-URL browser environment and existing initialization, not signed-off Android APK.

Final Android device QA pending for real header / system nav insets, touch/scroll, chart live prices and true finance history sources. Preserve V204 files in zip as historical references, root V205 manual is current.
