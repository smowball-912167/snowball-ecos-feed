id]=x});
 var a=Object.keys(m).map(function(k){return m[k]}).sort(function(x,y){return y.ts-x.ts}).slice(0,80);
 jset(FIRE_PENDING,a);return a;
}
function firePendingList(mode){
 var scope=mode==='global'?'GLOBAL':'KR',a=jget(FIRE_PENDING,[]);if(!Array.isArray(a))return[];
 var ready=jget(FIRE_STORE,[]);if(!Array.isArray(ready))ready=[];
 var verified={};ready.forEach(function(x){if(x&&x.preReadReady&&x.trustedBody)verified[x.id]=1});
 return a.filter(function(x){return x&&x.scope===scope&&!verified[x.id]&&x.ts&&Date.now()-x.ts<4*86400000}).sort(fireRankCompare).slice(0,12);
}
function fireSpecsForBucket(bucket){var scope=bucket==='global'?'GLOBAL':'KR';return FIRE_QUERY_SPECS.filter(function(x){return x.scope===scope})}
function collectFire(reason,bucket){
 bucket=bucket==='global'?'global':'domestic';
 if(fireRunning){if(!FIRE_QUEUED.some(function(x){return x.mode===bucket}))FIRE_QUEUED.push({mode:bucket,reason:reason||'queued-refresh'});FIRE_QUEUED_MODE=FIRE_QUEUED.map(function(x){return x.mode}).join(',');renderFiremouthAuto();return Promise.resolve(false)}
 fireRunning=true;var began=Date.now(),specs=fireSpecsForBucket(bucket),scope=bucket==='global'?'GLOBAL':'KR';jset(FIRE_ATTEMPT,began);renderFiremouthAuto();
 function finish(ok,rawCount,candidateCount,ready,failed,errors){var lastSuccess=Number(jget(FIRE_RUN,0))||0,prev=jget(FIRE_STATS,{})||{},by=prev.lastSuccessByMode&&typeof prev.lastSuccessByMode==='object'?prev.lastSuccessByMode:{};if(ready.length){lastSuccess=Date.now();by[bucket]=lastSuccess;jset(FIRE_RUN,lastSuccess)}try{localStorage.setItem('nt_v121r4_firemouth_last_reason',String(reason||'manual-refresh'))}catch(e){}var newest=fireView(bucket).reduce(function(mm,x){return Math.max(mm,fireRepairTs(x))},0),state=ok===0?'fail':(ready.length?'ok':(candidateCount?'partial':'stale'));var statusByMode=Object.assign({},prev.statusByMode||{});statusByMode[bucket]={at:Date.now(),state:state,queries:specs.length,okQueries:ok,raw:rawCount,candidates:candidateCount,prepared:ready.length,errorSummary:errors.slice(0,4).join(' | ')};jset(FIRE_STATS,{lastAttempt:began,lastSuccess:lastSuccess,lastSuccessByMode:by,statusByMode:statusByMode,lastRun:lastSuccess,reason:String(reason||''),bucket:bucket,totalQueries:specs.length,okQueries:ok,failedIds:failed,raw:rawCount,candidates:candidateCount,prepared:ready.length,stored7d:fireView(bucket).length,archived30d:(function(){var h=jget(FIRE_HISTORY,[]);return Array.isArray(h)?h.filter(function(x){return bucket==='global'?x.scope==='GLOBAL':x.scope==='KR'}).length:0})(),newestTs:newest,elapsedMs:Date.now()-began,state:state,errorSummary:errors.slice(0,4).join(' | ')});renderFiremouthAuto();renderFireBell();if(bucket==='global')setTimeout(fireKickPendingGlobalTranslations,300);return ready.length>0}
 var ok=0,rawCount=0,failed=[],errors=[],raw=[];
 function absorb(packs){(packs||[]).forEach(function(pack){if(pack.ok)ok++;else{failed.push(pack.spec.id);if(pack.error)errors.push(pack.spec.id+':'+pack.error)}var items=Array.isArray(pack.r&&pack.r.items)?pack.r.items:[];rawCount+=items.length;items.forEach(function(it){var pm=pubMs(it.pubDate);if(pm&&Date.now()-pm<72*3600000&&Date.now()-pm>-3600000&&fireDiscoveryCandidate(it,pack.spec))raw.push(normalizeFire(it,pack.spec))})})}
 function currentPool(){return fireEventDedupe(raw).filter(function(x){return x.scope===scope}).sort(fireRankCompare)}
 return runFireSpecs(specs,9000).then(function(primary){absorb(primary);var pool=currentPool(),need=[];if(pool.length<(bucket==='global'?18:8))need=FIRE_FALLBACK_SPECS.filter(function(x){return x.scope===scope});var more=need.length?runFireSpecs(need,9000):Promise.resolve([]);return more.then(function(packs){absorb(packs);var candidates=currentPool().slice(0,bucket==='global'?28:16);firePendingSave(candidates);renderFiremouthAuto();return preReadFireBatch(candidates).then(function(ready){return finish(ok,rawCount,candidates.length,ready,failed,errors)})})
 }).catch(function(err){var prev=jget(FIRE_STATS,{})||{},by=prev.lastSuccessByMode&&typeof prev.lastSuccessByMode==='object'?prev.lastSuccessByMode:{};jset(FIRE_STATS,Object.assign({},prev,{lastAttempt:began,lastSuccessByMode:by,reason:String(reason||''),bucket:bucket,state:'fail',error:String(err&&err.message||err||'COLLECT_FAILED').slice(0,180),elapsedMs:Date.now()-began}));renderFiremouthAuto();return false}).finally(function(){fireRunning=false;try{document.documentElement.dataset.v190FireMs=String(Date.now()-began)}catch(e){}renderFiremouthAuto();var queued=FIRE_QUEUED.shift();FIRE_QUEUED_MODE=FIRE_QUEUED.map(function(x){return x.mode}).join(',');if(queued)setTimeout(function(){collectFire(queued.reason||'queued-refresh',queued.mode)},100)})
}

function scheduleFire(){try{var old=localStorage.getItem(FIRE_SCHEMA)||'';if(old!=='V189'){localStorage.setItem(FIRE_SCHEMA,'V189');fireMigrateV188History()}}catch(e){}setTimeout(notifyFireOwner,120);setTimeout(fireKickPendingGlobalTranslations,1500)}

function fireSnapshot(){var a=fireView('domestic'),x=a[0];if(!x)return {ready:false,text:'불주댕이에 준비 완료된 영향력 인사 발언이 아직 없습니다.'};return {ready:true,item:x,text:String(x.deepSummary||''),src:'불주댕이 · 사전 정독 발언 요약'}}
function selfTest(){var cases=[['단기투자 보여줘','nav'],['한온시스템 보여줘','stock'],['이 종목 설명해줘','explain'],['오늘 왜 반등했어','latest'],['최신 뉴스 알려줘','latest'],['이 내용 읽어줘','read'],['단기투자가 왜 중요해','explain']];var ok=true,got=[];cases.forEach(function(c){var x=intent(c[0]);got.push(c[0]+'=>'+x);if(x!==c[1])ok=false});document.documentElement.dataset.v121r4IntentSelftest=ok?'ok':'fail';document.documentElement.dataset.v121r4IntentCases=got.join('|');return ok}
function fireAnalysisSelfTest(){var now=Date.now(),base={title:'한국은행 총재, 물가와 환율 고려해 금리 판단',actor:'한국은행 총재',description:'통화정책 관련 발언',deepStatus:'done',scope:'KR',ts:now},body='한국은행 총재는 이날 서울에서 물가 둔화 흐름과 원화 환율을 확인한 뒤 기준금리 인하 시기를 판단하겠다고 말했다. 물가가 목표 수준으로 안정되는지 확인할 필요가 있기 때문이라고 설명했다. 그는 금융시장 변동성이 확대되면 인하 속도를 조정하겠다고 밝혔다.',story=fireSpeechNarrativeText(base,body),politics=!fireDiscoveryCandidate({title:'의원 질의 답하는 이형일 부총리 [포토]',description:'국회 국정감사 질의 답변'},{scope:'KR'}),bodyPolitics=!fireSpeechBodyVerified({title:'김정관 장관 대미투자 국익 최우선',actor:'김정관 장관',scope:'KR',description:'대미투자'},'김정관 장관은 국정감사에서 의원 질의에 답하며 대미 투자는 국익을 최우선으로 판단하겠다고 말했다. 투자 규모와 방식도 검토하겠다고 밝혔다.'),meeting=!fireDiscoveryCandidate({title:'경제6단체장 만나 이형일 부총리 기업 투자 애로 해소 약속',description:'간담회 참석'},{scope:'KR'}),personnel=!fireDiscoveryCandidate({title:'한국은행 수뇌부 전격 개편 부총재보 최영주 선임',description:'인사 단행'},{scope:'KR'}),generic=!fireMeaningfulSpeech({title:'리사 수 AMD 회장 삼성 SK 협력 강조',actor:'리사 수',scope:'GLOBAL',description:'파트너십'},'Lisa Su said Samsung and SK are very important partners and AMD will continue close cooperation for the next three to five years.'),tariff=fireMeaningfulSpeech({title:'트럼프 한국에 관세 인하 대가 요구',actor:'Donald Trump',scope:'GLOBAL',description:'tariff trade'},'Donald Trump said the United States would lower tariffs on Korea only in exchange for a large investment commitment and demanded new terms.'),crypto=fireMeaningfulSpeech({title:'Cathie Wood reiterates Bitcoin target',actor:'Cathie Wood',scope:'GLOBAL',description:'bitcoin forecast'},'Cathie Wood said Bitcoin could reach $1.5 million by 2030 as institutional investment and AI payment adoption expand.'),greenDupe=fireEventDedupe([{title:'이 대통령, 삼성 LG 포스코 한화와 K-GX 시동 녹색산업 투자전략 공개',actor:'이재명 대통령',scope:'KR',ts:now,source:'매체A',description:'녹색산업 투자전략',trustedBody:true,preReadReady:true},{title:'이재명 대통령 녹색대전환은 첨단산업 초격차 유지 위한 필수 전제',actor:'이재명 대통령',scope:'KR',ts:now,source:'매체B',description:'녹색대전환 산업정책',trustedBody:true,preReadReady:true}]).length===1,dupe=fireEventDedupe([{title:'파월 물가 둔화에도 금리 인하 신중',actor:'제롬 파월',scope:'GLOBAL',ts:now,source:'Reuters',description:'연준 금리 발언',trustedBody:true,preReadReady:true},{title:'파월 물가 둔화 속 금리 인하 신중론',actor:'Jerome Powell',scope:'GLOBAL',ts:now,source:'Bloomberg',description:'Federal Reserve rates inflation',trustedBody:true,preReadReady:true}]).length===1,sixW=story.length>=120&&/서울/.test(story)&&/(필요|때문)/.test(story)&&/(조정|판단)/.test(story),tailClean=fireNarrationClean("핵심 발언자는 금리를 신중히 판단하겠다고 말했다. 음료수로 180억 매출 '120억 펜트하우스 이사' 연예뉴스…").indexOf('펜트하우스')<0,pendingGlobal=firePreparedStory({trustedBody:true,deepVersion:'V189',scope:'GLOBAL',translationReady:false,originalDeepSummary:'Ray Dalio said debt risks could rise over the next two years as fiscal burdens and bond-market volatility increase, and investors should consider gold and inflation-linked bonds as defensive assets.'}).length>0,koReady=firePreparedStory({trustedBody:true,deepVersion:'V189',scope:'GLOBAL',translationReady:true,displaySummary:'레이 달리오는 최근 인터뷰에서 향후 2년 안에 부채 위기가 발생할 가능성이 커지고 있다고 경고했다. 그는 정부의 재정 부담과 채권시장 변동성이 확대될 수 있다며 투자자들이 금과 물가연동채 같은 방어 자산의 역할을 함께 살펴야 한다고 말했다. 또한 부채와 물가 흐름이 동시에 시장 위험을 키울 수 있다고 설명했다.'}).length>0,ok=politics&&bodyPolitics&&meeting&&personnel&&generic&&tariff&&crypto&&greenDupe&&dupe&&sixW&&tailClean&&pendingGlobal&&koReady&&!fireFatalJunk(story);document.documentElement.dataset.v189FireReaderSelftest=ok?'ok':'fail';document.documentElement.dataset.v189FireReaderSelftestDetail=[story.length,politics,bodyPolitics,meeting,personnel,generic,tariff,crypto,greenDupe,dupe,sixW,tailClean,koReady].join('|');document.documentElement.dataset.v189FireReaderSelftestStory=story.slice(0,900);return ok}

/* V190 ARTICLE MONITOR — separate quick menu. Same evidence-first philosophy as Firemouth; the speaker is the reporter/article. */
var ARTICLE_STORE='nt_v190_article_monitor_store',ARTICLE_HIST='nt_v190_article_monitor_history',ARTICLE_STATS='nt_v190_article_monitor_stats';
var ARTICLE_OPEN_MODE='domestic',ARTICLE_HISTORY_VIEW=false,ARTICLE_RUNNING=false,ARTICLE_RUNNING_MODE='',ARTICLE_QUEUED_MODE='',ARTICLE_FIRST={domestic:false,global:false};
var ARTICLE_PREVIEWS='nt_v192_major_news_preview',ARTICLE_TRANSLATING={},ARTICLE_KO_PUMP=[],ARTICLE_KO_BUSY=0;
var ARTICLE_SORT_KEY='nt_v193_major_news_sort',ARTICLE_SORT_MODE=String(jget(ARTICLE_SORT_KEY,'impact')||'impact');if(ARTICLE_SORT_MODE!=='recent')ARTICLE_SORT_MODE='impact';
var ARTICLE_SPECS=[
 {id:'nk_market',scope:'KR',q:'증시 기업 실적 when:3d'},
 {id:'nk_chip',scope:'KR',q:'반도체 HBM AI 투자 when:3d'},
 {id:'nk_energy',scope:'KR',q:'전력 원전 공급망 수주 when:3d'},
 {id:'nk_industry',scope:'KR',q:'자동차 배터리 조선 방산 수주 when:3d'},
 {id:'nk_money',scope:'KR',q:'금리 환율 코스피 시장 when:3d'},
 {id:'nk_analysis',scope:'KR',q:'기업 산업 분석 전망 when:3d'},
 {id:'ng_market',scope:'GLOBAL',q:'stock markets economy earnings when:3d'},
 {id:'ng_chip',scope:'GLOBAL',q:'AI chips semiconductor investment when:3d'},
 {id:'ng_trade',scope:'GLOBAL',q:'tariffs trade export controls when:3d'},
 {id:'ng_energy',scope:'GLOBAL',q:'energy electricity grid nuclear when:3d'},
 {id:'ng_fed',scope:'GLOBAL',q:'Federal Reserve inflation rates when:3d'},
 {id:'ng_company',scope:'GLOBAL',q:'technology companies earnings capex when:3d'},
 {id:'ng_finance',scope:'GLOBAL',q:'credit bonds markets risk when:3d'},
 {id:'ng_korea',scope:'GLOBAL',q:'Korea semiconductor batteries trade when:3d'}
];
function articleScreenClean(v){return String(v||'').replace(/^(?:상황|배경|요약|핵심내용)\s*[:：]\s*/i,'').replace(/\bAMD\s+AMD는\s+CEO인\s+Lisa\s+Su가/gi,'AMD 최고경영자 리사 수가').replace(/\b(AMD|NVIDIA|TSMC|SK|LG|AI)\s+\1(?=[은는이가을를와과]?(?:\s|[가-힣]|$))/gi,'$1').replace(/\s+/g,' ').trim()}
function articleClean(v){return fireNarrationClean(String(v||'')).replace(/\s+/g,' ').trim()}
function articleCandidate(it,spec){var t=String(it&&it.title||''),d=String(it&&it.description||'').replace(/<[^>]+>/g,' '),z=t+' '+d;if(t.length<10)return false;if(/연예|아이돌|드라마|영화|맛집|여행|프로야구|축구 경기|농구|celebrity|movie|travel|recipe|sports/i.test(z))return false;if(/포토|사진기사|주요 일정|날씨|운세|로또|사건사고|교통사고/.test(z))return false;return fireInvestmentRelevant(z)||/(실적|수주|증설|공급망|업황|산업|기업|시장|분석|전망|risk|outlook|earnings|revenue|orders|capex|supply chain|industry|markets?)/i.test(z)}
function articleNorm(it,spec){var pm=pubMs(it.pubDate)||Date.now(),src=String(it.source||'공개보도');return {id:'art_'+Math.abs(fireHash(String(it.url||it.link||it.title||'')+'|'+String(pm))).toString(36),title:String(it.title||'').replace(/\s+-\s+[^-]{2,50}$/,'').trim(),description:String(it.description||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim(),url:String(it.url||it.link||''),source:src,pubDate:it.pubDate||'',ts:pm,scope:spec.scope,queryId:spec.id,collectedAt:Date.now(),version:'V190'}}
function articleTopicKey(x){var t=norm(String(x&&x.title||'')).replace(/(단독|속보|분석|종합|update|analysis|exclusive)/g,'');var words=t.match(/[0-9a-z가-힣]{2,}/g)||[];return (x.scope||'KR')+'|'+words.slice(0,9).join('|')}
function articleDedupe(a){var out=[],seen=[];(a||[]).sort(function(x,y){return Number(y.ts||0)-Number(x.ts||0)}).forEach(function(x){var k=articleTopicKey(x),dup=seen.some(function(v){return v===k||(k.length>14&&v.indexOf(k.slice(0,14))===0)});if(!dup){seen.push(k);out.push(x)}});return out}
function articleReporter(text,source){var z=String(text||'').slice(0,1800),m=z.match(/([가-힣]{2,4})\s*(?:기자|특파원)/);if(m)return m[1]+' '+(/특파원/.test(m[0])?'특파원':'기자');m=z.match(/(?:By|Reporting by)\s+([A-Z][A-Za-z.'-]+(?:\s+[A-Z][A-Za-z.'-]+){0,3})/i);if(m)return m[1];return String(source||'').trim()+' 취재팀'}
function articleEvidenceScore(x,body){var z=String(body||''),s=0;if(/[0-9][0-9,.]*\s*(?:%|조|억|만|달러|원|bp|bps)|\$[0-9]/i.test(z))s+=6;if(/공시|정부|부처|한국은행|거래소|회사 측|IR|자료|보고서|according to|filing|data|regulator|official/i.test(z))s+=6;if(/단독|취재|복수의 관계자|업계에 따르면|exclusive|sources? said|people familiar/i.test(z))s+=5;if(z.length>1200)s+=3;return Math.min(20,s)}
function articleExpertiseScore(x){var z=(x.title+' '+x.description+' '+x.source),s=6;if(/반도체|HBM|AI|chip|semiconductor|energy|에너지|금융|채권|금리|바이오|방산|조선|자동차|battery|trade|통상/i.test(z))s+=6;if(/Reuters|Bloomberg|Financial Times|WSJ|Wall Street Journal|연합뉴스|한국경제|매일경제|서울경제|이데일리|머니투데이|조선비즈|전자신문/i.test(x.source))s+=5;if(/단독|심층|분석|exclusive|analysis/i.test(x.title))s+=3;return Math.min(20,s)}
/* V191 기자 평가는 이력의 검증된 정보만 활용하며 보도 건수 자체를 성공으로 보지 않는다. */
var ARTICLE_TRACK='nt_v191_article_track',ARTICLE_PRICE_CACHE='nt_v191_price_lastcheck';
var ARTICLE_PRICE_PENDING={},ARTICLE_PRICE_SEQ=0,ARTICLE_PRICE_BRIDGE=false,ARTICLE_TRACK_REFRESHING=false;
function articleProfileLoad(){var x=jget('nt_v191_reporter_profiles',{});return x&&typeof x==='object'?x:{}}
function articleProfileSave(m){jset('nt_v191_reporter_profiles',m)}
function articleProfileKey(x){return [String(x.source||'').trim(),String(x.reporter||'').trim()].join(' / ')||'미확인'}
function articleReporterScore(x,body){
 var p=articleProfileLoad()[articleProfileKey(x)]||{},source=fireSourceReliability10({source:x.source})*2.5;
 var count=Number(p.outcomes||0),confirmed=Number(p.marketDirectionConfirmed||0);
 // 사후시장 반응은 인과/예측 적중의 증거가 아님. 누적 결과는 정렬 소프트 가중치(최대 4점)로만 반영.
 var followWeight=count>=3?Math.min(4,Math.round(4*confirmed/count)):0;
 return Math.min(100,Math.round(source+articleExpertiseScore(x)+articleEvidenceScore(x,body)+8+followWeight));
}
function articleUpdateProfile(x){/* Merge에서 고유 기사 ID 단위로 재계산한다. 재검색/번역은 건수에 가산하지 않는다. */}
function articleRebuildProfiles(hist){
 var res={},tracks=articleTrackLoad();
 (hist||[]).forEach(function(x){if(!x||!x.id)return;var k=articleProfileKey(x),p=res[k]||(res[k]={count:0,outcomes:0,marketDirectionConfirmed:0,lastAt:0});p.count++;p.lastAt=Math.max(p.lastAt,Number(x.ts||0));var t=tracks[x.id];if(t&&t.windows){Object.keys(t.windows).forEach(function(w){var o=t.windows[w];if(o&&o.status==='observed'&&o.relativeReturn!=null&&x.direction&&x.direction!=='neutral'){p.outcomes++;if((x.direction==='up'&&o.relativeReturn>0)||(x.direction==='down'&&o.relativeReturn<0))p.marketDirectionConfirmed++}})}});
 articleProfileSave(res);return res;
}
function articleSentenceScore(v){var s=0;if(fireInvestmentRelevant(v))s+=5;if(/[0-9][0-9,.]*\s*(?:%|조|억|만|달러|원|bp|bps)|\$[0-9]/i.test(v))s+=3;if(/증가|감소|확대|축소|인상|인하|수주|계약|투자|증설|부족|과잉|전망|위험|관건|변수|핵심|demand|supply|capex|orders|risk|outlook|forecast|increase|decline/i.test(v))s+=3;if(/지난|이날|오늘|현지시간|서울|뉴욕|워싱턴|according to|on monday|on tuesday|on wednesday|on thursday|on friday/i.test(v))s+=1;return s}
function articleBuildSummary(x,body){var ss=fireSentenceList(articleClean(body)).filter(function(v){return v.length>=28&&!fireFatalJunk(v)&&!FIRE_BODY_NOISE.test(v)});if(!ss.length)return null;var ranked=ss.map(function(v,i){return {v:v,i:i,s:articleSentenceScore(v)}}).sort(function(a,b){return b.s-a.s||a.i-b.i}),pick=[];var context=ss.find(function(v){return /(지난|이날|오늘|현지시간|서울|뉴욕|워싱턴|정부|기업|회사|시장|according to|on monday|on tuesday|on wednesday|on thursday|on friday)/i.test(v)&&articleSentenceScore(v)>=3});if(context)pick.push(context);ranked.forEach(function(o){if(pick.length>=4||o.s<4)return;if(!pick.some(function(p){return fireSentenceSimilar(p,o.v)}))pick.push(o.v)});if(!pick.length)pick=ss.slice(0,3);pick.sort(function(a,b){return ss.indexOf(a)-ss.indexOf(b)});var summary=articleClean(pick.join(' '));if(summary.length>760)summary=summary.slice(0,760).replace(/\s+\S*$/,'')+'.';var tail=ss.slice(Math.max(0,Math.floor(ss.length*.45))),thesis=tail.slice().reverse().find(function(v){return articleSentenceScore(v)>=5&&/(전망|관건|변수|위험|가능성|필요|때문|핵심|주목|could|likely|risk|outlook|key|suggest|because|therefore)/i.test(v)})||ranked[0].v;thesis=articleClean(thesis);if(thesis.length>260)thesis=thesis.slice(0,260).replace(/\s+\S*$/,'')+'…';var theme=fireTheme(x.title+' '+body),invest='이 기사가 투자에 주는 확인 포인트는 '+fireKoreaPath({scope:x.scope,theme:theme,title:x.title,articleText:body})+' 입니다.';return {summary:summary,thesis:'기자가 결국 강조하는 핵심은 '+thesis,invest:invest,theme:theme}}
function articlePreRead(x){x=Object.assign({},x);return extFetchArticle(x,16000).then(function(a){a=a||{};var body=String(a.articleText||'');if(a.status==='unavailable'||!a.trustedBody||body.length<220)return null;if(!fireInvestmentRelevant(x.title+' '+x.description+' '+body)&&!/(earnings|revenue|orders|capex|industry|market|outlook|risk|실적|수주|증설|산업|시장|전망|위험)/i.test(body))return null;var b=articleBuildSummary(x,body);if(!b||b.summary.length<100)return null;x.articleText=body;x.articleUrl=String(a.finalUrl||x.url||'');x.trustedBody=true;x.reporter=articleReporter(body,x.source);x.summary=b.summary;x.reporterPoint=b.thesis;x.investPoint=b.invest;x.theme=b.theme;articleAttachTracker(x);x.reporterScore=articleReporterScore(x,body);x.investScore=Math.min(100,Math.round(fireMarketImpact30({title:x.title,description:x.description,deepSummary:x.summary,articleText:body})*2+articleEvidenceScore(x,body)*1.5+articleExpertiseScore(x)*1.2));x.ready=true;x.preparedAt=Date.now();x.translationReady=x.scope==='KR';x.displayText=x.scope==='KR'?(x.summary+' '+x.reporterPoint+' '+x.investPoint):'';articleUpdateProfile(x);return x}).catch(function(){return null})}
function articleMerge(rows){
 var old=jget(ARTICLE_STORE,[]);if(!Array.isArray(old))old=[];
 var byArticle={};old.concat(rows||[]).forEach(function(x){if(x&&x.id)byArticle[x.id]=Object.assign({},byArticle[x.id]||{},x)});
 var all=articleDedupe(Object.keys(byArticle).map(function(k){return byArticle[k]})).filter(function(x){return x&&Number(x.ts||0)>0&&Date.now()-Number(x.ts||0)<=7*86400000}).sort(function(a,b){return Number(b.investScore||0)-Number(a.investScore||0)||Number(b.reporterScore||0)-Number(a.reporterScore||0)||Number(b.ts||0)-Number(a.ts||0)}).slice(0,120);
 jset(ARTICLE_STORE,all);
 var hist=jget(ARTICLE_HIST,[]);if(!Array.isArray(hist))hist=[];
 var byId={};hist.concat(rows||[]).forEach(function(x){if(!x||!x.id||!Number(x.ts)||Date.now()-Number(x.ts)>130*86400000)return;var y=byId[x.id]||{};byId[x.id]=Object.assign(y,{id:x.id,title:x.title||y.title||'',source:x.source||y.source||'',reporter:x.reporter||y.reporter||'',scope:x.scope||y.scope||'',theme:x.theme||y.theme||'',ticker:x.ticker||y.ticker||'',benchmark:x.benchmark||y.benchmark||'',direction:x.direction||y.direction||'neutral',ts:x.ts,summary:x.summary||y.summary||'',reporterPoint:x.reporterPoint||y.reporterPoint||'',investPoint:x.investPoint||y.investPoint||'',reporterScore:Number(x.reporterScore||y.reporterScore||0),investScore:Number(x.investScore||y.investScore||0),url:x.articleUrl||x.url||y.url||'',displayText:x.displayText||y.displayText||'',translationReady:!!(x.translationReady||y.translationReady)})});
 var unique=Object.keys(byId).map(function(k){return byId[k]}).sort(function(a,b){return b.ts-a.ts}).slice(0,1000);
 jset(ARTICLE_HIST,unique);articleRebuildProfiles(unique);return all;
}
function articleQueueKo(task){return new Promise(function(resolve){ARTICLE_KO_PUMP.push({task:task,resolve:resolve});articleRunKo()})}
function articleRunKo(){while(ARTICLE_KO_BUSY<2&&ARTICLE_KO_PUMP.length){var job=ARTICLE_KO_PUMP.shift();ARTICLE_KO_BUSY++;Promise.resolve().then(job.task).then(job.resolve,function(){job.resolve('')}).finally(function(){ARTICLE_KO_BUSY--;articleRunKo()})}}
function articleKoReady(x){var t=String(x&&x.displayText||''),hangul=(t.match(/[가-힣]/g)||[]).length,latin=(t.match(/[A-Za-z]/g)||[]).length;return !!(x&&x.translationReady&&hangul>=32&&hangul>=latin*.65)}
function articleTranslate(x){
 if(!x||x.scope!=='GLOBAL')return Promise.resolve(x);
 if(ARTICLE_TRANSLATING[x.id])return ARTICLE_TRANSLATING[x.id];
 var source=String(x.summary||''),head=String(x.title||''),extras=[String(x.reporterPoint||''),String(x.investPoint||'')].filter(Boolean).join(' ');
  var pieces=[source.slice(0,700),extras.slice(0,650)].filter(Boolean);
 var job=articleQueueKo(function(){return Promise.all([extTranslateKo(head,18000)].concat(pieces.map(function(t){return extTranslateKo(t,18000)})))}).then(function(pair){
  var titleKo=articleClean(pair&&pair[0]||''),descKo=articleClean((pair||[]).slice(1).filter(Boolean).join(' '));
  var previous=articleList('global').find(function(v){return v.id===x.id})||{};
  var y=Object.assign({},previous,x);
  if(/[가-힣]/.test(titleKo))y.titleKo=titleKo;
  var koNum=(descKo.match(/[가-힣]/g)||[]).length,enNum=(descKo.match(/[A-Za-z]/g)||[]).length;
  if(koNum>=32&&koNum>=enNum*.65){y.displayText=descKo;y.translationReady=true}else {y.displayText=articleKoReady(previous)?previous.displayText:'';y.translationReady=articleKoReady(previous)}
  y.translationAttemptedAt=Date.now();articleMerge([y]);articleRender();return y;
 }).finally(function(){delete ARTICLE_TRANSLATING[x.id]});
 ARTICLE_TRANSLATING[x.id]=job;return job;
}
function articlePreviewList(mode){var scope=mode==='global'?'GLOBAL':'KR',a=jget(ARTICLE_PREVIEWS,[]);if(!Array.isArray(a))a=[];return a.filter(function(x){return x&&x.scope===scope&&Date.now()-Number(x.ts||0)<4*86400000}).sort(function(a,b){return b.ts-a.ts}).slice(0,15)}
function articleSavePreviews(candidates){var old=jget(ARTICLE_PREVIEWS,[]);if(!Array.isArray(old))old=[];var keyed={};old.concat(candidates||[]).forEach(function(x){if(x&&x.id)keyed[x.id]=Object.assign({},keyed[x.id]||{},x)});var a=Object.values(keyed).filter(function(x){return Date.now()-Number(x.ts||0)<4*86400000}).sort(function(a,b){return b.ts-a.ts}).slice(0,70);jset(ARTICLE_PREVIEWS,a);articleRender();return a}
function articleTranslatePreviews(candidates){
 var needed=(candidates||[]).filter(function(x){return x&&x.scope==='GLOBAL'&&!/[가-힣]/.test(String(x.titleKo||''))}).slice(0,10);
 needed.forEach(function(x){if(ARTICLE_TRANSLATING['preview:'+x.id])return;ARTICLE_TRANSLATING['preview:'+x.id]=true;
  articleQueueKo(function(){return extTranslateKo(x.title,16000)}).then(function(t){if(/[가-힣]/.test(String(t||''))){x.titleKo=articleClean(t);articleSavePreviews([x])}}).finally(function(){delete ARTICLE_TRANSLATING['preview:'+x.id]})
 });
}
function articleCollect(mode,reason){
 mode=mode==='global'?'global':'domestic';
 if(ARTICLE_RUNNING){ARTICLE_QUEUED_MODE=mode;articleRender();return Promise.resolve(false)}
 ARTICLE_RUNNING=true;ARTICLE_RUNNING_MODE=mode;ARTICLE_FIRST[mode]=true;articleRender();
 var scope=mode==='global'?'GLOBAL':'KR',specs=ARTICLE_SPECS.filter(function(q){return q.scope===scope}),raw=[],ok=0,failed=[];
 function absorb(packs){(packs||[]).forEach(function(pack){if(pack.ok)ok++;else failed.push(pack.spec.id+':'+(pack.error||''));(pack.r&&Array.isArray(pack.r.items)?pack.r.items:[]).forEach(function(it){var pm=pubMs(it.pubDate);if(pm&&Date.now()-pm<100*3600000&&Date.now()-pm>-3600000&&articleCandidate(it,pack.spec))raw.push(articleNorm(it,pack.spec))})})}
 return runFireSpecs(specs,10000).then(function(packs){
  absorb(packs);
  var more=raw.length<5?[{id:'v192_fallback_'+mode,scope:scope,q:scope==='KR'?'한국 기업 주식 실적 when:3d':'global stocks business earnings when:3d'}]:[];
  return (more.length?runFireSpecs(more,10000):Promise.resolve([])).then(function(extra){absorb(extra);
   var cand=articleDedupe(raw).slice(0,scope==='GLOBAL'?32:22),ready=[],cursor=0,target=scope==='GLOBAL'?12:9,workers=Math.min(3,cand.length);
   articleSavePreviews(cand);
   if(scope==='GLOBAL')articleTranslatePreviews(cand);
   function one(){if(ready.length>=target)return Promise.resolve();var i=cursor++;if(i>=cand.length)return Promise.resolve();return articlePreRead(cand[i]).then(function(x){if(x){ready.push(x);articleMerge([x]);if(x.scope==='GLOBAL')articleTranslate(x)}}).then(one)}
   var ps=[];for(var k=0;k<workers;k++)ps.push(one());
   return Promise.all(ps).then(function(){var prev=jget(ARTICLE_STATS,{})||{},per=Object.assign({},prev.statusByMode||{});per[mode]={at:Date.now(),state:ok===0?'fail':ready.length?'ready':cand.length?'pending':'empty',ok:ok,failed:failed.slice(0,8),raw:raw.length,candidates:cand.length,prepared:ready.length};jset(ARTICLE_STATS,{mode:mode,reason:String(reason||''),at:Date.now(),statusByMode:per,queries:specs.length+more.length,ok:ok,failed:failed.slice(0,8),raw:raw.length,candidates:cand.length,prepared:ready.length,lastSuccessByMode:Object.assign({},prev.lastSuccessByMode||{},ok?{[mode]:Date.now()}:{})});if(ready.length)setTimeout(function(){articleRefreshTracks(false)},500);return ready.length>0})
  })
 }).catch(function(e){var prev=jget(ARTICLE_STATS,{})||{},per=Object.assign({},prev.statusByMode||{});per[mode]={at:Date.now(),state:'fail',error:String(e&&e.message||e)};jset(ARTICLE_STATS,Object.assign({},prev,{mode:mode,at:Date.now(),error:String(e&&e.message||e),statusByMode:per}));return false}).finally(function(){ARTICLE_RUNNING=false;ARTICLE_RUNNING_MODE='';articleRender();var next=ARTICLE_QUEUED_MODE;ARTICLE_QUEUED_MODE='';if(next)setTimeout(function(){articleCollect(next,'queued-tab')},100)})
}
/* V193 Major News: evidence-first investment impact ranking, not prediction or independently verified investment advice. */
function articlePriorityMeta(x){
 var title=String(x&&x.title||'');
 var z=(title+' '+String(x&&x.summary||'').slice(0,600)+' '+String(x&&x.description||'').slice(0,250)).toLowerCase();
 var t=title.toLowerCase();
 var speculative=/(전망|예상|추측|기대|가능성|검토|계획|예고|논의|전망치|수주 기대|계약 기대|could|may |might |expected to|plans? to|considering|rumou?r|potential)/i.test(t);
 var direct=/(실적 발표|실적 개선|실적 악화|영업이익|순이익|매출액|매출 증가|매출 감소|흑자 전환|적자 전환|공급계약|계약 체결|수주 계약|수주 성공|계약 해지|계약 취소|생산 중단|파산 신청|earnings report|quarterly results|net profit|operating profit|revenue (?:rose|fell|grew|declined)|awarded (?:a |the )?contract|sign(?:s|ed).{0,55}?(?:deal|contract)|contract cancell?ed|bankruptcy)/i.test(z);
 var policy=/(금리 (?:인상|인하|동결|결정)|기준금리|관세 (?:시행|인상|인하|부과|철회)|규제 (?:확정|시행|강화|완화)|정책 (?:발표|시행|확정)|법안 (?:통과|가결)|수출 통제|제재 (?:발표|시행)|연준|한국은행|정부 예산|federal reserve|interest rates?|central bank|tariffs?|export controls?|sanctions?|regulation|legislation|policy change|rate (?:cut|hike))/i.test(z);
 var money=/(기관.*순매수|외국인.*순매수|순매도|자금 유입|자금 유출|자금 이동|설비투자|시설투자|투자 확대|대규모 투자|증설|자본조달|채권 발행|유상증자|buyback|share repurchase|net inflows?|outflows?|capital spending|capex|capital expenditure|fundraising|share offering|investment increase|factory expansion|fund flows?)/i.test(z);
 var lead=/(기술 개발|신제품|신규 사업|신사업|신시장|시장 진출|공급 부족|수요 증가|수요 급증|공급망|신기술|양산 준비|임상 결과|approval|new product|product launch|demand (?:surge|growth|rises?)|supply (?:shortage|chain)|new technology|capacity plans?|market entry|clinical results)/i.test(z);
 // Only the source article text can promote a candidate. A headline preview is never ranked as a confirmed report.
 var category=direct&&!speculative?'실적·수주 변화':policy?'정책·규제':money?'자금·투자':lead||direct?'선행신호':'시장 일반';
 var base=category==='실적·수주 변화'?55:category==='정책·규제'?43:category==='자금·투자'?34:category==='선행신호'?25:12;
 // Original-article access is checked by the existing trustedBody gate; this is evidence of retrieval, NOT proof the reporting is true.
 var evidence=x&&x.trustedBody?Math.min(12,Math.round(articleEvidenceScore(x,x.articleText||'')*.6)):0;
 var relevance=Math.min(13,Math.max(0,Number(x&&x.investScore||0))*.13);
 var age=Math.max(0,(Date.now()-Number(x&&x.ts||0))/3600000);
 var recent=age<=6?13:age<=24?11:age<=48?8:age<=72?5:age<=120?2:0;
 var qualifier=speculative?6:0;
 var score=Math.round(Math.max(0,Math.min(100,base+evidence+relevance+recent-qualifier)));
 return {score:score,category:category,ageHours:age,sourceChecked:!!(x&&x.trustedBody)};
}
function articleSorted(a){return (a||[]).slice().sort(function(x,y){
 if(ARTICLE_SORT_MODE==='recent')return Number(y.ts||0)-Number(x.ts||0)||String(x.id||'').localeCompare(String(y.id||''));
 var p=articlePriorityMeta(x),q=articlePriorityMeta(y);
 return q.score-p.score||Number(y.ts||0)-Number(x.ts||0)||String(x.id||'').localeCompare(String(y.id||''));
})}
function articleList(mode){var scope=mode==='global'?'GLOBAL':'KR',a=jget(ARTICLE_STORE,[]);if(!Array.isArray(a))a=[];return articleSorted(a.filter(function(x){return x&&x.ready&&x.scope===scope&&Date.now()-Number(x.ts||0)<=7*86400000})).slice(0,30)}
function articleWhen(x){var d=new Date(Number(x.ts||0));if(!isFinite(d.getTime()))return'';return (d.getMonth()+1)+'/'+d.getDate()+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')}
/* V191 자동 사후 관찰: 7/30/90일 · 실가격/벤치마크가 모두 확인될 때만 관찰 결과로 표시한다. */
function articleTrackLoad(){var m=jget(ARTICLE_TRACK,{});return m&&typeof m==='object'&&!Array.isArray(m)?m:{}}
function articleTrackSave(m){var keys=Object.keys(m).sort(function(a,b){return Number(m[b].ts||0)-Number(m[a].ts||0)}).slice(0,700),out={};keys.forEach(function(k){if(Date.now()-Number(m[k].ts||0)<=400*86400000)out[k]=m[k]});jset(ARTICLE_TRACK,out);return out}
function articleDetectTicker(x){
 var z=String(x.title||'')+' '+String(x.articleText||'').slice(0,2600);
 var m=z.match(/(?:종목코드|KRX|KOSPI|KOSDAQ|코스피|코스닥)\s*[:：#]?\s*\(?\s*(\d{6})\b/i)||z.match(/[（(]\s*(\d{6})\s*[)）]/);
 if(m){var kd=/\bKOSDAQ\b|코스닥/i.test(z.slice(0,220));return {symbol:m[1]+(kd?'.KQ':'.KS'),code:m[1],market:'KR',benchmark:kd?'%5EKQ11':'%5EKS11',description:'6자리 종목코드 명시'}};
 m=z.match(/\b(?:NASDAQ|NYSE|AMEX)\s*[:：]\s*([A-Z]{1,5}(?:\.[A-Z])?)\b/i);
 if(m)return {symbol:m[1].toUpperCase(),code:m[1].toUpperCase(),market:'US',benchmark:'%5EGSPC',description:'시장·티커 명시'};
 return null;
}
function articleDetectDirection(x){
 var z=String(x.title||'')+' '+String(x.reporterPoint||'');
 if(/(?:주가|stock price|share price|주식).*?(?:상승 전망|오를 전망|상승할 것|반등 예상|rise expected|expected to rise|upside)/i.test(z))return'up';
 if(/(?:주가|stock price|share price|주식).*?(?:하락 전망|내릴 전망|하락할 것|약세 예상|fall expected|expected to fall|downside)/i.test(z))return'down';
 return'neutral';
}
function articlePriceBridgeInstall(){
 if(ARTICLE_PRICE_BRIDGE)return;ARTICLE_PRICE_BRIDGE=true;
 var prev=window.__SnowballNativeAsyncResolve;
 window.__SnowballNativeAsyncResolve=function(id,raw){if(String(id).indexOf('v191price_')===0){var p=ARTICLE_PRICE_PENDING[id];if(!p)return;delete ARTICLE_PRICE_PENDING[id];clearTimeout(p.timeout);try{var v=JSON.parse(String(raw||'{}'));if(v&&v.error)throw new Error(String(v.error));p.resolve(v)}catch(e){p.reject(e)}return}if(typeof prev==='function')return prev(id,raw)};
}
function articlePriceGet(url){return new Promise(function(resolve,reject){
 var bridge=window.SnowballMarketData;if(!bridge||typeof bridge.getAsync!=='function'){reject(new Error('가격데이터 브리지 없음'));return}
 articlePriceBridgeInstall();var id='v191price_'+(++ARTICLE_PRICE_SEQ)+'_'+Date.now(),to=setTimeout(function(){delete ARTICLE_PRICE_PENDING[id];reject(new Error('가격 확인 시간초과'))},9000);
 ARTICLE_PRICE_PENDING[id]={resolve:resolve,reject:reject,timeout:to};
 try{bridge.getAsync(url,id)}catch(e){clearTimeout(to);delete ARTICLE_PRICE_PENDING[id];reject(e)}
})}
function articlePriceSeries(symbol,fromMs){
 var now=Date.now(),p1=Math.max(0,Math.floor((fromMs-4*86400000)/1000)),p2=Math.floor((now+2*86400000)/1000);
 function one(host){return articlePriceGet('https://'+host+'/v8/finance/chart/'+encodeURIComponent(symbol)+'?interval=1d&period1='+p1+'&period2='+p2+'&events=div%2Csplits').then(function(j){
 var o=j&&j.chart&&j.chart.result&&j.chart.result[0],tm=o&&o.timestamp,q=o&&o.indicators&&o.indicators.quote&&o.indicators.quote[0],adj=o&&o.indicators&&o.indicators.adjclose&&o.indicators.adjclose[0],out=[];
 if(!Array.isArray(tm)||!q)throw new Error('일봉 데이터 없음');tm.forEach(function(t,i){var a=Number(adj&&adj.adjclose&&adj.adjclose[i]),close=Number(q.close&&q.close[i]);var p=isFinite(a)&&a>0?a:close;if(isFinite(p)&&p>0)out.push({ts:t*1000,price:p})});
 if(out.length<2)throw new Error('검증 가능한 일봉 부족');return out.sort(function(a,b){return a.ts-b.ts})
 })}
 return one('query1.finance.yahoo.com').catch(function(){return one('query2.finance.yahoo.com')});
}
function articleDay(t){var d=new Date(t);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function articleAtOrAfter(rows,day,maxGap){var t=day;return (rows||[]).find(function(o){var delta=(new Date(articleDay(o.ts)).getTime()-new Date(articleDay(t)).getTime())/86400000;return delta>=0&&delta<=maxGap})||null}
function articleBuildTrack(x,stock,bench,now){
 now=Number(now||Date.now());var t=Number(x.ts||0),base=articleAtOrAfter(stock,t,5),bm=articleAtOrAfter(bench,t,5),obj={ts:t,ticker:x.ticker||'',benchmark:x.benchmark||'',source:'Yahoo Finance 조정종가 우선',priceBasis:'기사일 이후 첫 거래일 종가',checkedAt:now,windows:{}};
 [7,30,90].forEach(function(days){var due=t+days*86400000,key=String(days);if(now<due){obj.windows[key]={status:'pending',dueAt:due};return}
 var a=articleAtOrAfter(stock,due,5),b=articleAtOrAfter(bench,due,5);
 if(!base||!bm||!a||!b||a.ts>now||b.ts>now){obj.windows[key]={status:'unavailable',dueAt:due};return}
 var abs=(a.price/base.price-1)*100,idx=(b.price/bm.price-1)*100;
 obj.windows[key]={status:'observed',dueAt:due,baselineAt:base.ts,observedAt:a.ts,benchmarkAt:b.ts,returnPct:Math.round(abs*100)/100,indexReturnPct:Math.round(idx*100)/100,relativeReturn:Math.round((abs-idx)*100)/100};
 });return obj;
}
function articleUpdateTrack(x,force){
 if(!x||!x.id||!x.ticker||!x.benchmark)return Promise.resolve(false);
 var cache=jget(ARTICLE_PRICE_CACHE,{}),c=cache[x.id],age=Date.now()-Number(c&&c.at||0);
 if(!force&&age>=0&&age<20*3600000)return Promise.resolve(false);
 return Promise.all([articlePriceSeries(x.ticker,x.ts),articlePriceSeries(x.benchmark,x.ts)]).then(function(a){var m=articleTrackLoad();m[x.id]=articleBuildTrack(x,a[0],a[1],Date.now());articleTrackSave(m);cache[x.id]={at:Date.now(),ok:true};jset(ARTICLE_PRICE_CACHE,cache);articleRebuildProfiles(jget(ARTICLE_HIST,[]));return true}).catch(function(e){cache[x.id]={at:Date.now(),ok:false,error:String(e&&e.message||e)};jset(ARTICLE_PRICE_CACHE,cache);return false})
}
function articleRefreshTracks(force){
 if(ARTICLE_TRACK_REFRESHING)return Promise.resolve(false);var hist=jget(ARTICLE_HIST,[]),all=Array.isArray(hist)?hist:[],cache=jget(ARTICLE_PRICE_CACHE,{});
 var jobs=all.filter(function(x){return x&&x.ticker&&x.benchmark&&Date.now()-Number(x.ts||0)<130*86400000&&(force||Date.now()-Number(cache[x.id]&&cache[x.id].at||0)>20*3600000)}).slice(0,3);
 if(!jobs.length)return Promise.resolve(false);ARTICLE_TRACK_REFRESHING=true;
 function run(i){if(i>=jobs.length)return Promise.resolve(true);return articleUpdateTrack(jobs[i],force).then(function(){return run(i+1)})}
 return run(0).finally(function(){ARTICLE_TRACK_REFRESHING=false;articleRender()});
}
function articleTrackLabel(x){var y=articleTrackLoad()[x.id],rows=[],parts={'7':'1주','30':'1개월','90':'3개월'};
 ['7','30','90'].forEach(function(k){var v=y&&y.windows&&y.windows[k];if(!v||v.status==='pending'){rows.push(parts[k]+': 기간 미도래');return}
 if(v.status!=='observed'){rows.push(parts[k]+': 시세 검증 대기');return}
 rows.push(parts[k]+': 종목 '+(v.returnPct>=0?'+':'')+v.returnPct.toFixed(2)+'% / 지수 '+(v.indexReturnPct>=0?'+':'')+v.indexReturnPct.toFixed(2)+'% / 상대 '+(v.relativeReturn>=0?'+':'')+v.relativeReturn.toFixed(2)+'%')});
 if(!x.ticker)return'검증 대기: 기사에 명시된 거래소·종목코드가 없어 임의 종목을 연결하지 않았습니다. 관련 정책·실적·수주 등 실물 결과는 별도 공식자료 확인이 필요합니다.';
 return '후속 시장 관찰 ('+x.ticker+', 기준지수 '+(x.benchmark==='%5EGSPC'?'S&P 500':x.benchmark==='%5EKQ11'?'KOSDAQ':'KOSPI')+') — '+rows.join(' / ')+'. 출처: Yahoo Finance 일봉, 기사일 이후 첫 거래일 종가 기준. 시장 반응은 기사 적중 또는 인과관계 확정이 아닙니다. 정책·실적·계약의 실제 이행은 별도 검증 대기입니다.';
}
function articleAttachTracker(x){var v=articleDetectTicker(x);x.ticker=v?v.symbol:'';x.benchmark=v?v.benchmark:'';x.direction=articleDetectDirection(x);return x}
function articleMigrateLegacy(){
 var tag='nt_v191_article_migrated_once';if(jget(tag,false))return;
 var old=jget(ARTICLE_STORE,[]);if(!Array.isArray(old))old=[];
 var changed=old.map(function(x){if(!x||!x.id)return x;if(!x.ticker)articleAttachTracker(x);return x});
 if(changed.length)articleMerge(changed);jset(tag,true);
}
function articleHistoryList(){var a=jget(ARTICLE_HIST,[]),scope=ARTICLE_OPEN_MODE==='global'?'GLOBAL':'KR';if(!Array.isArray(a))return[];return a.filter(function(x){return x&&x.scope===scope&&Date.now()-Number(x.ts||0)<130*86400000}).sort(function(a,b){return Number(b.ts||0)-Number(a.ts||0)}).slice(0,100).map(function(x){return Object.assign({ready:true,articleUrl:x.url},x,{displayText:x.displayText||[x.summary,x.reporterPoint,x.investPoint].filter(Boolean).join(' ')})})}
function articleEnsureUI(){var p=document.getElementById('ntv190ArticleMonitor');if(p)return p;p=document.createElement('div');p.id='ntv190ArticleMonitor';p.innerHTML='<div class="v190-art-shell"><div class="v190-art-head"><div><b>📰 주요뉴스</b><small>국내·글로벌 주요 투자뉴스 · 글로벌은 한국어 번역</small></div><button type="button" data-v190-article-close aria-label="주요뉴스 닫기">×</button></div><div class="v190-art-body"><div class="v190-art-tabs"><button type="button" data-v190-article-mode="domestic" class="on">국내</button><button type="button" data-v190-article-mode="global">글로벌</button></div><div class="v193-news-sort" role="group" aria-label="뉴스 정렬"><button type="button" data-v193-article-sort="impact">투자 영향력순</button><button type="button" data-v193-article-sort="recent">최신순</button><small>원문 확인된 기사만 정렬 · 최신성 반영</small></div><div class="v190-art-toolbar"><span class="v190-art-status"></span><button type="button" data-v190-article-refresh>재확인</button></div><div class="v190-art-list"></div><button type="button" class="v192-news-track-switch" data-v191-track-history>사후검증 · 최근 130일</button></div></div>';document.body.appendChild(p);return p}
function articleRender(){
 var p=document.getElementById('ntv190ArticleMonitor');if(!p)return;
 var a=ARTICLE_HISTORY_VIEW?articleHistoryList():articleList(ARTICLE_OPEN_MODE),st=jget(ARTICLE_STATS,{}),laneStatus=(st.statusByMode||{})[ARTICLE_OPEN_MODE]||{},list=p.querySelector('.v190-art-list'),status=p.querySelector('.v190-art-status');
 p.querySelectorAll('[data-v190-article-mode]').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-v190-article-mode')===ARTICLE_OPEN_MODE)});
 p.querySelectorAll('[data-v193-article-sort]').forEach(function(b){var selected=b.getAttribute('data-v193-article-sort')===ARTICLE_SORT_MODE;b.classList.toggle('on',selected);b.setAttribute('aria-pressed',selected?'true':'false')});
 var hb=p.querySelector('[data-v191-track-history]');if(hb){hb.textContent=ARTICLE_HISTORY_VIEW?'최근 주요뉴스 보기':'사후검증 · 최근 130일';hb.classList.toggle('on',ARTICLE_HISTORY_VIEW)}
 var mode=ARTICLE_OPEN_MODE==='global'?'글로벌':'국내',busy=ARTICLE_RUNNING&&ARTICLE_RUNNING_MODE===ARTICLE_OPEN_MODE,queued=ARTICLE_QUEUED_MODE===ARTICLE_OPEN_MODE;
 var previews=ARTICLE_HISTORY_VIEW?[]:articlePreviewList(ARTICLE_OPEN_MODE).filter(function(x){return !a.some(function(y){return y.id===x.id})});
 var last=st&&st.lastSuccessByMode&&st.lastSuccessByMode[ARTICLE_OPEN_MODE],when=last?new Date(last).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'}):'';
 status.innerHTML=ARTICLE_HISTORY_VIEW?'사후검증 기록 '+a.length+'건':('<span class="v192-status-dot"></span> '+(busy?'새 '+mode+' 뉴스 원문 확인 중':queued?mode+' 뉴스 확인 예약됨':a.length?mode+' 주요뉴스 '+a.length+'건':previews.length?mode+' 뉴스 후보 '+previews.length+'건 · 원문 확인 진행 중':(laneStatus.state==='fail'?'뉴스 검색 연결 실패 · 재확인 가능':laneStatus.state==='pending'?'기사 후보 확인됨 · 원문 검증 대기':laneStatus.state==='empty'?'검색 성공 · 조건에 맞는 뉴스 없음':'확인된 주요뉴스 없음 · 재확인 가능'))+(laneStatus.at?' · 검색 '+new Date(laneStatus.at).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'}):'')+(when?' · 마지막 '+esc(when):''));
 var refresh=p.querySelector('[data-v190-article-refresh]');if(refresh){refresh.disabled=busy;refresh.textContent=busy?'확인 중':'재확인'}
 var html=a.map(function(x){
  var global=x.scope==='GLOBAL',translated=global&&articleKoReady(x),detail=global&&!translated?'한글 번역 준비 중입니다. 번역이 완료되면 기사 정리를 표시합니다.':articleScreenClean(x.displayText||x.summary||'');
  var koHead=global?String(x.titleKo||''):String(x.title||'');var title=articleScreenClean(global&&!/[가-힣]/.test(koHead)?'글로벌 뉴스 · 제목 한글 번역 준비 중':koHead);
  var source=String(x.source||'공개보도'),url=String(x.articleUrl||x.url||'');
  return '<details class="v190-art-row"><summary><div><b>'+esc(title)+'</b><small><span class="v193-news-category">'+esc(ARTICLE_HISTORY_VIEW?'추적 기록':articlePriorityMeta(x).category)+'</span> '+'<span class="scope '+(global?'global':'')+'">'+(global?'글로벌':'국내')+'</span> '+esc(source)+' · '+esc(articleWhen(x))+'</small></div><span>›</span></summary><div class="v190-art-detail"><p>'+esc(detail)+'</p><div class="v190-art-meta"><b>기사·취재</b> '+esc(x.reporter||source)+' · 기사근거 '+Number(x.reporterScore||0)+' · 투자연관 '+Number(x.investScore||0)+'</div><div class="v190-art-track">'+esc(articleTrackLabel(x))+'</div>'+(url?'<a href="'+esc(url)+'" target="_blank" rel="noopener">원문 보기</a>':'')+'</div></details>'
 }).join('');
 // Unverified headlines are clearly separated and never presented as verified or analysed.
 if(!ARTICLE_HISTORY_VIEW&&previews.length){html+='<div class="v192-news-pending-label">원문 확인 대기 · 기사 제목만 확인된 후보</div>'+previews.slice(0,12).map(function(x){var global=x.scope==='GLOBAL',head=global?String(x.titleKo||''):String(x.title||'');if(global&&!/[가-힣]/.test(head))head='글로벌 뉴스 · 제목 한글 번역 준비 중';return '<details class="v190-art-row v192-news-pending"><summary><div><b>'+esc(head)+'</b><small><span class="scope '+(global?'global':'')+'">'+(global?'글로벌':'국내')+'</span> '+esc(x.source||'공개보도')+' · '+esc(articleWhen(x))+' · 원문 확인 전</small></div><span>›</span></summary><div class="v190-art-detail"><p>기사 제목만 검색된 상태입니다. 원문 확인이 완료되어야 요약과 투자 영향을 제공합니다.</p>'+(x.url?'<a href="'+esc(x.url)+'" target="_blank" rel="noopener">원문 보기</a>':'')+'</div></details>'}).join('')}
 list.innerHTML=html||'<div class="v190-art-empty">'+esc(ARTICLE_RUNNING?'뉴스를 수집하고 있습니다. 검색 후 원문을 확인합니다.':'현재 준비된 뉴스가 없습니다. 재확인하여 새 뉴스를 찾을 수 있습니다.')+'</div>';
}
function articleRetryKo(mode){if(mode!=='global')return;var current=articleList('global').filter(function(x){return !articleKoReady(x)&&Date.now()-Number(x.translationAttemptedAt||0)>120000}).slice(0,3);current.forEach(function(x){articleTranslate(x)})}
function articleOpen(){articleMigrateLegacy();var p=articleEnsureUI();p.classList.add('open');p.setAttribute('aria-hidden','false');p.scrollTop=0;articleRender();articleRetryKo(ARTICLE_OPEN_MODE);var a=articleList(ARTICLE_OPEN_MODE);setTimeout(function(){articleRefreshTracks(false)},300);if(!a.length&&!ARTICLE_FIRST[ARTICLE_OPEN_MODE]){ARTICLE_FIRST[ARTICLE_OPEN_MODE]=true;setTimeout(function(){articleCollect(ARTICLE_OPEN_MODE,'first-open')},120)}}
function articleClose(){try{window.NOONTANGI_VOICE_GLOBAL&&window.NOONTANGI_VOICE_GLOBAL.stopReading&&window.NOONTANGI_VOICE_GLOBAL.stopReading()}catch(e){}var p=document.getElementById('ntv190ArticleMonitor');if(p){p.classList.remove('open');p.setAttribute('aria-hidden','true')}}
 document.addEventListener('click',function(e){if(e.target&&e.target.closest&&e.target.closest('#mainNav label, #mainNav .cnav'))articleClose()},false);
document.addEventListener('click',function(e){var q=e.target&&e.target.closest&&e.target.closest('[data-v190-article-open]');if(q){e.preventDefault();e.stopImmediatePropagation();articleOpen();return}var c=e.target&&e.target.closest&&e.target.closest('[data-v190-article-close]');if(c){e.preventDefault();articleClose();return}var sortBtn=e.target&&e.target.closest&&e.target.closest('[data-v193-article-sort]');if(sortBtn){e.preventDefault();ARTICLE_SORT_MODE=sortBtn.getAttribute('data-v193-article-sort')==='recent'?'recent':'impact';jset(ARTICLE_SORT_KEY,ARTICLE_SORT_MODE);articleRender();return}var m=e.target&&e.target.closest&&e.target.closest('[data-v190-article-mode]');if(m){e.preventDefault();ARTICLE_OPEN_MODE=m.getAttribute('data-v190-article-mode')==='global'?'global':'domestic';var articlePanel=document.getElementById('ntv190ArticleMonitor');if(articlePanel)articlePanel.scrollTop=0;articleRender();articleRetryKo(ARTICLE_OPEN_MODE);if(!articleList(ARTICLE_OPEN_MODE).length&&!ARTICLE_FIRST[ARTICLE_OPEN_MODE]){articleCollect(ARTICLE_OPEN_MODE,'tab-first')}return}var h=e.target&&e.target.closest&&e.target.closest('[data-v191-track-history]');if(h){e.preventDefault();ARTICLE_HISTORY_VIEW=!ARTICLE_HISTORY_VIEW;articleRender();if(ARTICLE_HISTORY_VIEW)setTimeout(function(){articleRefreshTracks(false)},120);return}var r=e.target&&e.target.closest&&e.target.closest('[data-v190-article-refresh]');if(r){e.preventDefault();articleCollect(ARTICLE_OPEN_MODE,'manual-refresh');return}},true);
window.NOONTANGI_ARTICLE_MONITOR={open:articleOpen,list:articleList,refresh:articleCollect,status:function(){return jget(ARTICLE_STATS,{})},track:articleTrackLoad,verify:articleRefreshTracks,version:'V195 NEWS COLLECTION DIAGNOSTIC / PRIORITY / EVIDENCE TRACK'};

function boot(){installExternalResolver();installNavClose();installVoiceRouter();scheduleFire();renderFiremouthAuto();renderFireBell();selfTest();fireAnalysisSelfTest();var b=document.getElementById('snowballBuildV42');if(b)b.textContent='V60.8 · V121';document.documentElement.dataset.v121r4=VERSION;setTimeout(function(){installVoiceRouter();renderFiremouthAuto();renderFireBell()},800)}
document.addEventListener('change',function(e){if(e.target&&e.target.id==='rBell'&&e.target.checked)setTimeout(renderFireBell,100)},true);
window.NOONTANGI_FIRE_SERVICE={list:fireView,pending:firePendingList,status:function(){return jget(FIRE_STATS,{})},running:function(){return fireRunning},queued:function(){return FIRE_QUEUED_MODE},refresh:function(mode,reason){return collectFire(re