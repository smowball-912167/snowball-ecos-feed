# V265 — Native STT confirmation and auto-mic guard (2026-10-23)

- Microphone in automatic chat mode starts only when HTTPS gateway, secure client access code and consent are configured.
- Add a one-shot Android STT diagnostic in Settings > AI voice: shows recognized phrase, does not route a menu command, launch provider request, keep audio recordings or collect voice biometrics.
- Prevent repeating spoken "server not connected" prompts when the gateway is missing. The unavailable message displays once and the active voice session stops.
- Slightly relax the Android speech endpoint pauses (recognizers may ignore these hints).
- Preserve V264 ChatGPT/Gemini routing and all market/finance/data processing. Do not claim speaker verification or live AI connection.
- Recalculate 3 S1 source hashes and versionCode 60343. APK build and Galaxy physical test NOT performed in this environment.
- Note: Android speech service may process audio on network according to device configuration.
