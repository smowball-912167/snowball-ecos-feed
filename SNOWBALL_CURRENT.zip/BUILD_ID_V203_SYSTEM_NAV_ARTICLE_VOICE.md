# V203 — GALAXY SYSTEM NAV FLOOR / ARTICLE TTS OWNER RESET (2026-10-10)

- Baseline V202 (no new news/theme/portfolio/ledger changes).
- The Android three-button/gesture area is native system UI and must have priority. Added `#ntv203SystemNavGuard` over WebView inset supplied by Android and clamped news/firemouth overlays above the seven-icon in-app nav. Overlay body remains vertically scrollable only within its bounded content region.
- On successful matching final TTS utteranceId, news collapses the *read article `<details>` only*; firemouth clears current `.is-open` and its internal `FIRE_OPEN_ID` without closing the list overlay. The rest of the article list remains open; no HOME navigation from article completion.
- Closing or reopening firemouth now clears previous open-article state. Opening a new firemouth session starts with collapsed items.
- Voice installation follows `NOONTANGI_VOICE_GLOBAL` identity; late object replacement during boot is patched again at read/user tap. Previous final utteranceId and explicit stop/error events do not close a newly opened screen.
- Calendar and separate temporary dialogs may still auto-close when read successfully finishes; main routes remain open.
- Tested: all 99 inline JS syntax checks; Chromium isolated speech completion tests (news article only, fire article only, stale completion, calendar close); actual whole-app Chromium boot with mocked native TTS (both news and fire article-only close, fire reopen cleared) and 412×915 layout rectangles (OS floor, app nav, firemouth separate).
- Browser limitation: `set_content()` opaque origin denies localStorage/sessionStorage, causing known legacy boot errors; actual Android APK compile & real Samsung UI/TTS **not verified**.
- `versionCode 60249`; versionName `6.0.8-r9-v121-system-nav-article-voice-r85-v203`; `index.html?v=792`; package `SNOWBALL_CURRENT.zip`.
