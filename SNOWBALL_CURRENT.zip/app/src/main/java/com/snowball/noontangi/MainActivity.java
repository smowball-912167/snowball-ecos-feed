package com.snowball.noontangi;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.media.MediaPlayer;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.speech.tts.UtteranceProgressListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Build;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.net.Uri;
import android.text.Html;
import android.view.WindowInsets;
import android.view.ViewGroup;
import android.widget.Toast;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.security.KeyStore;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;
import org.json.JSONArray;

public class MainActivity extends Activity {
    private WebView webView;
    private int bottomSystemInsetCssPx = 44;
    private int topSystemInsetCssPx = 24;
    private long lastBackPressedAt = 0L;
    private static final int REQ_CREATE_BACKUP = 5601;
    private static final int REQ_OPEN_BACKUP = 5602;
    private static final int REQ_VOICE_MIC = 5603;
    private TextToSpeech textToSpeech;
    private boolean textToSpeechReady = false;
    // V161: the five profile buttons must select genuinely different base voices when the
    // device exposes them. Google Speech Services exposes the Korean ISM/KOB(female) and
    // KOC/KOD(male) families, so try it first; Samsung/default remain fallbacks.
    private String activeTtsEngineLabel = "기본 TTS";
    // V160: user-owned AI voice tuning. The settings screen persists the chosen profile and
    // prosody so voice iteration no longer requires a new APK for every small adjustment.
    private static final String VOICE_PREFS = "snowball_voice_v160";
    private String voiceProfile = "female_soft";
    private float voiceRate = 0.90f;
    private float voicePitch = 0.78f;
    private float voiceTone = -0.20f;      // -1 warm/calm, +1 bright
    private float voiceBody = 0.25f;       // -1 thin, +1 thick
    private float voiceSoftness = 0.72f;   // 0 direct, 1 soft
    private String activeTtsVoiceName = "";
    private SpeechRecognizer speechRecognizer;
    private boolean pendingVoiceListen = false;
    // V117: SpeechRecognizer single owner. Samsung/Android can deliver stale ERROR_CLIENT/BUSY
    // callbacks when cancel() and startListening() are fired back-to-back. Keep only one native
    // recognition session alive and suppress callbacks caused by an intentional cancel.
    private boolean voiceRecognizerActive = false;
    // V265: one-shot STT check is isolated from navigation and AI routing. No audio is stored.
    private boolean voiceCheckOnce = false;
    // AI-generated Gemini/OpenAI speech. Temporary files are deleted after playback.
    private MediaPlayer chatAudioPlayer;
    private File chatAudioFile;
    private long chatAudioGeneration = 0;
    private volatile long chatVoiceRequestGen = 0;
    private long voiceListenSerial = 0L;
    private long voiceIgnoreErrorsUntilMs = 0L;
    // V120: keep partial STT hypotheses for the current turn. Samsung speech recognition can
    // return a final phrase that drops the first words (e.g. final="보여줘" after partial="단기 투자").
    // We merge those hypotheses only for intent routing, then clear them at the end of the turn.
    private long voicePartialSessionSerial = 0L;
    private final ArrayList<String> voicePartialHistory = new ArrayList<>();
    // V120: native navigation is the only owner of screen-open voice commands and uses partial STT context.
    // It consumes those utterances before they can ever reach the JS AI fallback.
    private long nativeNavPendingUntilMs = 0L;
    private String nativeNavPendingPrompt = "";
    private String lastNativeNavCommand = "";
    private long lastNativeNavCommandAtMs = 0L;
    private String pendingBackupJson = null;
    private String pendingBackupName = null;
    private volatile boolean activityActive = true;
    private volatile long marketGeneration = 1L;
    private final ThreadPoolExecutor marketExecutor = new ThreadPoolExecutor(
            4, 6, 30L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(32),
            runnable -> { Thread t = new Thread(runnable, "snowball-market-pool"); t.setDaemon(true); return t; },
            new ThreadPoolExecutor.AbortPolicy());
    // V190: keep Korean translation independent from market/news requests; results are applied asynchronously.
    private final ThreadPoolExecutor chatExecutor = new ThreadPoolExecutor(
            1, 1, 20L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(3),
            runnable -> { Thread t = new Thread(runnable, "snowball-chat-pool"); t.setDaemon(true); return t; },
            new ThreadPoolExecutor.AbortPolicy());
    private final ThreadPoolExecutor translationExecutor = new ThreadPoolExecutor(
            2, 2, 30L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(16),
            runnable -> { Thread t = new Thread(runnable, "snowball-translate-pool"); t.setDaemon(true); return t; },
            new ThreadPoolExecutor.AbortPolicy());

    // V139: KRX long-range investor flow is imported from a CSV the user explicitly
    // downloaded from the official KRX Data Marketplace UI. This avoids depending on an
    // unverified private/login endpoint while the equivalent public OPEN API is not confirmed.
    // S1-DIAG: aggregate counters only; never retain news queries or article text.
    private final java.util.concurrent.atomic.AtomicInteger diagNewsRequests = new java.util.concurrent.atomic.AtomicInteger();
    private final java.util.concurrent.atomic.AtomicInteger diagNewsSuccess = new java.util.concurrent.atomic.AtomicInteger();
    private final java.util.concurrent.atomic.AtomicInteger diagNewsFailures = new java.util.concurrent.atomic.AtomicInteger();
    private volatile long diagNewsLastSuccessMs = 0L;
    private volatile String diagNewsLastError = "NONE";
    private static final int REQ_OPEN_KRX_FLOW = 5604;
    private String pendingKrxFlowCode = "";
    private String pendingKrxFlowName = "";

    // V144: KRX Data Marketplace uses a browser-style session. Keep only anonymous
    // session cookies here; no user ID/password is stored or requested by this bridge.
    private static final Object KRX_SESSION_LOCK = new Object();
    private static String krxSessionCookie = "";
    private static long krxSessionAtMs = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        // V47: keep Android system-navigation area solid white.
        getWindow().setNavigationBarColor(android.graphics.Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility() | android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().setNavigationBarDividerColor(android.graphics.Color.WHITE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setDisplayZoomControls(false);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true);
        }
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setUserAgentString(s.getUserAgentString() + " SNOWBALLAPK/3.1-V121-AUTO-LONG-FLOW-R24");

        webView.setWebViewClient(new SnowballWebViewClient());
        // V45: use a restricted native bridge for market-data GET requests.
        // This avoids file:// WebView CORS/network restrictions and is limited to
        // the four Naver market-data hosts whitelisted by isNaverDataUrl().
        webView.addJavascriptInterface(new MarketDataBridge(), "SnowballMarketData");
        webView.addJavascriptInterface(new BackupBridge(), "SnowballBackup");
        webView.addJavascriptInterface(new BookmarkBridge(), "SnowballBookmarks");
        webView.addJavascriptInterface(new VoiceBridge(), "SnowballVoice");
        webView.addJavascriptInterface(new ChatBridge(), "SnowballChat");
        webView.addJavascriptInterface(new ExternalInfoBridge(), "SnowballExternalInfo");
        // S1: read-only runtime identity; no holdings, trade history or preferences accessed.
        webView.addJavascriptInterface(new DiagnosticBridge(), "SnowballDiagnostics");
        initVoiceEngines();

        // Android 15/16 can lay app content behind the system navigation bar.
        // Read the real device bottom inset and expose it to CSS so the common
        // SNOWBALL menu always sits above the phone buttons/gesture area.
        // Read insets from the decor view (more reliable on Samsung/Android 15+
        // than reading only from WebView). Convert physical px -> CSS px and
        // keep a practical minimum clearance while also exposing the status-bar inset.
        // V8 uses the real device inset when it is larger, without the previous over-lift.
        getWindow().getDecorView().setOnApplyWindowInsetsListener((v, insets) -> {
            int bottomPx;
            int topPx;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                bottomPx = insets.getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars()).bottom;
                topPx = insets.getInsetsIgnoringVisibility(WindowInsets.Type.statusBars()).top;
            } else {
                bottomPx = insets.getSystemWindowInsetBottom();
                topPx = insets.getSystemWindowInsetTop();
            }
            float density = getResources().getDisplayMetrics().density;
            int bottomCssPx = density > 0 ? Math.round(bottomPx / density) : bottomPx;
            int topCssPx = density > 0 ? Math.round(topPx / density) : topPx;
            bottomSystemInsetCssPx = Math.max(44, bottomCssPx);
            topSystemInsetCssPx = Math.max(24, topCssPx);
            applyBottomInsetToPage();
            return insets;
        });
        getWindow().getDecorView().requestApplyInsets();

        webView.clearCache(true);
        webView.loadUrl("file:///android_asset/index.html?v=800");
    }

    private void applyBottomInsetToPage() {
        if (webView == null) return;
        final int bottomPx = Math.max(44, bottomSystemInsetCssPx);
        final int topPx = Math.max(24, topSystemInsetCssPx);
        webView.post(() -> webView.evaluateJavascript(
                "document.documentElement.style.setProperty('--android-bottom-inset','" + bottomPx + "px');" +
                "document.documentElement.style.setProperty('--android-top-inset','" + topPx + "px');",
                null));
    }

    @Override
    protected void onPause() {
        activityActive = false;
        marketGeneration++;
        voiceCheckOnce = false;
        stopVoiceNative();
        notifyJsLifecycle("window.SNOWBALL_NATURAL_CHAT&&window.SNOWBALL_NATURAL_CHAT.onAppPause&&window.SNOWBALL_NATURAL_CHAT.onAppPause();");
        notifyJsLifecycle("window.NOONTANGI_STABILITY&&window.NOONTANGI_STABILITY.pauseFromNative&&window.NOONTANGI_STABILITY.pauseFromNative();");
        if (webView != null) {
            webView.onPause();
            webView.pauseTimers();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        activityActive = true;
        if (webView != null) {
            webView.resumeTimers();
            webView.onResume();
        }
        notifyJsLifecycle("window.NOONTANGI_STABILITY&&window.NOONTANGI_STABILITY.resumeFromNative&&window.NOONTANGI_STABILITY.resumeFromNative();");
        notifyJsLifecycle("window.SNOWBALL_NATURAL_CHAT&&window.SNOWBALL_NATURAL_CHAT.onAppResume&&window.SNOWBALL_NATURAL_CHAT.onAppResume();");
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        notifyJsLifecycle("window.NOONTANGI_STABILITY&&window.NOONTANGI_STABILITY.trimFromNative&&window.NOONTANGI_STABILITY.trimFromNative(" + level + ");");
        if (level >= TRIM_MEMORY_RUNNING_LOW) {
            marketGeneration++;
            marketExecutor.purge();
            translationExecutor.purge();
            if (webView != null) webView.clearCache(false);
        }
    }

    @Override
    protected void onDestroy() {
        activityActive = false;
        marketGeneration++;
        marketExecutor.shutdownNow();
        translationExecutor.shutdownNow();
        chatExecutor.shutdownNow();
        stopChatAudioOnUi();
        try { if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; } } catch (Exception ignored) { }
        try { if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; } } catch (Exception ignored) { }
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.loadUrl("about:blank");
                webView.removeJavascriptInterface("SnowballMarketData");
                webView.removeJavascriptInterface("SnowballBackup");
                webView.removeJavascriptInterface("SnowballVoice");
                webView.removeJavascriptInterface("SnowballExternalInfo");
                webView.destroy();
            } catch (Exception ignored) { }
            webView = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            safeExitOnSecondBack();
            return;
        }

        // V224: a visible top-level modal consumes Android Back before route navigation.
        webView.evaluateJavascript("(function(){return !!(window.NOONTANGI_MODAL_STANDARD&&window.NOONTANGI_MODAL_STANDARD.consumeBack&&window.NOONTANGI_MODAL_STANDARD.consumeBack());})()", modalClosed -> {
            if ("true".equals(modalClosed)) return;
            // V212: preserve theme article back behavior unchanged.
            webView.evaluateJavascript("(function(){return !!(window.NTV211_THEME_ARTICLE&&window.NTV211_THEME_ARTICLE.consumeBack&&window.NTV211_THEME_ARTICLE.consumeBack());})()", consumed -> {
                if ("true".equals(consumed)) return;
                continueBackNavigation();
            });
        });
    }

    private void continueBackNavigation() {
        if (webView == null) return;
        String url = webView.getUrl();
        boolean isAppPage = url != null && url.startsWith("file:///android_asset/index.html");
        if (!isAppPage && webView.canGoBack()) {
            webView.goBack();
            return;
        }

        // Radio-button routes do not create WebView history. On a subpage, a Back
        // press returns to HOME instead of closing the app. On HOME, require a
        // second Back press so an accidental touch near Samsung's system Back
        // button does not immediately close SNOWBALL.
        webView.evaluateJavascript(
                "(function(){var h=document.getElementById('rHome');return !!(h&&h.checked);})()",
                value -> {
                    boolean onHome = "true".equals(value);
                    if (!onHome) {
                        webView.evaluateJavascript(
                                "(function(){var h=document.getElementById('rHome');if(h){h.checked=true;h.dispatchEvent(new Event('change',{bubbles:true}));window.scrollTo(0,0);}})()",
                                null);
                    } else {
                        safeExitOnSecondBack();
                    }
                });
    }

    private void safeExitOnSecondBack() {
        long now = System.currentTimeMillis();
        if (now - lastBackPressedAt < 3000L) {
            super.onBackPressed();
            return;
        }
        lastBackPressedAt = now;
        Toast.makeText(this, "한 번 더 누르면 종료됩니다.", Toast.LENGTH_SHORT).show();
    }

    // V239: document-backed, read-only public economic-series sources.
    // Never pass credentials or arbitrary hosts through this bridge.
    private static boolean isApprovedPublicMacroUrl(String address) {
        if (address == null) return false;
        if (address.equals("https://smowball-912167.github.io/snowball-ecos-feed/ecos/feed.json")) return true; // V245 verified GitHub Pages ECOS feed only
        // V249: only exact expected public finance feed and official ISM month slugs; no keys or arbitrary URLs.
        if (address.equals("https://smowball-912167.github.io/snowball-ecos-feed/market/finance.json")) return true;
        // V258: exact CNN-owned fear & greed JSON endpoint, read-only; no keys or arbitrary paths.
        if (address.equals("https://production.dataviz.cnn.io/index/fearandgreed/graphdata")) return true;
        if (address.matches("https://www\\.ismworld\\.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/(january|february|march|april|may|june|july|august|september|october|november|december)/")) return true;

        if (address.equals("https://sdmx.oecd.org/public/rest/data/OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL,1.0/KOR.M.N.CPI.PA._T.N.GY?startPeriod=2025-01&dimensionAtObservation=AllDimensions&format=csvfile") ||
            address.equals("https://sdmx.oecd.org/public/rest/data/OECD.SDD.STES,DSD_STES@DF_CLI,4.1/KOR.M.LI...AA...H?startPeriod=2025-01&dimensionAtObservation=AllDimensions&format=csvfile")) return true;
        if (address.equals("https://stats.bis.org/api/v2/data/dataflow/BIS/WS_CBPOL/1.0/M.KR?startPeriod=2025-01&format=csv") ||
            address.equals("https://stats.bis.org/api/v2/data/dataflow/BIS/WS_CBPOL/1.0/M.US?startPeriod=2025-01&format=csv") ||
            address.equals("https://fred.stlouisfed.org/graph/fredgraph.csv?id=T10YIE")) return true;
        if (address.equals("https://api.bls.gov/publicAPI/v1/timeseries/data/CUUR0000SA0") ||
            address.equals("https://api.bls.gov/publicAPI/v1/timeseries/data/CUUR0000SA0L1E")) return true;
        return address.matches("https://home\\.treasury\\.gov/resource-center/data-chart-center/interest-rates/pages/xml\\?data=daily_treasury_yield_curve&field_tdr_date_value_month=20[0-9]{4}");
    }

    private static boolean isNaverDataUrl(String url) {
        return isApprovedPublicMacroUrl(url) || (url != null && (
            url.startsWith("https://api.stock.naver.com/") ||
            url.startsWith("https://m.stock.naver.com/api/") ||
            url.startsWith("https://m.stock.naver.com/front-api/") ||
            url.startsWith("https://stock.naver.com/api/") ||
            url.startsWith("https://polling.finance.naver.com/api/") ||
            url.startsWith("https://fchart.stock.naver.com/") ||
            url.startsWith("https://query1.finance.yahoo.com/") ||
            url.startsWith("https://query2.finance.yahoo.com/") ||
            url.startsWith("https://wts-info-api.tossinvest.com/")
        ));
    }

    private static String mimeFor(String url, String contentType) {
        if (contentType != null) {
            String c = contentType.toLowerCase();
            if (c.contains("json")) return "application/json";
            if (c.contains("xml")) return "text/xml";
        }
        if (url.contains("fchart.stock.naver.com")) return "text/xml";
        return "application/json";
    }

    private static WebResourceResponse proxy(String urlString) {
        HttpURLConnection con = null;
        try {
            URL url = new URL(urlString);
            con = (HttpURLConnection) url.openConnection();
            con.setConnectTimeout(7000);
            con.setReadTimeout(7000);
            con.setInstanceFollowRedirects(true);
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36");
            con.setRequestProperty("Referer", urlString.contains("sdmx.oecd.org") ? "https://data-explorer.oecd.org/" : (urlString.contains("finance.yahoo.com") ? "https://finance.yahoo.com/" : (urlString.contains("tossinvest.com") ? "https://www.tossinvest.com/" : "https://finance.naver.com/")));
            con.setRequestProperty("Accept-Encoding", "identity");
            con.setRequestProperty("Accept", "application/json,text/plain,*/*");
            con.connect();

            int code = con.getResponseCode();
            InputStream raw = code >= 400 ? con.getErrorStream() : con.getInputStream();
            if (raw == null) raw = new ByteArrayInputStream(new byte[0]);
            BufferedInputStream in = new BufferedInputStream(raw);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            in.close();

            String type = mimeFor(urlString, con.getContentType());
            Map<String,String> headers = new HashMap<>();
            headers.put("Access-Control-Allow-Origin", "*");
            headers.put("Access-Control-Allow-Methods", "GET, OPTIONS");
            headers.put("Access-Control-Allow-Headers", "*");
            headers.put("Cache-Control", "no-store");
            return new WebResourceResponse(type, "UTF-8", code, code >= 400 ? "Upstream error" : "OK", headers,
                    new ByteArrayInputStream(out.toByteArray()));
        } catch (Exception e) {
            String msg = "{\"error\":\"APK_PROXY_ERROR\",\"message\":\"" +
                    e.toString().replace("\\", "\\\\").replace("\"", "\\\"") + "\"}";
            Map<String,String> headers = new HashMap<>();
            headers.put("Access-Control-Allow-Origin", "*");
            return new WebResourceResponse("application/json", "UTF-8", 502, "Proxy error", headers,
                    new ByteArrayInputStream(msg.getBytes()));
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private static String mergeCookies(String existing, Map<String,List<String>> headers) {
        Map<String,String> jar = new HashMap<>();
        if (existing != null && !existing.trim().isEmpty()) {
            for (String part : existing.split(";")) {
                String s = part.trim();
                int eq = s.indexOf('=');
                if (eq > 0) jar.put(s.substring(0, eq).trim(), s.substring(eq + 1).trim());
            }
        }
        if (headers != null) {
            for (Map.Entry<String,List<String>> e : headers.entrySet()) {
                if (e.getKey() == null || !"Set-Cookie".equalsIgnoreCase(e.getKey()) || e.getValue() == null) continue;
                for (String raw : e.getValue()) {
                    if (raw == null) continue;
                    String first = raw.split(";", 2)[0].trim();
                    int eq = first.indexOf('=');
                    if (eq > 0) jar.put(first.substring(0, eq).trim(), first.substring(eq + 1).trim());
                }
            }
        }
        StringBuilder out = new StringBuilder();
        for (Map.Entry<String,String> e : jar.entrySet()) {
            if (out.length() > 0) out.append("; ");
            out.append(e.getKey()).append('=').append(e.getValue());
        }
        return out.toString();
    }

    private static void krxWarmGet(String urlString, String referer) throws Exception {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(urlString).openConnection();
            con.setConnectTimeout(8000);
            con.setReadTimeout(9000);
            con.setInstanceFollowRedirects(true);
            con.setUseCaches(false);
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36");
            con.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8");
            con.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.6");
            if (referer != null && !referer.isEmpty()) con.setRequestProperty("Referer", referer);
            if (!krxSessionCookie.isEmpty()) con.setRequestProperty("Cookie", krxSessionCookie);
            int code = con.getResponseCode();
            krxSessionCookie = mergeCookies(krxSessionCookie, con.getHeaderFields());
            InputStream raw = code >= 400 ? con.getErrorStream() : con.getInputStream();
            if (raw != null) {
                byte[] buf = new byte[4096];
                while (raw.read(buf) != -1) { /* drain for cookie/session completion */ }
                raw.close();
            }
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private static void ensureKrxAnonymousSession(boolean force) {
        synchronized (KRX_SESSION_LOCK) {
            long now = System.currentTimeMillis();
            if (!force && !krxSessionCookie.isEmpty() && now - krxSessionAtMs < 30L * 60L * 1000L) return;
            try {
                if (force) krxSessionCookie = "";
                String main = "https://data.krx.co.kr/contents/MDC/MAIN/main/index.cmd";
                String loader = "https://data.krx.co.kr/contents/MDC/MDI/outerLoader/index.cmd?screenId=MDCSTAT023";
                krxWarmGet(main, "https://data.krx.co.kr/");
                krxWarmGet(loader, main);
                krxSessionAtMs = now;
            } catch (Exception ignored) {
                // POST below still runs; failure is returned to JS and falls back without blanking the chart.
            }
        }
    }

    private static String krxPostOnce(Map<String,String> params, boolean refreshOnFailure) {
        HttpURLConnection con = null;
        try {
            ensureKrxAnonymousSession(false);
            URL url = new URL("https://data.krx.co.kr/comm/bldAttendant/getJsonData.cmd");
            con = (HttpURLConnection) url.openConnection();
            con.setConnectTimeout(9000);
            con.setReadTimeout(14000);
            con.setInstanceFollowRedirects(true);
            con.setUseCaches(false);
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36 SNOWBALL/60");
            con.setRequestProperty("Referer", "https://data.krx.co.kr/contents/MDC/MDI/outerLoader/index.cmd?screenId=MDCSTAT023");
            con.setRequestProperty("Origin", "https://data.krx.co.kr");
            con.setRequestProperty("X-Requested-With", "XMLHttpRequest");
            con.setRequestProperty("Accept", "application/json,text/plain,*/*");
            con.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.6");
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            if (!krxSessionCookie.isEmpty()) con.setRequestProperty("Cookie", krxSessionCookie);
            StringBuilder form = new StringBuilder();
            for (Map.Entry<String,String> e : params.entrySet()) {
                if (form.length() > 0) form.append('&');
                form.append(URLEncoder.encode(e.getKey(), "UTF-8"));
                form.append('=');
                form.append(URLEncoder.encode(e.getValue() == null ? "" : e.getValue(), "UTF-8"));
            }
            byte[] body = form.toString().getBytes(StandardCharsets.UTF_8);
            con.setFixedLengthStreamingMode(body.length);
            try (OutputStream os = con.getOutputStream()) { os.write(body); }
            int code = con.getResponseCode();
            krxSessionCookie = mergeCookies(krxSessionCookie, con.getHeaderFields());
            InputStream raw = code >= 400 ? con.getErrorStream() : con.getInputStream();
            if (raw == null) raw = new ByteArrayInputStream(new byte[0]);
            BufferedInputStream in = new BufferedInputStream(raw);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            in.close();
            String text = out.toString("UTF-8");
            if ((code == 401 || code == 403 || code == 500) && refreshOnFailure) {
                ensureKrxAnonymousSession(true);
                return krxPostOnce(params, false);
            }
            if (code >= 400) throw new RuntimeException("KRX HTTP " + code + " " + text.substring(0, Math.min(180, text.length())));
            return text;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private static String krxPost(Map<String,String> params) {
        return krxPostOnce(params, true);
    }

    private static String nativeGetKrxFlow(String stockCode, String fromYmd, String toYmd) {
        try {
            if (stockCode == null || !stockCode.matches("\\d{6}")) throw new IllegalArgumentException("KRX 종목코드 오류");
            if (fromYmd == null || !fromYmd.matches("\\d{8}") || toYmd == null || !toYmd.matches("\\d{8}")) throw new IllegalArgumentException("KRX 조회기간 오류");

            Map<String,String> finder = new HashMap<>();
            finder.put("bld", "dbms/comm/finder/finder_stkisu");
            finder.put("locale", "ko_KR");
            finder.put("mktsel", "ALL");
            finder.put("searchText", stockCode);
            finder.put("typeNo", "0");
            JSONObject fj = new JSONObject(krxPost(finder));
            JSONArray block = fj.optJSONArray("block1");
            String isin = "";
            if (block != null) {
                for (int i = 0; i < block.length(); i++) {
                    JSONObject row = block.optJSONObject(i);
                    if (row != null && stockCode.equals(row.optString("short_code"))) {
                        isin = row.optString("full_code", "");
                        if (!isin.isEmpty()) break;
                    }
                }
            }
            if (isin.isEmpty()) throw new IllegalStateException("KRX ISIN 조회 실패: " + stockCode);

            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyyMMdd", Locale.KOREA);
            sdf.setLenient(false);
            java.util.Date startDate = sdf.parse(fromYmd);
            java.util.Date endDate = sdf.parse(toYmd);
            if (startDate == null || endDate == null || startDate.after(endDate)) throw new IllegalArgumentException("KRX 조회기간 역전");
            java.util.Calendar cur = java.util.Calendar.getInstance(Locale.KOREA);
            cur.setTime(startDate);
            java.util.Calendar end = java.util.Calendar.getInstance(Locale.KOREA);
            end.setTime(endDate);
            JSONArray all = new JSONArray();
            int chunks = 0;
            while (!cur.after(end) && chunks < 12) {
                java.util.Calendar chunkEnd = (java.util.Calendar) cur.clone();
                chunkEnd.add(java.util.Calendar.DAY_OF_MONTH, 719);
                if (chunkEnd.after(end)) chunkEnd = (java.util.Calendar) end.clone();
                Map<String,String> q = new HashMap<>();
                q.put("bld", "dbms/MDC/STAT/standard/MDCSTAT02302");
                q.put("strtDd", sdf.format(cur.getTime()));
                q.put("endDd", sdf.format(chunkEnd.getTime()));
                q.put("isuCd", isin);
                q.put("inqTpCd", "2");
                q.put("trdVolVal", "1");
                q.put("askBid", "3");
                JSONObject kj = new JSONObject(krxPost(q));
                JSONArray out = kj.optJSONArray("output");
                if (out != null) for (int i = 0; i < out.length(); i++) all.put(out.get(i));
                chunks++;
                cur = (java.util.Calendar) chunkEnd.clone();
                cur.add(java.util.Calendar.DAY_OF_MONTH, 1);
                if (!cur.after(end)) try { Thread.sleep(220L); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); break; }
            }
            JSONObject result = new JSONObject();
            result.put("source", "KRX MDCSTAT02302");
            result.put("official", true);
            result.put("ticker", stockCode);
            result.put("isin", isin);
            result.put("from", fromYmd);
            result.put("to", toYmd);
            result.put("chunks", chunks);
            result.put("output", all);
            return result.toString();
        } catch (Exception e) {
            String safe = e.toString().replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
            return "{\"error\":\"KRX_FLOW_ERROR\",\"message\":\"" + safe + "\"}";
        }
    }

    private static String nativeGetText(String urlString) {
        if (!isNaverDataUrl(urlString)) {
            return "{\"error\":\"URL_NOT_ALLOWED\"}";
        }
        HttpURLConnection con = null;
        try {
            URL url = new URL(urlString);
            con = (HttpURLConnection) url.openConnection();
            con.setConnectTimeout(6500);
            con.setReadTimeout(6500);
            con.setInstanceFollowRedirects(true);
            con.setUseCaches(false);
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36 SNOWBALL/60");
            con.setRequestProperty("Referer", urlString.contains("stats.bis.org") ? "https://data.bis.org/" : (urlString.contains("fred.stlouisfed.org") ? "https://fred.stlouisfed.org/" : (urlString.contains("finance.yahoo.com") ? "https://finance.yahoo.com/" : (urlString.contains("tossinvest.com") ? "https://www.tossinvest.com/" : "https://finance.naver.com/"))));
            con.setRequestProperty("Accept-Encoding", "identity");
            con.setRequestProperty("Accept", (urlString.contains("sdmx.oecd.org") || urlString.contains("stats.bis.org") || urlString.contains("fred.stlouisfed.org")) ? "text/csv,*/*" : "application/json,text/plain,text/html,application/xml,text/xml,*/*");
            con.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.7,en;q=0.6");
            con.setRequestProperty("Cache-Control", "no-cache");
            con.connect();

            int code = con.getResponseCode();
            InputStream raw = code >= 400 ? con.getErrorStream() : con.getInputStream();
            if (raw == null) raw = new ByteArrayInputStream(new byte[0]);
            BufferedInputStream in = new BufferedInputStream(raw);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            in.close();
            String body = out.toString("UTF-8");
            if (code >= 400) {
                String safe = body.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
                return "{\"error\":\"HTTP_" + code + "\",\"message\":\"" + safe + "\"}";
            }
            return body;
        } catch (Exception e) {
            String safe = e.toString().replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
            return "{\"error\":\"APK_NATIVE_GET_ERROR\",\"message\":\"" + safe + "\"}";
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private void initVoiceEngines() {
        initTextToSpeechEngine(0);
        try {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
                speechRecognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) {
                        voiceRecognizerActive = true;
                        notifyVoiceState("listening", "말씀하세요");
                    }
                    @Override public void onBeginningOfSpeech() {
                        voiceRecognizerActive = true;
                        notifyVoiceState("listening", "듣고 있습니다");
                    }
                    @Override public void onRmsChanged(float rmsdB) { }
                    @Override public void onBufferReceived(byte[] buffer) { }
                    @Override public void onEndOfSpeech() { notifyVoiceState("processing", "요청을 확인하고 있습니다"); }
                    @Override public void onError(int error) {
                        voiceRecognizerActive = false;
                        long now = System.currentTimeMillis();
                        // cancel() itself commonly produces ERROR_CLIENT/NO_MATCH on Samsung.
                        // These stale callbacks must not reopen/reset the JS conversation state.
                        if (voiceCheckOnce) {
                            voiceCheckOnce = false;
                            notifyVoiceCheckResult("", "음성을 인식하지 못했습니다 (" + error + "). 다시 한 번 짧게 말씀해 보세요.");
                            return;
                        }
                        if (now < voiceIgnoreErrorsUntilMs &&
                                (error == SpeechRecognizer.ERROR_CLIENT ||
                                 error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                                 error == SpeechRecognizer.ERROR_NO_MATCH ||
                                 error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) return;
                        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                            notifyVoiceError("NO_SPEECH");
                        } else if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                            notifyVoiceError("RECOGNIZER_BUSY");
                        } else {
                            notifyVoiceError("VOICE_ERROR_" + error);
                        }
                    }
                    @Override public void onResults(Bundle results) {
                        voiceRecognizerActive = false;
                        ArrayList<String> finals = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        ArrayList<String> turnCandidates = mergeVoiceTurnCandidates(voiceListenSerial, finals);
                        if (voiceCheckOnce) {
                            voiceCheckOnce = false;
                            String heard = (finals != null && !finals.isEmpty()) ? finals.get(0) :
                                    (turnCandidates.isEmpty() ? "" : turnCandidates.get(0));
                            clearVoicePartialHistory();
                            notifyVoiceCheckResult(heard, heard.isEmpty() ? "인식 결과가 없습니다." : "");
                            return; // Never navigate, dispatch an AI question, or speak during STT check.
                        }
                        // V120: judge one complete turn from final + partial hypotheses. If the final phrase
                        // is a real AI question without an execution verb, do not let an earlier bare partial
                        // such as "단기 투자" steal the turn as navigation.
                        if (!finalTurnIsAiQuestionWithoutNavVerb(finals) && handleNativeNavigationCandidates(turnCandidates)) {
                            clearVoicePartialHistory();
                            return;
                        }
                        // Non-navigation speech continues to AI. Prefer final STT candidates; use merged
                        // hypotheses only when the recognizer returned no final text.
                        ArrayList<String> aiCandidates = (finals != null && !finals.isEmpty()) ? finals : turnCandidates;
                        clearVoicePartialHistory();
                        deliverVoiceCandidates(voiceListenSerial, aiCandidates);
                    }
                    @Override public void onPartialResults(Bundle partialResults) {
                        ArrayList<String> list = partialResults == null ? null : partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        rememberVoicePartialCandidates(voiceListenSerial, list);
                    }
                    @Override public void onEvent(int eventType, Bundle params) { }
                });
            }
        } catch (Exception ignored) { speechRecognizer = null; }
    }

    private static float clampFloat(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private boolean validVoiceProfile(String p) {
        return "female_soft".equals(p) || "female_calm".equals(p) || "female_clear".equals(p) ||
               "male_calm".equals(p) || "male_deep".equals(p);
    }

    private void loadVoiceTuning() {
        try {
            SharedPreferences sp = getSharedPreferences(VOICE_PREFS, MODE_PRIVATE);
            String profile = sp.getString("profile", "female_soft");
            voiceProfile = validVoiceProfile(profile) ? profile : "female_soft";
            voiceRate = clampFloat(sp.getFloat("rate", 0.90f), 0.65f, 1.30f);
            voicePitch = clampFloat(sp.getFloat("pitch", 0.78f), 0.50f, 1.30f);
            voiceTone = clampFloat(sp.getFloat("tone", -0.20f), -1.0f, 1.0f);
            voiceBody = clampFloat(sp.getFloat("body", 0.25f), -1.0f, 1.0f);
            voiceSoftness = clampFloat(sp.getFloat("softness", 0.72f), 0.0f, 1.0f);
        } catch (Exception ignored) { }
    }

    private void saveVoiceTuning() {
        try {
            getSharedPreferences(VOICE_PREFS, MODE_PRIVATE).edit()
                    .putString("profile", voiceProfile)
                    .putFloat("rate", voiceRate)
                    .putFloat("pitch", voicePitch)
                    .putFloat("tone", voiceTone)
                    .putFloat("body", voiceBody)
                    .putFloat("softness", voiceSoftness)
                    .apply();
        } catch (Exception ignored) { }
    }

    private float profilePitchMultiplier() {
        switch (voiceProfile) {
            case "female_calm": return 0.95f;
            case "female_clear": return 1.02f;
            // V161: male profiles now target real Korean male voice families (KOC/KOD).
            // Do not fake gender by crushing a female voice's pitch; keep only a mild profile offset.
            case "male_calm": return 0.97f;
            case "male_deep": return 0.90f;
            case "female_soft":
            default: return 0.98f;
        }
    }

    private float profileRateMultiplier() {
        switch (voiceProfile) {
            case "female_calm": return 0.95f;
            case "female_clear": return 1.02f;
            case "male_calm": return 0.94f;
            case "male_deep": return 0.90f;
            case "female_soft":
            default: return 0.98f;
        }
    }

    private float effectiveVoicePitch() {
        float p = voicePitch * profilePitchMultiplier();
        p *= (1.0f + 0.07f * voiceTone);
        if (voiceBody >= 0) p *= (1.0f - 0.10f * voiceBody);
        else p *= (1.0f + 0.05f * (-voiceBody));
        return clampFloat(p, 0.50f, 1.25f);
    }

    private float effectiveVoiceRate() {
        float r = voiceRate * profileRateMultiplier();
        r *= (1.0f + 0.015f * voiceTone);
        if (voiceBody >= 0) r *= (1.0f - 0.03f * voiceBody);
        else r *= (1.0f + 0.02f * (-voiceBody));
        return clampFloat(r, 0.65f, 1.25f);
    }

    private float effectiveVoiceVolume() {
        // Android TTS does not expose a true spectral EQ/thickness control. Softness therefore
        // trims utterance drive while tone/body are represented by voice choice + prosody.
        return clampFloat(0.98f - 0.20f * voiceSoftness, 0.72f, 0.98f);
    }

    private long effectiveVoiceGapMs() {
        return Math.round(80f + 120f * voiceSoftness);
    }

    private int effectiveVoiceChunkMax() {
        return Math.max(150, Math.min(220, Math.round(220f - 50f * voiceSoftness)));
    }

    private boolean voiceNameHas(String name, String... parts) {
        if (name == null) return false;
        String n = name.toLowerCase(Locale.ROOT);
        for (String p : parts) if (p != null && !p.isEmpty() && n.contains(p.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private int profileFamilyBonus(String name, String profile) {
        // V161 REAL VOICE FAMILY MAP. Google/Android Korean TTS commonly exposes:
        // ISM/KOB = female, KOC/KOD = male. Some builds additionally expose #female_N/#male_N variants.
        // We choose a real family first, then use general scoring only as a fallback.
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        boolean local = n.contains("-local");
        boolean network = n.contains("-network");
        if ("female_soft".equals(profile)) {
            if (voiceNameHas(n, "#female_1", "#female_2")) return 9800;
            if (n.contains("x-ism") && local) return 9500;
            if (n.contains("x-ism")) return 9000;
        } else if ("female_calm".equals(profile)) {
            if (n.contains("x-kob") && local) return 9700;
            if (n.contains("x-kob")) return 9300;
            if (n.contains("#female_2")) return 9000;
        } else if ("female_clear".equals(profile)) {
            if (n.contains("#female_3")) return 9900;
            // ko-KR-language is a separate female entry on Google TTS voice lists and is preferable
            // to reusing the same ISM local voice. If unavailable, use a network female family.
            if (n.equals("ko-kr-language") || n.endsWith("ko-kr-language") || n.contains("ko-kr-language")) return 9600;
            if (n.contains("x-kob") && network) return 9200;
            if (n.contains("x-ism") && network) return 9000;
        } else if ("male_calm".equals(profile)) {
            if (voiceNameHas(n, "#male_1", "#male_2")) return 10000;
            if (n.contains("x-koc") && local) return 9900;
            if (n.contains("x-koc")) return 9500;
        } else if ("male_deep".equals(profile)) {
            if (voiceNameHas(n, "#male_3", "#male_2")) return 10000;
            if (n.contains("x-kod") && local) return 9950;
            if (n.contains("x-kod")) return 9550;
        }
        return 0;
    }

    private boolean activeVoiceMatchesProfile() {
        String n = activeTtsVoiceName == null ? "" : activeTtsVoiceName.toLowerCase(Locale.ROOT);
        if (n.isEmpty()) return false;
        switch (voiceProfile) {
            case "female_soft": return n.contains("x-ism") || n.contains("#female_1") || n.contains("#female_2");
            case "female_calm": return n.contains("x-kob") || n.contains("#female_2");
            case "female_clear": return n.contains("#female_3") || n.contains("ko-kr-language") || (n.contains("x-ism") && n.contains("network")) || (n.contains("x-kob") && n.contains("network"));
            case "male_calm": return n.contains("x-koc") || n.contains("#male_1") || n.contains("#male_2");
            case "male_deep": return n.contains("x-kod") || n.contains("#male_3");
            default: return false;
        }
    }

    private String profileExpectedFamily() {
        switch (voiceProfile) {
            case "female_soft": return "여성 ISM";
            case "female_calm": return "여성 KOB";
            case "female_clear": return "여성 추가/기본";
            case "male_calm": return "남성 KOC";
            case "male_deep": return "남성 KOD";
            default: return "한국어";
        }
    }

    private int voiceScore(Voice v, String profile) {
        if (v == null || v.getLocale() == null || !"ko".equalsIgnoreCase(v.getLocale().getLanguage())) return Integer.MIN_VALUE / 4;
        String name = String.valueOf(v.getName()).toLowerCase(Locale.ROOT);
        int score = profileFamilyBonus(name, profile);
        if (!v.isNetworkConnectionRequired()) score += 420;
        score += Math.max(0, v.getQuality()) / 2;
        score -= Math.max(0, v.getLatency()) / 10;
        if (name.contains("natural") || name.contains("neural") || name.contains("premium")) score += 100;

        boolean femaleHint = voiceNameHas(name,
                "#female", "female", "fem", "woman", "여성",
                "x-ism", "x-kob", "두리", "duri", "윤정", "yunjung", "지우", "jiwoo",
                "voice 1", "voice1", "voice 3", "voice3", "voice 5", "voice5", "l05", "l01", "l08");
        boolean maleHint = voiceNameHas(name,
                "#male", "male", "man", "남성", "x-koc", "x-kod",
                "voice 2", "voice2", "음성 2", "voice 4", "voice4", "음성 4");

        if (profile.startsWith("female")) {
            if (femaleHint) score += 1000;
            if (maleHint) score -= 5000;
        } else {
            if (maleHint) score += 1800;
            if (femaleHint) score -= 6000;
        }

        if ("female_soft".equals(profile)) {
            if (name.contains("soft") || name.contains("warm") || name.contains("calm") || name.contains("low")) score += 360;
            if (name.contains("bright") || name.contains("child") || name.contains("young")) score -= 320;
        } else if ("female_calm".equals(profile)) {
            if (name.contains("calm") || name.contains("warm") || name.contains("soft") || name.contains("low")) score += 380;
        } else if ("female_clear".equals(profile)) {
            if (name.contains("clear") || name.contains("natural") || name.contains("neural")) score += 300;
        } else if ("male_calm".equals(profile)) {
            if (name.contains("calm") || name.contains("warm") || name.contains("low")) score += 420;
        } else if ("male_deep".equals(profile)) {
            if (name.contains("deep") || name.contains("low") || name.contains("warm")) score += 520;
        }
        return score;
    }

    private void chooseUserKoreanVoice() {
        if (textToSpeech == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        try {
            Set<Voice> voices = textToSpeech.getVoices();
            if (voices == null || voices.isEmpty()) return;
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            for (Voice v : voices) {
                int score = voiceScore(v, voiceProfile);
                if (best == null || score > bestScore) { best = v; bestScore = score; }
            }
            if (best != null) {
                textToSpeech.setVoice(best);
                activeTtsVoiceName = String.valueOf(best.getName());
            }
        } catch (Exception ignored) { }
    }

    private void applyVoiceTuning() {
        if (textToSpeech == null) return;
        try {
            chooseUserKoreanVoice();
            textToSpeech.setSpeechRate(effectiveVoiceRate());
            textToSpeech.setPitch(effectiveVoicePitch());
        } catch (Exception ignored) { }
    }

    private void updateVoiceTuningFromJson(String raw, boolean persist) {
        try {
            JSONObject j = new JSONObject(raw == null ? "{}" : raw);
            String profile = j.optString("profile", voiceProfile);
            if (validVoiceProfile(profile)) voiceProfile = profile;
            if (j.has("rate")) voiceRate = clampFloat((float) j.optDouble("rate", voiceRate), 0.65f, 1.30f);
            if (j.has("pitch")) voicePitch = clampFloat((float) j.optDouble("pitch", voicePitch), 0.50f, 1.30f);
            if (j.has("tone")) voiceTone = clampFloat((float) j.optDouble("tone", voiceTone), -1.0f, 1.0f);
            if (j.has("body")) voiceBody = clampFloat((float) j.optDouble("body", voiceBody), -1.0f, 1.0f);
            if (j.has("softness")) voiceSoftness = clampFloat((float) j.optDouble("softness", voiceSoftness), 0.0f, 1.0f);
            if (persist) saveVoiceTuning();
            runOnUiThread(this::applyVoiceTuning);
        } catch (Exception ignored) { }
    }

    private String voiceTuningJson() {
        JSONObject j = new JSONObject();
        try {
            j.put("profile", voiceProfile);
            j.put("rate", voiceRate);
            j.put("pitch", voicePitch);
            j.put("tone", voiceTone);
            j.put("body", voiceBody);
            j.put("softness", voiceSoftness);
            j.put("effectiveRate", effectiveVoiceRate());
            j.put("effectivePitch", effectiveVoicePitch());
            j.put("effectiveVolume", effectiveVoiceVolume());
            j.put("gapMs", effectiveVoiceGapMs());
            j.put("voiceName", activeTtsVoiceName);
            j.put("engine", activeTtsEngineLabel);
            j.put("profileMatched", activeVoiceMatchesProfile());
            j.put("profileExpected", profileExpectedFamily());
        } catch (Exception ignored) { }
        return j.toString();
    }

    private void resetVoiceTuning() {
        voiceProfile = "female_soft";
        voiceRate = 0.90f;
        voicePitch = 0.78f;
        voiceTone = -0.20f;
        voiceBody = 0.25f;
        voiceSoftness = 0.72f;
        saveVoiceTuning();
        runOnUiThread(this::applyVoiceTuning);
    }

    private void initTextToSpeechEngine(int stage) {
        // stage 0 = Google Speech Services (real Korean male/female families),
        // stage 1 = Samsung TTS, stage 2 = Android default engine.
        final String enginePackage = stage == 0 ? "com.google.android.tts" : (stage == 1 ? "com.samsung.SMT" : null);
        final String engineLabel = stage == 0 ? "Google TTS" : (stage == 1 ? "Samsung TTS" : "기본 TTS");
        try {
            activeTtsEngineLabel = engineLabel;
            TextToSpeech.OnInitListener listener = status -> {
                if (status != TextToSpeech.SUCCESS || textToSpeech == null) {
                    if (stage < 2) {
                        try { if (textToSpeech != null) textToSpeech.shutdown(); } catch (Exception ignored) { }
                        textToSpeech = null;
                        initTextToSpeechEngine(stage + 1);
                    }
                    return;
                }
                try {
                    textToSpeech.setLanguage(Locale.KOREA);
                    loadVoiceTuning();
                    applyVoiceTuning();
                    textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override public void onStart(String utteranceId) { }
                        @Override public void onDone(String utteranceId) {
                            if (utteranceId != null && utteranceId.startsWith("snowball-tts-final-")) notifyVoiceState("idle", "", utteranceId);
                        }
                        @Override public void onError(String utteranceId) { notifyVoiceState("idle", "", "error:" + String.valueOf(utteranceId)); }
                    });
                    textToSpeechReady = true;
                } catch (Exception ignored) { }
            };
            if (enginePackage != null) textToSpeech = new TextToSpeech(this, listener, enginePackage);
            else textToSpeech = new TextToSpeech(this, listener);
        } catch (Exception e) {
            if (stage < 2) initTextToSpeechEngine(stage + 1);
        }
    }


    private static String koreanDigits(String digits) {
        String[] names = {"영","일","이","삼","사","오","육","칠","팔","구"};
        StringBuilder out = new StringBuilder();
        if (digits == null) return "";
        for (int i = 0; i < digits.length(); i++) {
            char c = digits.charAt(i);
            if (c >= '0' && c <= '9') {
                if (out.length() > 0) out.append(' ');
                out.append(names[c - '0']);
            } else out.append(c);
        }
        return out.toString();
    }

    private static String koreanGroup(int n) {
        String[] digit = {"","일","이","삼","사","오","육","칠","팔","구"};
        String[] unit = {"","십","백","천"};
        StringBuilder out = new StringBuilder();
        int place = 0;
        while (n > 0) {
            int d = n % 10;
            if (d != 0) {
                String part = (d == 1 && place > 0 ? "" : digit[d]) + unit[place];
                out.insert(0, part);
            }
            n /= 10;
            place++;
        }
        return out.toString();
    }

    private static String koreanInteger(long n) {
        if (n == 0) return "영";
        if (n < 0) return "마이너스 " + koreanInteger(-n);
        String[] big = {"", "만", "억", "조", "경"};
        StringBuilder out = new StringBuilder();
        int idx = 0;
        while (n > 0 && idx < big.length) {
            int g = (int)(n % 10000L);
            if (g != 0) {
                String part;
                if (g == 1 && idx == 1) part = ""; // 10,000원 -> 만 원
                else part = koreanGroup(g);
                out.insert(0, part + big[idx]);
            }
            n /= 10000L;
            idx++;
        }
        return out.toString();
    }

    private static String replaceNumberUnit(String text, String unit, String spokenUnit) {
        Pattern p = Pattern.compile("(?<![0-9.])([0-9]{1,3}(?:,[0-9]{3})+|[0-9]+)\\s*" + Pattern.quote(unit));
        Matcher m = p.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            try {
                long v = Long.parseLong(m.group(1).replace(",", ""));
                m.appendReplacement(sb, Matcher.quoteReplacement(koreanInteger(v) + spokenUnit));
            } catch (Exception e) {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
            }
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static String semanticTtsText(String raw) {
        String text = raw == null ? "" : raw;
        // V158: UI cards often contain meaningful line/paragraph boundaries. Keep them as speech
        // boundaries instead of flattening everything into one breath.
        text = text.replaceAll("[\\r\\n]+", ". ");
        text = text.replace('\u00b7', ' ').replace("→", "에서").replace("⇒", "에서");

        // 기간/금리 약어는 날짜 하이픈보다 먼저 의미를 고정한다.
        text = text.replaceAll("(?i)\\b2Y\\s*[-~]\\s*10Y\\b", "2년물과 10년물 금리차");
        text = text.replaceAll("(?i)\\b([0-9]{1,2})Y\\b", "$1년물");
        text = text.replaceAll("(?<![0-9])1/3/5/10/20/30년", "1년, 3년, 5년, 10년, 20년, 30년");
        text = text.replaceAll("(?<![0-9])1/3/5/10년", "1년, 3년, 5년, 10년");

        // 날짜: 2026-09-30 / 2026.09.30 / 2026/09/30 -> 2026년 9월 30일
        Pattern date = Pattern.compile("(?<![0-9])((?:19|20)[0-9]{2})[-./]([01]?[0-9])[-./]([0-3]?[0-9])(?![0-9])");
        Matcher dm = date.matcher(text);
        StringBuffer dsb = new StringBuffer();
        while (dm.find()) {
            int mo = Integer.parseInt(dm.group(2));
            int day = Integer.parseInt(dm.group(3));
            dm.appendReplacement(dsb, Matcher.quoteReplacement(dm.group(1) + "년 " + mo + "월 " + day + "일"));
        }
        dm.appendTail(dsb);
        text = dsb.toString();

        // 시각: 14:30 -> 14시 30분
        Pattern time = Pattern.compile("(?<![0-9])([01]?[0-9]|2[0-3]):([0-5][0-9])(?![0-9])");
        Matcher tm = time.matcher(text);
        StringBuffer tsb = new StringBuffer();
        while (tm.find()) {
            int hh = Integer.parseInt(tm.group(1));
            int mm = Integer.parseInt(tm.group(2));
            String rep = hh + "시" + (mm == 0 ? "" : " " + mm + "분");
            tm.appendReplacement(tsb, Matcher.quoteReplacement(rep));
        }
        tm.appendTail(tsb);
        text = tsb.toString();

        // 등락률은 부호의 뜻까지 읽는다.
        Pattern pct = Pattern.compile("(?<![0-9])([+-]?)([0-9]+(?:\\.[0-9]+)?)\\s*%");
        Matcher pm = pct.matcher(text);
        StringBuffer psb = new StringBuffer();
        while (pm.find()) {
            String sign = pm.group(1), val = pm.group(2);
            String rep = val + "퍼센트";
            if ("+".equals(sign)) rep += " 상승";
            else if ("-".equals(sign)) rep += " 하락";
            pm.appendReplacement(psb, Matcher.quoteReplacement(rep));
        }
        pm.appendTail(psb);
        text = psb.toString();

        // 통화/수량은 사람이 읽는 단위로 바꾼다.
        text = replaceNumberUnit(text, "원", " 원");
        text = replaceNumberUnit(text, "주", " 주");

        // 종목코드는 자리수 자체가 의미이므로 한 자리씩 읽는다.
        Pattern code = Pattern.compile("(종목\\s*코드|코드)\\s*[:：]?\\s*([0-9]{6})");
        Matcher cm = code.matcher(text);
        StringBuffer csb = new StringBuffer();
        while (cm.find()) {
            cm.appendReplacement(csb, Matcher.quoteReplacement(cm.group(1) + " " + koreanDigits(cm.group(2))));
        }
        cm.appendTail(csb);
        text = csb.toString();

        // 투자 화면에서 자주 쓰는 영문 약어를 의미대로 읽는다.
        text = text.replaceAll("(?i)\\bIRP\\b", "아이알피");
        text = text.replaceAll("(?i)\\bAI\\b", "에이아이");
        text = text.replaceAll("(?i)\\bETF\\b", "이티에프");
        text = text.replaceAll("(?i)\\bVIX\\b", "빅스");
        text = text.replaceAll("(?i)\\bDXY\\b", "달러 인덱스");
        text = text.replaceAll("(?i)\\bCPI\\b", "소비자물가지수");
        text = text.replaceAll("(?i)\\bPCE\\b", "개인소비지출 물가지수");
        text = text.replaceAll("(?i)\\bEPS\\b", "주당순이익");
        text = text.replaceAll("(?i)S&P\\s*500", "에스앤피 오백");
        text = text.replaceAll("(?i)\\bKOSPI\\b", "코스피");
        text = text.replaceAll("(?i)\\bKOSDAQ\\b", "코스닥");
        text = text.replaceAll("(?i)\\bUSD/KRW\\b", "원 달러 환율");

        return text.replaceAll("\\.{2,}", ".").replaceAll("\\s+", " ").trim();
    }

    private static String xmlDecode(String s) {
        if (s == null) return "";
        return s.replace("<![CDATA[", "").replace("]]>", "")
                .replace("&amp;", "&").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">");
    }

    private static String stripHtml(String s) {
        if (s == null) return "";
        return xmlDecode(s.replaceAll("(?s)<[^>]+>", " ")).replaceAll("\\s+", " ").trim();
    }

    private static String tagValue(String block, String tag) {
        Pattern p = Pattern.compile("(?is)<" + tag + "(?:\\s[^>]*)?>(.*?)</" + tag + ">");
        Matcher m = p.matcher(block == null ? "" : block);
        return m.find() ? stripHtml(m.group(1)) : "";
    }

    private static String sourceValue(String block) {
        Pattern p = Pattern.compile("(?is)<source(?:\\s[^>]*)?>(.*?)</source>");
        Matcher m = p.matcher(block == null ? "" : block);
        return m.find() ? stripHtml(m.group(1)) : "";
    }

    private static String sourceUrlValue(String block) {
        Pattern p = Pattern.compile("(?is)<source[^>]+url\\s*=\\s*[\"\'](.*?)[\"\'][^>]*>");
        Matcher m = p.matcher(block == null ? "" : block);
        return m.find() ? xmlDecode(m.group(1)).trim() : "";
    }

    // V231: RSS image extraction. Use image URLs actually supplied by the source;
    // never show unrelated stock photography as an article thumbnail.
    private static String marketRssImage(String block) {
        if (block == null) return "";
        for (String kind : new String[]{"media:thumbnail", "media:content", "enclosure"}) {
            Pattern p = Pattern.compile("(?is)<" + kind + "\\b([^>]*)>");
            Matcher m = p.matcher(block);
            while (m.find()) {
                String attrs = m.group(1);
                if (kind.equals("enclosure") && !attrs.matches("(?is).*\\btype\\s*=\\s*['\"]image/[^'\"]+['\"].*")) continue;
                Matcher u = Pattern.compile("(?is)\\burl\\s*=\\s*['\"](https://[^'\"\\s<>]+)['\"]").matcher(attrs);
                if (u.find()) return xmlDecode(u.group(1));
            }
        }
        return "";
    }

    /* V195: keep full balanced terms; never truncate parentheses mid-query.
       A public RSS fallback is only used when the specific feed produced no items. */
    private static JSONObject searchPublicNews(String query) {
        String raw = query == null ? "" : query.trim();
        boolean globalLane = raw.startsWith("__GLOBAL__");
        String q = globalLane ? raw.substring("__GLOBAL__".length()).trim() : raw;
        if (q.length() > 260) {
            // A complete and intentionally broad fallback is better than a broken half-parenthesis expression.
            q = globalLane ? "global markets economy earnings when:3d" : "한국 기업 증시 실적 투자 when:3d";
        }
        JSONObject first = searchPublicNewsOnce(q, globalLane);
        JSONArray firstItems = first.optJSONArray("items");
        if (firstItems != null && firstItems.length() > 0) return first;
        String fallback = globalLane ? "global stocks earnings markets when:3d" : "한국 기업 실적 투자 증시 when:3d";
        if (q.equals(fallback)) return first;
        JSONObject second = searchPublicNewsOnce(fallback, globalLane);
        JSONArray secondItems = second.optJSONArray("items");
        if (secondItems != null && secondItems.length() > 0) {
            try { second.put("fallbackUsed", true); second.put("originalQuery", q); } catch (Exception ignored) { }
            return second;
        }
        try {
            first.put("fallbackError", second.optString("message", second.optString("error", "EMPTY_FEED")));
            first.put("fallbackUsed", false);
        } catch (Exception ignored) { }
        return first;
    }

    private static JSONObject searchPublicNewsOnce(String q, boolean globalLane) {
        JSONObject out = new JSONObject();
        JSONArray items = new JSONArray();
        HttpURLConnection con = null;
        try {
            out.put("query", q);
            out.put("lane", globalLane ? "GLOBAL" : "KR");
            out.put("fetchedAt", System.currentTimeMillis());
            if (q.isEmpty()) {
                out.put("items", items);
                out.put("error", "EMPTY_QUERY");
                return out;
            }
            String locale = globalLane ? "&hl=en-US&gl=US&ceid=US:en" : "&hl=ko&gl=KR&ceid=KR:ko";
            String u = "https://news.google.com/rss/search?q=" + URLEncoder.encode(q, "UTF-8") + locale;
            con = (HttpURLConnection) new URL(u).openConnection();
            con.setConnectTimeout(3000);
            con.setReadTimeout(4500);
            con.setInstanceFollowRedirects(true);
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) SNOWBALL/1.0");
            con.setRequestProperty("Accept-Encoding", "identity");
            int httpStatus = con.getResponseCode();
            if (httpStatus >= 400) throw new Exception("NEWS_HTTP_" + httpStatus);
            InputStream raw = con.getInputStream();
            if (raw == null) throw new Exception("NEWS_EMPTY_RESPONSE");
            BufferedInputStream in = new BufferedInputStream(raw);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1 && bos.size() < 600000) bos.write(buf, 0, n);
            in.close();
            String xml = new String(bos.toByteArray(), StandardCharsets.UTF_8);
            Matcher im = Pattern.compile("(?is)<item>(.*?)</item>").matcher(xml);
            int count = 0;
            Set<String> publishers = new java.util.HashSet<>();
            while (im.find() && count < 18) {
                String block = im.group(1);
                String title = tagValue(block, "title");
                String link = tagValue(block, "link");
                String pubDate = tagValue(block, "pubDate");
                String source = sourceValue(block);
                String sourceUrl = sourceUrlValue(block);
                String description = tagValue(block, "description");
                if (title.isEmpty()) continue;
                JSONObject it = new JSONObject();
                it.put("title", title);
                it.put("source", source);
                it.put("sourceUrl", sourceUrl);
                it.put("pubDate", pubDate);
                it.put("link", link);
                it.put("url", link);
                it.put("description", description);
                String imageUrl = marketRssImage(block);
                if (!imageUrl.isEmpty()) it.put("imageUrl", imageUrl);
                items.put(it);
                if (!source.isEmpty()) publishers.add(source.toLowerCase(Locale.ROOT));
                count++;
            }
            out.put("items", items);
            out.put("distinctSources", publishers.size());
            out.put("source", "Google News RSS · 공개 보도 출처 집계");
            if (items.length()==0) out.put("error","RSS_ZERO_ITEMS");
        } catch (Exception e) {
            try { out.put("error", "NEWS_FETCH_FAILED"); out.put("message", String.valueOf(e.getMessage())); out.put("items", items); } catch (Exception ignored) { }
        } finally {
            if (con != null) con.disconnect();
        }
        return out;
    }



    // V190: public Korean translation stays independent from the market/news queue.
    // The JS layer stores the global event first and retries translation without deleting the event.
    private static String translateGoogleTextToKorean(String rawText) throws Exception {
        String text = rawText == null ? "" : rawText.replace('\u0000', ' ').replaceAll("\\s+", " ").trim();
        if (text.isEmpty()) return "";
        if (text.length() > 1800) text = text.substring(0, 1800);
        HttpURLConnection con = null;
        try {
            String u = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ko&dt=t&q="
                    + URLEncoder.encode(text, "UTF-8");
            con = (HttpURLConnection) new URL(u).openConnection();
            con.setConnectTimeout(4500);
            con.setReadTimeout(7000);
            con.setInstanceFollowRedirects(true);
            con.setUseCaches(false);
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) SNOWBALL/1.0");
            con.setRequestProperty("Accept", "application/json,text/plain,*/*");
            con.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.5");
            InputStream raw = con.getResponseCode() >= 400 ? con.getErrorStream() : con.getInputStream();
            if (raw == null) throw new Exception("TRANSLATE_EMPTY_RESPONSE");
            BufferedInputStream in = new BufferedInputStream(raw);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) != -1 && bos.size() < 120000) bos.write(buf, 0, n);
            in.close();
            JSONArray root = new JSONArray(new String(bos.toByteArray(), StandardCharsets.UTF_8));
            JSONArray segs = root.optJSONArray(0);
            StringBuilder ko = new StringBuilder();
            if (segs != null) {
                for (int i = 0; i < segs.length(); i++) {
                    JSONArray seg = segs.optJSONArray(i);
                    if (seg == null) continue;
                    String part = seg.optString(0, "");
                    if (!part.isEmpty()) ko.append(part);
                }
            }
            String translated = ko.toString().replaceAll("\\s+", " ").trim();
            if (!translated.matches(".*[가-힣].*")) throw new Exception("TRANSLATE_NOT_KOREAN");
            return translated;
        } finally { if (con != null) con.disconnect(); }
    }

    private static JSONObject translatePublicToKorean(String rawText) {
        JSONObject out = new JSONObject();
        try {
            String text = rawText == null ? "" : rawText.replace('\u0000', ' ').replaceAll("\\s+", " ").trim();
            out.put("translated", "");
            if (text.isEmpty()) { out.put("error", "EMPTY_TRANSLATION_TEXT"); return out; }
            if (text.length() > 1800) text = text.substring(0, 1800);
            String translated = "";
            for (int attempt = 0; attempt < 3 && translated.isEmpty(); attempt++) {
                try { translated = translateGoogleTextToKorean(text); } catch (Exception ignored) { translated = ""; }
                if (translated.isEmpty() && attempt < 2) {
                    try { Thread.sleep(attempt == 0 ? 180L : 520L); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); break; }
                }
            }
            if (translated.isEmpty() || !translated.matches(".*[가-힣].*")) throw new Exception("TRANSLATE_FAILED");
            out.put("translated", translated);
            out.put("source", "public-ko-translation-v189-async");
            out.put("fetchedAt", System.currentTimeMillis());
        } catch (Exception e) {
            try { out.put("translated", ""); out.put("error", "TRANSLATE_FAILED"); out.put("message", String.valueOf(e.getMessage())); } catch (Exception ignored) { }
        }
        return out;
    }

    private static boolean isPublicHttpUrl(String urlString) {
        try {
            if (urlString == null) return false;
            URL u = new URL(urlString.trim());
            String scheme = u.getProtocol();
            if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) return false;
            String h = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            if (h.isEmpty() || "localhost".equals(h) || h.endsWith(".local") ||
                    h.startsWith("127.") || h.startsWith("10.") || h.startsWith("192.168.") ||
                    h.startsWith("169.254.")) return false;
            Matcher m = Pattern.compile("^172\\.(\\d{1,3})\\.").matcher(h);
            if (m.find()) {
                int b = Integer.parseInt(m.group(1));
                if (b >= 16 && b <= 31) return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // V178 simple reader: no HTML resolver/parser chain. The exact article URL is rendered once in WebView.

    private static Set<String> articleTitleTokens(String title) {
        Set<String> out = new java.util.LinkedHashSet<>();
        String raw = title == null ? "" : title.toLowerCase(Locale.ROOT);
        for (String w : raw.split("[^0-9a-z가-힣]+")) {
            if (w.length() < 2) continue;
            if (w.matches("(?:단독|종합|속보|기자|대표|회장|장관|대통령|관련|전망|발언|말해|밝혀|강조)")) continue;
            out.add(w);
        }
        return out;
    }

    private static boolean articleTailHeadlineLike(String x, Set<String> titleTokens, int bodyChars, int bodyLines) {
        if (x == null || bodyChars < 160 || bodyLines < 2) return false;
        String t = x.trim();
        if (t.length() < 18 || t.length() > 190) return false;
        String lo = t.toLowerCase(Locale.ROOT);
        boolean terminal = t.matches(".*[.!?。！？][\\\"'”’)]*$") ||
                t.matches(".*(?:했다|말했다|밝혔다|설명했다|강조했다|전했다|전망했다|예상했다|예정이다|것이다|된다|있다|없다)[\\\"'”’)]*$");
        boolean headlinePunct = t.contains("…") || t.contains("...") ||
                t.matches(".*[‘’\\\"'].*[‘’\\\"'].*") || lo.contains(" vs ") || t.matches("^\\[[^]]{1,18}].*");
        boolean topicHit = false;
        for (String w : titleTokens) { if (lo.contains(w)) { topicHit = true; break; } }
        boolean obviousOtherNews = lo.matches(".*(?:맛집|몸매|다이어트|열애설|패싸움|재산|아내|남편|실종|구조|재판|무죄|출간|운동하던).*?");
        boolean compactOtherHeadline = bodyChars >= 350 && bodyLines >= 3 && !terminal && !topicHit && t.length() <= 150;
        return !terminal && (headlinePunct || obviousOtherNews || compactOtherHeadline) && !topicHit;
    }

    private static String cleanRenderedArticleText(String raw, String requestedTitle) {
        String text = raw == null ? "" : raw.replace('\u00A0', ' ').replace("\r", "\n");
        StringBuilder out = new StringBuilder();
        Set<String> seen = new java.util.LinkedHashSet<>();
        Set<String> titleTokens = articleTitleTokens(requestedTitle);
        int bodyLines = 0;
        for (String line : text.split("\\n+")) {
            String x = line.replaceAll("\\s+", " ").trim();
            if (x.isEmpty()) continue;
            String lo = x.toLowerCase(Locale.ROOT);
            boolean hardTail = lo.contains("관련기사") || lo.contains("추천기사") || lo.contains("많이 본 뉴스") ||
                    lo.contains("실시간 인기") || lo.contains("기사제보") || lo.contains("제보를 기다") ||
                    lo.contains("제보는 24시간") || lo.contains("다시보기") || lo.contains("자세히 보기") ||
                    lo.contains("오늘의 주요뉴스") || lo.contains("이 시각 뉴스") || lo.contains("헤드라인") ||
                    lo.contains("댓글") || lo.contains("공유하기") || lo.contains("태그") || lo.contains("/bbs/") ||
                    lo.contains("flipboard") || lo.contains("pocket") || lo.contains("custom_chain") ||
                    lo.contains("webstory") || lo.contains("korean_weather") || lo.contains("videoplay") ||
                    lo.matches(".*(?:^|\\s)ad(?:\\s|$|[%_]).*") ||
                    lo.contains("[영상]") || lo.contains("[숏폼]") || lo.contains("[포토]") || lo.contains("[사진]");
            if (hardTail && out.length() >= 180) continue;
            if (lo.contains("cookie") || lo.contains("로그인") || lo.contains("구독") ||
                    lo.contains("무단 전재") || lo.contains("저작권") || lo.contains("개인정보") ||
                    lo.contains("이용약관") || lo.equals("광고") || hardTail) continue;
            if (x.matches("(?i).*(?:입력|수정|등록|기사입력)\\s*20\\d{2}[-./].*")) continue;
            if (x.matches("^[가-힣]{2,4}\\s*(?:기자|특파원)(?:\\s*=.*)?$")) continue;
            if (x.matches("(?i)^\\d{1,2}:\\d{2}\\s+.{8,120}$") && out.length() >= 260) break;
            if (x.length() < 18) continue;
            if (articleTailHeadlineLike(x, titleTokens, out.length(), bodyLines)) continue;
            if (!seen.add(x)) continue;
            if (out.length() > 0) out.append('\n');
            out.append(x);
            bodyLines++;
            if (out.length() >= 30000) break;
        }
        return out.length() > 30000 ? out.substring(0, 30000) : out.toString().trim();
    }

    private void finishArticleWebView(WebView reader, String callbackId, boolean[] done, JSONObject out) {
        if (done[0]) return;
        done[0] = true;
        try { reader.stopLoading(); } catch (Exception ignored) { }
        try {
            if (reader.getParent() instanceof ViewGroup) ((ViewGroup) reader.getParent()).removeView(reader);
        } catch (Exception ignored) { }
        try { reader.destroy(); } catch (Exception ignored) { }
        deliverExternalInfo(callbackId, out);
    }

    private void extractArticleFromWebView(WebView reader, String title, String callbackId, boolean[] done, boolean finalAttempt) {
        if (done[0] || reader == null) return;
        String wanted = title == null ? "" : title.replaceAll("\\s+-\\s+[^-]{2,40}$", "").trim();
        String qTitle = JSONObject.quote(wanted);
        String js = "(function(){try{" +
                "var wanted=" + qTitle + ";" +
                "function txt(n){return String(n&&((n.innerText||n.textContent))||'').replace(/\\s+/g,' ').trim();}" +
                "function norm(v){return String(v||'').toLowerCase().replace(/[^0-9a-z가-힣]/g,'');}" +
                "function score(a,b){a=norm(a);b=norm(b);if(!a||!b)return 0;if(a===b)return 1;if(a.indexOf(b)>=0||b.indexOf(a)>=0)return Math.min(a.length,b.length)/Math.max(a.length,b.length)+0.30;var aa=String(a),bb=String(b),n=0,step=Math.max(2,Math.floor(bb.length/9));for(var i=0;i<=bb.length-step;i+=step){if(aa.indexOf(bb.slice(i,i+step))>=0)n++;}return n/Math.max(1,Math.ceil((bb.length-step+1)/step));}" +
                "function noise(t){t=String(t||'');return /(관련기사|추천기사|많이\\s*본\\s*뉴스|실시간\\s*인기|기사제보|제보는\\s*24시간|다시보기|자세히\\s*보기|오늘의\\s*주요뉴스|이\\s*시각\\s*뉴스|헤드라인|댓글|공유하기|태그|Flipboard|Pocket|custom_chain|webstory|korean_weather|VIDEOplay|(?:^|\\s)AD(?:\\s|$|[%_])|\\[영상\\]|\\[숏폼\\]|\\[포토\\]|\\[사진\\])/i.test(t);}" +
                "function meta(t){return /(?:입력|수정|등록|기사입력)\\s*20\\d{2}[-./]/i.test(t)||/^[가-힣]{2,4}\\s*(?:기자|특파원)(?:\\s*=.*)?$/.test(t);}" +
                "function badNode(n){if(!n||!n.getAttribute)return false;var z=((n.id||'')+' '+(n.className||'')+' '+(n.getAttribute('role')||'')+' '+(n.getAttribute('data-type')||'')+' '+(n.getAttribute('data-component')||'')).toLowerCase();return /(related|recommend|popular|ranking|comment|reply|advert|\\bad\\b|banner|promotion|footer|sidebar|share|social|sns|outbrain|taboola|more-news|other-news|next-article|cluster|chain|webstory|weather|video-list|photo-list)/.test(z);}" +
                "function linkRatio(n){if(!n)return 0;var all=txt(n),ln='';Array.from(n.querySelectorAll?n.querySelectorAll('a'):[]).forEach(function(a){ln+=' '+txt(a);});return all.length?ln.trim().length/all.length:0;}" +
                "function authorName(){var picks=[];function add(v){if(!v)return;v=String(v).replace(/\\s+/g,' ').trim();if(v&&picks.indexOf(v)<0)picks.push(v);}document.querySelectorAll('meta[name=author],meta[property=\"article:author\"],meta[name=\"parsely-author\"],meta[name=\"citation_author\"],[itemprop=author],[class*=byline],[class*=author-name],[data-testid*=byline]').forEach(function(n){var v=n.getAttribute('content')||n.getAttribute('name')||n.innerText||n.textContent; if(v&&String(v).length<230)add(v);});Array.from(document.querySelectorAll('script[type=\"application/ld+json\"]')).forEach(function(n){try{var v=JSON.parse(n.textContent||'');function walk(x){if(!x)return;if(Array.isArray(x)){x.forEach(walk);return;}if(typeof x!=='object')return;if(x.author){var list=Array.isArray(x.author)?x.author:[x.author];list.forEach(function(a){if(typeof a==='string')add(a);else if(a&&a.name)add(a.name);});}if(x['@graph'])walk(x['@graph']);}walk(v);}catch(e){}});return picks.join(' | ').slice(0,360);}" +
                "function jsonLdBody(){var best='';Array.from(document.querySelectorAll('script[type=\\\"application/ld+json\\\"]')).forEach(function(sc){try{var j=JSON.parse(sc.textContent||'');function walk(v){if(!v)return;if(Array.isArray(v)){v.forEach(walk);return;}if(typeof v!=='object')return;var b=v.articleBody;if(typeof b==='string'&&b.replace(/\\s+/g,' ').trim().length>best.length)best=b;Object.keys(v).forEach(function(k){if(k!=='articleBody'&&typeof v[k]==='object')walk(v[k]);});}walk(j);}catch(e){}});return best.replace(/\\r/g,'\\n').replace(/\\n{3,}/g,'\\n\\n').trim();}" +
                "function collect(root,headline){if(!root)return '';var c=root.cloneNode(true);c.querySelectorAll('script,style,nav,aside,footer,form,noscript,button,iframe,figure,figcaption,[aria-label*=\"광고\"],[data-ad],[class*=related],[class*=recommend],[class*=popular],[class*=ranking],[class*=comment],[class*=reply],[class*=advert],[class*=banner],[class*=promotion],[class*=footer],[class*=sidebar],[class*=share],[class*=social],[class*=sns],[class*=outbrain],[class*=taboola],[class*=cluster],[class*=chain],[class*=webstory],[class*=more-news],[class*=other-news],[class*=next-article],[id*=related],[id*=recommend],[id*=popular],[id*=ranking],[id*=comment],[id*=advert],[id*=share],[id*=cluster],[id*=chain]').forEach(function(n){n.remove();});var rows=[],started=false,stop=false,total=0;function boundary(n){if(!n||!n.getAttribute)return false;var tag=String(n.tagName||'').toLowerCase(),z=((n.id||'')+' '+(n.className||'')+' '+(n.getAttribute('role')||'')+' '+(n.getAttribute('data-type')||'')+' '+(n.getAttribute('data-component')||'')).toLowerCase();if(/^(nav|aside|footer)$/.test(tag))return true;return /(related|recommend|popular|ranking|comment|reply|advert|\\bad\\b|banner|promotion|footer|sidebar|share|social|sns|outbrain|taboola|more-news|other-news|next-article|cluster|chain|webstory|weather|video-list|photo-list|breaking-list|headline-list)/.test(z);}function dense(n){if(!n||!n.querySelectorAll)return false;var ac=n.querySelectorAll('a').length;return ac>=3&&linkRatio(n)>.42;}function tailHeadline(t){if(total<180||rows.length<2||t.length<18||t.length>190)return false;if(headline&&score(t,headline)>.32)return false;var terminal=/[.!?。！？][\"'”’)]*$/.test(t)||/(?:했다|말했다|밝혔다|설명했다|강조했다|전했다|전망했다|예상했다|예정이다|것이다|된다|있다|없다)[\"'”’)]*$/.test(t);var burst=/…|\\.{3}|[‘’\"'][^‘’\"']{2,90}[‘’\"']|\\svs\\s|^\\[[^\\]]{1,18}\\]/i.test(t);return !terminal&&(burst||(rows.length>=3&&total>=350&&t.length<=150));}function addP(p){if(stop)return;var t=txt(p);if(!t||t.length<18)return;if(noise(t)){return;}if(meta(t))return;if(headline&&score(t,headline)>.84)return;var lr=linkRatio(p),pr=linkRatio(p.parentElement);if(started&&(lr>.30||pr>.64)&&t.length<280){stop=true;return;}if(lr>.72)return;if(/^\\d{1,2}:\\d{2}\\s+.{8,120}$/.test(t)&&started){stop=true;return;}if(started&&tailHeadline(t)){return;}if(rows.indexOf(t)<0){rows.push(t);started=true;total+=t.length+1;}if(total>30000)stop=true;}var hs=0,hnode=null;Array.from(c.querySelectorAll('h1,h2,h3,[itemprop=\"headline\"],[class*=\"headline\"],[class*=\"article-title\"],[class*=\"view-title\"],[class*=\"news-title\"]')).forEach(function(n){var sc=score(txt(n),headline);if(sc>hs){hs=sc;hnode=n;}});var passed=!hnode;function walk(n){if(stop||!n||n.nodeType!==1)return;if(n===hnode){passed=true;return;}if(!passed){Array.from(n.children||[]).forEach(walk);return;}if(n!==c&&boundary(n)){if(started&&total>180)stop=true;return;}if(started&&dense(n)&&txt(n).length<5000){stop=true;return;}var tag=String(n.tagName||'').toLowerCase();if(tag==='p'){addP(n);return;}if(started&&tag==='a'){return;}if(started&&(tag==='ul'||tag==='ol')&&n.querySelectorAll&&n.querySelectorAll('a').length>=2){stop=true;return;}Array.from(n.children||[]).forEach(walk);}walk(c);return rows.join('\\n').trim();}" +
                "var jd=jsonLdBody();if(jd.length>=220&&!noise(jd.slice(0,500))){return JSON.stringify({text:jd.slice(0,30000),anchor:true,score:1,trusted:true,kind:'jsonld',author:authorName()});}" +
                "var heads=Array.from(document.querySelectorAll('h1,h2,h3,[itemprop=\\\"headline\\\"],[class*=\\\"headline\\\"],[class*=\\\"article-title\\\"],[class*=\\\"view-title\\\"],[class*=\\\"news-title\\\"]')),best=null,bs=0;heads.forEach(function(n){var t=txt(n),sc=score(t,wanted);if(sc>bs){bs=sc;best=n;}});" +
                "var sels='[itemprop=\\\"articleBody\\\"],[data-article-body],#dic_area,#newsct_article,#articleBody,.article_body,.article-body,.articleBody,.news_view,.view_cont,.news_body,.article-content,.article_content,.article_view_content,.article_txt,.news-article,.news_article,.story-body,.story_body,.entry-content,.post-content';" +
                "var cand=[];function add(n,kind){if(!n||cand.some(function(x){return x.n===n;}))return;var t=txt(n),pc=n.querySelectorAll?n.querySelectorAll('p').length:0;if(t.length>=220&&t.length<=45000&&pc>=2)cand.push({n:n,kind:kind||'body'});}document.querySelectorAll(sels).forEach(function(n){add(n,'articleBody');});" +
                "if(best){var art=best.closest&&best.closest('article');if(art)add(art,'article');var p=best.parentElement;for(var d=0;d<5&&p;d++,p=p.parentElement){if(p.querySelectorAll&&p.querySelectorAll('p').length>=3&&txt(p).length>=260&&txt(p).length<=24000){add(p,'anchored');break;}}}" +
                "var root=null,kind='',rs=-1,top=best&&best.getBoundingClientRect?best.getBoundingClientRect().top:0;cand.forEach(function(o){var n=o.n,t=txt(n),r=n.getBoundingClientRect?n.getBoundingClientRect():{top:0},dist=best?Math.abs(r.top-top):0,sc=Math.min(7,t.length/1100)-(dist/1200);if(o.kind==='articleBody')sc+=7;if(best&&n.contains&&n.contains(best))sc+=3;if(linkRatio(n)>.45)sc-=4;if(sc>rs){rs=sc;root=n;kind=o.kind;}});" +
                "if(!root)return JSON.stringify({text:'',anchor:!!(best&&bs>=0.45),score:bs,trusted:false,kind:'none',author:authorName()});var h=best?txt(best):wanted,text=collect(root,h),trusted=(kind==='articleBody'||kind==='article'||(kind==='anchored'&&!!best&&bs>=0.45));if(text.length<180)trusted=false;return JSON.stringify({text:text.slice(0,18000),anchor:!!(best&&bs>=0.45),score:bs,trusted:trusted,kind:kind,author:authorName()});" +
                "}catch(e){return JSON.stringify({text:'',anchor:false,trusted:false,kind:'error',error:String(e),author:''});}})()";
        try {
            reader.evaluateJavascript(js, value -> {
                if (done[0]) return;
                String payload = "";
                try {
                    if (value != null && !"null".equals(value)) payload = new JSONArray("[" + value + "]").getString(0);
                } catch (Exception ignored) { }
                String text = ""; boolean anchorMatched = false; double anchorScore = 0; boolean trusted = false; String kind = ""; String reporterByline = "";
                try {
                    JSONObject parsed = new JSONObject(payload);
                    text = parsed.optString("text", "");
                    anchorMatched = parsed.optBoolean("anchor", false);
                    anchorScore = parsed.optDouble("score", 0);
                    trusted = parsed.optBoolean("trusted", false);
                    kind = parsed.optString("kind", "");
                    reporterByline = parsed.optString("author", "");
                } catch (Exception ignored) { text = payload; }
                text = cleanRenderedArticleText(text, title);
                if (trusted && text.length() >= 180) {
                    JSONObject out = new JSONObject();
                    try {
                        out.put("status", text.length() >= 1200 ? "full" : "partial"); // length only; completeness is not guaranteed
                        out.put("articleText", text);
                        out.put("chars", text.length());
                        out.put("finalUrl", reader.getUrl() == null ? "" : reader.getUrl());
                        out.put("source", "동일 URL WebView · V190 연속 본문 구조 전용 추출");
                        out.put("anchorMatched", anchorMatched);
                        out.put("anchorScore", anchorScore);
                        out.put("extractorKind", kind);
                        out.put("author", reporterByline);
                        out.put("trustedBody", true);
                        out.put("fetchedAt", System.currentTimeMillis());
                    } catch (Exception ignored) { }
                    finishArticleWebView(reader, callbackId, done, out);
                } else if (finalAttempt) {
                    JSONObject out = new JSONObject();
                    try {
                        out.put("status", "unavailable");
                        out.put("error", trusted ? "TRUSTED_ARTICLE_TEXT_TOO_SHORT" : "NO_TRUSTED_ARTICLE_BODY");
                        out.put("finalUrl", reader.getUrl() == null ? "" : reader.getUrl());
                        out.put("anchorMatched", anchorMatched);
                        out.put("anchorScore", anchorScore);
                        out.put("extractorKind", kind);
                        out.put("author", reporterByline);
                    } catch (Exception ignored) { }
                    finishArticleWebView(reader, callbackId, done, out);
                }
            });
        } catch (Exception e) {
            if (finalAttempt) {
                JSONObject out = new JSONObject();
                try { out.put("status", "unavailable"); out.put("error", "WEBVIEW_EXTRACT_FAILED"); } catch (Exception ignored) { }
                finishArticleWebView(reader, callbackId, done, out);
            }
        }
    }

    private void fetchArticleViaWebView(String url, String title, String callbackId) {
        runOnUiThread(() -> {
            if (!activityActive || !isPublicHttpUrl(url)) {
                JSONObject out = new JSONObject();
                try { out.put("status", "unavailable"); out.put("error", "WEBVIEW_READER_UNAVAILABLE"); } catch (Exception ignored) { }
                deliverExternalInfo(callbackId, out);
                return;
            }
            final WebView reader = new WebView(MainActivity.this);
            final boolean[] done = new boolean[] { false };
            WebSettings rs = reader.getSettings();
            rs.setJavaScriptEnabled(true);
            rs.setDomStorageEnabled(true);
            rs.setDatabaseEnabled(true);
            rs.setLoadWithOverviewMode(false);
            rs.setUseWideViewPort(true);
            rs.setCacheMode(WebSettings.LOAD_DEFAULT);
            // Use the same browser identity as the visible app WebView instead of inventing a second client.
            if (webView != null && webView.getSettings().getUserAgentString() != null) {
                rs.setUserAgentString(webView.getSettings().getUserAgentString());
            }
            reader.setAlpha(0.01f);
            reader.setTranslationX(-10000f);
            reader.setTranslationY(-10000f);
            // Google News RSS stores an intermediate article URL, not the publisher's URL.
            // Try ONE visible, corroborated source link before article extraction.
            // Never invent a URL or send the article to a third-party search service.
            final boolean[] googleSourceTried = new boolean[] { false };
            reader.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String finishedUrl) {
                    super.onPageFinished(view, finishedUrl);
                    boolean intermediate = false;
                    try { intermediate = new URL(finishedUrl).getHost().equalsIgnoreCase("news.google.com"); }
                    catch (Exception ignored) { }
                    if (intermediate && !googleSourceTried[0]) {
                        googleSourceTried[0] = true;
                        String targetTitle = title == null ? "" : title.replaceAll("\\s+-\\s+[^-]{2,40}$", "").trim();
                        String lookupJs = "(function(){try{" +
                            "var wanted=" + JSONObject.quote(targetTitle) + ";" +
                            "function norm(x){return String(x||'').toLowerCase().replace(/[^0-9a-z가-힣]/g,'');}" +
                            "var w=norm(wanted);var best='',bestScore=0,candidates=[];" +
                            "var tags=document.querySelectorAll('a[href^=\"http\"],link[rel=\"canonical\"],meta[property=\"og:url\"]');" +
                            "Array.from(tags).forEach(function(a){try{var url=a.href||a.content||'';var u=new URL(url,location.href);" +
                            "if(u.protocol!=='https:'||/(^|\\.)google\\.com$/.test(u.hostname)||/youtube|facebook|instagram|twitter|x\\.com|tiktok|linkedin/i.test(u.hostname))return;" +
                            "var t=norm((a.innerText||'')+' '+(a.getAttribute('aria-label')||''));if(!t)return;candidates.push(url);" +
                            "var hits=0,terms=String(wanted).toLowerCase().split(/[^0-9a-z가-힣]+/).filter(function(x){return x.length>=2;});" +
                            "terms.forEach(function(x){if(t.indexOf(norm(x))>=0)hits++;});var sc=hits/Math.max(1,terms.length);" +
                            "if(t===w||t.indexOf(w)>=0||w.indexOf(t)>=0&&t.length>15)sc=Math.max(sc,.9);" +
                            "if(sc>bestScore){bestScore=sc;best=url;}" +
                            "}catch(e){}});" +
                            "if(bestScore>=.45)return best;" +
                            "return '';" +
                            "}catch(e){return '';}})()";
                        final int[] attempts = new int[] { 0 };
                        final Runnable[] resolver = new Runnable[1];
                        resolver[0] = () -> {
                            if (done[0] || reader.getUrl() == null) return;
                            try { if (!new URL(reader.getUrl()).getHost().equalsIgnoreCase("news.google.com")) return; }
                            catch (Exception ignored) { return; }
                            attempts[0]++;
                            view.evaluateJavascript(lookupJs, value -> {
                                if (done[0]) return;
                                String candidate = "";
                                try { if (value != null && !"null".equals(value)) candidate = new JSONArray("[" + value + "]").getString(0); }
                                catch (Exception ignored) { }
                                boolean valid = isPublicHttpUrl(candidate);
                                try { valid = valid && !new URL(candidate).getHost().equalsIgnoreCase("news.google.com"); }
                                catch (Exception ignored) { valid = false; }
                                if (valid) view.loadUrl(candidate);
                                else if (attempts[0] < 3) view.postDelayed(resolver[0], attempts[0] == 1 ? 550 : 900);
                                else extractArticleFromWebView(view, title, callbackId, done, false);
                            });
                        };
                        view.postDelayed(resolver[0], 170);
                    } else view.postDelayed(() -> extractArticleFromWebView(view, title, callbackId, done, false), 550);
                }
            });
            try {
                ViewGroup root = findViewById(android.R.id.content);
                // Give the page a normal viewport so responsive/lazy article bodies render, then keep it off-screen.
                root.addView(reader, new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                reader.loadUrl(url);
                reader.postDelayed(() -> extractArticleFromWebView(reader, title, callbackId, done, true), 12500);
            } catch (Exception e) {
                JSONObject out = new JSONObject();
                try { out.put("status", "unavailable"); out.put("error", "WEBVIEW_LOAD_FAILED"); } catch (Exception ignored) { }
                finishArticleWebView(reader, callbackId, done, out);
            }
        });
    }

    private List<String> ttsChunks(String raw) {
        ArrayList<String> out = new ArrayList<>();
        String text = semanticTtsText(raw);
        if (text.isEmpty()) return out;

        // V159 soft-low cadence: long UI passages spoken as one huge utterance sound hard and
        // sharp on Samsung TTS. Prefer complete sentences and only split inside a sentence when it
        // becomes long. This keeps the uploaded reference voice's continuous flow without rushing
        // paragraph endings.
        int engineMax = Math.min(2800, TextToSpeech.getMaxSpeechInputLength() - 100);
        int softMax = Math.min(effectiveVoiceChunkMax(), engineMax);
        Matcher sentence = Pattern.compile(".+?(?:[.!?。]+(?:\\s+|$)|$)").matcher(text);
        while (sentence.find()) {
            String part = sentence.group().trim();
            if (part.isEmpty()) continue;
            while (part.length() > softMax) {
                int cut = -1;
                int from = Math.max(80, softMax - 90);
                for (int i = softMax; i >= from; i--) {
                    char c = part.charAt(i - 1);
                    if (c == ',' || c == '，' || c == ';' || c == ':' || c == '·' || c == ' ') { cut = i; break; }
                }
                if (cut < 1) cut = softMax;
                String head = part.substring(0, cut).trim();
                if (!head.isEmpty()) out.add(head);
                part = part.substring(cut).trim();
            }
            if (!part.isEmpty()) out.add(part);
        }
        if (out.isEmpty()) out.add(text);
        return out;
    }

    private void stopChatAudioOnUi() {
        chatAudioGeneration++;
        try { if (chatAudioPlayer != null) { chatAudioPlayer.reset(); chatAudioPlayer.release(); } } catch (Exception ignored) { }
        chatAudioPlayer = null;
        try { if (chatAudioFile != null) chatAudioFile.delete(); } catch (Exception ignored) { }
        chatAudioFile = null;
    }
    private void notifyChatAudioError(String callbackId) {
        if (webView == null) return;
        webView.post(() -> webView.evaluateJavascript("window.SNOWBALL_NATURAL_CHAT&&window.SNOWBALL_NATURAL_CHAT.onVoiceAudioError(" + JSONObject.quote(callbackId) + ");", null));
    }
    private void notifyChatAudioDone(String callbackId) {
        if (webView == null) return;
        webView.post(() -> webView.evaluateJavascript("window.SNOWBALL_NATURAL_CHAT&&window.SNOWBALL_NATURAL_CHAT.onVoiceAudioDone(" + JSONObject.quote(callbackId) + ");", null));
    }
    private void startAiSpeechAudio(File file, String callbackId, long requestGen) {
        runOnUiThread(() -> {
            if (!activityActive || chatVoiceRequestGen != requestGen) { file.delete(); return; }
            stopChatAudioOnUi();
            chatAudioFile = file;
            try {
                if (textToSpeech != null) textToSpeech.stop();
                if (voiceRecognizerActive && speechRecognizer != null) {
                    voiceIgnoreErrorsUntilMs = System.currentTimeMillis() + 650L;
                    speechRecognizer.cancel();
                    voiceRecognizerActive = false;
                }
                final long gen = chatAudioGeneration;
                final MediaPlayer player = new MediaPlayer();
                chatAudioPlayer = player;
                player.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
                player.setDataSource(file.getAbsolutePath());
                player.setOnPreparedListener(mp -> {
                    if (chatAudioGeneration != gen) return;
                    try { mp.start(); notifyVoiceState("speaking", "AI 음성으로 답하는 중", "native-ai-audio"); }
                    catch (Exception ex) { stopChatAudioOnUi(); notifyVoiceState("idle", "", "audio-error"); notifyChatAudioError(callbackId); }
                });
                player.setOnCompletionListener(mp -> {
                    if (chatAudioGeneration != gen) return;
                    stopChatAudioOnUi(); notifyVoiceState("idle", "", "native-ai-audio-done"); notifyChatAudioDone(callbackId);
                });
                player.setOnErrorListener((mp, what, extra) -> {
                    if (chatAudioGeneration == gen) {
                        stopChatAudioOnUi(); notifyVoiceState("idle", "", "native-ai-audio-error"); notifyChatAudioError(callbackId);
                    }
                    return true;
                });
                player.prepareAsync();
            } catch (Exception ex) {
                stopChatAudioOnUi();
                notifyVoiceState("idle", "", "audio-setup-error");
                notifyChatAudioError(callbackId);
            }
        });
    }

    private void speakNative(String text) {
        runOnUiThread(() -> {
            stopChatAudioOnUi();
            if (!textToSpeechReady || textToSpeech == null) {
                Toast.makeText(MainActivity.this, "음성 엔진을 준비 중입니다. 잠시 후 다시 눌러 주세요.", Toast.LENGTH_SHORT).show();
                return;
            }
            List<String> chunks = ttsChunks(text);
            if (chunks.isEmpty()) return;
            if (voiceRecognizerActive && speechRecognizer != null) {
                voiceIgnoreErrorsUntilMs = System.currentTimeMillis() + 650L;
                try { speechRecognizer.cancel(); } catch (Exception ignored) { }
                voiceRecognizerActive = false;
            }
            textToSpeech.stop();
            final long stamp = System.currentTimeMillis();
            for (int i = 0; i < chunks.size(); i++) {
                String utteranceId = (i == chunks.size() - 1 ? "snowball-tts-final-" : "snowball-tts-") + i + "-" + stamp;
                Bundle params = new Bundle();
                // V160: user softness control trims utterance drive without changing system media volume.
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, effectiveVoiceVolume());
                textToSpeech.speak(chunks.get(i), i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, params, utteranceId);
                if (i < chunks.size() - 1) {
                    // V160: softness also owns the short breath between phrases.
                    textToSpeech.playSilentUtterance(effectiveVoiceGapMs(), TextToSpeech.QUEUE_ADD, "snowball-tts-gap-" + i + "-" + stamp);
                }
            }
            notifyVoiceState("speaking", "음성으로 읽고 있습니다", "snowball-tts-final-" + (chunks.size() - 1) + "-" + stamp);
        });
    }

    private void stopVoiceNative() {
        chatVoiceRequestGen++;
        runOnUiThread(() -> {
            stopChatAudioOnUi();
            try { if (textToSpeech != null) textToSpeech.stop(); } catch (Exception ignored) { }
            voiceIgnoreErrorsUntilMs = System.currentTimeMillis() + 650L;
            try { if (speechRecognizer != null && voiceRecognizerActive) speechRecognizer.cancel(); } catch (Exception ignored) { }
            voiceRecognizerActive = false;
            notifyVoiceState("idle", "", "stopped");
        });
    }

    private void startVoiceListen() {
        runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                pendingVoiceListen = true;
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_VOICE_MIC);
                return;
            }
            if (speechRecognizer == null) {
                notifyVoiceError("이 기기에서 음성 인식을 사용할 수 없습니다.");
                return;
            }
            // V117: never cancel and immediately restart an active recognizer. That race was a likely
            // source of repeated/stale results on Samsung devices during continuous conversation.
            if (voiceRecognizerActive) {
                notifyVoiceState("listening", "듣고 있습니다");
                return;
            }
            try {
                if (textToSpeech != null) textToSpeech.stop();
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ko-KR");
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                // V120: allow a natural short pause without cutting off the beginning of a command.
                i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1450L);
                i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L);
                i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1100L);
                i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false);
                voiceListenSerial++;
                clearVoicePartialHistory();
                voicePartialSessionSerial = voiceListenSerial;
                voiceRecognizerActive = true;
                speechRecognizer.startListening(i);
            } catch (Exception e) {
                voiceRecognizerActive = false;
                notifyVoiceError("음성 인식을 시작하지 못했습니다.");
            }
        });
    }

    private void clearVoicePartialHistory() {
        voicePartialHistory.clear();
        voicePartialSessionSerial = voiceListenSerial;
    }

    private void rememberVoicePartialCandidates(long sessionId, ArrayList<String> candidates) {
        if (candidates == null || candidates.isEmpty()) return;
        if (voicePartialSessionSerial != sessionId) {
            voicePartialHistory.clear();
            voicePartialSessionSerial = sessionId;
        }
        int limit = Math.min(candidates.size(), 5);
        for (int i = 0; i < limit; i++) {
            String v = candidates.get(i);
            if (v == null) continue;
            v = v.trim();
            if (v.isEmpty()) continue;
            boolean exists = false;
            for (String old : voicePartialHistory) {
                if (old.equals(v)) { exists = true; break; }
            }
            if (!exists) voicePartialHistory.add(v);
        }
        while (voicePartialHistory.size() > 24) voicePartialHistory.remove(0);
    }

    private ArrayList<String> mergeVoiceTurnCandidates(long sessionId, ArrayList<String> finals) {
        ArrayList<String> out = new ArrayList<>();
        if (finals != null) {
            int limit = Math.min(finals.size(), 5);
            for (int i = 0; i < limit; i++) {
                String v = finals.get(i);
                if (v != null && !v.trim().isEmpty() && !out.contains(v.trim())) out.add(v.trim());
            }
        }
        if (voicePartialSessionSerial == sessionId) {
            // Longest partials tend to preserve the full phrase best, so add them first.
            ArrayList<String> partials = new ArrayList<>(voicePartialHistory);
            partials.sort((a,b) -> Integer.compare(b.length(), a.length()));
            for (String v : partials) if (!out.contains(v)) out.add(v);
        }
        return out;
    }

    private static boolean finalTurnIsAiQuestionWithoutNavVerb(ArrayList<String> finals) {
        if (finals == null) return false;
        int limit = Math.min(finals.size(), 5);
        for (int i = 0; i < limit; i++) {
            String x = normalizeNativeNav(finals.get(i));
            if (!x.isEmpty() && looksLikeAiQuestion(x) && !hasNativeNavVerb(x)) return true;
        }
        return false;
    }

    private static class NativeNavMatch {
        final String routeId;
        final String label;
        final String heard;
        final int score;
        final boolean unknownNavigation;
        NativeNavMatch(String routeId, String label, String heard, int score, boolean unknownNavigation) {
            this.routeId = routeId; this.label = label; this.heard = heard; this.score = score; this.unknownNavigation = unknownNavigation;
        }
    }

    private static String normalizeNativeNav(String raw) {
        String s = raw == null ? "" : raw.toLowerCase(Locale.KOREA).trim();
        s = s.replace("에이 아이", "ai").replace("에이아이", "ai");
        s = s.replaceAll("[\\s\\p{Punct}·ㆍ…]+", "");
        return s;
    }

    private static boolean hasNativeNavVerb(String normalized) {
        if (normalized == null) return false;
        return normalized.contains("보여줘") || normalized.contains("보여") || normalized.contains("열어줘") ||
                normalized.contains("열어") || normalized.contains("띄워") || normalized.contains("이동") ||
                normalized.contains("가자") || normalized.contains("가줘") || normalized.contains("들어가") ||
                normalized.contains("실행") || normalized.contains("켜줘") || normalized.contains("선택") ||
                normalized.contains("눌러") || normalized.contains("화면") || normalized.contains("메뉴") ||
                normalized.contains("페이지") || normalized.contains("탭");
    }

    private static boolean looksLikeAiQuestion(String normalized) {
        if (normalized == null) return false;
        return normalized.contains("왜") || normalized.contains("어떻게") || normalized.contains("어때") ||
                normalized.contains("뭐") || normalized.contains("무엇") || normalized.contains("설명") ||
                normalized.contains("분석") || normalized.contains("전망") || normalized.contains("위험") ||
                normalized.contains("살까") || normalized.contains("팔까") || normalized.contains("대응") ||
                normalized.contains("중요") || normalized.contains("의미");
    }

    private static boolean equalsAny(String x, String... xs) {
        for (String v : xs) if (x.equals(v)) return true;
        return false;
    }

    private static NativeNavMatch routeFromNativeUtterance(String raw, boolean pending) {
        String x = normalizeNativeNav(raw);
        if (x.isEmpty()) return null;
        boolean verb = hasNativeNavVerb(x);
        boolean question = looksLikeAiQuestion(x);

        String rid = null, label = null;
        int routeStrength = 0;
        if (x.contains("단기투자") || x.contains("단기화면") || x.contains("단기차트") ||
                x.contains("단계투자") || x.contains("단계화면") || x.contains("단계차트") ||
                x.contains("단게투자") || x.contains("단게화면") || x.contains("당기투자")) {
            rid = "rShort"; label = "단기투자"; routeStrength = 120;
        } else if (x.contains("장기투자") || x.contains("장기화면") || x.contains("장기차트")) {
            rid = "rLong"; label = "장기투자"; routeStrength = 115;
        } else if (x.contains("시장환경") || x.contains("시장화면") || x.contains("시장메뉴")) {
            rid = "rMarket"; label = "시장환경"; routeStrength = 112;
        } else if (x.contains("액션벨") || x.contains("액션뱅") || x.contains("액션뻴")) {
            rid = "rBell"; label = "액션벨"; routeStrength = 110;
        } else if (x.contains("불주댕") || x.contains("불주뎅") || x.contains("불주댕이") || x.contains("불주뎅이")) {
            rid = "FIRE"; label = "불주댕이"; routeStrength = 110;
        } else if (x.contains("밑밥") || x.contains("레이더")) {
            rid = "rRadar"; label = "밑밥"; routeStrength = 105;
        } else if (x.contains("리포트") || x.contains("보고서")) {
            rid = "rReport"; label = "리포트"; routeStrength = 100;
        } else if (x.contains("홈화면") || x.contains("메인화면") || x.equals("홈") || x.equals("메인")) {
            rid = "rHome"; label = "홈"; routeStrength = 100;
        } else if (x.contains("ai화면") || x.contains("ai메뉴")) {
            rid = "rAI"; label = "AI"; routeStrength = 95;
        }

        // Bare menu-name replies are accepted only when the utterance itself is just that menu,
        // or while native navigation is waiting for a screen name.
        if (rid == null) {
            if (equalsAny(x,"단기투자","단기","단계투자","단계","단게","당기")) { rid="rShort"; label="단기투자"; routeStrength=130; }
            else if (equalsAny(x,"장기투자","장기")) { rid="rLong"; label="장기투자"; routeStrength=125; }
            else if (equalsAny(x,"시장환경","시장")) { rid="rMarket"; label="시장환경"; routeStrength=122; }
            else if (equalsAny(x,"액션벨","액션뱅","벨")) { rid="rBell"; label="액션벨"; routeStrength=118; }
            else if (equalsAny(x,"불주댕이","불주뎅이","불주")) { rid="FIRE"; label="불주댕이"; routeStrength=118; }
            else if (equalsAny(x,"밑밥","레이더")) { rid="rRadar"; label="밑밥"; routeStrength=115; }
            else if (equalsAny(x,"리포트","보고서")) { rid="rReport"; label="리포트"; routeStrength=112; }
            else if (equalsAny(x,"홈","메인")) { rid="rHome"; label="홈"; routeStrength=112; }
            else if (equalsAny(x,"ai")) { rid="rAI"; label="AI"; routeStrength=108; }
        }

        if (rid != null) {
            boolean bare = !verb && !question && x.length() <= 10;
            if (verb || pending || bare) {
                if (question && !verb && !pending) return null;
                int score = routeStrength + (verb ? 40 : 0) + (pending ? 25 : 0);
                return new NativeNavMatch(rid, label, raw, score, false);
            }
        }

        // A clear navigation request with no resolvable screen is consumed here instead of
        // falling through to AI. Never enumerate menu names; ask only the short clarification.
        // V121: generic words like "보여줘" are not enough to claim navigation.
        // A stock command such as "한온시스템 보여줄래" must reach the JS stock selector.
        // Only explicit generic screen/menu nouns are consumed as unresolved navigation.
        if (verb && (x.contains("화면") || x.contains("메뉴") || x.contains("페이지") || x.contains("탭") || x.contains("창"))) {
            return new NativeNavMatch("", "", raw, 40, true);
        }
        return null;
    }

    private boolean handleNativeNavigationCandidates(ArrayList<String> candidates) {
        if (candidates == null || candidates.isEmpty()) return false;
        long now = System.currentTimeMillis();
        boolean pending = now < nativeNavPendingUntilMs;
        NativeNavMatch best = null;
        int limit = Math.min(candidates.size(), 5);
        for (int i = 0; i < limit; i++) {
            String raw = candidates.get(i);
            if (raw == null || raw.trim().isEmpty()) continue;
            NativeNavMatch m = routeFromNativeUtterance(raw.trim(), pending);
            if (m != null && (best == null || m.score > best.score)) best = m;
        }
        if (best == null) {
            if (pending) {
                // While waiting for a screen name, do not let unrelated leftovers trigger the old JS menu loop.
                nativeNavPendingUntilMs = 0L;
                nativeNavPendingPrompt = "";
            }
            return false;
        }

        String dedupeKey = normalizeNativeNav(best.heard) + "|" + best.routeId + "|" + best.unknownNavigation;
        if (dedupeKey.equals(lastNativeNavCommand) && now - lastNativeNavCommandAtMs < 4500L) return true;
        lastNativeNavCommand = dedupeKey;
        lastNativeNavCommandAtMs = now;

        if (best.unknownNavigation) {
            nativeNavPendingUntilMs = now + 18000L;
            nativeNavPendingPrompt = best.heard;
            // V120: do not interrupt the user with an immediate re-question. Keep listening and
            // wait for the screen name; this prevents the assistant from talking over the user's
            // still-continuing command.
            notifyNativeNavDiagnostic(best.heard, "화면명 다시 듣는 중", "대기");
            notifyVoiceState("idle", "화면명을 다시 듣고 있습니다");
            return true;
        }

        nativeNavPendingUntilMs = 0L;
        nativeNavPendingPrompt = "";
        executeNativeNavigation(best.routeId, best.label, best.heard);
        return true;
    }

    private void notifyNativeNavDiagnostic(String heard, String intent, String result) {
        if (webView == null) return;
        String js = "window.NOONTANGI_NATIVE_NAV_V121&&window.NOONTANGI_NATIVE_NAV_V121.diag(" +
                JSONObject.quote(heard == null ? "" : heard) + "," + JSONObject.quote(intent) + "," + JSONObject.quote(result) + ");";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void executeNativeNavigation(String routeId, String label, String heard) {
        if (webView == null) return;
        final String rid = routeId == null ? "" : routeId;
        final String lab = label == null ? "화면" : label;
        notifyNativeNavDiagnostic(heard, lab, "실행 요청");
        String js = "window.NOONTANGI_NATIVE_NAV_V121&&window.NOONTANGI_NATIVE_NAV_V121.open(" +
                JSONObject.quote(rid) + "," + JSONObject.quote(lab) + "," + JSONObject.quote(heard == null ? "" : heard) + ");";
        webView.post(() -> {
            webView.evaluateJavascript(js, null);
            webView.postDelayed(() -> {
                if (webView == null) return;
                String verify = "window.NOONTANGI_NATIVE_NAV_V121?window.NOONTANGI_NATIVE_NAV_V121.verify(" + JSONObject.quote(rid) + "):false";
                webView.evaluateJavascript(verify, value -> {
                    boolean ok = "true".equals(String.valueOf(value));
                    notifyNativeNavDiagnostic(heard, lab, ok ? "실행 성공" : "실행 실패");
                    speakNative(ok ? lab + " 화면입니다." : lab + " 화면을 열지 못했습니다.");
                });
            }, "FIRE".equals(rid) ? 520L : 260L);
        });
    }

    private void deliverVoiceResult(String text) {
        if (webView == null) return;
        String q = JSONObject.quote(text == null ? "" : text);
        webView.post(() -> webView.evaluateJavascript("window.NOONTANGI_VOICE_GLOBAL&&window.NOONTANGI_VOICE_GLOBAL.onVoiceResult(" + q + ");", null));
    }

    private void deliverVoiceCandidates(long sessionId, ArrayList<String> candidates) {
        if (webView == null) return;
        JSONArray arr = new JSONArray();
        if (candidates != null) {
            int limit = Math.min(candidates.size(), 5);
            for (int i = 0; i < limit; i++) {
                String v = candidates.get(i);
                if (v != null && !v.trim().isEmpty()) arr.put(v.trim());
            }
        }
        String payload = arr.toString();
        String js = "(function(){var v=window.NOONTANGI_VOICE_GLOBAL;if(!v)return;" +
                "if(typeof v.onVoiceTurn==='function')v.onVoiceTurn(" + sessionId + "," + payload + ");" +
                "else if(typeof v.onVoiceCandidates==='function')v.onVoiceCandidates(" + payload + ");})()";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void notifyVoiceState(String state, String message) {
        notifyVoiceState(state, message, "");
    }

    private void notifyVoiceState(String state, String message, String utteranceId) {
        if (webView == null) return;
        String a = JSONObject.quote(state == null ? "idle" : state), b = JSONObject.quote(message == null ? "" : message);
        String c = JSONObject.quote(utteranceId == null ? "" : utteranceId);
        webView.post(() -> webView.evaluateJavascript("window.NOONTANGI_VOICE_GLOBAL&&window.NOONTANGI_VOICE_GLOBAL.onNativeState(" + a + "," + b + "," + c + ");", null));
    }

    private void notifyVoiceCheckResult(String text, String error) {
        if (webView == null) return;
        String heard = JSONObject.quote(text == null ? "" : text);
        String detail = JSONObject.quote(error == null ? "" : error);
        webView.post(() -> webView.evaluateJavascript(
                "window.SNOWBALL_NATURAL_CHAT&&window.SNOWBALL_NATURAL_CHAT.onSpeechCheckResult(" +
                heard + "," + detail + ");", null));
    }

    private void notifyVoiceError(String message) {
        if (webView == null) return;
        String q = JSONObject.quote(message == null ? "음성 오류" : message);
        webView.post(() -> webView.evaluateJavascript("window.NOONTANGI_VOICE_GLOBAL&&window.NOONTANGI_VOICE_GLOBAL.onVoiceError(" + q + ");", null));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_VOICE_MIC) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (pendingVoiceListen && granted) { pendingVoiceListen = false; startVoiceListen(); }
        else {
            pendingVoiceListen = false;
            if (voiceCheckOnce) {
                voiceCheckOnce = false;
                notifyVoiceCheckResult("", "마이크 권한이 필요합니다. 휴대폰 설정에서 허용해 주세요.");
            } else notifyVoiceError("마이크 권한이 필요합니다. 설정에서 마이크 권한을 허용해 주세요.");
        }
    }


    private void deliverExternalInfo(String callbackId, JSONObject result) {
        if (webView == null || callbackId == null) return;
        String payload = result == null ? "{}" : result.toString();
        String js = "window.NOONTANGI_EXTERNAL_INFO&&window.NOONTANGI_EXTERNAL_INFO.resolve(" +
                JSONObject.quote(callbackId) + "," + JSONObject.quote(payload) + ");";
        webView.post(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    // V201 official economic calendar: a fixed-origin BLS ICS feed. Never infer release dates.
    private JSONObject loadOfficialBlsCalendar() {
        JSONObject result = new JSONObject();
        JSONArray events = new JSONArray();
        HttpURLConnection connection = null;
        try {
            String officialUrl = "https://www.bls.gov/schedule/news_release/bls.ics";
            connection = (HttpURLConnection) new URL(officialUrl).openConnection();
            connection.setConnectTimeout(4000);
            connection.setReadTimeout(7000);
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) SNOWBALL/1.0");
            connection.setRequestProperty("Accept", "text/calendar,text/plain,*/*");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("BLS_HTTP_" + code);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try (InputStream input = connection.getInputStream()) {
                byte[] buf = new byte[8192];
                int read;
                while ((read = input.read(buf)) != -1) {
                    if (buffer.size() + read > 1500000) throw new Exception("BLS_ICS_TOO_LARGE");
                    buffer.write(buf, 0, read);
                }
            }
            String text = buffer.toString("UTF-8").replaceAll("\\r?\\n[ \\t]", "");
            for (String item : text.split("BEGIN:VEVENT")) {
                if (!item.contains("END:VEVENT")) continue;
                Matcher titleMatcher = Pattern.compile("(?m)^SUMMARY(?:;[^:\\r\\n]*)?:(.*)$").matcher(item);
                Matcher dateMatcher = Pattern.compile("(?m)^DTSTART(?:;[^:\\r\\n]*)?:(\\d{8})(?:T(\\d{4})\\d{0,2}Z?)?").matcher(item);
                if (!titleMatcher.find() || !dateMatcher.find()) continue;
                String label = titleMatcher.group(1).trim().replace("\\,", ",").replace("\\n", " ");
                String lower = label.toLowerCase(Locale.US);
                String korean;
                if (lower.contains("consumer price index")) korean = "미국 소비자물가지수(CPI) 발표";
                else if (lower.contains("producer price index")) korean = "미국 생산자물가지수(PPI) 발표";
                else if (lower.contains("employment situation")) korean = "미국 고용보고서 발표";
                else if (lower.contains("employment cost index")) korean = "미국 고용비용지수(ECI) 발표";
                else if (lower.contains("job openings and labor turnover")) korean = "미국 구인·이직(JOLTS) 발표";
                else continue;
                String compact = dateMatcher.group(1);
                String date = compact.substring(0, 4) + "-" + compact.substring(4, 6) + "-" + compact.substring(6, 8);
                String hhmm = dateMatcher.group(2);
                boolean utc = dateMatcher.group(0).endsWith("Z");
                String time = hhmm != null && hhmm.length() == 4
                    ? hhmm.substring(0, 2) + ":" + hhmm.substring(2) + (utc ? " UTC (현지시간 변환 확인)" : " ET (미 동부)")
                    : "발표시간 공식 일정 확인";
                JSONObject out = new JSONObject();
                out.put("date", date);
                out.put("title", korean);
                out.put("source", "BLS");
                out.put("time", time);
                events.put(out);
                if (events.length() >= 100) break;
            }
            result.put("fetchedAt", System.currentTimeMillis());
            result.put("url", officialUrl);
            result.put("events", events);
        } catch (Exception e) {
            try { result.put("error", "BLS_CALENDAR_UNAVAILABLE"); result.put("events", events); } catch (Exception ignored) { }
        } finally { if (connection != null) connection.disconnect(); }
        return result;
    }

    // S1 STABILIZATION: read-only identity derived from the *installed* APK.
    // Computes hashes only when the user explicitly presses the guide diagnostic button.
    // Returns no account, trading, device identifier, or user data.
    private class DiagnosticBridge {
        private String sha256OfStream(InputStream stream) throws Exception {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[65536];
            int n;
            while ((n = stream.read(buffer)) != -1) digest.update(buffer, 0, n);
            byte[] hash = digest.digest();
            StringBuilder hex = new StringBuilder(hash.length * 2);
            for (byte b : hash) hex.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return hex.toString();
        }

        // Expose no query, article, URL, account, positions, or local storage.
        @JavascriptInterface
        public String status() {
            JSONObject o = new JSONObject();
            try {
                o.put("newsRequests", diagNewsRequests.get());
                o.put("newsSuccess", diagNewsSuccess.get());
                o.put("newsFailures", diagNewsFailures.get());
                o.put("lastNewsSuccessEpochMs", diagNewsLastSuccessMs);
                o.put("lastNewsError", diagNewsLastError);
            } catch (Exception ignored) { }
            return o.toString();
        }

        private String allow(String s, String[] values, String fallback) {
            if (s == null) return fallback;
            for (String v : values) if (v.equals(s)) return s;
            return fallback;
        }

        // Java sanitizes again: do not trust arbitrary JS payloads even on a local WebView.
        @JavascriptInterface
        public void share(String raw) {
            if (raw == null || raw.length() > 20000) return;
            try {
                JSONObject req = new JSONObject(raw);
                JSONObject doc = new JSONObject();
                doc.put("schema", "NTB_DIAGNOSTIC_REPORT_V1");
                doc.put("createdAtEpochMs", System.currentTimeMillis());
                doc.put("privacy", "No accounts, holdings, trades, URLs, raw exception messages or article text");
                JSONObject identity = new JSONObject(read());
                JSONObject safeIdentity = new JSONObject();
                for (String k : new String[]{"status", "packageName", "versionCode", "versionName", "sourceRevision", "integrity", "loadedAssetSha256", "installedApkSha256", "expectedAssetSha256"}) {
                    if (identity.has(k)) safeIdentity.put(k, identity.get(k));
                }
                doc.put("installedRuntime", safeIdentity);
                JSONObject status = new JSONObject(status());
                doc.put("newsTransport", status);
                doc.put("category", allow(req.optString("category"),
                        new String[]{"SCREEN", "JOURNAL", "CHART", "NEWS", "FIREMOUTH", "AI_RECOMMENDATION", "VOICE", "MARKET_DATA", "OTHER"}, "OTHER"));
                String screen = req.optString("screen", "unknown");
                if (!screen.matches("[A-Za-z][A-Za-z0-9_-]{0,45}")) screen = "unknown";
                doc.put("screen", screen);
                JSONObject flags = new JSONObject();
                JSONObject rawFlags = req.optJSONObject("featureFlags");
                if (rawFlags != null) for (String k : new String[]{"chartSettingsPresent", "guidePresent", "journalPresent", "newsStatusPresent", "firemouthStatusPresent", "aiProofPresent"})
                    flags.put(k, rawFlags.optBoolean(k, false));
                doc.put("featureFlags", flags);
                JSONObject feeds = new JSONObject();
                JSONObject rawFeeds = req.optJSONObject("feeds");
                if (rawFeeds != null) for (String kind : new String[]{"news", "fire"}) {
                    JSONObject x = rawFeeds.optJSONObject(kind);
                    if (x == null) continue;
                    JSONObject safeFeed = new JSONObject();
                    safeFeed.put("verifiedCount", Math.max(0, Math.min(100000, x.optInt("verifiedCount", 0))));
                    safeFeed.put("connected", x.optBoolean("connected", false));
                    safeFeed.put("ageHours", Math.max(-1, Math.min(99999, x.optInt("ageHours", -1))));
                    safeFeed.put("freshness", allow(x.optString("freshness"),
                        new String[]{"NO_BRIDGE", "FETCH_FAIL", "EMPTY", "STALE", "NEEDS_REFRESH", "RECENT"}, "UNKNOWN"));
                    feeds.put(kind, safeFeed);
                }
                doc.put("feeds", feeds);
                // V250: sanitized public-indicator connectivity only, never indicator numeric values or user records.
                JSONArray safeMarket = new JSONArray();
                JSONArray market = req.optJSONArray("marketIndicators");
                String[] marketIds = {"us10yOfficial","usCurveSpread","krRate","usRate","krCpi","usCpi","usCoreCpi","usBei","us02y","kr03y","ismPmi","oecdCli","krExports","twExports","semiconductorExports","semiconductorShipments","semiconductorPrice","semiconductorInventory","krImportPrice","krPpi","fearGreed","customerDeposits","creditBalance","creditRatio","vkospi","foreign20d","us10y20dma","wti60dma","krwVolatility","fxChangePeriod"};
                if (market != null) for (String id : marketIds) {
                    JSONObject match = null;
                    for (int i = 0; i < Math.min(100, market.length()); i++) {
                        JSONObject item = market.optJSONObject(i);
                        if (item != null && id.equals(item.optString("id"))) { match = item; break; }
                    }
                    JSONObject value = new JSONObject();
                    value.put("id", id);
                    value.put("state", match == null ? "UNKNOWN" : allow(match.optString("state"),
                            new String[]{"CONNECTED", "STALE", "MISSING"}, "UNKNOWN"));
                    String asOf = match == null ? "" : match.optString("asOf", "");
                    value.put("asOf", asOf.matches("20[0-9]{2}-[0-9]{2}-[0-9]{2}") ? asOf : "");
                    safeMarket.put(value);
                }
                doc.put("marketIndicators", safeMarket);
                JSONArray events = new JSONArray();
                JSONArray arr = req.optJSONArray("events");
                if (arr != null) for (int i = Math.max(0, arr.length() - 20); i < arr.length(); i++) {
                    JSONObject entry = arr.optJSONObject(i);
                    if (entry == null) continue;
                    JSONObject e = new JSONObject();
                    e.put("type", allow(entry.optString("type"),
                            new String[]{"JS_ERROR", "UNHANDLED_REJECTION", "WEBVIEW_ERROR", "WEBVIEW_CRASH"}, "JS_ERROR"));
                    e.put("occurredAtEpochMs", Math.max(0L, entry.optLong("occurredAtEpochMs", 0L)));
                    e.put("line", Math.max(0, Math.min(999999, entry.optInt("line", 0))));
                    events.put(e);
                }
                doc.put("events", events);
                java.io.File dir = new java.io.File(getCacheDir(), "ntb-diagnostic");
                if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("CACHE_DIR_UNAVAILABLE");
                java.io.File[] old = dir.listFiles();
                if (old != null) for (java.io.File f : old) if (f.isFile() && (System.currentTimeMillis()-f.lastModified()>86400000L)) f.delete();
                String filename = "diagnostic-" + java.util.UUID.randomUUID().toString().replace("-", "").substring(0,16) + ".json";
                java.io.File file = new java.io.File(dir, filename);
                try (java.io.FileOutputStream stream = new java.io.FileOutputStream(file)) {
                    stream.write(doc.toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                }
                Uri uri = new Uri.Builder().scheme("content").authority(getPackageName()+".diagnostics")
                        .appendPath(filename).build();
                runOnUiThread(() -> {
                    try {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("application/json");
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.setClipData(android.content.ClipData.newUri(getContentResolver(), "eyes diagnostics", uri));
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "오류 진단파일 공유"));
                    } catch (Exception error) {
                        Toast.makeText(MainActivity.this, "진단파일 공유창을 열지 못했습니다.", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception error) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "진단파일 작성 실패", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public String read() {
            JSONObject result = new JSONObject();
            try {
                android.content.pm.PackageInfo pkg = getPackageManager().getPackageInfo(getPackageName(), 0);
                long code = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                        ? pkg.getLongVersionCode() : pkg.versionCode;
                result.put("schema", "NTB_S1_IDENTITY_V1");
                result.put("status", "installed-runtime");
                result.put("packageName", getPackageName());
                result.put("versionCode", code);
                result.put("versionName", pkg.versionName == null ? "" : pkg.versionName);
                result.put("lastUpdateEpochMs", pkg.lastUpdateTime);
                String assetHash;
                try (InputStream input = getAssets().open("index.html")) {
                    assetHash = sha256OfStream(input);
                }
                result.put("loadedAssetSha256", assetHash);
                try (InputStream input = getAssets().open("s1_manifest.json")) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = input.read(buf)) != -1) out.write(buf, 0, n);
                    JSONObject manifest = new JSONObject(out.toString("UTF-8"));
                    result.put("sourceRevision", manifest.optString("sourceRevision", ""));
                    result.put("baselineZipSha256", manifest.optString("baselineZipSha256", ""));
                    result.put("expectedAssetSha256", manifest.optString("assetSha256", ""));
                    boolean versionMatches = code == manifest.optLong("versionCode", -1);
                    boolean htmlMatches = assetHash.equalsIgnoreCase(manifest.optString("assetSha256", ""));
                    result.put("versionMatchesManifest", versionMatches);
                    result.put("assetMatchesManifest", htmlMatches);
                    result.put("integrity", versionMatches && htmlMatches ? "MATCH" : "MISMATCH");
                } catch (Exception manifestError) {
                    result.put("integrity", "MANIFEST_ERROR");
                    result.put("manifestError", manifestError.getClass().getSimpleName());
                }
                // APK hash distinguishes the installed binary from a locally built candidate.
                // This is the base APK SHA-256, not a claim that this binary was tested.
                try (InputStream input = new java.io.FileInputStream(getPackageCodePath())) {
                    result.put("installedApkSha256", sha256OfStream(input));
                } catch (Exception apkError) {
                    result.put("installedApkSha256", "unavailable");
                    result.put("apkHashError", apkError.getClass().getSimpleName());
                }
            } catch (Exception error) {
                try {
                    result.put("status", "error");
                    result.put("errorType", error.getClass().getSimpleName());
                } catch (Exception ignored) { }
            }
            return result.toString();
        }
    }

    private class ExternalInfoBridge {
        @JavascriptInterface public void loadBlsCalendar(String callbackId) {
            if (callbackId == null || callbackId.trim().isEmpty()) return;
            try { marketExecutor.execute(() -> deliverExternalInfo(callbackId, loadOfficialBlsCalendar())); }
            catch (RejectedExecutionException busy) {
                JSONObject out = new JSONObject();
                try { out.put("error", "REQUEST_QUEUE_FULL"); out.put("events", new JSONArray()); } catch (Exception ignored) { }
                deliverExternalInfo(callbackId, out);
            }
        }
        @JavascriptInterface public void searchNews(String query, String callbackId) {
            if (callbackId == null || callbackId.trim().isEmpty()) return;
            try {
                marketExecutor.execute(() -> {
                    diagNewsRequests.incrementAndGet();
                    JSONObject info = searchPublicNews(query);
                    String error = info.optString("error", "");
                    if (error.isEmpty()) {
                        diagNewsSuccess.incrementAndGet();
                        diagNewsLastSuccessMs = System.currentTimeMillis();
                        diagNewsLastError = "NONE";
                    } else {
                        diagNewsFailures.incrementAndGet();
                        diagNewsLastError = "SEARCH_FAILED";
                    }
                    deliverExternalInfo(callbackId, info);
                });
            } catch (RejectedExecutionException busy) {
                JSONObject out = new JSONObject();
                try { out.put("error", "REQUEST_QUEUE_FULL"); out.put("items", new JSONArray()); } catch (Exception ignored) { }
                diagNewsRequests.incrementAndGet();
                diagNewsFailures.incrementAndGet();
                diagNewsLastError = "QUEUE_FULL";
                deliverExternalInfo(callbackId, out);
            }
        }
        @JavascriptInterface public void fetchArticleSmart(String url, String title, String publisherHome, String callbackId) {
            if (callbackId == null || callbackId.trim().isEmpty()) return;
            final String target = url == null ? "" : url.trim();
            if (!isPublicHttpUrl(target)) {
                JSONObject out = new JSONObject();
                try { out.put("status", "unavailable"); out.put("error", "UNSUPPORTED_URL"); } catch (Exception ignored) { }
                deliverExternalInfo(callbackId, out);
                return;
            }
            // V178: exactly the same URL used by "원문 보기". One rendered-WebView path only.
            fetchArticleViaWebView(target, title, callbackId);
        }
        @JavascriptInterface public void translateKorean(String text, String callbackId) {
            if (callbackId == null || callbackId.trim().isEmpty()) return;
            try {
                translationExecutor.execute(() -> deliverExternalInfo(callbackId, translatePublicToKorean(text)));
            } catch (RejectedExecutionException busy) {
                JSONObject out = new JSONObject();
                try { out.put("translated", ""); out.put("error", "REQUEST_QUEUE_FULL"); } catch (Exception ignored) { }
                deliverExternalInfo(callbackId, out);
            }
        }
        @JavascriptInterface public String ping() { return "OK-V199-STOCK-REGISTRY"; }
    }


    // V264: HTTPS-only AI gateway; no API keys or account data are embedded in the APK.
    // Separate executor so chat requests never occupy market or news collection queues.
    private static final String CHAT_AUTH_STORE = "snowball_chat_authorization_v264";
    private static final String CHAT_KEY_ALIAS = "SNOWBALL_CHAT_AUTH_AES_264";
    private String loadClientToken() {
        try {
            String data = getSharedPreferences(CHAT_AUTH_STORE, MODE_PRIVATE).getString("token", "");
            if (data == null || data.isEmpty()) return "";
            byte[] bytes = Base64.decode(data, Base64.NO_WRAP);
            byte[] iv = java.util.Arrays.copyOfRange(bytes, 0, 12);
            byte[] encrypted = java.util.Arrays.copyOfRange(bytes, 12, bytes.length);
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
            SecretKey key = (SecretKey) ks.getKey(CHAT_KEY_ALIAS, null);
            if (key == null) return "";
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }
    private boolean saveClientToken(String token) {
        if (token == null || token.length() < 12 || token.length() > 256 || token.contains("\n")) return false;
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
            SecretKey key = (SecretKey) ks.getKey(CHAT_KEY_ALIAS, null);
            if (key == null) {
                KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
                g.init(new KeyGenParameterSpec.Builder(CHAT_KEY_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256).build());
                key = g.generateKey();
            }
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] iv = cipher.getIV(); byte[] encrypted = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
            byte[] full = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, full, 0, iv.length);
            System.arraycopy(encrypted, 0, full, iv.length, encrypted.length);
            return getSharedPreferences(CHAT_AUTH_STORE, MODE_PRIVATE).edit()
                    .putString("token", Base64.encodeToString(full, Base64.NO_WRAP)).commit();
        } catch (Exception e) { return false; }
    }
    private class ChatBridge {
        private void reply(String callbackId, JSONObject response) {
            if (webView == null) return;
            String js = "window.SNOWBALL_NATURAL_CHAT&&window.SNOWBALL_NATURAL_CHAT.onReply(" +
                JSONObject.quote(callbackId) + "," + response.toString() + ");";
            webView.post(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
        }
        private JSONObject error(String code) {
            JSONObject obj = new JSONObject();
            try { obj.put("error", code); } catch (Exception ignored) { }
            return obj;
        }
        @JavascriptInterface public boolean saveAccessCode(String code) { return saveClientToken(code); }
        @JavascriptInterface public boolean hasAccessCode() { return !loadClientToken().isEmpty(); }
        @JavascriptInterface public void clearAccessCode() {
            getSharedPreferences(CHAT_AUTH_STORE, MODE_PRIVATE).edit().remove("token").apply();
        }
        @JavascriptInterface public void ask(String endpoint, String payload, String callbackId) {
            if (callbackId == null || !callbackId.matches("ntchat_[0-9]{1,9}_[0-9]{8,17}")) return;
            if (endpoint == null || endpoint.length() > 220 || payload == null || payload.length() > 12000) {
                reply(callbackId, error("INVALID_REQUEST")); return;
            }
            final URL url;
            try {
                URL base = new URL(endpoint);
                if (!"https".equalsIgnoreCase(base.getProtocol()) || base.getHost() == null ||
                    base.getHost().length() < 4 || base.getUserInfo() != null ||
                    (base.getPort() != -1 && base.getPort() != 443) ||
                    base.getQuery() != null || base.getRef() != null ||
                    !base.getHost().matches("[A-Za-z0-9.-]{4,190}") ||
                    base.getHost().equalsIgnoreCase("localhost")) {
                    reply(callbackId, error("HTTPS_REQUIRED")); return;
                }
                // Accept a server origin as well as its explicit /chat endpoint.
                String path=base.getPath();
                if (path.isEmpty() || "/".equals(path))
                    url=new URL(base.getProtocol(),base.getHost(),base.getPort(),"/chat");
                else if ("/chat".equals(path)) url=base;
                else { reply(callbackId, error("CHAT_BAD_PATH")); return; }
            } catch (Exception ex) { reply(callbackId, error("INVALID_ENDPOINT")); return; }
            try {
                JSONObject data = new JSONObject(payload);
                if (data.optString("message", "").trim().isEmpty()) {
                    reply(callbackId, error("EMPTY_MESSAGE")); return;
                }
            } catch (Exception ex) { reply(callbackId, error("INVALID_JSON")); return; }
            try {
                chatExecutor.execute(() -> {
                    HttpURLConnection conn = null;
                    JSONObject out;
                    try {
                        conn = (HttpURLConnection) url.openConnection();
                        conn.setInstanceFollowRedirects(false);
                        conn.setConnectTimeout(13000);
                        // Render free instances can take 50+ seconds to wake after inactivity.
                        // Allow cold start + one upstream AI request without failing after 17 seconds.
                        conn.setReadTimeout(105000);
                        conn.setRequestMethod("POST");
                        conn.setDoOutput(true);
                        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                        conn.setRequestProperty("Accept", "application/json");
                        String accessCode = loadClientToken();
                        if (accessCode.isEmpty()) throw new java.io.IOException("AUTH_REQUIRED");
                        conn.setRequestProperty("Authorization", "Bearer " + accessCode);
                        byte[] raw = payload.getBytes(StandardCharsets.UTF_8);
                        conn.setFixedLengthStreamingMode(raw.length);
                        try (OutputStream os = conn.getOutputStream()) { os.write(raw); }
                        int status = conn.getResponseCode();
                        if (status != 200) { out = error("CHAT_HTTP_" + status); }
                        else {
                            ByteArrayOutputStream buf = new ByteArrayOutputStream();
                            try (InputStream in = conn.getInputStream()) {
                                byte[] tmp = new byte[1024]; int n;
                                while ((n = in.read(tmp)) != -1) {
                                    if (buf.size() + n > 18000) throw new java.io.IOException("LENGTH_LIMIT");
                                    buf.write(tmp, 0, n);
                                }
                            }
                            out = new JSONObject(buf.toString("UTF-8"));
                        }
                    } catch (Exception ex) { out = error("CHAT_CONNECTION_FAILED"); }
                    finally { if (conn != null) conn.disconnect(); }
                    reply(callbackId, out);
                });
            } catch (RejectedExecutionException ex) { reply(callbackId, error("CHAT_BUSY")); }
        }
        @JavascriptInterface public void speakProvider(String endpoint, String text, String provider, String callbackId) {
            if (callbackId == null || !callbackId.matches("ntvoice_[0-9]{1,9}_[0-9]{8,17}")) return;
            String phrase = text == null ? "" : text.trim();
            if(phrase.isEmpty()) return;
            if(phrase.length()>850)phrase=phrase.substring(0,850);
            final URL url;
            try {
                URL base=new URL(endpoint);
                if (!"https".equalsIgnoreCase(base.getProtocol()) || base.getUserInfo()!=null ||
                    base.getQuery()!=null || base.getRef()!=null ||
                    (base.getPort()!=-1 && base.getPort()!=443) ||
                    !base.getHost().matches("[A-Za-z0-9.-]{4,190}") ||
                    !(base.getPath().isEmpty() || "/".equals(base.getPath()) || "/chat".equals(base.getPath()))) throw new Exception("bad endpoint");
                url=new URL(base.getProtocol(),base.getHost(),base.getPort(),"/speak");
            } catch(Exception ex) { audioError(callbackId); return; }
            final String safeText=phrase;
            // GPT replies use the previously selected Snowball TTS voice; Gemini only here.
            if (!"gemini".equals(provider)) { audioError(callbackId); return; }
            final long requestGen=++chatVoiceRequestGen;
            final String route="gemini";
            try { chatExecutor.execute(() -> {
                HttpURLConnection conn=null;
                File temp=null;
                try {
                    String code=loadClientToken();
                    if(code.isEmpty())throw new Exception("AUTH_REQUIRED");
                    conn=(HttpURLConnection)url.openConnection();
                    conn.setInstanceFollowRedirects(false);
                    conn.setConnectTimeout(6500);
                    conn.setReadTimeout(27000);
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
                    conn.setRequestProperty("Authorization","Bearer "+code);
                    JSONObject payload=new JSONObject();
                    payload.put("text",safeText);payload.put("route",route);
                    byte[] content=payload.toString().getBytes(StandardCharsets.UTF_8);
                    conn.setFixedLengthStreamingMode(content.length);
                    try(OutputStream output=conn.getOutputStream()){output.write(content);}
                    if(conn.getResponseCode()!=200)throw new Exception("SPEECH_HTTP");
                    String mime=conn.getContentType();
                    if(mime==null||(!mime.startsWith("audio/wav")&&!mime.startsWith("audio/mpeg")))throw new Exception("SPEECH_FORMAT");
                    temp=File.createTempFile("snowball-voice-",mime.startsWith("audio/wav")?".wav":".mp3",getCacheDir());
                    int count=0;
                    try(InputStream input=conn.getInputStream();FileOutputStream out=new FileOutputStream(temp)) {
                        byte[] buf=new byte[8192];int n;
                        while((n=input.read(buf))!=-1){count+=n;if(count>2500000)throw new Exception("AUDIO_TOO_LARGE");out.write(buf,0,n);}
                    }
                    if(count<100)throw new Exception("AUDIO_EMPTY");
                    startAiSpeechAudio(temp, callbackId, requestGen);
                    temp=null;
                } catch(Exception ex) {audioError(callbackId);}
                finally { if(conn!=null)conn.disconnect();if(temp!=null)temp.delete(); }
            });} catch(RejectedExecutionException ex){audioError(callbackId);}
        }
        private void audioError(String callbackId) {
            if(webView==null)return;
            notifyChatAudioError(callbackId);
        }
        @JavascriptInterface public String ping() { return "V264_HTTPS_GATEWAY"; }
    }

    private class VoiceBridge {
        @JavascriptInterface public void speak(String text) { speakNative(text); }
        @JavascriptInterface public void stop() { stopVoiceNative(); }
        @JavascriptInterface public void listen() { startVoiceListen(); }
        @JavascriptInterface public void checkSpeech() {
            runOnUiThread(() -> {
                voiceCheckOnce = true;
                if (voiceRecognizerActive) {
                    voiceCheckOnce = false;
                    notifyVoiceCheckResult("", "음성 대화가 실행 중입니다. 먼저 대화를 종료해 주세요.");
                    return;
                }
                startVoiceListen();
            });
        }
        @JavascriptInterface public boolean ready() { return textToSpeechReady; }
        @JavascriptInterface public String getVoiceSettings() { return voiceTuningJson(); }
        @JavascriptInterface public void saveVoiceSettings(String json) { updateVoiceTuningFromJson(json, true); }
        @JavascriptInterface public void previewVoiceSettings(String json) { updateVoiceTuningFromJson(json, false); }
        @JavascriptInterface public void reloadSavedVoiceSettings() { loadVoiceTuning(); runOnUiThread(MainActivity.this::applyVoiceTuning); }
        @JavascriptInterface public void resetVoiceSettings() { resetVoiceTuning(); }
        @JavascriptInterface public String ping() { return "OK-V178-VOICE"; }
        @JavascriptInterface public long session() { return voiceListenSerial; }
    }

    private static String cleanBackupName(String raw) {
        String name = raw == null ? "" : raw.trim();
        if (name.isEmpty()) name = "눈탱이_백업.json";
        name = name.replace("/", "_").replace("\\", "_");
        if (!name.toLowerCase().endsWith(".json")) name += ".json";
        return name;
    }

    private void notifyBackupSaved(String name) {
        if (webView == null) return;
        String quoted = JSONObject.quote(name == null ? "눈탱이_백업.json" : name);
        webView.post(() -> webView.evaluateJavascript(
                "window.SnowballNativeBackup&&window.SnowballNativeBackup.saved(" + quoted + ");", null));
    }

    private void notifyBackupError(String message) {
        if (webView == null) return;
        String quoted = JSONObject.quote(message == null ? "백업 처리 오류" : message);
        webView.post(() -> webView.evaluateJavascript(
                "window.SnowballNativeBackup&&window.SnowballNativeBackup.error(" + quoted + ");", null));
    }

    private void notifyBackupCancelled(String message) {
        if (webView == null) return;
        String quoted = JSONObject.quote(message == null ? "백업 작업을 취소했습니다." : message);
        webView.post(() -> webView.evaluateJavascript(
                "window.SnowballNativeBackup&&window.SnowballNativeBackup.cancelled(" + quoted + ");", null));
    }

    private void saveBackup(String json, String requestedName) {
        final String payload = json == null ? "" : json;
        final String name = cleanBackupName(requestedName);
        if (payload.isEmpty()) {
            notifyBackupError("저장할 백업 데이터가 없습니다.");
            return;
        }
        try {
            // V57: always use Android's system document creator.
            // This avoids WebView/Blob download ambiguity and makes the real file
            // location visible to the user before anything is reported as saved.
            pendingBackupJson = payload;
            pendingBackupName = name;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, name);
            startActivityForResult(intent, REQ_CREATE_BACKUP);
        } catch (Exception e) {
            pendingBackupJson = null;
            pendingBackupName = null;
            notifyBackupError("백업 저장창을 열지 못했습니다: " + e.getMessage());
        }
    }

    private void pickBackup() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            startActivityForResult(intent, REQ_OPEN_BACKUP);
        } catch (Exception e) {
            notifyBackupError("백업 파일 선택 실패: " + e.getMessage());
        }
    }

    private void pickKrxFlowCsv(String stockCode, String stockName) {
        try {
            pendingKrxFlowCode = stockCode == null ? "" : stockCode.trim();
            pendingKrxFlowName = stockName == null ? "" : stockName.trim();
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/csv","text/comma-separated-values","text/plain","application/vnd.ms-excel"});
            startActivityForResult(intent, REQ_OPEN_KRX_FLOW);
        } catch (Exception e) {
            pendingKrxFlowCode = "";
            pendingKrxFlowName = "";
            notifyJsLifecycle("window.SnowballKrxCsvImport&&window.SnowballKrxCsvImport.error(" + JSONObject.quote("KRX CSV 파일 선택 실패: " + e.getMessage()) + ");");
        }
    }

    private String decodeKrxCsv(byte[] bytes) throws Exception {
        if (bytes == null || bytes.length == 0) throw new IllegalStateException("선택한 CSV 파일이 비어 있습니다.");
        String utf = new String(bytes, StandardCharsets.UTF_8);
        if (utf.indexOf('\uFFFD') < 0) return utf;
        return new String(bytes, Charset.forName("EUC-KR"));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_CREATE_BACKUP && resultCode != RESULT_OK) {
            pendingBackupJson = null;
            pendingBackupName = null;
            notifyBackupCancelled("백업 저장을 취소했습니다.");
            return;
        }
        if (requestCode == REQ_OPEN_BACKUP && resultCode != RESULT_OK) {
            notifyBackupCancelled("백업 파일 선택을 취소했습니다.");
            return;
        }
        if (requestCode == REQ_OPEN_KRX_FLOW && resultCode != RESULT_OK) {
            String code = pendingKrxFlowCode;
            pendingKrxFlowCode = "";
            pendingKrxFlowName = "";
            notifyJsLifecycle("window.SnowballKrxCsvImport&&window.SnowballKrxCsvImport.cancelled(" + JSONObject.quote(code) + ");");
            return;
        }
        if (data == null || data.getData() == null) {
            notifyBackupError("선택한 파일 위치를 확인할 수 없습니다.");
            return;
        }

        Uri uri = data.getData();
        try {
            if (requestCode == REQ_CREATE_BACKUP) {
                String payload = pendingBackupJson == null ? "" : pendingBackupJson;
                String name = pendingBackupName == null ? "눈탱이_백업.json" : pendingBackupName;
                byte[] expected = payload.getBytes(StandardCharsets.UTF_8);
                if (expected.length == 0) throw new IllegalStateException("저장할 백업 데이터가 없습니다.");

                try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                    if (out == null) throw new IllegalStateException("백업 파일을 열 수 없습니다.");
                    out.write(expected);
                    out.flush();
                }

                // Verify the actual stored bytes, not merely their length, before announcing success.
                java.security.MessageDigest writtenDigest = java.security.MessageDigest.getInstance("SHA-256");
                int verifiedBytes = 0;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IllegalStateException("저장된 백업 파일을 다시 확인할 수 없습니다.");
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        if (n == 0) continue;
                        verifiedBytes += n;
                        if (verifiedBytes > expected.length) throw new IllegalStateException("백업 저장 검증 실패: 파일 크기 불일치");
                        writtenDigest.update(buf, 0, n);
                    }
                }
                byte[] expectedDigest = java.security.MessageDigest.getInstance("SHA-256").digest(expected);
                if (verifiedBytes != expected.length || !java.security.MessageDigest.isEqual(expectedDigest, writtenDigest.digest())) {
                    throw new IllegalStateException("백업 저장 검증 실패: 저장된 내용이 원본과 다릅니다.");
                }

                pendingBackupJson = null;
                pendingBackupName = null;
                Toast.makeText(this, "백업 파일 실제 저장 확인 완료", Toast.LENGTH_LONG).show();
                notifyBackupSaved(name);
                return;
            }
            if (requestCode == REQ_OPEN_KRX_FLOW) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IllegalStateException("KRX CSV 파일을 열 수 없습니다.");
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        out.write(buf, 0, n);
                        if (out.size() > 8 * 1024 * 1024) throw new IllegalStateException("KRX CSV 파일이 너무 큽니다 (8MB 초과).");
                    }
                }
                String text = decodeKrxCsv(out.toByteArray());
                String code = pendingKrxFlowCode;
                String name = pendingKrxFlowName;
                pendingKrxFlowCode = "";
                pendingKrxFlowName = "";
                String js = "window.SnowballKrxCsvImport&&window.SnowballKrxCsvImport.receive(" +
                        JSONObject.quote(code) + "," + JSONObject.quote(name) + "," + JSONObject.quote(text) + ");";
                if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
                return;
            }
            if (requestCode == REQ_OPEN_BACKUP) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IllegalStateException("백업 파일을 열 수 없습니다.");
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
                String text = out.toString("UTF-8");
                String quoted = JSONObject.quote(text);
                if (webView != null) webView.post(() -> webView.evaluateJavascript(
                        "window.SnowballNativeBackup&&window.SnowballNativeBackup.receive(" + quoted + ");", null));
            }
        } catch (Exception e) {
            if (requestCode == REQ_CREATE_BACKUP) {
                pendingBackupJson = null;
                pendingBackupName = null;
            }
            if (requestCode == REQ_OPEN_KRX_FLOW) {
                pendingKrxFlowCode = "";
                pendingKrxFlowName = "";
                notifyJsLifecycle("window.SnowballKrxCsvImport&&window.SnowballKrxCsvImport.error(" + JSONObject.quote("KRX CSV 처리 실패: " + e.getMessage()) + ");");
                return;
            }
            notifyBackupError("백업 처리 실패: " + e.getMessage());
        }
    }

    private class BackupBridge {
        @JavascriptInterface
        public String ping() {
            return "BACKUP-OK-V60";
        }

        @JavascriptInterface
        public void save(String json, String requestedName) {
            runOnUiThread(() -> saveBackup(json, requestedName));
        }

        @JavascriptInterface
        public void pick() {
            runOnUiThread(() -> pickBackup());
        }
    }

    private void deliverMarketAsync(String callbackId, String body) {
        final String js = "window.__SnowballNativeAsyncResolve&&window.__SnowballNativeAsyncResolve(" +
                JSONObject.quote(callbackId) + "," + JSONObject.quote(body == null ? "" : body) + ");";
        WebView w = webView;
        if (w != null) w.post(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    private void notifyJsLifecycle(String expression) {
        WebView w = webView;
        if (w != null) w.post(() -> { if (webView != null) webView.evaluateJavascript(expression, null); });
    }

    private class MarketDataBridge {
        @JavascriptInterface
        public String ping() {
            return "OK-V60.8";
        }

        @JavascriptInterface
        public String get(String urlString) {
            return nativeGetText(urlString);
        }

        @JavascriptInterface
        public void getAsync(String urlString, String callbackId) {
            if (callbackId == null || callbackId.isEmpty()) return;
            final long generation = marketGeneration;
            if (!activityActive) {
                deliverMarketAsync(callbackId, "{\"error\":\"APP_PAUSED\"}");
                return;
            }
            try {
                marketExecutor.execute(() -> {
                    if (!activityActive || generation != marketGeneration) {
                        deliverMarketAsync(callbackId, "{\"error\":\"REQUEST_CANCELLED\"}");
                        return;
                    }
                    final String body = nativeGetText(urlString);
                    if (generation != marketGeneration) {
                        deliverMarketAsync(callbackId, "{\"error\":\"REQUEST_CANCELLED\"}");
                        return;
                    }
                    deliverMarketAsync(callbackId, body);
                });
            } catch (RejectedExecutionException busy) {
                deliverMarketAsync(callbackId, "{\"error\":\"REQUEST_QUEUE_FULL\",\"message\":\"시장데이터 요청이 많아 다음 갱신에서 재시도합니다.\"}");
            }
        }

        @JavascriptInterface
        public void getKrxFlowAsync(String stockCode, String fromYmd, String toYmd, String callbackId) {
            if (callbackId == null || callbackId.isEmpty()) return;
            final long generation = marketGeneration;
            if (!activityActive) {
                deliverMarketAsync(callbackId, "{\"error\":\"APP_PAUSED\"}");
                return;
            }
            try {
                marketExecutor.execute(() -> {
                    if (!activityActive || generation != marketGeneration) {
                        deliverMarketAsync(callbackId, "{\"error\":\"REQUEST_CANCELLED\"}");
                        return;
                    }
                    final String body = nativeGetKrxFlow(stockCode, fromYmd, toYmd);
                    if (generation != marketGeneration) {
                        deliverMarketAsync(callbackId, "{\"error\":\"REQUEST_CANCELLED\"}");
                        return;
                    }
                    deliverMarketAsync(callbackId, body);
                });
            } catch (RejectedExecutionException busy) {
                deliverMarketAsync(callbackId, "{\"error\":\"REQUEST_QUEUE_FULL\",\"message\":\"KRX 수급 요청이 많아 다음 갱신에서 재시도합니다.\"}");
            }
        }

        @JavascriptInterface
        public void pickKrxFlowCsv(String stockCode, String stockName) {
            runOnUiThread(() -> MainActivity.this.pickKrxFlowCsv(stockCode, stockName));
        }

    }

    // S11: only user-clicked HTTP(S) shortcuts. Launch outside the app WebView.
    private class BookmarkBridge {
        @JavascriptInterface
        public void openUrl(String address) {
            if (address == null || address.length() > 1800) return;
            final Uri target;
            try {
                target = Uri.parse(address);
                String scheme = target.getScheme();
                if ((scheme == null || !(scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http")))
                        || target.getHost() == null || target.getHost().isEmpty()
                        || target.getUserInfo() != null) return;
            } catch (Exception ignored) { return; }
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, target);
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    startActivity(intent);
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "사이트를 열 수 없습니다.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private class SnowballWebViewClient extends WebViewClient {
        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            // V50 stability: renderer failure must not close the whole app.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                runOnUiThread(() -> {
                    try {
                        if (view != null && view.getParent() instanceof ViewGroup) {
                            ((ViewGroup) view.getParent()).removeView(view);
                        }
                        if (view != null) view.destroy();
                    } catch (Exception ignored) { }
                    webView = null;
                    Toast.makeText(MainActivity.this, "화면 엔진을 복구합니다.", Toast.LENGTH_SHORT).show();
                    recreate();
                });
                return true;
            }
            return false;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            applyBottomInsetToPage();
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            String url = u == null ? null : u.toString();
            if (isNaverDataUrl(url)) return proxy(url);
            return super.shouldInterceptRequest(view, request);
        }

        @Override
        @SuppressWarnings("deprecation")
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            if (isNaverDataUrl(url)) return proxy(url);
            return super.shouldInterceptRequest(view, url);
        }
    }
}
