package com.snowball.noontangi;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/** Read-only, explicitly granted JSON attachment. No app database or private files are exposed. */
public final class DiagnosticFileProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }
    private File resolve(Uri uri) throws FileNotFoundException {
        if (uri == null || !uri.getAuthority().equals(getContext().getPackageName()+".diagnostics"))
            throw new FileNotFoundException("INVALID_AUTHORITY");
        if (uri.getPathSegments().size()!=1) throw new FileNotFoundException("INVALID_PATH");
        String name=uri.getLastPathSegment();
        if (name==null || !name.matches("diagnostic-[0-9a-f]{16}\\.json")) throw new FileNotFoundException("INVALID_NAME");
        File dir=new File(getContext().getCacheDir(), "ntb-diagnostic");
        File file=new File(dir, name);
        if (!file.isFile()) throw new FileNotFoundException("NOT_FOUND");
        return file;
    }
    @Override public String getType(Uri uri) { return "application/json"; }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("READ_ONLY");
        return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Cursor query(Uri uri, String[] projection, String sel, String[] args, String sort) {
        try {
            File file=resolve(uri);
            String[] cols=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor c=new MatrixCursor(cols);
            Object[] row=new Object[cols.length];
            for(int i=0;i<cols.length;i++){
                if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i]="눈탱이_오류진단.json";
                else if(OpenableColumns.SIZE.equals(cols[i])) row[i]=file.length();
            }
            c.addRow(row);
            return c;
        } catch(Exception ignored) { return null; }
    }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException("READ_ONLY"); }
    @Override public int delete(Uri uri,String sel,String[] args) { throw new UnsupportedOperationException("READ_ONLY"); }
    @Override public int update(Uri uri,ContentValues v,String sel,String[] args) { throw new UnsupportedOperationException("READ_ONLY"); }
}