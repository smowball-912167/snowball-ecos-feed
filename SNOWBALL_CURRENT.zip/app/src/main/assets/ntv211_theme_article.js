/* 눈탱이 V218 성장테마 자료 정독/한국어 표시/선택읽기 서비스.
   기존 589개 메타데이터는 변경하지 않는다. 신뢰 원문 추출 실패 시 요약하지 않는다.
   외부 Gemini 키를 앱에 저장하지 않으며, 기사 본문 기반 발췌이며 수집 자료에 AI 판정·내용 배제 필터를 적용하지 않는다. */
(function(){'use strict';
var STORE='ntv211-theme-source-briefs-v1', TITLE_STORE='ntv211-theme-korean-titles-v1';
var briefs={}, titles={}, pending={}, idSeq=0, queue=[], active=0, titleQ=[], titleActive=0, titleTried={}, interested={}, opened=null, startedAt={};
var URL_STORE='ntv218-theme-source-urls-v1', resolvedUrls={};
var listMounted=0, viewMode="summary", translatingFull={}, viewGeneration=0;
function load(k){try{var v=JSON.parse(localStorage.getItem(k)||'{}');return v&&typeof v==='object'&&!Array.isArray(v)?v:{};}catch(_){return {};}}
function save(k,v,max){try{var keys=Object.keys(v).sort(function(a,b){return Number(v[b].at||0)-Number(v[a].at||0);});var out={};keys.slice(0,max).forEach(function(key){out[key]=v[key];});localStorage.setItem(k,JSON.stringify(out));}catch(_){}}
briefs=load(STORE);titles=load(TITLE_STORE);resolvedUrls=load(URL_STORE);
function make(tag,cls,value){var e=document.createElement(tag);if(cls)e.className=cls;if(value!==undefined)e.textContent=value;return e;}
function valid(url){return typeof url==='string'&&/^https:\/\//i.test(url);}
function text(v){return String(v||'').replace(/\s+/g,' ').trim();}
function articleKey(e){return 'i'+String(e.index)+'_'+String(e.date||'');}
function hasKorean(v){return /[가-힣]/.test(String(v||''));}
function needsKo(v){var s=String(v||''),latin=(s.match(/[a-zA-Z]/g)||[]).length,korean=(s.match(/[가-힣]/g)||[]).length;return latin>18&&latin>korean*1.35;}
function stopVoice(){try{var g=window.NOONTANGI_VOICE_GLOBAL;if(g&&typeof g.stopReading==='function')g.stopReading();else if(window.SnowballVoice&&typeof window.SnowballVoice.stop==='function')window.SnowballVoice.stop();}catch(_){}}
function talk(v){try{var g=window.NOONTANGI_VOICE_GLOBAL;if(g&&typeof g.speak==='function'){g.speak(String(v||''),{resume:false});return true;}var b=window.SnowballVoice;if(b&&typeof b.speak==='function'){b.speak(String(v||''));return true;}}catch(_){}return false;}
function resolver(){window.NOONTANGI_EXTERNAL_INFO=window.NOONTANGI_EXTERNAL_INFO||{};var dest=window.NOONTANGI_EXTERNAL_INFO;if(dest.__v211ThemeCallback)return;var prior=dest.resolve;
 dest.resolve=function(id,raw){if(String(id||'').indexOf('v211tg_')===0){var p=pending[id];if(!p)return false;delete pending[id];clearTimeout(p.timer);try{p.resolve(JSON.parse(String(raw||'{}')));}catch(_){p.resolve({error:'INVALID_JSON'});}return true;}if(typeof prior==='function')return prior(id,raw);return false;};dest.__v211ThemeCallback=true;}
function native(method,args,timeout){return new Promise(function(resolve){var b=window.SnowballExternalInfo;if(!b||typeof b[method]!=='function'){resolve({error:'기기 기사읽기 기능 연결 안 됨'});return;}resolver();var id='v211tg_'+(++idSeq)+'_'+Date.now();var timer=setTimeout(function(){if(!pending[id])return;delete pending[id];resolve({error:'요청시간 초과'});},timeout||47000);pending[id]={resolve:resolve,timer:timer};try{b[method].apply(b,(args||[]).concat([id]));}catch(err){clearTimeout(timer);delete pending[id];resolve({error:'기기 기능 호출 실패'});}});}
function translate(v){v=text(v);if(!v)return Promise.resolve('');if(!needsKo(v))return Promise.resolve(v);return native('translateKorean',[v.slice(0,1790)],42000).then(function(r){var t=text(r.translated);return hasKorean(t)?t:'';});}
function publicUrl(url){try{if(window.SnowballBookmarks&&window.SnowballBookmarks.openUrl)window.SnowballBookmarks.openUrl(url);else if(window.Android&&window.Android.openUrl)window.Android.openUrl(url);else window.open(url,'_blank','noopener,noreferrer');}catch(_){window.open(url,'_blank','noopener,noreferrer');}}
function cleanArticleProse(raw){
 // Display/summary only. Do not rewrite or delete source original, links or archived records.
 var s=String(raw||'').replace(/\r/g,'\n').replace(/\u00a0/g,' '),rows=s.split(/\n+/),kept=[],seen=Object.create(null),chars=0;
 var starts=/^(?:\[?사진\s*[=:]|\(?사진\s*[=:]|사진\s*[=:]|(?:\(|\[)?(?:출처|자료제공|캡처)\s*[:=]|(?:\(|\[)?\S{2,18}\s*(?:기자|특파원)(?:\]|\))?\s*[=:]|\S+@\S+\.\S+|관련\s*기사|추천\s*기사|많이\s*본|이\s*시각\s*뉴스|또한\s*읽어\s*보세요|업데이트\s*및\s*수정\s*내용|editor's note|stocktwits|share this article|copyright|더구루\s*\S+\s*기자)/i;
 var tail=/(?:\[?더구루\s*[^\]\n]{1,35}\s*기자\]?|\(?사진\s*[=:][^)\n]{0,140}\)?|\b(?:stocktwits|subscribe to|also read|read more|sign up for|send an email to|for updates and corrections|related articles)\b|업데이트\s*및\s*수정\s*내용|또한\s*읽어\s*보세요|관련\s*기사를?\s*보려면)/i;
 for(var i=0;i<rows.length;i++){
  var x=rows[i].replace(/\s+/g,' ').trim();if(!x)continue;
  if(starts.test(x))continue;
  // High-confidence captions, publication boilerplate and linked stock-trading widgets within the body.
  x=x.replace(/^(?:(?:송고\s*)?(?:20\d{2}[-./]\d{1,2}[-./]\d{1,2}\s*\d{1,2}:\d{2}|20\d{2}년\d{1,2}월\d{1,2}일\s*\d{1,2}시\s*\d{1,2}분)\s*){1,3}/,'');
  x=x.replace(/^\([^)]+=[^)]+\)\s*[가-힣]{2,5}\s*(?:기자|통신원|특파원)\s*=\s*/,'');
  x=x.replace(/\[[^\]]{0,32}(?:기자|통신원|특파원)\]/g,' ');
  x=x.replace(/(?:\(|\[)?(?:사진|자료제공|출처)\s*[:=][^\])]{0,110}[\])]?(?:\s+|$)/gi,' ');
  if(chars+x.length>=100){var m=tail.exec(x);if(m&&(chars>=100||m.index>=95))x=x.slice(0,m.index).trim();}
  x=x.replace(/\s+/g,' ').trim();if(x.length<8)continue;
  var key=x.toLowerCase();if(seen[key])continue;seen[key]=1;kept.push(x);chars+=x.length;
 }
 return kept.join(' ').replace(/\s+/g,' ').trim();
}
function splitFacts(raw){
 var s=cleanArticleProse(raw);
 // Match source sentences, preserving reported facts without inventing a conclusion.
 return (s.match(/[^.!?。？！]+(?:[.!?。？！]+|$)/g)||[]).map(text).filter(function(x){return x.length>=16;});
}
function summaryExtract(body){
 var parts=splitFacts(body);if(!parts.length)return null;
 // Preserve the actual order: lead → principal evidence → reported closing fact.
 // These are editorial section functions, not labels or separate cards.
 var chosen=[],n=parts.length,seen=Object.create(null);
 function pick(i){if(i<0||i>=n)return;var x=parts[i],k=x.toLowerCase();if(!seen[k]){seen[k]=1;chosen.push({i:i,v:x});}}
 for(var i=0;i<Math.min(3,n);i++)pick(i);
 if(n>5){var middle=Math.max(3,Math.floor(n*.38));for(var j=middle;j<Math.min(n-2,middle+3);j++)pick(j);}
 // Never automatically include tail sentences: pages often append stock tickers, related articles and notices.
 chosen.sort(function(a,b){return a.i-b.i;});
 var out='',cap=850;
 chosen.forEach(function(it){if(out.length>=cap)return;if(out.length+it.v.length>cap&&out.length>=300)return;out+=(out?' ':'')+it.v;});
 return out||parts[0];
}
function ready(e){var s=briefs[articleKey(e)];if(!s||s.state!=='ready'||typeof s.summary!=='string')return null;
 if(s.revision!=='V227'){
  // Avoid re-fetching source solely to clean old cached summaries; reuse saved confirmed source.
  var source=s.original&&!needsKo(s.original)?s.original:s.summary;
  var revised=summaryExtract(source);
  if(revised)s.summary=revised;s.revision='V227';store(e,s);
 }
 return s;
}
// V218: no mass reading during list paint; explicit user choices get a dedicated fast lane.
function store(e,data){briefs[articleKey(e)]=Object.assign({at:Date.now()},data);save(STORE,briefs,90);return briefs[articleKey(e)];}
function verifiedSource(url){try{var u=new URL(String(url||''));return u.protocol==='https:'&&u.hostname!=='news.google.com'&&!/(^|\.)google\.com$/.test(u.hostname);}catch(_){return false;}}
function originalUrl(e){var saved=resolvedUrls[articleKey(e)];return saved&&verifiedSource(saved.url)?saved.url:e.url;}
function saveVerifiedSource(e,url){if(!verifiedSource(url))return;resolvedUrls[articleKey(e)]={url:url,at:Date.now()};save(URL_STORE,resolvedUrls,589);}
function prepare(e,high,force){var k=articleKey(e),old=ready(e);if(old&&!force)return Promise.resolve(old);
 if(interested[k]){if(high){var at=queue.findIndex(function(q){return articleKey(q.e)===k;});if(at>=0){var task=queue.splice(at,1)[0];queue.unshift(task);}}return interested[k];}
 interested[k]=new Promise(function(resolve){if(high)queue.unshift({e:e,resolve:resolve});else queue.push({e:e,resolve:resolve});pump();});return interested[k];}
function pump(){while(active<2&&queue.length){(function(q){active++;var e=q.e,k=articleKey(e),candidate=originalUrl(e);startedAt[k]=Date.now();
 if(!valid(candidate)){store(e,{state:'failed',error:'원문 주소 없음'});finish();return;}
 function fetch(url){return native('fetchArticleSmart',[url,e.title,''],19000);}
 // If a previously verified publisher URL becomes stale, retry the original Google News link once.
 fetch(candidate).then(function(r){if((!r||!r.trustedBody)&&candidate!==e.url&&valid(e.url))return fetch(e.url);return r;}).then(function(r){
  if(!r||!r.trustedBody||['full','partial'].indexOf(r.status)<0||text(r.articleText).length<170){throw new Error(text(r&&r.error||'기사 본문을 확인하지 못했습니다.'));}
  if(r.finalUrl)saveVerifiedSource(e,r.finalUrl);
  var body=String(r.articleText).slice(0,30000),summary=summaryExtract(body);
  if(!summary)throw new Error('문장 추출 불가');
  if(needsKo(summary))return translateBlocks(summary,function(){}).then(function(v){if(!v)throw new Error('한국어 번역에 실패했습니다');return {state:'ready',summary:v,original:body,originalKo:'',sourceLength:body.length,partial:r.status==='partial',finalUrl:originalUrl(e),at:Date.now(),revision:'V227'};});
  return {state:'ready',summary:summary,original:body,originalKo:needsKo(body)?'':body,sourceLength:body.length,partial:r.status==='partial',finalUrl:originalUrl(e),at:Date.now(),revision:'V227'};
 }).then(function(d){store(e,d);}).catch(function(err){var old=briefs[k];if(old&&old.state==='ready'&&old.original){old.note='기존 원문/요약 보존. 새 원문 확인은 실패했습니다.';store(e,old);}else store(e,{state:'failed',error:text(err&&err.message||'본문 확인 실패')});}).then(finish);
 function finish(){var result=briefs[k]||{state:'failed',error:'확인 실패'};delete interested[k];delete startedAt[k];q.resolve(result);active--;if(opened&&articleKey(opened.e)===k)renderOpened();pump();if(titleQ.length)translationPump();}
 })(queue.shift());}}
function translateBlocks(body,progress){
 // Public translation bridge accepts 1800 Unicode chars max per call. Do not cut mid-sentence.
 var remaining=cleanArticleProse(body),blocks=[];
 while(remaining){var cut=Math.min(1400,remaining.length);if(cut<remaining.length){var breakAt=remaining.lastIndexOf(' ',cut);if(breakAt>cut*.55)cut=breakAt;}
  blocks.push(remaining.slice(0,cut));remaining=remaining.slice(cut).trim();}
 var chain=Promise.resolve([]);blocks.forEach(function(chunk,i){chain=chain.then(function(out){return translate(chunk).then(function(v){if(!hasKorean(v))throw new Error('원문 일부 번역 실패');out.push(v);if(progress)progress(i+1,blocks.length);return out;});});});
 return chain.then(function(out){return out.join('\n\n');}).catch(function(){return '';});
}
function fullKorean(e){var k=articleKey(e),d=ready(e);if(!d||!d.original)return Promise.resolve('');
 if(d.originalKo)return Promise.resolve(d.originalKo);
 if(translatingFull[k])return translatingFull[k];
 translatingFull[k]=translateBlocks(d.original,function(n,total){var status=document.getElementById('tg213-translation-progress');if(status)status.textContent='원문 한글 번역 중 '+n+'/'+total+' 구간';}).then(function(v){
   delete translatingFull[k];if(v){d.originalKo=v;store(e,d);}if(opened&&articleKey(opened.e)===k)renderOpened();return v;
 });return translatingFull[k];
}
function translationPump(){if(titleActive>=1||active>0||!titleQ.length)return;titleActive++;var item=titleQ.shift(),key=articleKey(item.e);translate(item.e.title).then(function(v){if(hasKorean(v)){titles[key]={value:v,at:Date.now()};save(TITLE_STORE,titles,240);document.querySelectorAll('[data-tg211-key="'+key+'"] .tg-link').forEach(function(node){node.textContent=translatedTitle(item.e);});if(opened&&articleKey(opened.e)===key)renderOpened();}}).finally(function(){titleActive--;translationPump();});}
function translatedTitle(e){var record=titles[articleKey(e)],t=record&&hasKorean(record.value)?record.value:e.title,p=text(e&&e.publisher||'');
 // Publisher belongs in the second list row, not inside the first-line headline.
 if(p){var pat=new RegExp('\\s*[-–|]\\s*'+p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\s*$','i');for(var i=0;i<3&&pat.test(t);i++)t=t.replace(pat,'').trim();}
 return t;
}
function previewText(data){return data.summary||'';}
function renderPreview(e,node){node.textContent=''; /* V216: summaries belong only in the article detail, never the two-line list. */}
function beginList(){listMounted=0;}
function mount(e,row){listMounted++;var k=articleKey(e);row.setAttribute('data-tg211-key',k);var link=row.querySelector('.tg-link');if(link){link.textContent=translatedTitle(e);link.setAttribute('aria-label','기사 상세보기: '+translatedTitle(e));}
 // Read/summary and background fetch are separate from list rendering. No extra rows are appended.
 if(listMounted<=8&&needsKo(e.title)&&!titles[k]&&!titleTried[k]){titleTried[k]=true;titleQ.push({e:e});translationPump();}
 // On-demand body extraction: opening 589 saved records must NOT launch 589 native WebViews.
}
// V212: article detail is a separate fixed scroll surface. Re-render only its content,
// never replace the scroll container; close stays above content and remains tappable.
function closeDetail(){
 viewGeneration++;stopVoice();opened=null;
 var overlay=document.getElementById('tg212-overlay');if(overlay)overlay.remove();viewMode="summary";
 var growth=window.NTV210_THEME_GROWTH;if(growth&&growth.onArticleClosed)growth.onArticleClosed();return true;
}
function fitDetailToNav(overlay){if(!overlay)return;var bottom=0,nav=document.getElementById('mainNav');
 try{if(nav){var r=nav.getBoundingClientRect();if(r.height&&r.top>0)bottom=Math.max(0,Math.ceil(window.innerHeight-r.top)+4);}}catch(_){}
 if(!bottom)bottom=Number.parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ntv53-nav-height'))||76;
 overlay.style.setProperty('bottom',bottom+'px','important');}
window.addEventListener('resize',function(){fitDetailToNav(document.getElementById('tg212-overlay'));});
function ensureDetail(){
 var overlay=document.getElementById('tg212-overlay');if(overlay)return overlay;
 overlay=make('div','tg212-overlay');overlay.id='tg212-overlay';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','테마 기사 상세보기');
 var head=make('div','tg212-header');
 var left=make('button','tg212-close','‹ 목록으로');left.type='button';left.setAttribute('aria-label','기사 닫고 목록으로');left.addEventListener('click',closeDetail);head.appendChild(left);
 head.appendChild(make('strong','tg212-caption','기사 상세'));
 // Header/list back buttons are removed: Android system Back closes the reader.
 var controller=window.NTV210_THEME_GROWTH;var tools=controller&&controller.detailToolbar&&controller.detailToolbar();
 if(tools)overlay.appendChild(tools);
 var scroller=make('div','tg212-scroller');scroller.id='tg212-scroller';scroller.tabIndex=0;overlay.appendChild(scroller);
 document.body.appendChild(overlay);fitDetailToNav(overlay);return overlay;
}
function open(e){
 // Switching articles closes the previous one and invalidates any stale reading request.
 if(opened)closeDetail();viewGeneration++;stopVoice();viewMode='summary';opened={e:e};ensureDetail();renderOpened();
 var sc=document.getElementById('tg212-scroller');if(sc)sc.scrollTop=0;
 prepare(e,true).then(function(){if(opened&&articleKey(opened.e)===articleKey(e))renderOpened();});
 setTimeout(function(){if(opened&&articleKey(opened.e)===articleKey(e)&&!ready(e))renderOpened();},3000);
}
function renderOpened(){if(!opened)return;
 var e=opened.e,overlay=ensureDetail(),holder=overlay.querySelector('#tg212-scroller');if(!holder)return;
 var y=holder.scrollTop,root=make('section','tg211-detail');root.setAttribute('role','region');root.setAttribute('aria-label','기사 상세 정리');
 root.appendChild(make('h2','tg211-title',translatedTitle(e)));
 root.appendChild(make('div','tg-detail-sub',[e.date,e.publisher,e.region.indexOf('KR')>=0?'국내':'글로벌'].join(' · ')));
 var d=ready(e),state=briefs[articleKey(e)];
 // A single natural summary is shown. Original source is available via 원본보기.
 if(d){
  root.appendChild(make('p','tg213-natural-summary',d.summary));
 }else{
   root.appendChild(make('div','tg211-wait',state&&state.state==='failed'?'제목과 출처는 검색·RSS에서 확인됐지만, 언론사 본문은 가져오지 못했습니다. RSS가 기사 본문을 제공하지 않거나 접근 제한·페이지 구조·통신 문제일 수 있습니다. 제목을 기사 내용처럼 요약하지 않으며 원문 링크와 수집 기록은 유지합니다.':'선택한 기사를 최우선으로 확인하고 있습니다. 3초 안에 정독이 완료되지 않으면 원문 조회·번역을 계속 진행하고, 완료 즉시 이 화면을 갱신합니다.'));
 }
 var growth=window.NTV210_THEME_GROWTH,likes=growth&&growth.states?growth.states(e):{heart:false,trash:false};
 var reactions=make('div','tg213-reactions');[['heart',likes.heart?'♥ 좋아요':'♡ 좋아요'],['trash',likes.trash?'↶ 싫어요 취소':'🗑 싫어요']].forEach(function(pair){var b=make('button','tg213-reaction',pair[1]);b.type='button';b.setAttribute('aria-pressed',String(!!likes[pair[0]]));b.addEventListener('click',function(){if(growth&&growth.vote&&growth.vote(e,pair[0])!==null)renderOpened();});reactions.appendChild(b);});
 var original=make('button','tg213-reaction tg213-original-link','원본보기 ↗');original.type='button';original.addEventListener('click',function(){if(valid(originalUrl(e)))publicUrl(originalUrl(e));});reactions.appendChild(original);root.appendChild(reactions);
 var info=make('div','tg213-detail-foot');
 if((state&&state.state==='failed')||(d&&d.partial)){var retry=make('button','tg211-action','원문 다시 불러오기');retry.type='button';retry.addEventListener('click',function(){renderOpened();prepare(e,true,true).then(function(){if(opened&&articleKey(opened.e)===articleKey(e))renderOpened();});});info.appendChild(retry);}
 root.appendChild(info);holder.replaceChildren(root);holder.scrollTop=y;
}
function onList(){closeDetail();}
function readCurrent(){var radio=document.getElementById('rLong');if(!radio||!radio.checked)return false;
 // Do not fall through to the old generic whole-page reader, even when no article is open.
 if(!opened)return true;
 // Common header toggles selection/read-stop; stopping must NEVER start the same summary again.
 var dockRead=document.querySelector('[data-ntv110-read]');
 if(dockRead&&/읽기정지|읽기 중지/.test(dockRead.textContent||'')){stopVoice();return true;}
 if(viewMode!=='summary'){viewMode='summary';renderOpened();}
 var p=document.querySelector('#tg212-overlay .tg213-natural-summary');
 // This exact displayed paragraph, and ONLY this paragraph, is spoken. No title, provider, original, or buttons.
 var visibleSummary=p&&p.textContent&&p.textContent.trim();
 if(!visibleSummary)return true;stopVoice();talk(visibleSummary);return true;
}
document.addEventListener('click',function(ev){var nav=ev.target&&ev.target.closest?ev.target.closest('#mainNav label[for]'):null;if(nav&&nav.getAttribute('for')!=='rLong'){stopVoice();if(opened)closeDetail();}},true);
// Android system Back delegates here before switching the radio route to HOME.
function consumeBack(){if(opened)return closeDetail();var growth=window.NTV210_THEME_GROWTH;var route=document.getElementById('rLong');return !!(route&&route.checked&&growth&&growth.backTheme&&growth.backTheme());}
document.addEventListener('keydown',function(ev){if(ev.key==='Escape'&&consumeBack()){ev.preventDefault();ev.stopPropagation();}},true);
document.addEventListener('change',function(ev){if(opened&&ev.target&&ev.target.matches&&ev.target.matches('input.route-radio')&&ev.target.id!=='rLong')closeDetail();},true);
function style(){var el=make('style');el.id='tg211-css';el.textContent=`
 #tg212-overlay{position:fixed!important;top:var(--ntv127-symbol-total,134px)!important;left:0!important;right:0!important;bottom:0!important;z-index:2147481400!important;background:#fff!important;display:flex!important;flex-direction:column!important;max-width:100vw!important;overflow:hidden!important;touch-action:auto!important;color:#172a42!important;font-family:system-ui,-apple-system,'Noto Sans KR',sans-serif}
 #tg212-overlay *{box-sizing:border-box}
 #tg212-overlay button{font-family:inherit;touch-action:manipulation;cursor:pointer}
 #tg212-overlay .tg212-header{display:flex;justify-content:space-between;align-items:center;flex:0 0 auto;gap:6px;min-height:62px;background:white;z-index:2;border-bottom:1px solid #e3e8ef;padding:8px 10px}
 #tg212-overlay .tg212-caption{font-size:16px}
 #tg212-overlay .tg212-close{border:1px solid #d8e0e9;background:#f7f9fc;color:#203c5b;border-radius:11px;font-size:15px;font-weight:800;min-height:44px;padding:9px 12px}
 #tg212-overlay .tg212-scroller{overflow-x:hidden!important;overflow-y:auto!important;overscroll-behavior-y:contain!important;-webkit-overflow-scrolling:touch!important;touch-action:pan-y!important;min-height:0!important;flex:1 1 auto!important;padding:16px max(15px,calc((100vw - 700px)/2)) calc(30px + env(safe-area-inset-bottom,0px))!important;scroll-behavior:auto!important}
 #tg212-overlay .tg212-bottom-close{border:1px solid #d5dce8;background:white;color:#364e6b;border-radius:9px;padding:10px 14px;font-size:14px;font-weight:800}
 #tg212-overlay .tg212-message{font-size:12px;color:#8a5760}
 .tg213-reactions{display:flex;flex-wrap:wrap;gap:8px;margin:13px 0}.tg213-reaction{padding:10px 13px;background:#fafafa;border:1px solid #dde5ef;border-radius:10px;font-size:14px;font-weight:700;color:#4e5c70}.tg213-reaction[aria-pressed="true"]{color:#bc3748;background:#fff4f5;border-color:#eec3ca}
 .tg213-switches{display:flex;gap:8px;margin:14px 0 10px} .tg213-switch{flex:1;border:1px solid #dce3ed;background:#f7f9fc;color:#425772;border-radius:10px;padding:11px 8px;font-size:14px;font-weight:800}
 .tg213-switch[aria-pressed="true"]{background:#e8f4fc;color:#126296;border-color:#a2cbe8}
 .tg213-natural-summary,.tg213-original{font-size:17px;line-height:1.92;color:#283e55;white-space:pre-wrap;overflow-wrap:anywhere;margin:16px 1px 22px;max-width:100%;user-select:text;-webkit-user-select:text}
 .tg213-detail-foot{display:flex;flex-wrap:wrap;gap:9px;margin:22px 0 45px}
 .tg211-brief{margin-top:9px;font-size:13px;color:#485569;line-height:1.65}.tg211-brief p{margin:4px 0 0;font-size:14px;white-space:normal;overflow:visible;display:block;max-height:none;line-clamp:unset;-webkit-line-clamp:unset}.tg211-brief-label{font-weight:800;color:#59667a;font-size:12px}.tg211-placeholder{color:#9da4af;font-size:12px}
 .tg211-actions,.tg211-detail-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}.tg211-action{border:1px solid #dde3ec;border-radius:9px;background:#f9fafb;padding:8px 10px;font-size:12px;font-weight:750;color:#435269}.tg211-detail{padding:6px 0 24px}.tg211-title{font-size:23px;line-height:1.45;color:#172a42;margin:7px 0 12px;overflow-wrap:anywhere}.tg211-method{font-size:12px;color:#778392;line-height:1.7}
 .tg211-section{border:1px solid #edf0f4;border-radius:12px;padding:14px;margin:12px 0}.tg211-section h3{font-size:16px;color:#172a42;margin:0 0 9px}.tg211-section p{font-size:15px;line-height:1.85;color:#3e4c60;margin:0;white-space:pre-wrap;overflow-wrap:anywhere}.tg211-wait{padding:20px;border:1px dashed #d9dee7;border-radius:12px;font-size:14px;line-height:1.8;color:#59677a}.tg211-primary{border:0;background:#e74453;color:white;border-radius:9px;padding:10px 14px;font-size:13px;font-weight:800}.tg211-primary:disabled{opacity:.45}
 `;document.head.appendChild(el);}
style();(function(){var el=document.createElement('style');el.id='tg-v217-compact';el.textContent='#tg212-overlay{-webkit-text-size-adjust:100%;text-size-adjust:100%} #tg212-overlay .tg212-header{min-height:48px!important;padding:6px 10px!important;gap:8px!important} #tg212-overlay .tg212-close{min-height:44px!important;font-size:16px!important;padding:7px 10px!important} #tg212-overlay .tg212-scroller{padding-top:10px!important} #tg212-overlay .tg211-title{font-size:20px!important;line-height:1.45!important} #tg212-overlay .tg213-switches{gap:8px!important;margin:9px 0!important} #tg212-overlay .tg213-switch{min-height:44px!important;padding:8px!important;font-size:16px!important} #tg212-overlay .tg213-natural-summary,#tg212-overlay .tg213-original{font-size:17px!important;line-height:1.7!important;margin:10px 0 14px!important} #tg212-overlay .tg211-method,#tg212-overlay .tg211-wait{font-size:16px!important;line-height:1.6!important} #tg212-overlay .tg213-reactions{gap:8px!important;margin:10px 0!important} #tg212-overlay .tg213-reaction,#tg212-overlay .tg211-action,#tg212-overlay .tg212-bottom-close{min-height:44px!important;padding:9px 10px!important;font-size:16px!important} #tg212-overlay .tg213-detail-foot{gap:8px!important;margin:12px 0 22px!important}';document.head.appendChild(el)})();
// V219: common article detail UI, one navigation control and one action row, all 20 themes.
(function(){var st=make('style');st.id='ntv219-theme-article-ui';st.textContent=`
 #tg212-overlay .tg212-header{min-height:54px!important;display:grid!important;grid-template-columns:auto 1fr!important;gap:8px!important;padding:5px 12px!important}
 #tg212-overlay .tg212-close{min-height:44px!important;padding:8px 12px!important;font-size:17px!important}
 #tg212-overlay .tg212-caption{font-size:20px!important;text-align:center!important;margin-right:0!important}
 #tg212-overlay .tg212-scroller{padding:12px 12px calc(28px + env(safe-area-inset-bottom,0px))!important}
 #tg212-overlay .tg211-detail{padding:4px 0 16px!important}
 #tg212-overlay .tg211-title{font-size:22px!important;line-height:1.42!important;margin:4px 0 9px!important}
 #tg212-overlay .tg-detail-sub{font-size:16px!important;line-height:1.5!important;margin:0 0 10px!important}
 #tg212-overlay .tg213-switches{gap:4px!important;margin:10px 0 8px!important}
 #tg212-overlay .tg213-switch{min-height:48px!important;padding:8px 6px!important;font-size:17px!important}
 #tg212-overlay .tg213-natural-summary,#tg212-overlay .tg213-original{font-size:17px!important;line-height:1.68!important;margin:9px 0 13px!important}
 #tg212-overlay .tg211-method,#tg212-overlay .tg211-wait{font-size:16px!important;line-height:1.58!important;margin:7px 0 10px!important}
 #tg212-overlay .tg213-reactions{display:flex!important;flex-wrap:nowrap!important;gap:4px!important;width:100%!important;margin:10px 0 12px!important}
 #tg212-overlay .tg213-reaction{flex:1 1 0!important;min-width:0!important;min-height:48px!important;padding:8px 3px!important;font-size:16px!important;font-weight:800!important;text-align:center!important;white-space:nowrap!important;line-height:1.25!important}
 #tg212-overlay .tg213-detail-foot{gap:4px!important;margin:8px 0 15px!important}
 #tg212-overlay .tg213-detail-foot .tg211-action{min-height:48px!important;font-size:16px!important;padding:9px 12px!important}
 `;document.head.appendChild(st);})();
function seedKoreanTitle(e,title){if(!e||!title||!/[가-힣]/.test(String(title)))return false;
 titles[articleKey(e)]={value:String(title),at:Date.now()};save(TITLE_STORE,titles,240);return true;}
function seedVerified(e,verified,summary){
 var body=String(verified&&verified.articleText||'');if(body.length<170)return false;
 var text=String(summary||'').trim();if(!text)text=summaryExtract(body)||'';
 if(!text)return false;
 if(/^[^가-힣]*$/.test(text)&&/[A-Za-z]/.test(text))return false;
 store(e,{state:'ready',summary:text,original:body,originalKo:needsKo(body)?'':body,sourceLength:body.length,
 partial:verified.status==='partial',finalUrl:verified.finalUrl||e.url,at:Date.now(),revision:'V227'});
 if(verified.finalUrl)saveVerifiedSource(e,verified.finalUrl);
 return true;
}
window.NTV211_THEME_ARTICLE={seedKoreanTitle:seedKoreanTitle,seedVerified:seedVerified,beginList:beginList,mount:mount,prefetch:function(e){if(e&&!ready(e))return prepare(e,false);return Promise.resolve(ready(e));},open:open,onList:onList,readCurrent:readCurrent,stop:stopVoice,consumeBack:consumeBack,close:closeDetail,version:'V230'};
})();

/* V229: prevent final reaction row being obscured by Galaxy fixed bottom navigation. */
(function(){var st=document.createElement('style');st.id='ntv229-article-bottom-title';st.textContent=`
#tg212-overlay .tg212-scroller{padding-bottom:max(88px,calc(38px + env(safe-area-inset-bottom,0px)))!important;overscroll-behavior-y:contain!important;overflow-y:auto!important}
#tg212-overlay .tg211-detail{padding-bottom:44px!important}
#tg212-overlay .tg211-title{font-weight:500!important;letter-spacing:-.4px!important}
#tg212-overlay .tg213-reactions{margin:14px 0 28px!important}
`;document.head.appendChild(st);})();


/* V230: keep the entire reaction row scrollable above fixed native menu. */
(function(){var css=document.createElement('style');css.id='ntv230-article-end';css.textContent=`
#tg212-overlay{min-height:0!important;max-height:none!important;}
#tg212-overlay .tg212-scroller{min-height:0!important;flex:1 1 auto!important;overflow-y:auto!important;overflow-x:hidden!important;
 overscroll-behavior-y:contain!important;-webkit-overflow-scrolling:touch!important;
 padding:12px 12px 64px!important;scroll-padding-bottom:60px!important;}
#tg212-overlay .tg211-detail{margin:0!important;padding:0 0 30px!important;min-height:0!important;}
#tg212-overlay .tg213-reactions{display:flex!important;flex-wrap:nowrap!important;align-items:stretch!important;
 margin:10px 0 12px!important;padding:0 0 6px!important;min-height:54px!important;}
#tg212-overlay .tg213-reaction{min-height:50px!important;line-height:1.3!important;}
#tg212-overlay .tg213-detail-foot{margin:0!important;min-height:0!important;}
`;document.head.appendChild(css);})();
