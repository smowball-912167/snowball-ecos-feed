/* V238: four approved investment factors; no invented scoring or substitution of indicators.
   Reads the SAME verified market snapshot as Correlation Indicators. Additional verified
   observations may be supplied by a source-specific collector using the strict ingest API.
   The 65/35 weighting is ONLY for the same Korea/US indicator, never for unrelated proxies. */
(function(root){'use strict';
 var KEY='NOONTANGI_OFFICIAL_INDICATORS_V238';
 var ALLOWED={us10yOfficial:'%',usCurveSpread:'%p',krRate:'%',usRate:'%',krCpi:'% YoY',usCpi:'% YoY',usCoreCpi:'% YoY',usBei:'%',us02y:'%',kr03y:'%',ismPmi:'지수',oecdCli:'지수',krExports:'% YoY',twExports:'% YoY',semiconductorExports:'억원',semiconductorShipments:'',semiconductorPrice:'',semiconductorInventory:'',krImportPrice:'지수',krPpi:'지수',fearGreed:'지수',customerDeposits:'억원',creditBalance:'억원',creditRatio:'%',vkospi:'지수',foreign20d:'억원',us10y20dma:'%',wti60dma:'USD',krwVolatility:'%',fxChangePeriod:''};
 function read(k){try{return JSON.parse(localStorage.getItem(k)||'null')}catch(_){return null}}
 function n(v){if(v===null||v===undefined||v==='')return null;var x=Number(v);return isFinite(x)?x:null}
 function fmt(v,d){return v==null?'—':Number(v).toLocaleString('ko-KR',{maximumFractionDigits:d==null?2:d})}
 function when(v){var t=Date.parse(v||'');return isFinite(t)?t:NaN}
 function valid(entry){if(!entry||typeof entry!=='object'||!Object.prototype.hasOwnProperty.call(ALLOWED,entry.id))return false;
  var v=n(entry.value),at=when(entry.asOf),source=String(entry.source||'').trim(),label=String(entry.period||'').trim();
  return v!==null&&isFinite(at)&&at<=Date.now()+86400000&&at>=Date.now()-395*86400000&&source.length>=5&&source.length<=160&&label.length>0&&label.length<=24&&entry.verified===true;}
 function ingest(items){if(!Array.isArray(items))return 0;var before=read(KEY)||{},clean=Object.assign({},before),count=0;
  items.forEach(function(x){if(!valid(x))return;clean[x.id]={id:x.id,value:n(x.value),asOf:x.asOf,period:x.period,source:x.source,verified:true,history:Array.isArray(x.history)?x.history.filter(function(y){return y&&n(y.value)!==null&&isFinite(when(y.asOf))}).slice(-36):[]};count++});
  if(count){try{localStorage.setItem(KEY,JSON.stringify(clean));window.dispatchEvent(new Event('ntv238:indicators'))}catch(_){return 0}}return count;}
 function official(id){var x=(read(KEY)||{})[id];if(!valid(x))return null;
  var t=when(x.asOf),max=/^(krRate|usRate|oecdCli)$/.test(id)?150:/^(krExports)$/.test(id)?105:/^(krPpi)$/.test(id)?95:/^(krCpi|usCpi|usCoreCpi|ismPmi|twExports|krImportPrice|semiconductorExports|semiconductorShipments|semiconductorPrice|semiconductorInventory)$/.test(id)?70:/^(customerDeposits|creditBalance|creditRatio|foreign20d)$/.test(id)?14:8;
  if(Date.now()-t>max*86400000)return null;return x;}
 function sources(){var q=(root.NOONTANGI_MARKET_ENV&&root.NOONTANGI_MARKET_ENV.snapshot&&root.NOONTANGI_MARKET_ENV.snapshot())||read('NOONTANGI_MARKET_ENV_V2')||{},m={};(q.items||[]).forEach(function(x){if(x&&x.id&&x.valid===true&&n(x.price)!==null&&n(x.ts)!==null&&Date.now()-n(x.ts)<120*3600000)m[x.id]=x});
  var ext=read('NOONTANGI_MARKET_EXTERNAL_V1')||{},flow=Array.isArray(ext.flow)?ext.flow.filter(function(x){if(!x||x.valid!==true||!/^20\d{6}$/.test(String(x.bizdate||'')))return false;var d=String(x.bizdate),ms=Date.parse(d.slice(0,4)+'-'+d.slice(4,6)+'-'+d.slice(6,8)+'T15:30:00+09:00');return isFinite(ms)&&Date.now()-ms<7*86400000;}):[];
  return {q:m,flow:flow};}
 function line(id,label,suffix){var x=official(id);return {id:id,label:label,status:x?'실제값 확인':'자료 미연결',value:x?fmt(x.value,3)+(suffix||''):null,source:x?x.source:null,asOf:x?x.period:null};}
 function ecosMonthlyRef(id,label){var x=(read('NOONTANGI_ECOS_MONTHLY_REFERENCES_V247')||{})[id],t=x&&when(x.asOf);
  if(!x||x.verified!==true||x.cycle!=='M'||!/^20\d{4}$/.test(String(x.period||''))||n(x.value)===null||!isFinite(t)||t>Date.now()+86400000||Date.now()-t>105*86400000)return null;
  return {id:id,label:label+' · ECOS 월별 참고',status:'월별 참고',value:fmt(x.value,2)+'억 원',source:x.source,asOf:x.period,supplementary:true};}
 function sharedReference(id,label,expectedCycle,suffix,maximum,divider){
  var api=root.NOONTANGI_ECOS_V245,x=api&&api.getSharedSeries&&api.getSharedSeries(id);
  if(!x||x.cycle!==expectedCycle||!Array.isArray(x.points)||!x.points.length||!/^20\d{4}(?:\d{2})?$/.test(String(x.latest||'')))return null;
  var latest=x.points[x.points.length-1],v=n(latest&&latest.value);
  if(!latest||String(latest.period)!==String(x.latest)||v===null||v<=0||v>maximum)return null;
  var num=divider?v/divider:v;
  if(!isFinite(num)||num<=0)return null;
  var hint=expectedCycle==='M'?'ECOS 월별 참고':'ECOS 일별 참고';
  return {id:'ecosRef_'+id,label:label+' · '+hint,status:'참고자료',value:fmt(num,3)+(suffix||''),
   source:'한국은행 ECOS 경유 · '+x.table+'/'+x.item+' · '+hint+' · 기존 일별/YoY 대체 아님',asOf:x.latest,supplementary:true};
 }
 function quote(s,id,label,suffix,dec){var x=s.q[id];return {id:id,label:label,status:x?'시세 확인':'자료 미연결',value:x?fmt(x.price,dec==null?2:dec)+(suffix||''):null,source:x?x.source||'기존 상관지수 시세':null,asOf:x?new Date(Number(x.ts)).toLocaleString('ko-KR',{month:'numeric',day:'numeric'}):null,change:x?n(x.changePct):null};}
 function signal(id){var x=official(id);if(!x)return null;var v=x.value,h=Array.isArray(x.history)?x.history:[],prev=h.length?h[h.length-1]:null;var pv=prev&&n(prev.value),older=h.length>1?n(h[h.length-2].value):null;
  if(id==='krRate'||id==='usRate'){if(pv===null)return null;return v<pv?'긍정':v>pv?'부정':'보합'}
  if(id==='krCpi'){if(pv===null)return null;return v>=2&&v<3&&pv>=2&&pv<3?'긍정':v>=3&&pv>=3?'부정':'조건 확인 중'}
  if(id==='usCpi'){if(pv===null)return null;return v>=2&&v<=2.5&&v<=pv?'긍정':v>=3.5&&pv>=3.5?'부정':'조건 확인 중'}
  return null;}
 function pair(kr,us,title){var a=official(kr),b=official(us);if(!a||!b)return null;
  var ks=signal(kr),usig=signal(us),usable=['긍정','부정','보합'];var judgment='양국 신호 확인 중';
  if(usable.indexOf(ks)>=0&&usable.indexOf(usig)>=0){
   if(ks===usig)judgment=ks;
   else if(ks==='보합'&&usig==='보합')judgment='보합';
   else if(ks==='긍정'&&usig==='부정')judgment='국내 우세 긍정';
   else if(ks==='부정'&&usig==='긍정')judgment='국내 우세 부정';
   else if(ks==='보합')judgment='국내 보합 · 미국 '+usig;
   else judgment='국내 '+ks+' · 미국 보합';
  }
  return {title:title,domestic:fmt(a.value,2)+'%',us:fmt(b.value,2)+'%',koreanSignal:ks||'추세 미확인',usSignal:usig||'추세 미확인',ratio:'국내 65% · 미국 35%',verdict:judgment};}
 function build(){var s=sources(),flows=[];s.flow.forEach(function(x){var market=String(x.market||'시장'),fore=n(x.foreign),inst=n(x.institutional);if(fore!==null)flows.push({id:'foreign'+market,label:market+' 외국인 순매수',status:'최근 수급 확인',value:(fore>0?'+':'')+fmt(fore)+'억 원',source:'기존 수급 수집 원장',asOf:String(x.bizdate)});if(inst!==null)flows.push({id:'institutional'+market,label:market+' 기관 순매수',status:'최근 수급 확인',value:(inst>0?'+':'')+fmt(inst)+'억 원',source:'기존 수급 수집 원장',asOf:String(x.bizdate)})});
  var groups=[
   {name:'통화정책 및 금리',items:[quote(s,'usdkrw','원/달러 환율','원'),line('krwVolatility','원/달러 환율 변동성','%'),line('krRate','한국은행 기준금리','%'),line('usRate','미국 연준 기준금리','%'),line('kr03y','한국 국고채 3년물','%'),(official('us10yOfficial')?line('us10yOfficial','미국 국채 10년물','%'):quote(s,'us10y','미국 국채 10년물','%')),line('us02y','미국 국채 2년물','%'),line('usCurveSpread','미국채 10년-2년 금리차','%p'),line('us10y20dma','미국채 10년물 20일선','%')].concat([sharedReference('kr_treasury_10y_d','한국 국고채 10년물','D','%',30),sharedReference('us_policy_m','미국 정책금리','M','%',30)].filter(Boolean)),pair:pair('krRate','usRate','한·미 기준금리'),bull:['원/달러 환율 하향 안정화(원화 강세)','한국·미국 금리 인하 사이클 진입','국고채·미국채 금리 급등세 완화','미국채 10년물 20일 이동평균 아래 하강','미국 10년·2년 금리차 역전에서 정상화 전환'],bear:['환율 급등(원화 약세·자금 이탈)','고금리 기조 장기화·추가 금리 인상','국고채·미국채 금리 급등','미국 장단기 금리차 역전 심화']},
   {name:'경기 사이클 및 성장',items:[line('krExports','한국 수출증가율 (YoY)','%'),line('twExports','대만 수출증가율 (YoY)','%'),line('semiconductorExports','한국 반도체 수출액','억 원'),line('semiconductorShipments','한국 반도체 출하량',''),line('semiconductorPrice','반도체 가격',''),line('semiconductorInventory','반도체 재고',''),line('ismPmi','미국 ISM 제조업 PMI',''),line('oecdCli','OECD 경기선행지수 CLI','')],bull:['한국 수출증가율 0% 초과·플러스 전환','반도체 수출액·출하량·가격 상승','미국 ISM PMI 50 초과 또는 3개월 연속 반등','OECD CLI 100 초과 및 상승'],bear:['한국 수출증가율 연속 음수','반도체 재고 증가 및 단가 하락','미국 ISM PMI 48 미만 및 하향(50 미만 수축 참고)','OECD CLI 100 미만 및 하락']},
   {name:'인플레이션 및 물가',items:[line('krCpi','한국 소비자물가 K-CPI','%'),line('krImportPrice','한국 수입물가지수',''),line('krPpi','한국 생산자물가지수 PPI',''),line('usCpi','미국 CPI','%'),line('usCoreCpi','미국 근원 CPI','%'),line('usBei','미국 10년 BEI','%'),quote(s,'wti','국제유가 WTI','$'),line('wti60dma','WTI 60일 평균','$')].concat([sharedReference('us_cpi_m','미국 CPI 원지수','M','',1000),sharedReference('wti_m','국제유가 WTI','M','달러/배럴',1000),sharedReference('gold_m','국제 금','M','달러/트로이온스',20000),sharedReference('copper_m','국제 구리','M','달러/톤',50000)].filter(Boolean)),pair:pair('krCpi','usCpi','한·미 CPI'),bull:['한국 CPI 2%대 수렴·안정','수입물가 상승세 둔화','미국 CPI 2.0~2.5% 수렴·BEI 2.3% 이하 안정','WTI 60일 평균 이하에서 하향 안정'],bear:['한국 CPI 3% 이상 지속·재반등','수입물가지수 급등(원가 부담)','미국 CPI 예상치 상회 또는 3.5% 이상 지속','WTI 90달러 이상 급등 등 스태그플레이션 우려']},
   {name:'시장 심리 및 수급',items:[line('fearGreed','CNN 공포·탐욕지수','/100'),line('foreign20d','외국인 최근 20거래일 누적 순매수','억 원'),line('customerDeposits','고객예탁금','억 원'),line('creditBalance','신용융자 잔고','억 원'),line('creditRatio','신용잔고율','%'),line('vkospi','VKOSPI','')].concat([ecosMonthlyRef('customerDepositsMonthly','고객예탁금'),ecosMonthlyRef('creditBalanceMonthly','신용융자 잔고')].filter(Boolean),flows),bull:['CNN 공포·탐욕지수 40~60','코스피·코스닥 외국인 연속 순매수·기관 매수','외국인 최근 20일 누적 순매수 양수 전환','고객예탁금 증가·신용잔고 비율 2% 미만'],bear:['CNN 공포·탐욕지수 20 미만 또는 80 초과','외국인 대량 연속 순매도','신용잔고 과열 및 반대매매 위험 증가','VKOSPI 급등']}
  ];return groups;}
 root.NOONTANGI_FOUR_FACTORS={build:build,ingest:ingest,version:'V238',official:official};
 if(typeof module==='object'&&module.exports)module.exports=root.NOONTANGI_FOUR_FACTORS;
})(typeof window!=='undefined'?window:globalThis);
