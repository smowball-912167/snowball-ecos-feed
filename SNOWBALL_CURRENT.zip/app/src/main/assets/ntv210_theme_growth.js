/* 눈탱이 V216: 성장테마 목록의 단일 렌더러. 원문 확인/번역/읽기는 NTV211 서비스로 위임. */
(function(){'use strict';
var KEY='ntv210-theme-growth-favorites-v1', HIDE_KEY='ntv213-theme-muted-v1', PAGE_SIZE=20;
var ICONS=['▦','✈','⚡','♟','▣','⚓','✚','◉','◈','◆','🚀','◇','🚘','▤','◐','✜','◍','☀','▥','⬡'];
var TABS=[['all','전체'],['article','기사'],['youtube','유튜브'],['disclosure','공시'],['report','보고서'],['broadcast','방송']];
function make(tag,cls,txt){var e=document.createElement(tag);if(cls)e.className=cls;if(txt!==undefined)e.textContent=txt;return e;}
function stored(){try{var data=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(data)?data.filter(function(x){return typeof x==='string';}):[];}catch(_){return [];}}
function storedHidden(){try{var x=JSON.parse(localStorage.getItem(HIDE_KEY)||'[]');return Array.isArray(x)?x:[];}catch(_){return [];}}
function saveHidden(ids){try{localStorage.setItem(HIDE_KEY,JSON.stringify(ids));return true;}catch(_){return false;}}
function save(ids){try{localStorage.setItem(KEY,JSON.stringify(ids));return true;}catch(_){return false;}}
function linkOpen(url){if(typeof url!=='string'||!/^https:\/\//i.test(url))return;
  try{if(window.SnowballBookmarks&&typeof window.SnowballBookmarks.openUrl==='function')window.SnowballBookmarks.openUrl(url);
  else if(window.Android&&typeof window.Android.openUrl==='function')window.Android.openUrl(url);
  else window.open(url,'_blank','noopener,noreferrer');}catch(_){window.open(url,'_blank','noopener,noreferrer');}}
function todayDate(){var d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
function launch(){
 var page=document.getElementById('pageLong'),archive=window.NT_THEME_ARCHIVE_DATA;
 if(!page||!archive||!Array.isArray(archive.DATA)||document.getElementById('ntv210-growth'))return;
 var old=archive.DATA,themes=archive.THEMES, ids=Object.keys(themes).sort(function(a,b){return Number(a)-Number(b)});
 var entriesRaw=old.map(function(x,i){return {title:String(x[0]||''),publisher:String(x[1]||''),date:String(x[2]||''),themeIds:Array.isArray(x[3])?x[3]:[],region:Array.isArray(x[4])?x[4]:[],url:String(x[5]||''),sourceVerified:!!x[6],index:i,type:'article'};});
 // Only exact article duplicates are grouped. Retain the original archive untouched.
 function headlineNorm(raw){return String(raw||'').replace(/\s+[-–|]\s+[^-–|]+$/,'').replace(/\[[^\]]+\]/g,' ').replace(/[“”‘’'"\`·,.;:!?()[\]{}~—–-]/g,' ').replace(/\s+/g,' ').trim().toLowerCase();}
 function tokens(head){var stop={뉴스:1,기사:1,국내:1,글로벌:1,속보:1,단독:1,현장:1,오늘:1,한국:1,미국:1,발표:1,관련:1,기업:1,시장:1,기술:1,성장:1,최신:1,연구:1,전망:1,산업:1,증시:1,주가:1,소식:1,단계:1,위해:1,대한:1,눈길:1,AI:1,ai:1,market:1,size:1,share:1,growth:1,report:1,by:1,for:1,the:1,of:1,on:1,benefits:1,advanced:1,news:1,today:1,latest:1,small:1,modular:1,reactors:1};return headlineNorm(head).split(/\s+/).map(function(t){return t.replace(/(?:은|는|이|가|을|를|의|에|와|과|에서|으로|에게|에도|까지|부터|했다|한다|한다는|이라고|이라며|라고|됐다|되다|되며|기자)$/,'');}).filter(function(t){return t.length>=2&&!stop[t];});}
 function nearSameEvent(a,b){
   if(a.date!==b.date)return false;
   var sa=tokens(a.title),sb=tokens(b.title);if(sa.length<3||sb.length<3)return false;
   var set=new Set(sa),share=sb.filter(function(w){return set.has(w);});
   // Require multiple concrete shared terms, both title coverage, and a shared distinctive name/numeric anchor.
   var min=Math.min(sa.length,sb.length),cov=share.length/min,full=share.length/Math.max(sa.length,sb.length);
   var anchored=share.some(function(w){return /[0-9]/.test(w)||/[a-z]/i.test(w)||w.length>=4;});
   return anchored&&share.length>=3&&cov>=.70&&full>=.46;
 }
 function dedupe(records){var out=[],byKey=Object.create(null),byDay=Object.create(null);
   records.forEach(function(e){var title=headlineNorm(e.title),url=String(e.url||'').replace(/[#?].*$/,'').replace(/\/$/,'');
     var key=url?'url:'+url:'title:'+e.date+'|'+title,tKey='title:'+e.date+'|'+title;
     var existing=byKey[key]||byKey[tKey];
     if(!existing){var sameDay=byDay[e.date]||[];for(var i=0;i<sameDay.length;i++){if(nearSameEvent(sameDay[i],e)){existing=sameDay[i];break;}}}
     if(existing){existing.duplicates.push(e);e.themeIds.forEach(function(id){if(existing.themeIds.indexOf(id)<0)existing.themeIds.push(id);});e.region.forEach(function(r){if(existing.region.indexOf(r)<0)existing.region.push(r);});byKey[key]=existing;byKey[tKey]=existing;
     }else{var item=Object.assign({},e,{themeIds:e.themeIds.slice(),region:e.region.slice(),duplicates:[]});out.push(item);byKey[key]=item;byKey[tKey]=item;(byDay[e.date]||(byDay[e.date]=[])).push(item);}
   });return out;
 }

 // V220: real on-demand growth-theme discovery using the existing Android public-news bridge.
 // The original 589 records remain immutable. These live records are additive and persist locally.
 var LIVE_KEY='ntv220-theme-new-articles-v1', LIVE_CHECK_KEY='ntv220-theme-fetch-state-v1';
 var LIVE_QUERIES={
  1:['HBM OR 첨단패키징 when:14d','__GLOBAL__HBM OR advanced packaging when:14d'],
  2:['방산 OR 항공우주 when:14d','__GLOBAL__defense OR aerospace when:14d'],
  3:['AI 데이터센터 OR HVDC when:14d','__GLOBAL__AI data center OR HVDC when:14d'],
  4:['로봇 OR 피지컬AI when:14d','__GLOBAL__humanoid robot OR physical AI when:14d'],
  5:['2차전지 OR ESS when:14d','__GLOBAL__battery OR energy storage when:14d'],
  6:['조선 OR LNG선 when:14d','__GLOBAL__shipbuilding OR LNG ship when:14d'],
  7:['ADC OR CDMO when:14d','__GLOBAL__ADC OR CDMO when:14d'],
  8:['원전 OR SMR when:14d','__GLOBAL__SMR OR nuclear reactor when:14d'],
  9:['광통신 OR CPO when:14d','__GLOBAL__CPO OR optical networking when:14d'],
  10:['희토류 OR 핵심광물 when:14d','__GLOBAL__rare earth OR critical minerals when:14d'],
  11:['위성 OR 우주발사체 when:14d','__GLOBAL__LEO satellite OR rocket launch when:14d'],
  12:['스테이블코인 OR 토큰증권 when:14d','__GLOBAL__stablecoin OR tokenized securities when:14d'],
  13:['자율주행 OR SDV when:14d','__GLOBAL__autonomous driving OR software defined vehicle when:14d'],
  14:['반도체 장비 OR 소부장 when:14d','__GLOBAL__semiconductor equipment OR chipmaking tools when:14d'],
  15:['첨단소재 OR 기능성필름 when:14d','__GLOBAL__advanced materials OR specialty film when:14d'],
  16:['분자진단 OR 정밀의료 when:14d','__GLOBAL__molecular diagnostics OR precision medicine when:14d'],
  17:['열관리 OR 공조 when:14d','__GLOBAL__thermal management OR HVAC when:14d'],
  18:['태양광 OR 재생에너지 when:14d','__GLOBAL__solar OR renewable energy when:14d'],
  19:['스마트팩토리 OR 산업자동화 when:14d','__GLOBAL__smart factory OR industrial automation when:14d'],
  20:['사이버보안 OR 양자보안 when:14d','__GLOBAL__cybersecurity OR quantum security when:14d']
 };
 function localGet(k,fallback){try{var d=JSON.parse(localStorage.getItem(k)||'null');return d===null?fallback:d;}catch(_){return fallback;}}
 var liveRecords=localGet(LIVE_KEY,[]),lastChecks=localGet(LIVE_CHECK_KEY,{});
 if(!Array.isArray(liveRecords))liveRecords=[];
 if(!lastChecks||typeof lastChecks!=='object'||Array.isArray(lastChecks))lastChecks={};
 function localPut(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true;}catch(_){return false;}}
 function liveHash(s){var h=2166136261;for(var i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(36);}
 function safeDate(raw){if(!raw)return '';var d=new Date(raw);return isNaN(d.getTime())?'':d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
 function liveToEntry(rec){return {title:rec.title,publisher:rec.publisher||'',date:rec.date||'',themeIds:rec.themeIds||[],region:rec.region||[],url:rec.url,sourceVerified:false,index:'live_'+liveHash(rec.url+'|'+rec.date),type:'article',isLive:true};}
 liveRecords=liveRecords.filter(function(x){return x&&typeof x.title==='string'&&typeof x.url==='string'&&/^https:\/\//i.test(x.url)&&Array.isArray(x.themeIds);});
 function sortedEntries(){return dedupe(entriesRaw.concat(liveRecords.map(liveToEntry))).sort(function(a,b){return (b.date||'').localeCompare(a.date||'');});}
 var entries=sortedEntries();
 var collecting=Object.create(null),collectStatus=Object.create(null),bridgePending=Object.create(null),bridgeSeq=0,bridgeInstalled=false;
 function installLiveBridge(){if(bridgeInstalled)return;var dest=window.NOONTANGI_EXTERNAL_INFO=window.NOONTANGI_EXTERNAL_INFO||{},prior=dest.resolve;
  dest.resolve=function(id,raw){if(String(id||'').indexOf('tg220search_')===0){var p=bridgePending[id];if(!p)return false;delete bridgePending[id];clearTimeout(p.timer);try{p.resolve(JSON.parse(String(raw||'{}')));}catch(_){p.resolve({error:'INVALID_JSON',items:[]});}return true;}return typeof prior==='function'?prior(id,raw):false;};bridgeInstalled=true;}
 function searchThemeFeed(query){return new Promise(function(resolve){var nativeBridge=window.SnowballExternalInfo;
  if(!nativeBridge||typeof nativeBridge.searchNews!=='function'){resolve({error:'기기 뉴스 검색 기능에 연결되지 않았습니다.',items:[]});return;}
  installLiveBridge();var id='tg220search_'+(++bridgeSeq)+'_'+Date.now();var timer=setTimeout(function(){delete bridgePending[id];resolve({error:'뉴스 검색 응답시간 초과',items:[]});},14500);
  bridgePending[id]={resolve:resolve,timer:timer};try{nativeBridge.searchNews(query,id);}catch(err){clearTimeout(timer);delete bridgePending[id];resolve({error:'기기 뉴스 검색 요청 실패',items:[]});}
 });}
 function absorbFeed(themeId,result,lane){var count=0;if(!result||!Array.isArray(result.items)||result.fallbackUsed)return 0;
  result.items.forEach(function(it){var title=String(it.title||'').trim(),url=String(it.link||it.url||'').trim();
   if(!title||!/^https:\/\//i.test(url))return;var date=safeDate(it.pubDate),regionLabel=lane==='GLOBAL'?'GLOBAL':'KR';
   var item=liveRecords.find(function(e){return e.url===url;});
   if(item){if(item.themeIds.indexOf(themeId)<0)item.themeIds.push(themeId);if(item.region.indexOf(regionLabel)<0)item.region.push(regionLabel);return;}
   liveRecords.push({title:title,publisher:String(it.source||'').trim(),date:date,themeIds:[themeId],region:[regionLabel],url:url});count++;
  });return count;}
 function refreshTheme(themeId,force){var id=Number(themeId);if(!id||!LIVE_QUERIES[id])return Promise.resolve(false);
  if(collecting[id])return collecting[id];var check=lastChecks[id]||{},now=Date.now();
  if(!force&&check.ok&&now-Number(check.at||0)<20*60000)return Promise.resolve(false);
  collectStatus[id]='최신 기사 검색 중 · 기존 자료는 그대로 표시합니다';if(selectedTheme===id)repaintAfterLive();
  var queries=LIVE_QUERIES[id],previous=liveRecords.length;
  collecting[id]=Promise.all(queries.map(function(q){return searchThemeFeed(q);})).then(function(result){
   var success=0,added=0,errors=[];result.forEach(function(r,i){if(r&&!r.error&&!r.fallbackUsed){success++;added+=absorbFeed(id,r,i===1?'GLOBAL':'KR');}
    else errors.push(String(r&&r.error||'검색 결과 없음'));});
   if(success){lastChecks[id]={ok:true,at:Date.now()};localPut(LIVE_CHECK_KEY,lastChecks);
     // Preserve every recorded result: never silently evict older articles.
     var didPersist=localPut(LIVE_KEY,liveRecords);entries=sortedEntries();
     collectStatus[id]=didPersist?'최신 기사 확인 완료 · 새 기사 '+added+'건'+(errors.length?' · 일부 검색 실패':''):'최신 기사 '+added+'건 확인 · 기기 저장 공간 부족으로 저장 실패';
   }else{collectStatus[id]='최신 뉴스 검색에 실패했습니다. 인터넷 연결을 확인하거나 다시 시도하세요.';}
   if(selectedTheme===id)repaintAfterLive();return success>0;
  }).catch(function(){collectStatus[id]='뉴스 검색 오류 · 다시 시도할 수 있습니다';if(selectedTheme===id)repaintAfterLive();return false;}).finally(function(){delete collecting[id];if(selectedTheme===id)repaintAfterLive();});
  return collecting[id];
 }

 var fav=stored(),hidden=storedHidden(),showHidden=false,needsRefreshOnClose=false,selectedTheme=0,reporterMode=false,veteranBrowse=false,tab='all',region='ALL',term='',shown=0,current=[],lastGridScrollY=0,refreshAllBusy=false,veteranRefreshBusy=false;
 function repaintAfterLive(){if(document.getElementById('tg212-overlay')){needsRefreshOnClose=true;return;}render();}
 var st=make('style');st.id='ntv210-theme-growth-style';st.textContent=`
 #pageLong{background:#fff!important;min-height:100vh!important;padding:0 0 calc(112px + env(safe-area-inset-bottom,0px))!important;overflow-x:hidden!important}
 #pageLong>.app,#pageLong>.shared-canon-header,#pageLong>.routeBack{display:none!important}
 #ntv210-growth{font-family:system-ui,-apple-system,'Noto Sans KR',sans-serif;color:#111827;background:white;box-sizing:border-box;max-width:900px;margin:0 auto;padding:18px clamp(12px,4.2vw,30px) 36px;min-height:100vh}
 #ntv210-growth *{box-sizing:border-box} #ntv210-growth button,#ntv210-growth input,#ntv210-growth select{font-family:inherit}
 #ntv210-growth button{touch-action:manipulation;cursor:pointer}#ntv210-growth button:focus-visible,#ntv210-growth input:focus-visible,#ntv210-growth select:focus-visible{outline:3px solid #ef555e;outline-offset:2px}
 .tg-head{display:flex;justify-content:space-between;align-items:center;padding:2px 3px 24px;gap:14px}
 .tg-logo{display:flex;gap:11px;align-items:center;font-weight:900;font-size:21px;letter-spacing:-.8px}
 .tg-mark{font-weight:900;color:#df4551;font-size:42px;font-family:Georgia,serif;line-height:.65;transform:rotate(-9deg);display:inline-block}
 .tg-icons{display:flex;gap:18px;align-items:center}.tg-headbutton{border:0;background:transparent;font-size:26px;padding:6px;color:#19202b;min-height:42px;min-width:42px}
 .tg-hero{display:flex;align-items:flex-start;gap:16px;margin-bottom:20px}.tg-hero h1{font-size:clamp(31px,7vw,44px);letter-spacing:-2.2px;white-space:nowrap;line-height:1.16;margin:0;font-weight:950}
 .tg-hero h1 em{font-style:normal;color:#d43c4a}.tg-hero p{padding:2px 0 0;margin:0;color:#777e88;font-size:clamp(12px,3.4vw,16px);line-height:1.55;font-weight:550}
 .tg-find{border:1.5px solid #d3d8df;border-radius:999px;display:flex;align-items:center;height:55px;gap:10px;padding:0 17px;margin:0 0 13px;background:#fff}
 .tg-find .tg-mag{font-size:25px;color:#66727d}.tg-find input{border:0!important;outline:0!important;flex:1;min-width:0;background:transparent!important;font-size:17px!important;color:#151c28!important;padding:0!important;height:48px!important}
 .tg-find input::placeholder{color:#979da7}.tg-find button{font-size:22px;border:0;background:transparent;color:#85909c;min-width:26px;display:none}
 .tg-tabs{display:flex;gap:8px;overflow-x:auto;padding:3px 0 16px;scrollbar-width:none;-webkit-overflow-scrolling:touch}.tg-tabs::-webkit-scrollbar{display:none}
 .tg-tab{white-space:nowrap;border-radius:999px;border:1px solid #e2e7ee;background:#f7f8fa;color:#3d4652;font-size:14px;font-weight:750;min-height:40px;padding:8px 16px}
 .tg-tab[aria-pressed="true"]{background:#ef4654;color:#fff;border-color:#ef4654;box-shadow:0 2px 6px #e4475344}
 .tg-summary{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid #e7ebef;border-radius:13px;padding:14px 4px;background:#fff;box-shadow:0 2px 11px #17202a0a;margin:0 0 18px}
 .tg-stat{display:flex;flex-direction:column;align-items:center;gap:3px;min-width:0;border-right:1px solid #e3e7ec}.tg-stat:last-child{border:0}
 .tg-stat .tg-stat-head{color:#757d86;font-size:12px;font-weight:700;white-space:nowrap}.tg-stat strong{font-size:25px;font-weight:900;line-height:1.3;color:#101722}.tg-stat small{font-size:10px;color:#9ba3ab}
 .tg-notice{font-size:11px;color:#858b95;line-height:1.5;margin:0 4px 14px}
 .tg-cards{display:grid;gap:8px}.tg-card{display:flex;gap:12px;width:100%;align-items:center;border-radius:14px;border:1px solid #eff1f4;background:#fff;box-shadow:0 3px 10px #151a2209;padding:12px;text-align:left;color:#101820;min-height:98px}
 .tg-card:active{background:#fafafa}.tg-ico{background:linear-gradient(140deg,#f1f3f6,#e9edf1);color:#647380;border-radius:14px;min-width:64px;width:64px;height:64px;display:flex;align-items:center;justify-content:center;font-size:31px;line-height:1;filter:grayscale(.3)}
 .tg-card-body{flex:1;min-width:0}.tg-card-title{font-size:clamp(15px,4vw,19px);font-weight:900;line-height:1.35;letter-spacing:-.5px;overflow-wrap:anywhere}
 .tg-card-sub{font-size:12px;line-height:1.5;margin-top:7px;color:#8a9098}.tg-card-right{display:flex;align-items:center;gap:7px;flex:0 0 auto}.tg-state{font-size:11px;color:#65707c;background:#f0f2f5;padding:6px 8px;border-radius:9px;white-space:nowrap;font-weight:700}.tg-chevron{font-size:25px;color:#858d95}
 .tg-empty{padding:35px 12px;color:#777d86;text-align:center;font-size:14px;border:1px dashed #dee5ec;border-radius:12px}
 .tg-back{position:sticky;top:var(--ntv127-symbol-total,134px);z-index:1050;width:100%;text-align:left;color:#183b5d;border:1px solid #dbe7f2;background:#f7fbff;border-radius:11px;padding:13px 15px;margin-bottom:12px;font-weight:850;font-size:16px;min-height:48px;box-shadow:0 3px 10px #15304b12}.tg-back-float{position:fixed;left:12px;bottom:calc(148px + env(safe-area-inset-bottom,0px));z-index:2147481200;background:#163f66;color:#fff;border:0;border-radius:28px;padding:10px 16px;min-height:43px;font-size:14px;font-weight:850;box-shadow:0 3px 15px #102b5166}
 .tg-detail-h{font-size:23px;line-height:1.3;font-weight:900;margin:0 0 8px}.tg-detail-sub{color:#7a818b;font-size:12px;line-height:1.5;margin-bottom:18px}
 .tg-controls{display:flex;gap:10px;align-items:center;justify-content:space-between;margin-bottom:14px}.tg-controls strong{font-size:14px}.tg-hidden-toggle{font-size:11px;border:1px solid #e3e8ef;background:#fff;border-radius:9px;padding:8px;color:#5b6372}.tg-controls select{background:#f8f9fb;border:1px solid #e2e6eb;padding:8px 10px;border-radius:9px;font-size:13px}
 .tg-article{border:1px solid #e6e9ef;border-radius:12px;padding:13px;margin:0 0 9px;background:#fff}.tg-article-top{color:#818792;font-size:12px;line-height:1.5;margin-bottom:6px}
 .tg-article-line{display:flex;align-items:flex-start;gap:8px}.tg-link{border:0;background:transparent;text-align:left;padding:0;color:#182b43;font-weight:750;font-size:15px;line-height:1.5;flex:1;overflow-wrap:anywhere}
 .tg-reject{border:1px solid #e5e8ec;background:#fff;color:#6a7380;border-radius:9px;width:34px;height:34px;font-size:18px;flex:0 0 34px}.tg-reject[aria-pressed="true"]{background:#f1f3f5;color:#b9474e;border-color:#e8c5c8}.tg-bookmark{border:1px solid #e5e8ec;background:#fff;color:#6a7380;border-radius:9px;width:34px;height:34px;font-size:20px;flex:0 0 34px}
 .tg-bookmark[aria-pressed="true"]{color:#d33e4c;border-color:#ffd4d7;background:#fff3f4}.tg-article-note{font-size:11px;color:#9aa0a9;margin-top:7px}
 .tg-article{padding:12px 13px!important} .tg-article-title-row{display:block} .tg-article-title-row .tg-link{width:100%;display:block;text-align:left;font-size:clamp(15px,4.2vw,18px);font-weight:850;line-height:1.45;padding:0 0 5px;white-space:normal}
 .tg-article-meta{display:flex;align-items:center;gap:7px;min-width:0;font-size:12px;color:#778492;min-height:40px}
 .tg-article-date{white-space:nowrap;flex:0 0 auto;font-variant-numeric:tabular-nums}.tg-article-publisher{overflow:hidden;white-space:nowrap;text-overflow:ellipsis;min-width:0;flex:1}
 .tg-article-actions{display:flex;gap:6px;flex:0 0 auto;margin-left:auto}.tg-article-meta button{width:36px;height:36px;flex:0 0 36px;min-height:36px;padding:1px;line-height:1}
 .tg-article .tg211-brief,.tg-article .tg-article-note,.tg-article .tg-article-top,.tg-article .tg211-actions,.tg-article .tg211-brief-label{display:none!important}
 @media(max-width:390px){.tg-article{padding:10px!important}.tg-article-meta{gap:5px;font-size:11px}.tg-article-meta button{width:32px;height:34px;flex-basis:32px}.tg-article-actions{gap:4px}}
 .tg-more{width:100%;border:1px solid #dce1e8;border-radius:11px;background:#f8f9fb;padding:13px;color:#374354;font-weight:750;margin-top:8px}
 @media(max-width:390px){.tg-head{padding-bottom:21px}.tg-hero{gap:12px}.tg-hero h1{font-size:33px}.tg-ico{height:56px;width:56px;min-width:56px;font-size:27px}.tg-card{padding:10px;gap:10px;min-height:82px}.tg-card-sub{font-size:11px}.tg-state{padding:5px 6px;font-size:10px}.tg-tabs{gap:6px}.tg-tab{padding:8px 13px}}
 `;
 document.head.appendChild(st);
 // V219: manual-locked growth theme sizing (UI Standard V36) across all 20 themes.
 var fit=make('style');fit.id='ntv219-growth-ui';fit.textContent=`
 #ntv210-growth{padding:12px 12px 30px!important}
 #ntv210-growth .tg-head{padding:2px 1px 12px!important}
 #ntv210-growth .tg-hero{margin-bottom:12px!important;gap:10px!important}
 #ntv210-growth .tg-hero h1{font-size:26px!important;letter-spacing:-.9px!important}
 #ntv210-growth .tg-hero p,#ntv210-growth .tg-notice{font-size:16px!important;line-height:1.5!important}
 #ntv210-growth .tg-find{height:48px!important;margin-bottom:9px!important}
 #ntv210-growth .tg-tabs{gap:4px!important;padding:2px 0 10px!important}
 #ntv210-growth .tg-tab{font-size:16px!important;min-height:48px!important;padding:8px 12px!important}
 #ntv210-growth .tg-summary{padding:10px 4px!important;margin-bottom:12px!important}
 #ntv210-growth .tg-stat .tg-stat-head,#ntv210-growth .tg-stat small{font-size:14px!important}
 #ntv210-growth .tg-cards{gap:8px!important}
 #ntv210-growth .tg-card{min-height:78px!important;padding:10px 12px!important;gap:10px!important}
 #ntv210-growth .tg-ico{width:52px!important;min-width:52px!important;height:52px!important;font-size:26px!important}
 #ntv210-growth .tg-card-title{font-size:18px!important;line-height:1.36!important}
 #ntv210-growth .tg-card-sub{font-size:14px!important;line-height:1.4!important;margin-top:3px!important}
 #ntv210-growth .tg-back{min-height:48px!important;padding:8px 12px!important;margin:0 0 8px!important;font-size:17px!important}
 #ntv210-growth .tg-detail-h{font-size:22px!important;line-height:1.3!important;margin:4px 0 6px!important}
 #ntv210-growth .tg-detail-sub{font-size:15px!important;line-height:1.45!important;margin:0 0 10px!important}
 #ntv210-growth .tg-controls{gap:4px!important;flex-wrap:wrap!important;margin-bottom:8px!important}
 #ntv210-growth .tg-controls strong{font-size:16px!important}
 #ntv210-growth .tg-controls select,#ntv210-growth .tg-hidden-toggle{font-size:16px!important;min-height:48px!important}
 #ntv210-growth .tg-article{padding:10px 11px!important;margin-bottom:8px!important}
 #ntv210-growth .tg-article-title-row{margin:0 0 5px!important}
 #ntv210-growth .tg-link{font-size:18px!important;line-height:1.42!important;font-weight:800!important}
 #ntv210-growth .tg-article-meta{font-size:15px!important;gap:4px!important;min-height:44px!important}
 #ntv210-growth .tg-article-publisher{font-size:15px!important;min-width:0!important}
 #ntv210-growth .tg-article-meta button{min-width:44px!important;min-height:44px!important;width:44px!important;height:44px!important;flex-basis:44px!important;font-size:21px!important}
 #ntv210-growth .tg-article-actions{gap:4px!important}
 #ntv210-growth .tg-more,#ntv210-growth .tg-reset-list{min-height:48px!important;font-size:16px!important}
 #ntv210-growth .tg-veteran-trigger{display:block;width:100%;text-align:center;border-radius:12px;border:1px solid #a7c8e1;background:#e9f5ff;color:#1a4d74;font-weight:700;font-size:19px;min-height:54px;margin:7px 0 13px}
 #ntv210-growth .tg-reset-list{margin-top:12px;border:1px solid #bbd2e9;background:#f1f7ff;color:#194970;border-radius:9px;padding:9px 12px;font-weight:800}
 #ntv210-growth .tg-live-bar{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:4px 0 10px;flex-wrap:wrap}
 #ntv210-growth .tg-live-status{font-size:14px;line-height:1.4;color:#64748b;flex:1 1 170px}
 #ntv210-growth .tg-live-reload{border:1px solid #cdd7e3;background:#f6f9fd;color:#214e79;border-radius:9px;min-height:44px;padding:8px 10px;font-size:15px;font-weight:800}
 #ntv210-growth .tg-live-reload:disabled{opacity:.55}
 #ntv210-growth .tg-empty{font-size:16px!important;line-height:1.6!important;padding:18px 12px!important}
 @media(max-width:390px){#ntv210-growth .tg-article-meta{flex-wrap:wrap!important}#ntv210-growth .tg-article-publisher{flex:1 1 80px!important}#ntv210-growth .tg-article-actions{margin-left:auto!important}}
 `;document.head.appendChild(fit);

 // Legacy investment DOM remains intact for data migration, but it is not displayed on this route.
 var root=make('div');root.id='ntv210-growth';page.insertBefore(root,page.firstChild);var buildBadge=document.getElementById('snowballBuildV42');if(buildBadge)buildBadge.textContent='V60.8 · V220';
 var head=make('div','tg-head');var logo=make('div','tg-logo');logo.appendChild(make('span','tg-mark','∞'));logo.appendChild(make('span','','눈탱이'));head.appendChild(logo);
 var acts=make('div','tg-icons');var alerts=make('button','tg-headbutton','♧');alerts.type='button';alerts.setAttribute('aria-label','액션벨');alerts.addEventListener('click',function(){var r=document.getElementById('rBell');if(r){r.checked=true;r.dispatchEvent(new Event('change',{bubbles:true}));}});acts.appendChild(alerts);
 var finder=make('button','tg-headbutton','⌕');finder.type='button';finder.setAttribute('aria-label','검색으로 이동');acts.appendChild(finder);head.appendChild(acts);root.appendChild(head);
 var hero=make('div','tg-hero'),title=make('h1');title.appendChild(make('em','','성장'));title.appendChild(document.createTextNode('테마'));hero.appendChild(title);hero.appendChild(make('p','','지금 주목할 성장 테마를\n한눈에 확인하세요.'));root.appendChild(hero);
 var searchRow=make('div','tg-find');searchRow.appendChild(make('span','tg-mag','⌕'));var input=make('input');input.type='search';input.setAttribute('aria-label','테마 기업 키워드 검색');input.placeholder='테마 / 기업 / 키워드 검색';searchRow.appendChild(input);
 var clear=make('button','','×');clear.type='button';clear.setAttribute('aria-label','검색어 지우기');searchRow.appendChild(clear);root.appendChild(searchRow);finder.addEventListener('click',function(){input.focus();input.scrollIntoView({block:'center',behavior:'smooth'});});
 var tabs=make('div','tg-tabs');tabs.setAttribute('role','group');tabs.setAttribute('aria-label','자료 유형 선택');TABS.forEach(function(t){var b=make('button','tg-tab',t[1]);b.type='button';b.setAttribute('data-tab',t[0]);b.setAttribute('aria-pressed',t[0]==='all'?'true':'false');b.addEventListener('click',function(){tab=t[0];selectedTheme=0;render();});tabs.appendChild(b);});root.appendChild(tabs);
 var stats=make('div','tg-summary');[['테마','20개'],['오늘 신규','0'],['관심자료','0']].forEach(function(p,i){var cell=make('div','tg-stat');cell.appendChild(make('span','tg-stat-head',p[0]));var num=make('strong','',p[1]);num.id='ntv210-stat'+i;cell.appendChild(num);stats.appendChild(cell);});root.appendChild(stats);
 var notice=make('p','tg-notice');root.appendChild(notice);
 var noticeStatus=make('p','tg-v227-status');root.appendChild(noticeStatus);
 var main=make('main');main.id='ntv210-main';root.appendChild(main);
 
 // V227: one shared top bar for the theme grid, theme articles and article detail.
 var topTools=make('div','tg-v227-toolbar');topTools.id='tg-v227-toolbar';topTools.setAttribute('role','group');topTools.setAttribute('aria-label','테마 기사 국내 글로벌 최신기사 요청');
 var btnDomestic=make('button','tg-v227-lane','국내'),btnGlobal=make('button','tg-v227-lane','글로벌'),btnRefresh=make('button','tg-v227-request','최신기사 요청'),btnVeteran=make('button','tg-v229-veteran','베테랑');
 [btnDomestic,btnGlobal,btnRefresh,btnVeteran].forEach(function(b){b.type='button';topTools.appendChild(b);});
 // Maintain the toolbar's space in the document while the controls are viewport-fixed.
 var topSpacer=make('div','tg-v228-toolbar-spacer');topSpacer.setAttribute('aria-hidden','true');root.insertBefore(topSpacer,main);root.insertBefore(topTools,topSpacer);
 function veteranEntries(themeId){var v=window.NTV226_VETERAN_REPORTERS;return v&&v.relatedArticles?v.relatedArticles(themeId):[];}
 function setRegion(which){region=which;render();if(reporterMode&&selectedTheme&&window.NTV226_VETERAN_REPORTERS)window.NTV226_VETERAN_REPORTERS.refreshTheme(selectedTheme,region,false);}
 btnDomestic.addEventListener('click',function(){setRegion(region==='KR'?'ALL':'KR');});
 btnGlobal.addEventListener('click',function(){setRegion(region==='GLOBAL'?'ALL':'GLOBAL');});
 function updateToolbar(){btnDomestic.setAttribute('aria-pressed',String(region==='KR'));btnGlobal.setAttribute('aria-pressed',String(region==='GLOBAL'));btnVeteran.setAttribute('aria-pressed',String(veteranBrowse));btnRefresh.disabled=!!(veteranRefreshBusy||(selectedTheme&&!reporterMode?collecting[selectedTheme]:refreshAllBusy));}
 async function latestRequest(){
  if(selectedTheme&&reporterMode){var veterans=window.NTV226_VETERAN_REPORTERS;noticeStatus.textContent='이 테마의 베테랑 기자 기사 새로 확인 중';veteranRefreshBusy=true;btnRefresh.disabled=true;try{if(veterans&&veterans.refreshTheme)await veterans.refreshTheme(selectedTheme,region,true);noticeStatus.textContent='베테랑 기사 확인 완료 · 원문 필자 확인 결과만 목록에 표시';}catch(_){noticeStatus.textContent='베테랑 기사 확인 실패 · 재시도 가능';}finally{veteranRefreshBusy=false;btnRefresh.disabled=false;render();}return;}
  if(selectedTheme){await refreshTheme(selectedTheme,true);return;}
  if(veteranBrowse){noticeStatus.textContent='베테랑 기사 새로고침: 아래에서 취재 테마를 하나 선택해 주세요.';return;}
  if(refreshAllBusy)return;refreshAllBusy=true;updateToolbar();
  var finished=0;noticeStatus.hidden=false;
  for(var i=0;i<ids.length;i++){noticeStatus.textContent='20개 테마 최신기사 확인 · '+finished+'/'+ids.length+'개 완료';try{await refreshTheme(Number(ids[i]),true);}catch(e){}finished++;}
  refreshAllBusy=false;noticeStatus.textContent='20개 테마 최신기사 확인 완료. 기존 기사 원본은 유지됩니다.';render();}
 btnRefresh.addEventListener('click',latestRequest);
 btnVeteran.addEventListener('click',function(){veteranBrowse=!veteranBrowse;reporterMode=!!(selectedTheme&&veteranBrowse);noticeStatus.textContent='';render();if(reporterMode&&window.NTV226_VETERAN_REPORTERS)window.NTV226_VETERAN_REPORTERS.refreshTheme(selectedTheme,region,false);});
 window.addEventListener('ntv226-veteran-updated',function(){if(veteranBrowse&&selectedTheme&&!document.getElementById('tg212-overlay'))render();});
 function forArticle(which){if(window.NTV211_THEME_ARTICLE&&window.NTV211_THEME_ARTICLE.close)window.NTV211_THEME_ARTICLE.close();setRegion(which);}
 function detailToolbar(){var tool=make('div','tg-v227-detail-toolbar');var x=make('button','','국내'),y=make('button','','글로벌'),z=make('button','','최신기사 요청'),v=make('button','','베테랑');[x,y,z,v].forEach(function(b){b.type='button';tool.appendChild(b);});
  x.setAttribute('aria-pressed',String(region==='KR'));y.setAttribute('aria-pressed',String(region==='GLOBAL'));v.setAttribute('aria-pressed',String(veteranBrowse));
  x.addEventListener('click',function(){forArticle('KR');});y.addEventListener('click',function(){forArticle('GLOBAL');});z.addEventListener('click',function(){if(window.NTV211_THEME_ARTICLE)window.NTV211_THEME_ARTICLE.close();latestRequest();});v.addEventListener('click',function(){if(window.NTV211_THEME_ARTICLE)window.NTV211_THEME_ARTICLE.close();btnVeteran.click();});return tool;}

 function favKey(e){return e.url||e.title+'|'+e.date;}
 function voteRecord(e,kind){var key=favKey(e),isHeart=kind==='heart',arr=isHeart?fav:hidden,at=arr.indexOf(key);if(at>=0)arr.splice(at,1);else arr.push(key);var saved=isHeart?save(fav):saveHidden(hidden);if(!saved){if(at>=0)arr.splice(at,0,key);else arr.pop();return null;}needsRefreshOnClose=true;counts();return arr.indexOf(key)>=0;}
 function voteState(e){var k=favKey(e);return {heart:fav.indexOf(k)>=0,trash:hidden.indexOf(k)>=0};}
 function onArticleClosed(){if(needsRefreshOnClose){needsRefreshOnClose=false;render();}}
 function matching(e){if(!showHidden&&hidden.indexOf(favKey(e))>=0)return false;if(tab!=='all'&&e.type!==tab)return false;if(region!=='ALL'&&e.region.indexOf(region)<0)return false;
   if(!term)return true;var hay=(e.title+' '+e.publisher+' '+e.themeIds.map(function(id){return themes[id]||'';}).join(' ')).toLowerCase();return hay.indexOf(term)>=0;}
 function counts(){document.getElementById('ntv210-stat0').textContent=ids.length+'개';document.getElementById('ntv210-stat1').textContent=entries.filter(function(e){return e.date===todayDate();}).length;document.getElementById('ntv210-stat2').textContent=fav.length;}
 function enterTheme(n,vet){
  lastGridScrollY=root.scrollTop||0;
  if(window.NTV211_THEME_ARTICLE&&window.NTV211_THEME_ARTICLE.close)window.NTV211_THEME_ARTICLE.close();
  selectedTheme=n;reporterMode=!!vet;veteranBrowse=!!vet;tab='all';input.value='';showHidden=false;
  render();root.scrollTop=0;try{window.scrollTo(0,0);}catch(_){}
  if(vet&&window.NTV226_VETERAN_REPORTERS)window.NTV226_VETERAN_REPORTERS.refreshTheme(n,region,false);
  else if(!vet)refreshTheme(n,false);
 }
 function allCard(id){var n=Number(id),associated=veteranBrowse?veteranEntries(n):entries.filter(function(e){return e.themeIds.indexOf(n)>=0;});var filtered=associated.filter(matching);
  if(tab!=='all'&&tab!=='article'&&!filtered.length)return null;
  if(term && (themes[id]||'').toLowerCase().indexOf(term)<0 && filtered.length===0)return null;
  var shell=make('div','tg-v228-card-shell');var b=make('button','tg-card');b.type='button';b.appendChild(make('span','tg-ico',ICONS[n-1]||'◈'));
  var tx=make('span','tg-card-body');tx.appendChild(make('div','tg-card-title',themes[id]));tx.appendChild(make('div','tg-card-sub',(veteranBrowse?'베테랑 기사 ':'자료 ')+(region==='ALL'?associated.length:filtered.length)+'건  |  최근 업데이트 '+(associated.length?associated[0].date:'없음')));b.appendChild(tx);
  b.appendChild(make('span','tg-card-right','›'));
  b.addEventListener('click',function(){enterTheme(n,veteranBrowse);});shell.appendChild(b);return shell;
 }
 function showMore(){var start=shown,end=Math.min(current.length,start+PAGE_SIZE),holder=document.getElementById('ntv210-articles'),more=document.getElementById('ntv210-more');
   var fragment=document.createDocumentFragment();for(var i=start;i<end;i++){var e=current[i],row=make('article','tg-article');
    var titleRow=make('div','tg-article-title-row');var open=make('button','tg-link',e.title);open.type='button';open.addEventListener('click',(function(item){return function(){var s=window.NTV211_THEME_ARTICLE;if(s&&s.open)s.open(item);else linkOpen(item.url);};})(e));titleRow.appendChild(open);row.appendChild(titleRow);
    var meta=make('div','tg-article-meta');meta.appendChild(make('time','tg-article-date',e.date||'날짜 미확인'));meta.appendChild(make('span','tg-article-publisher',e.publisher||'출처 미확인'));
    row.appendChild(meta);
    if(window.NTV211_THEME_ARTICLE&&window.NTV211_THEME_ARTICLE.mount)window.NTV211_THEME_ARTICLE.mount(e,row);fragment.appendChild(row);
   }holder.appendChild(fragment);shown=end;more.hidden=(shown>=current.length);more.textContent='자료 더 보기 ('+shown+' / '+current.length+')';}

 function leaveTheme(){
  // Return to the actual preceding theme grid, never jump directly to HOME.
  if(!selectedTheme)return false;
  if(reporterMode){reporterMode=false;veteranBrowse=false;render();return true;}
  selectedTheme=0;region='ALL';showHidden=false;render();
  root.scrollTop=lastGridScrollY;try{window.scrollTo(0,0);}catch(_){}
  return true;
 }
 function detail(){if(window.NTV211_THEME_ARTICLE&&window.NTV211_THEME_ARTICLE.beginList)window.NTV211_THEME_ARTICLE.beginList();
  main.appendChild(make('h2','tg-detail-h',themes[selectedTheme]+(reporterMode?' · 베테랑':'')));
  var associated=reporterMode?veteranEntries(selectedTheme):entries.filter(function(e){return e.themeIds.indexOf(selectedTheme)>=0;});
  main.appendChild(make('div','tg-detail-sub',(reporterMode?'확인된 베테랑 기사 ':'기사 ')+associated.length+'건 · 최근 확인 '+(associated.length?associated[0].date:'없음')));
  if(reporterMode){main.appendChild(make('p','tg-v229-explain','실제 기사 원문에서 기자 이름이 확인된 기사만 표시합니다. 새로고침은 이 테마의 베테랑 기사를 다시 확인합니다.'));}
  else{var liveBar=make('div','tg-live-bar');liveBar.appendChild(make('span','tg-live-status',collectStatus[selectedTheme]||((lastChecks[selectedTheme]&&lastChecks[selectedTheme].ok)?'최근 기사 확인 기록 있음 · 기존 기사도 보존됩니다':'저장된 기사 먼저 표시 · 최신 뉴스 추가 확인 가능')));main.appendChild(liveBar);}
  var controls=make('div','tg-controls');var result=make('strong');result.id='ntv210-result';controls.appendChild(result);
  var select=make('select');[['ALL','국내 · 글로벌'],['KR','국내'],['GLOBAL','글로벌']].forEach(function(pair){var op=make('option','',pair[1]);op.value=pair[0];op.selected=(region===pair[0]);select.appendChild(op);});select.setAttribute('aria-label','기사 지역');select.addEventListener('change',function(){setRegion(select.value);});controls.appendChild(select);var muteToggle=make('button','tg-hidden-toggle',showHidden?'숨김 자료 감추기':'숨김 자료 보기 ('+hidden.length+')');muteToggle.type='button';muteToggle.addEventListener('click',function(){showHidden=!showHidden;render();});controls.appendChild(muteToggle);main.appendChild(controls);
  current=associated.filter(matching);result.textContent='검색 결과 '+current.length+'건';var articles=make('div');articles.id='ntv210-articles';main.appendChild(articles);
  if(!current.length){
   var empty=make('div','tg-empty');empty.appendChild(make('div','',reporterMode?'이 테마에 실제 필자가 확인된 베테랑 기사가 아직 없습니다. 상단 최신기사 요청으로 새로 확인할 수 있습니다.':associated.length?'보관된 자료 '+associated.length+'건이 있습니다. 현재 검색·유형·숨김 조건 때문에 화면에는 표시되지 않습니다.':'현재 저장된 기사 자료가 없습니다. 원본 자료는 삭제하지 않습니다.'));
   if(associated.length){var recover=make('button','tg-reset-list','기사 목록 전체 보기');recover.type='button';recover.addEventListener('click',function(){tab='all';region='ALL';input.value='';showHidden=true;render();});empty.appendChild(recover);}articles.appendChild(empty);
  }
  var more=make('button','tg-more');more.id='ntv210-more';more.type='button';more.addEventListener('click',showMore);main.appendChild(more);shown=0;showMore();
  var focusId=selectedTheme,first=current[0];if(first)setTimeout(function(){if(selectedTheme===focusId&&!document.getElementById('tg212-overlay')){var svc=window.NTV211_THEME_ARTICLE;if(svc&&svc.prefetch)svc.prefetch(first);}},1800);
 }
 function render(){if(window.NTV211_THEME_ARTICLE&&window.NTV211_THEME_ARTICLE.onList)window.NTV211_THEME_ARTICLE.onList();term=input.value.trim().toLowerCase();clear.style.display=term?'inline-block':'none';
  tabs.querySelectorAll('button').forEach(function(b){b.setAttribute('aria-pressed',String(b.dataset.tab===tab));});counts();main.textContent='';
  notice.textContent='';updateToolbar();
  if(selectedTheme){detail();return;}
  var group=make('div','tg-cards');var n=0;ids.forEach(function(id){var card=allCard(id);if(card){group.appendChild(card);n++;}});main.appendChild(group);
  if(!n)main.appendChild(make('div','tg-empty',tab==='all'||tab==='article'?'검색되는 테마가 없습니다.':'현재 이 유형의 자료는 없습니다. 기사 외 자료는 추가 수집 후 표시됩니다.'));
 }
 input.addEventListener('input',function(){render();});clear.addEventListener('click',function(){input.value='';selectedTheme=0;render();input.focus();});
 render();window.NTV210_THEME_GROWTH={refresh:render,refreshTheme:refreshTheme,detailToolbar:detailToolbar,vote:voteRecord,states:voteState,onArticleClosed:onArticleClosed,backTheme:leaveTheme,isThemeOpen:function(){return selectedTheme>0;},version:'V230',count:function(){return entries.length;}};
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',launch,{once:true});else launch();
})();

/* V227 visual economy: avoid stacking old find/filter/stat controls on the theme grid. */
(function(){var s=document.createElement('style');s.textContent=`
#ntv210-growth .tg-head,#ntv210-growth .tg-hero,#ntv210-growth .tg-find,#ntv210-growth .tg-tabs,#ntv210-growth .tg-summary,#ntv210-growth .tg-notice{display:none!important}
#ntv210-growth .tg-v227-toolbar{position:fixed!important;top:var(--ntv127-symbol-total,134px)!important;left:0!important;right:0!important;width:100%!important;z-index:2147481300!important;display:grid;grid-template-columns:minmax(0,.84fr) minmax(0,.84fr) minmax(0,1.38fr) minmax(0,.91fr);gap:5px;padding:8px 1px 10px;background:#fff;box-shadow:0 3px 6px #17202a12;margin:0!important;box-sizing:border-box!important;padding:8px 10px 10px!important}
#ntv210-growth{padding-top:calc(var(--ntv127-symbol-total,134px) + 9px)!important}
#ntv210-growth .tg-v228-toolbar-spacer{height:73px;width:100%;flex:0 0 auto;}
#ntv210-growth .tg-v227-toolbar button,#tg212-overlay .tg-v227-detail-toolbar button{border:1px solid #cbdde8;border-radius:11px;padding:9px 4px;min-width:0;min-height:48px;font-size:16px;font-weight:650;line-height:1.25;color:#26506d;background:#eef7ff}
#ntv210-growth .tg-v227-toolbar button[aria-pressed=true],#tg212-overlay .tg-v227-detail-toolbar button[aria-pressed=true]{color:#fff;background:#1b638c;border-color:#1b638c}
#ntv210-growth .tg-v227-toolbar button:disabled{opacity:.55}
#ntv210-growth .tg-v228-card-shell,#ntv210-growth .tg-v228-veteran-quick,#ntv210-growth .tg-card,#ntv210-growth .tg-article{scroll-margin-top:calc(var(--ntv127-symbol-total,134px) + 86px)!important}
#ntv210-growth .tg-v228-card-shell{display:grid;grid-template-columns:minmax(0,1fr);gap:5px;align-items:stretch;width:100%;border:1px solid #e8edf4;border-radius:14px;overflow:hidden;background:#fff;box-shadow:0 3px 10px #151a2209}
#ntv210-growth .tg-v228-card-shell .tg-card{border:0!important;box-shadow:none!important;border-radius:0!important;min-width:0!important;text-align:left!important;margin:0!important}
#ntv210-growth .tg-v228-card-shell .tg-ico{min-width:44px!important;width:44px!important;height:48px!important;font-size:23px!important}
#ntv210-growth .tg-v228-card-shell .tg-card{gap:7px!important;padding:9px 3px 9px 9px!important}
#ntv210-growth .tg-v228-card-shell .tg-card-right{display:none!important}
#ntv210-growth .tg-v228-veteran-quick{align-self:stretch;background:#f1f9ff;border:0;border-left:1px solid #d6e7f2;color:#20577c;font-size:13px;font-weight:750;padding:8px 3px;line-height:1.4;min-width:0;overflow-wrap:keep-all}
#ntv210-growth .tg-v228-veteran-quick:active{background:#dbeeff}
#ntv210-growth .tg-v227-status{font-size:14px;line-height:1.5;margin:0 1px 9px;color:#486f87}
#ntv210-growth .tg-v227-status:empty{display:none}
#ntv210-growth .tg-live-bar .tg-live-reload,#ntv210-growth .tg-controls select,#ntv210-growth .tg-controls .tg-hidden-toggle{display:none!important}
#ntv210-growth .tg-live-bar{margin:0 0 8px!important}#ntv210-growth .tg-live-status{font-size:13px}
#ntv210-growth .tg-controls{margin:2px 0 10px!important}#ntv210-growth .tg-detail-sub{margin:0 0 12px!important}
#tg212-overlay .tg-v227-detail-toolbar{display:grid;grid-template-columns:minmax(0,.84fr) minmax(0,.84fr) minmax(0,1.38fr) minmax(0,.91fr);gap:5px;padding:7px 10px 8px;border-bottom:1px solid #e1eaf1;background:#fff;flex-shrink:0}
#tg212-overlay .tg212-header{display:none!important}#tg212-overlay .tg213-switches{display:none!important}
`;document.head.appendChild(s);})();

/* V229: single full-width theme row and 4-button fixed toolbar. */
(function(){var s=document.createElement('style');s.textContent=`
#ntv210-growth .tg-v227-toolbar{grid-template-columns:minmax(0,.86fr) minmax(0,.86fr) minmax(0,1.42fr) minmax(0,.93fr)!important;gap:5px!important}
#ntv210-growth .tg-v227-toolbar button{font-size:clamp(13px,3.6vw,16px)!important;font-weight:650!important;padding:7px 2px!important;word-break:keep-all}
#ntv210-growth .tg-v228-card-shell{grid-template-columns:minmax(0,1fr)!important}
#ntv210-growth .tg-v228-card-shell .tg-card{padding:12px 13px!important;min-height:88px!important}
#ntv210-growth .tg-v228-card-shell .tg-card-right{display:inline-flex!important;font-size:22px;color:#7791a3}
#ntv210-growth .tg-article-title-row .tg-link{font-weight:500!important}
#ntv210-growth .tg-v229-explain{font-size:14px;line-height:1.55;color:#61778a;margin:6px 0 12px}
`;document.head.appendChild(s);})();


/* V230: one owner for theme viewport, toolbar, article density and both scroll ends.
 * A fixed root scrollport prevents the last theme from disappearing behind Galaxy nav.
 * Measure the actual header and nav rather than stacking stale CSS inset assumptions.
 */
(function(){
 var css=document.createElement('style');css.id='ntv230-theme-density-scroll';css.textContent=`
 #pageLong #ntv210-growth{
  position:fixed!important;
  top:var(--ntv230-header-bottom,var(--ntv127-symbol-total,134px))!important;
  bottom:var(--ntv230-nav-bottom,calc(var(--ntv53-nav-height,76px) + var(--android-bottom-inset,44px)))!important;
  left:0!important;right:0!important;width:100%!important;
  height:auto!important;min-height:0!important;max-height:none!important;
  padding:calc(var(--ntv230-toolbar-height,72px) + 8px) 12px 22px!important;
  overflow-y:auto!important;overflow-x:hidden!important;
  overscroll-behavior-y:contain!important;touch-action:pan-y!important;
  -webkit-overflow-scrolling:touch!important;
  scroll-padding-top:10px!important;scroll-padding-bottom:22px!important;
  box-sizing:border-box!important;
 }
 #pageLong #ntv210-growth .tg-v227-toolbar{
  top:var(--ntv230-header-bottom,var(--ntv127-symbol-total,134px))!important;
 }
 #pageLong #ntv210-growth .tg-v228-toolbar-spacer{display:none!important;height:0!important}
 #pageLong #ntv210-main{padding-bottom:8px!important;margin:0!important}
 #pageLong #ntv210-growth .tg-cards{gap:8px!important}
 #pageLong #ntv210-growth .tg-v228-card-shell{margin:0!important}
 #pageLong #ntv210-growth .tg-article{
  display:block!important;position:relative!important;
  height:auto!important;min-height:0!important;max-height:none!important;
  padding:11px 12px!important;margin:0 0 8px!important;
  overflow:visible!important;
 }
 #pageLong #ntv210-growth .tg-article-title-row{
  display:block!important;margin:0 0 5px!important;padding:0!important;
  min-height:0!important;height:auto!important;
 }
 #pageLong #ntv210-growth .tg-article-title-row .tg-link{
  display:block!important;width:100%!important;
  margin:0!important;padding:0!important;
  font-size:18px!important;line-height:1.38!important;font-weight:500!important;
  letter-spacing:-.35px!important;
 }
 #pageLong #ntv210-growth .tg-article-meta{
  display:flex!important;align-items:center!important;flex-wrap:wrap!important;
  min-height:0!important;height:auto!important;
  padding:0!important;margin:0!important;gap:4px!important;
  line-height:1.35!important;font-size:14px!important;
 }
 #pageLong #ntv210-growth .tg-article-publisher{font-size:14px!important;line-height:1.35!important}
 #pageLong #ntv210-growth .tg-article-date{line-height:1.35!important}
 #pageLong #ntv210-growth .tg-v228-card-shell,
 #pageLong #ntv210-growth .tg-article{scroll-margin-top:10px!important}
 #pageLong #ntv210-growth .tg-v228-card-shell .tg-card{min-height:78px!important;padding:9px 12px!important}
 #pageLong #ntv210-growth .tg-v228-card-shell .tg-card-sub{margin-top:2px!important}
 #pageLong #ntv210-growth .tg-more{margin:8px 0 0!important}
 `;
 document.head.appendChild(css);
 function sync(){var r=document.getElementById('ntv210-growth');if(!r)return;
  var h=document.getElementById('ntv127GlobalHeader')||document.querySelector('.canon-header');
  var nav=document.getElementById('mainNav');
  var view=window.innerHeight||document.documentElement.clientHeight||0;
  var hr=h&&h.getBoundingClientRect(),nr=nav&&nav.getBoundingClientRect();
  var top=hr&&hr.height>0&&hr.bottom>0?Math.round(hr.bottom):parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ntv127-symbol-total'))||134;
  var bottom=nr&&nr.height>0&&nr.top>top?Math.max(0,Math.round(view-nr.top)):Math.max(76,parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ntv53-nav-height'))||76);
  if(top+bottom+80>=view&&view>250){top=Math.min(top,Math.floor(view*.42));bottom=Math.min(bottom,Math.floor(view*.28));}
  r.style.setProperty('--ntv230-header-bottom',top+'px');r.style.setProperty('--ntv230-nav-bottom',bottom+'px');
  var bar=r.querySelector('.tg-v227-toolbar');if(bar){var height=bar.getBoundingClientRect().height||64;r.style.setProperty('--ntv230-toolbar-height',Math.ceil(height)+'px');}
  var detail=document.getElementById('tg212-overlay');if(detail){detail.style.setProperty('top',top+'px','important');detail.style.setProperty('bottom',bottom+'px','important');}
 }
 function schedule(){window.requestAnimationFrame(sync);}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
 window.addEventListener('resize',schedule);window.addEventListener('orientationchange',schedule);
 document.addEventListener('change',function(e){if(e.target&&e.target.id==='rLong')schedule();},true);
 document.addEventListener('click',function(e){if(e.target&&e.target.closest&&e.target.closest('#mainNav label, .tg-card, .tg-link, .tg-v227-toolbar button'))schedule();},true);
 window.NTV230_SYNC_THEME_SCROLL=sync;
})();
