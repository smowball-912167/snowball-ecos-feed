/* V258 personal-use, read-only CNN Fear & Greed adapter.
 * IMPORTANT: the CNN JSON endpoint is not a guaranteed/publicly documented API.
 * Never infer values from headlines, never silently substitute VIX, and never store credentials.
 * Fail closed if unavailable or if schema/timestamp/units do not match. */
(function(root){'use strict';
var URL='https://production.dataviz.cnn.io/index/fearandgreed/graphdata';
var PREFIX='ntv258_cnn_', KEY='NOONTANGI_V258_FEAR_GREED_STATUS', DAY=86400000;
var pending={},seq=0,inflight=null,lastAttempt=0;
function read(){try{return JSON.parse(root.localStorage.getItem(KEY)||'null')}catch(_){return null}}
function record(status){try{root.localStorage.setItem(KEY,JSON.stringify(status))}catch(_){}}
function parse(raw,now){
 if(typeof raw!=='string'||!raw||raw.length>550000)return null;
 var obj;try{obj=JSON.parse(raw)}catch(_){return null}
 if(!obj||typeof obj!=='object'||obj.error||!obj.fear_and_greed)return null;
 var x=obj.fear_and_greed;
 if(typeof x.score!=='number'||!Number.isFinite(x.score)||x.score<0||x.score>100||typeof x.timestamp!=='string')return null;
 var stamp=Date.parse(x.timestamp),time=Number.isFinite(now)?now:Date.now();
 if(!Number.isFinite(stamp)||stamp>time+5*60000||time-stamp>4*DAY)return null;
 var accepted=['extreme fear','fear','neutral','greed','extreme greed'];
 var rating=String(x.rating||'').toLowerCase().trim();if(accepted.indexOf(rating)<0)return null;
 var dt=new Date(stamp),ymd=dt.toISOString().slice(0,10).replace(/-/g,'');
 return {id:'fearGreed',value:Math.round(x.score*100)/100,asOf:dt.toISOString(),period:ymd+' / CNN',
   source:'CNN Fear & Greed · CNN 직접 게시 JSON',verified:true,history:[]};
}
var oldResolve=root.__SnowballNativeAsyncResolve;
root.__SnowballNativeAsyncResolve=function(id,raw){
 if(String(id||'').indexOf(PREFIX)!==0){if(typeof oldResolve==='function')return oldResolve(id,raw);return;}
 var p=pending[id];if(!p)return;delete pending[id];clearTimeout(p.timer);
 if(typeof raw==='string'&&raw.length<=550000)p.resolve(raw);else p.resolve('');
};
function get(){return new Promise(function(resolve,reject){
 if(!root.SnowballMarketData||typeof root.SnowballMarketData.getAsync!=='function')return reject(Error('native bridge missing'));
 var id=PREFIX+(++seq)+'_'+Date.now();var timer=setTimeout(function(){delete pending[id];reject(Error('request timeout'))},12000);
 pending[id]={resolve:resolve,reject:reject,timer:timer};
 try{root.SnowballMarketData.getAsync(URL,id)}catch(ex){delete pending[id];clearTimeout(timer);reject(ex)}
})}
function refresh(force){
 if(inflight)return inflight;
 if(root.document&&root.document.hidden)return Promise.resolve({status:'hidden'});
 var now=Date.now(),state=read()||{};
 if(!force&&now-Number(state.lastAttempt||0)<6*3600000)return Promise.resolve({status:'throttled'});
 lastAttempt=now;record({version:'V258',lastAttempt:now,status:'checking'});
 inflight=get().then(function(raw){var x=parse(raw,Date.now());
   if(!x||!root.NOONTANGI_FOUR_FACTORS||typeof root.NOONTANGI_FOUR_FACTORS.ingest!=='function')return {status:'unavailable',updated:0};
   var prev=root.NOONTANGI_FOUR_FACTORS.official&&root.NOONTANGI_FOUR_FACTORS.official('fearGreed');
   if(prev&&Date.parse(prev.asOf)>=Date.parse(x.asOf))return {status:'preserved',updated:0};
   var count=root.NOONTANGI_FOUR_FACTORS.ingest([x]);return {status:count?'updated':'unavailable',updated:count};
 }).catch(function(){return {status:'unavailable',updated:0}}).then(function(out){
   record({version:'V258',lastAttempt:now,status:out.status,updated:out.updated});return out;
 }).finally(function(){inflight=null});
 return inflight;
}
function guide(){
 var d=root.document&&root.document.querySelector('#nt1232Guide .nt-master-doc');
 if(!d||d.querySelector('#ntv258-finance-source-guide'))return;
 var e=root.document.createElement('section');e.className='nt-master-v';e.id='ntv258-finance-source-guide';
 e.innerHTML='<h3>V258 · 시장심리 금융자료 점검</h3><p>기존 금융위원회 일별 고객예탁금·신용융자 2개와 ECOS 15개는 유지한다. CNN 공포·탐욕지수는 CNN 자체 게시 JSON에서 직접 조회할 수 있을 때에만 반영하며 날짜·점수 범위·평가 등급을 검증한다. 공개 접근이 차단되거나 갱신이 지연되면 미연결로 남기고 임의 수치를 만들지 않는다.</p><p>외국인 20거래일 누적 순매수는 실제 20거래일 KOSPI·KOSDAQ 원천 4개와 확인된 이용 권한이 필요하다. V260은 거래소 휴장일을 포함한 20거래일 일치를 공식 KOSPI·KOSDAQ 거래일로 확인하도록 보완했으며, 데이터 이용 권한이 없는 경우 연결로 표시하지 않는다. V261은 기존 금융 공개 피드 1회 조회에 외국인 20거래일, 신용잔고율, VKOSPI의 허가된 원천을 함께 수신할 수 있는 조건부 검증을 추가한다. 시장 전체 신용잔고율은 신용융자 잔고를 KOSPI·KOSDAQ 전체 시가총액으로 나눈 비율이며, 종목별 신용잔고율과 구별한다. 실제 데이터와 공개 재배포 허가가 입증되지 않으면 세 항목 모두 미연결로 유지한다. 앱 종료 안내는 3초 안에 한 번 더 뒤로가기를 누르면 종료하도록 개선했다.</p>';
 d.prepend(e);
}
function boot(){setTimeout(function(){refresh(false)},3100);guide();
 if(root.document&&root.document.addEventListener)root.document.addEventListener('visibilitychange',function(){if(!root.document.hidden)refresh(false)});
 if(root.document&&root.document.addEventListener)root.document.addEventListener('click',function(e){if(e.target&&e.target.closest&&e.target.closest('#nt1232GuideOpen,[data-v1232-guide-open]'))setTimeout(guide,0)},true);
}
if(root.document){if(root.document.readyState==='loading')root.document.addEventListener('DOMContentLoaded',boot,{once:true});else boot()}
root.NOONTANGI_V258_FINANCE={parse:parse,refresh:refresh,state:read,version:'V258'};
if(typeof module==='object'&&module.exports)module.exports=root.NOONTANGI_V258_FINANCE;
})(typeof window!=='undefined'?window:globalThis);
