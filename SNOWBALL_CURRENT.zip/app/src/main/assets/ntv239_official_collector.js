/* V239: initial verified official-data collection (no dummy values, no score).
 * U.S. Department of the Treasury: daily 2Y/10Y par yields and 20-business-day 10Y average.
 * U.S. Bureau of Labor Statistics: unadjusted CPI-U headline/core, YoY calculated from levels.
 * The reader does NOT run at app startup; it runs when a person opens Market Environment.
 * No keys are stored; no private credentials; errors do not overwrite good observations. */
(function(root){'use strict';
 var PREFIX='ntv239off_',META='NOONTANGI_V239_COLLECTOR_STATE',PERIOD=20*3600000,FAILED=6*3600000,waiting={},busy=false,serial=0;
 var BASE_BLS='https://api.bls.gov/publicAPI/v1/timeseries/data/';
 var BASE_UST='https://home.treasury.gov/resource-center/data-chart-center/interest-rates/pages/xml?data=daily_treasury_yield_curve&field_tdr_date_value_month=';
 function n(x){if(x===null||x===''||x===undefined)return null;var v=Number(x);return isFinite(v)?v:null;}
 function read(){try{return JSON.parse(localStorage.getItem(META)||'{}')}catch(_){return {};}}
 function save(o){try{localStorage.setItem(META,JSON.stringify(o))}catch(_){}}
 function ymd(t){return new Date(t).toISOString().slice(0,10);}
 function fail(v){return new Error(String(v||'공식 데이터 수신 실패').slice(0,180));}
 var priorResolve=root.__SnowballNativeAsyncResolve;
 root.__SnowballNativeAsyncResolve=function(id,raw){
  if(String(id||'').indexOf(PREFIX)!==0){if(typeof priorResolve==='function')return priorResolve(id,raw);return;}
  var task=waiting[id];if(!task)return;delete waiting[id];clearTimeout(task.to);
  if(!raw||String(raw).length>1800000){task.reject(fail('데이터 용량 초과·응답 없음'));return;}
  var trimmed=String(raw).trim();
  if(trimmed.startsWith('{')){try{var err=JSON.parse(trimmed);if(err.error){task.reject(fail(err.error));return;}}catch(_){} }
  task.resolve(String(raw));
 };
 function request(url){return new Promise(function(resolve,reject){
  var id=PREFIX+(++serial)+'_'+Date.now(),to=setTimeout(function(){if(waiting[id]){delete waiting[id];reject(fail('공식 데이터 응답 시간 초과'));}},14000);
  waiting[id]={resolve:resolve,reject:reject,to:to};
  try{if(root.SnowballMarketData&&typeof root.SnowballMarketData.getAsync==='function')root.SnowballMarketData.getAsync(url,id);
   else{clearTimeout(to);delete waiting[id];reject(fail('갤럭시 기본 데이터 연결 미설정'));}}
  catch(e){clearTimeout(to);delete waiting[id];reject(e)}
 });}
 function obs(id,value,date,source,period,history){return {id:id,value:value,asOf:date+'T12:00:00Z',period:period,source:source,verified:true,
   history:history.map(function(x){return {value:x.value,asOf:x.date+'T12:00:00Z'}})};}
 function parseBls(text,id){
  var j=JSON.parse(text);if(j.status!=='REQUEST_SUCCEEDED')throw fail('BLS 요청 실패');
  var list=j.Results&&j.Results[0]&&j.Results[0].series||j.Results&&j.Results.series||[];
  var match=list.filter(function(x){return x.seriesID===id})[0];
  if(!match||!Array.isArray(match.data))throw fail('BLS 수집 시계열 없음');
  var by={};match.data.forEach(function(x){var y=Number(x.year),m=/^M(\d\d)$/.exec(String(x.period||'')),v=n(x.value);
   if(y>=2000&&m&&Number(m[1])>=1&&Number(m[1])<=12&&v!==null&&v>0)by[y*100+Number(m[1])]=v;});
  var keys=Object.keys(by).map(Number).sort(function(a,b){return a-b}),points=[];
  keys.forEach(function(k){var old=(Math.floor(k/100)-1)*100+k%100;if(!by[old])return;
   var v=Math.round((by[k]/by[old]-1)*100000)/1000,day=String(Math.floor(k/100))+'-'+String(k%100).padStart(2,'0')+'-01';points.push({date:day,value:v});});
  if(!points.length)throw fail('BLS CPI 전년동월 관측값 부족');
  var last=points[points.length-1];if(Date.now()-Date.parse(last.date)>70*86400000)throw fail('BLS CPI 마지막 발표가 오래됨');
  return obs(id==='CUUR0000SA0'?'usCpi':'usCoreCpi',last.value,last.date,'미국 노동통계국 BLS · '+id,ymd(Date.parse(last.date)).slice(0,7)+' YoY',points.slice(-24));
 }
 function named(entry,name){var tags=entry.getElementsByTagNameNS?entry.getElementsByTagNameNS('*',name):[];
  if(tags.length)return String(tags[0].textContent||'').trim();
  var any=entry.getElementsByTagName(name);return any.length?String(any[0].textContent||'').trim():'';}
 function parseTreasury(xmlText){
  if(typeof DOMParser!=='function')throw fail('XML 읽기 기능 없음');
  var dom=new DOMParser().parseFromString(xmlText,'application/xml');
  if(dom.getElementsByTagName('parsererror').length)throw fail('미 재무부 XML 형식 오류');
  var entries=dom.getElementsByTagNameNS('*','entry'),by={};
  for(var i=0;i<entries.length;i++){var e=entries[i],day=named(e,'NEW_DATE').slice(0,10),two=n(named(e,'BC_2YEAR')),ten=n(named(e,'BC_10YEAR'));
   if(!/^20\d\d-\d\d-\d\d$/.test(day)||two===null||ten===null||two<=0||ten<=0||two>25||ten>25)continue;
   by[day]={date:day,two:two,ten:ten};}
  return Object.keys(by).sort().map(function(k){return by[k]});
 }
 function treasuryToObservations(a,b){
  var by={};a.concat(b).forEach(function(x){by[x.date]=x});var data=Object.keys(by).sort().map(function(k){return by[k]}),last=data[data.length-1];
  if(!last||Date.now()-Date.parse(last.date)>9*86400000)throw fail('미국채 최신 발표 자료 부족');
  var src='미국 재무부 Treasury · 일별 국채금리',period=last.date,history2=data.slice(-36).map(function(x){return {date:x.date,value:x.two}}),
   history10=data.slice(-36).map(function(x){return {date:x.date,value:x.ten}}),diff=Math.round((last.ten-last.two)*1000)/1000;
  var out=[obs('us02y',last.two,period,src,period,history2),obs('us10yOfficial',last.ten,period,src,period,history10),obs('usCurveSpread',diff,period,src,period,data.slice(-36).map(function(x){return {date:x.date,value:Math.round((x.ten-x.two)*1000)/1000}}))];
  if(data.length>=20){var mean=data.slice(-20).reduce(function(sum,x){return sum+x.ten},0)/20;
   out.push(obs('us10y20dma',Math.round(mean*1000)/1000,period,src,period,[]));}
  return out;
 }
 function months(){var today=new Date(),y=today.getUTCFullYear(),m=today.getUTCMonth()+1;return [String(y)+String(m).padStart(2,'0'),String(m===1?y-1:y)+String(m===1?12:m-1).padStart(2,'0')];}
 function requestTreasury(){var m=months();return Promise.allSettled(m.map(function(x){return request(BASE_UST+x).then(parseTreasury)})).then(function(res){
  var data=res.filter(function(x){return x.status==='fulfilled'}).map(function(x){return x.value});
  if(!data.length)throw fail('미국 재무부 연결 실패');return treasuryToObservations(data[0],data[1]||[]);
 });}
 function requestBls(id){return request(BASE_BLS+id).then(function(txt){return [parseBls(txt,id)]});}
 function refresh(force){
  if(busy)return Promise.resolve({status:'busy'});
  var now=Date.now(),old=read();if(!force&&now-Number(old.lastAttempt||0)<(old.success?PERIOD:FAILED))return Promise.resolve({status:'cached'});
  if(!root.NOONTANGI_FOUR_FACTORS||typeof root.NOONTANGI_FOUR_FACTORS.ingest!=='function')return Promise.resolve({status:'not-ready'});
  busy=true;save({lastAttempt:now,success:false,stage:'수집 중'});
  return Promise.allSettled([requestTreasury(),requestBls('CUUR0000SA0'),requestBls('CUUR0000SA0L1E')]).then(function(res){
   var records=[],errors=[];res.forEach(function(x){if(x.status==='fulfilled')records=records.concat(x.value);else errors.push(String(x.reason&&x.reason.message||x.reason).slice(0,110));});
   var stored=records.length?root.NOONTANGI_FOUR_FACTORS.ingest(records):0;
   save({lastAttempt:now,success:stored>0,lastSuccess:stored?Date.now():old.lastSuccess||null,count:stored,errors:errors,stage:stored?'일부 수신 완료':'자료 연결 실패'});
   return {status:stored?'received':'failed',count:stored,errors:errors};
  }).finally(function(){busy=false});
 }
 // No start-up network; only opening the actual Market Environment tab runs a collector.
 document.addEventListener('change',function(ev){if(ev.target&&ev.target.id==='rMarket'&&ev.target.checked)setTimeout(function(){refresh(false)},450)},true);
 root.NOONTANGI_OFFICIAL_COLLECTOR_V239={refresh:refresh,parseBls:parseBls,parseTreasury:parseTreasury,treasuryToObservations:treasuryToObservations,state:read,version:'V239'};
 if(typeof module==='object'&&module.exports)module.exports=root.NOONTANGI_OFFICIAL_COLLECTOR_V239;
})(typeof window!=='undefined'?window:globalThis);