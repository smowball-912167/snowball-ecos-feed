/* V241: BIS Korea/US monthly policy rates and FRED US 10Y breakeven inflation.
   Data read only from explicitly allowed source URLs. No made-up score. Policy rates
   are monthly-end series, not intraday values. Missing/stale/nonconforming is NOT connected. */
(function(root){'use strict';
 var PREFIX='ntv241_',META='NOONTANGI_V241_STATE',DAY=86400000,WAIT=23*3600000,RETRY=8*3600000,busy=false,serial=0,pending={};
 var BIS_KR='https://stats.bis.org/api/v2/data/dataflow/BIS/WS_CBPOL/1.0/M.KR?startPeriod=2025-01&format=csv',BIS_US='https://stats.bis.org/api/v2/data/dataflow/BIS/WS_CBPOL/1.0/M.US?startPeriod=2025-01&format=csv',FRED_BEI='https://fred.stlouisfed.org/graph/fredgraph.csv?id=T10YIE';
 function fail(s){return new Error(String(s||'자료 검증 실패').slice(0,200));}
 function num(v){if(v===null||v===undefined||String(v).trim()==='')return null;var x=Number(v);return isFinite(x)?x:null;}
 function state(){try{return JSON.parse(localStorage.getItem(META)||'{}')}catch(_){return {}}}
 function save(s){try{localStorage.setItem(META,JSON.stringify(s))}catch(_){}}
 var prior=root.__SnowballNativeAsyncResolve;
 root.__SnowballNativeAsyncResolve=function(id,body){if(String(id||'').indexOf(PREFIX)!==0){if(typeof prior==='function')return prior(id,body);return;}
   var q=pending[id];if(!q)return;delete pending[id];clearTimeout(q.timer);var raw=String(body||'').trim();
   if(!raw||raw.length>900000)return q.reject(fail('원본이 비어 있거나 너무 큼'));
   if(raw.startsWith('{')){try{var o=JSON.parse(raw);if(o.error)return q.reject(fail('공식 수집 실패: '+o.error))}catch(_){} }
   if(raw.startsWith('<')||raw.startsWith('{'))return q.reject(fail('CSV 아닌 원본/차단 응답'));
   q.resolve(raw);
 };
 function get(url){return new Promise(function(resolve,reject){if(!(root.SnowballMarketData&&typeof root.SnowballMarketData.getAsync==='function'))return reject(fail('기존 갤럭시 데이터 연결 없음'));
  var id=PREFIX+(++serial)+'_'+Date.now(),timer=setTimeout(function(){if(pending[id]){delete pending[id];reject(fail('원본 조회 시간 초과'))}},16000);
  pending[id]={resolve:resolve,reject:reject,timer:timer};try{root.SnowballMarketData.getAsync(url,id)}catch(e){clearTimeout(timer);delete pending[id];reject(e)}
 });}
 function parseCsv(src){src=String(src||'').replace(/^\uFEFF/,'');var rows=[],row=[],cell='',quote=false;
  for(var i=0;i<src.length;i++){var c=src[i];if(c==='"'){if(quote&&src[i+1]==='"'){cell+='"';i++}else quote=!quote;}
   else if(c===','&&!quote){row.push(cell);cell=''}else if((c==='\r'||c==='\n')&&!quote){if(c==='\r'&&src[i+1]==='\n')i++;row.push(cell);if(row.some(function(z){return z.trim()}))rows.push(row);row=[];cell=''}else cell+=c;}
  if(quote)throw fail('CSV 형식 오류');row.push(cell);if(row.some(function(z){return z.trim()}))rows.push(row);return rows;
 }
 function obs(id,value,date,period,source,h){return {id:id,value:Math.round(value*1000)/1000,asOf:date+'T12:00:00Z',period:period,source:source,verified:true,history:h.slice(-24).map(function(p){return {asOf:p.date+'T12:00:00Z',value:p.value}})};}
 function parseBIS(raw,country){var rows=parseCsv(raw);if(rows.length<2)throw fail('BIS CSV 내용 부족');var names=rows[0].map(function(s){return s.trim().replace(/^\uFEFF/,'')});
  var cols={};names.forEach(function(s,i){cols[s]=i});['FREQ','REF_AREA','TIME_PERIOD','OBS_VALUE'].forEach(function(s){if(cols[s]===undefined)throw fail('BIS CSV 필수 항목 누락 '+s)});
  var area=country==='kr'?'KR':'US',vals={};rows.slice(1).forEach(function(r){if(r.length!==names.length||r[cols.FREQ]!== 'M'||r[cols.REF_AREA]!==area)return;
   var t=String(r[cols.TIME_PERIOD]||''),v=num(r[cols.OBS_VALUE]);if(!/^20\d{2}-(0[1-9]|1[0-2])$/.test(t)||v===null||v<0||v>30)return;
   if(cols.DATAFLOW!==undefined&&!/WS_CBPOL/.test(String(r[cols.DATAFLOW])))return;
   vals[t]={date:t+'-01',value:v};});
  var h=Object.keys(vals).sort().map(function(k){return vals[k]});if(h.length<2)throw fail('BIS 목표 정책금리 시계열 미확인');var latest=h[h.length-1];
  if(Date.now()-Date.parse(latest.date+'T12:00:00Z')>105*DAY)throw fail('BIS 정책금리 자료 오래됨');
  return obs(country==='kr'?'krRate':'usRate',latest.value,latest.date,latest.date.slice(0,7)+' 월말', '국제결제은행 BIS · 정책금리 · '+area,h);
 }
 function parseBei(raw){var rows=parseCsv(raw);if(rows.length<2)throw fail('FRED BEI 데이터 없음');var cols={},header=rows[0].map(function(x){return x.trim().replace(/^\uFEFF/,'')});header.forEach(function(x,i){cols[x]=i});
  var d=cols.observation_date!==undefined?cols.observation_date:cols.DATE;
  if(d===undefined||cols.T10YIE===undefined)throw fail('FRED BEI 시계열 코드 누락');
  var dates={};rows.slice(1).forEach(function(r){if(r.length!==header.length)return;var date=String(r[d]||'').trim(),v=num(r[cols.T10YIE]);if(!/^20\d{2}-\d{2}-\d{2}$/.test(date)||v===null||v< -2||v>10)return;
   dates[date]={date:date,value:v};});var h=Object.keys(dates).sort().map(function(k){return dates[k]});
  if(h.length<10)throw fail('FRED BEI 유효 관측값 부족');var last=h[h.length-1];if(Date.now()-Date.parse(last.date+'T12:00:00Z')>12*DAY)throw fail('FRED BEI 자료 갱신 확인 필요');
  return obs('usBei',last.value,last.date,last.date,'미국 세인트루이스 연준 FRED · T10YIE',h);
 }
 function refresh(force){if(busy)return Promise.resolve({status:'busy'});var t=Date.now(),s=state();if(!force&&t-Number(s.lastAttempt||0)<(s.success?WAIT:RETRY))return Promise.resolve({status:'cached'});
  if(!root.NOONTANGI_FOUR_FACTORS||typeof root.NOONTANGI_FOUR_FACTORS.ingest!=='function')return Promise.resolve({status:'not-ready'});
  busy=true;save({lastAttempt:t,success:false,stage:'한미 정책금리 및 BEI 조회 중'});
  return Promise.allSettled([get(BIS_KR).then(function(x){return parseBIS(x,'kr')}),get(BIS_US).then(function(x){return parseBIS(x,'us')}),get(FRED_BEI).then(parseBei)]).then(function(res){
   var data=[],errors=[];res.forEach(function(x){if(x.status==='fulfilled')data.push(x.value);else errors.push(String(x.reason&&x.reason.message||x.reason).slice(0,130))});
   var n=data.length?root.NOONTANGI_FOUR_FACTORS.ingest(data):0;save({lastAttempt:t,success:n>0,lastSuccess:n?Date.now():s.lastSuccess||null,count:n,errors:errors,stage:n?'수신 완료':'미연결'});
   return {status:n?'received':'failed',count:n,errors:errors};}).finally(function(){busy=false});
 }
 document.addEventListener('change',function(e){if(e.target&&e.target.id==='rMarket'&&e.target.checked)setTimeout(function(){refresh(false)},1100)},true);
 root.NOONTANGI_BIS_FRED_V241={refresh:refresh,parseBIS:parseBIS,parseBei:parseBei,state:state,parseCsv:parseCsv};
 if(typeof module==='object'&&module.exports)module.exports=root.NOONTANGI_BIS_FRED_V241;
})(typeof window!=='undefined'?window:globalThis);
