/* V233 Unified Samsung Back for READ-ONLY overlays. Edit/settings retain their close controls. */
(function(){'use strict';
 var reading=[
  ['#nt223Detail.open','[data-nt223-close]'],
  ['#ntv190ArticleMonitor.open','[data-v190-article-close]'],
  ['#ntv106Firemouth.open','[data-fm106-close]'],
  ['#ntv201Cal.open','[data-ntc-close]'],
  ['#ntv80CorrOverlay.open','[data-corr-guide-close],[data-corr-close]'],
  ['#ntmeDetailOverlay.open,#ntmeDetailOverlay[aria-hidden="false"]','[data-ntme-detail-close]'],
  ['#ntv20PortfolioModal.open','[data-ntv20-close]'],
  ['#nt1232Guide.show','[data-nt1232-close],.gclose'],
  ['#ntv204Holdings.open','[data-v204-holdings-close]'],
  ['#s17Root.open','[data-s17-close]']
 ];
 function visible(el){if(!el||!el.isConnected)return false;var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>1&&r.height>1}
 function click(root,sel){var b=root&&root.querySelector(sel);if(!b)return false;try{b.click();return true}catch(_){return false}}
 function consume(){
  // Modal owner already handles settings; preserve its native hooks and editing behavior.
  for(var i=0;i<reading.length;i++){var defs=reading[i],rs=document.querySelectorAll(defs[0]);for(var k=rs.length-1;k>=0;k--){var p=rs[k];if(!visible(p))continue;
    // Editing and importing receive their original close button, rather than dismissing parent.
    var editor=p.querySelector('.fm106-editback.open,.fm106-importback.open');if(editor){var ec=editor.querySelector('[data-fm106-edit-close],[data-fm106-import-close]');if(ec){ec.click();return true}return false}
    if(click(p,defs[1]))return true;
  }}
  return false;
 }
 function install(){var api=window.NOONTANGI_MODAL_STANDARD;if(!api||api.__v233ReadonlyBack)return false;var old=api.consumeBack;
  api.consumeBack=function(){try{if(old&&old())return true}catch(_){}return consume()};api.__v233ReadonlyBack=true;return true;
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
 window.NOONTANGI_READONLY_BACK_V233={consumeBack:consume,install:install,version:'V233'};
})();
