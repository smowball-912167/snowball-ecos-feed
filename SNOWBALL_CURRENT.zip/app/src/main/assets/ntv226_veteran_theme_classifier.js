/* V226 | A veteran-author article can belong to several growth themes.
   Evidence: verified original article title + full body (never reporter specialty or menu origin).
   Conservative phrase matching; does not claim to be an AI semantic assessment. */
(function(){'use strict';
var LABELS={1:'AI반도체·HBM·첨단패키징',2:'방산·항공우주',3:'AI 데이터센터·전력망·HVDC',4:'로봇·Physical AI',5:'2차전지·ESS·차세대 소재',6:'조선·LNG·해양방산',7:'바이오 플랫폼·ADC·CDMO',8:'원전·SMR·발전설비',9:'AI 광통신·CPO·고속네트워크',10:'핵심광물·희토류·자원안보',11:'우주·위성·저궤도통신',12:'디지털자산·스테이블코인·토큰증권',13:'자율주행·SDV·AI자동차',14:'반도체 장비·소부장',15:'첨단소재·고기능성 필름',16:'분자진단·정밀의료',17:'열관리·차세대 공조',18:'태양광·재생에너지',19:'스마트팩토리·산업자동화',20:'사이버보안·양자보안'};
var DICT={
1:['HBM','high bandwidth memory','첨단패키징','advanced packaging','chiplet','칩렛','메모리 반도체','dram','디램','2.5d packaging','3d packaging','파운드리','foundry','semiconductor memory'],
2:['방산','defense contractor','defence contractor','방위산업','무기체계','군용 항공기','전투기','fighter jet','탄약','military aircraft','군사 장비','방산 수출','defense procurement','국방 수출'],
3:['데이터센터','data center','datacenter','초고압직류','HVDC','전력망','power grid','전력 케이블','grid infrastructure','전력변압기','변압기','transformer capacity','server rack','AI server','AI 서버'],
4:['협동로봇','산업용 로봇','humanoid robot','휴머노이드','physical ai','robotics','로봇팔','robot arm','robot actuator','로봇 감속기','산업 로봇','robotic automation'],
5:['2차전지','이차전지','리튬이온 배터리','battery cell','배터리 셀','양극재','음극재','battery storage','ESS','electrode','전해질','solid-state battery','전고체 배터리','battery materials'],
6:['조선소','선박 수주','조선업','shipbuilding','shipyard','LNG선','LNG carrier','해양플랜트','해양방산','선박 엔진','vessel orders','선가지수'],
7:['CDMO','ADC drug','항체약물접합체','신약 임상','clinical trial','바이오의약품','biopharmaceutical','위탁생산','drug discovery','biosimilar','바이오시밀러','신약 개발'],
8:['소형모듈원전','SMR','원자로','nuclear reactor','원자력 발전','nuclear power plant','원전 건설','핵연료','uranium enrichment','원전 설비','nuclear electricity'],
9:['CPO','co-packaged optics','co packaged optics','광트랜시버','optical transceiver','광통신','photonic interconnect','silicon photonics','실리콘 포토닉스','광모듈','optical networking','광섬유 통신'],
10:['희토류','rare earth','핵심광물','critical minerals','흑연 광산','리튬 광산','광물 공급망','mineral processing','자원안보','광산 개발','니켈 광산','cobalt mine','텅스텐 광산'],
11:['위성통신','satellite internet','저궤도','low earth orbit','LEO satellite','우주발사','rocket launch','발사체','space launch','우주항공청','spacecraft','위성 안테나','인공위성'],
12:['스테이블코인','stablecoin','토큰증권','security token','STO','digital asset','디지털자산','블록체인 결제','crypto exchange','암호화폐 거래소','증권토큰','tokenization'],
13:['자율주행','autonomous driving','self-driving','SDV','software-defined vehicle','첨단운전자보조','ADAS','전기차 자율','자율주행차','vehicle software','robotaxi','로보택시'],
14:['반도체 장비','semiconductor equipment','노광장비','EUV','ALD','식각장비','etch equipment','웨이퍼 장비','칩 제조장비','semiconductor tool','반도체 소부장','디퓨전 장비','웨이퍼 공정'],
15:['폴리이미드','polyimide','고기능성 필름','PI film','advanced materials','첨단소재','기능성 필름','특수필름','고분자 필름','OLED 소재','코팅 필름','복합소재'],
16:['분자진단','molecular diagnostics','체외진단','IVD','PCR 검사','PCR test','유전체 진단','gene sequencing','정밀의료','precision medicine','진단키트','diagnostic assay'],
17:['열관리','thermal management','냉각 시스템','liquid cooling','액침냉각','immersion cooling','히트펌프','heat pump','공조시스템','HVAC','전기차 열관리','냉매','refrigerant'],
18:['태양광','solar power','photovoltaic','풍력발전','wind turbine','재생에너지','renewable power','그린수소','green hydrogen','태양전지','solar cell','풍력 터빈','renewable energy'],
19:['스마트팩토리','smart factory','공장자동화','factory automation','industrial automation','산업자동화','PLC 제어','산업용 센서','manufacturing automation','industrial iot','무인 공장','생산설비 자동화'],
20:['사이버보안','cybersecurity','cyber security','양자보안','quantum encryption','post-quantum cryptography','랜섬웨어','ransomware','정보보안','zero trust','제로트러스트','보안 위협','quantum key distribution']
};
function norm(s){return String(s||'').toLowerCase().replace(/[\u00a0\t\r\n]+/g,' ').replace(/[‐‑‒–—]/g,'-').replace(/\s+/g,' ');}
function escapeRe(s){return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
function count(text,term){var t=norm(term),s=escapeRe(t);var isWord=/^[a-z0-9 ]+$/.test(t),re=new RegExp((isWord?'(?:^|[^a-z0-9])':'')+s+(isWord?'(?=$|[^a-z0-9])':''),'g');return Math.min((text.match(re)||[]).length,3);}
function classify(title,body){var titleN=norm(title),bodyN=norm(body).slice(0,75000),scores={},evidence={},themes=[];
 Object.keys(DICT).forEach(function(id){var score=0,found=[];DICT[id].forEach(function(k){var t=count(titleN,k),b=count(bodyN,k);if(t||b){score+=t*6+Math.min(b,2)*3;found.push(k);}});if(score>=6 && found.length){scores[id]=score;evidence[id]=found.slice(0,6);themes.push(Number(id));}});
 themes.sort(function(a,b){return scores[b]-scores[a]||a-b;});return {themeIds:themes,scores:scores,evidence:evidence,method:'verified-title-and-body-phrase-v1'};
}
window.NTV226_VETERAN_THEME_CLASSIFIER={classify:classify,labels:LABELS,version:'V226'};
})();
