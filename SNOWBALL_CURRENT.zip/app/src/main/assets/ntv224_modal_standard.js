/* V224 common top-level overlay/scroll owner for new app panels. */
(function(){'use strict';
 var IDS=['nt221Settings','nt223Detail'],lastFocus={};
 function panel(id){return document.getElementById(id)}
 function isOpen(id){var el=panel(id);return !!(el&&el.classList.contains('open'))}
 function anyOpen(){return IDS.some(isOpen)}
 function sync(){var on=anyOpen();document.documentElement.classList.toggle('nt224-modal-active',on);document.body.classList.toggle('nt224-modal-active',on)}
 function open(id){if(IDS.indexOf(id)<0)return false;var el=panel(id);if(!el)return false;
  lastFocus[id]=document.activeElement;el.classList.add('open');el.setAttribute('aria-hidden','false');sync();
  var close=el.querySelector('[data-nt221-close],[data-nt223-close]');if(close)close.focus({preventScroll:true});return true}
 function close(id){if(IDS.indexOf(id)<0)return false;var el=panel(id);if(!el||!el.classList.contains('open'))return false;
  el.classList.remove('open');el.setAttribute('aria-hidden','true');sync();document.dispatchEvent(new CustomEvent('nt224:closed',{detail:{id:id}}));
  var focus=lastFocus[id];if(focus&&focus.isConnected&&typeof focus.focus==='function')try{focus.focus({preventScroll:true})}catch(_){ }return true}
 function consumeBack(){if(isOpen('nt223Detail'))return close('nt223Detail');if(isOpen('nt221Settings'))return close('nt221Settings');return false}
 document.addEventListener('touchmove',function(ev){if(!anyOpen())return;var t=ev.target;
  if(t&&t.closest&&t.closest('[data-nt224-scroll]'))return;ev.preventDefault();},{capture:true,passive:false});
 document.addEventListener('wheel',function(ev){if(!anyOpen())return;var t=ev.target;
  if(t&&t.closest&&t.closest('[data-nt224-scroll]'))return;ev.preventDefault();},{capture:true,passive:false});
 document.addEventListener('click',function(ev){if(ev.target&&ev.target.matches&&ev.target.matches('#nt221Settings.nt224-modal.open,#nt223Detail.nt224-modal.open'))close(ev.target.id);},true);
 document.addEventListener('keydown',function(ev){if(!anyOpen())return;if(ev.key==='Escape'){if(consumeBack())ev.preventDefault()}else if(['PageUp','PageDown','Home','End','ArrowDown','ArrowUp',' '].indexOf(ev.key)>=0){var t=ev.target;if(!t||!t.closest||!t.closest('[data-nt224-scroll]'))ev.preventDefault()}},true);
 document.addEventListener('change',function(ev){if(ev.target&&ev.target.matches&&ev.target.matches('#rMarket,#rHome,#rLong,#rShort,#rRadar,#rBell,#rReport,#rAI'))IDS.forEach(close)},true);
 window.NOONTANGI_MODAL_STANDARD={open:open,close:close,consumeBack:consumeBack,isOpen:isOpen,version:'V224'};
})();
