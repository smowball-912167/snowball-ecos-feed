/* V225 market overview: dedicated news collection per four approved market domains.
   No import from major-news catalogue. User selects headline to see verified short summary.
   Old market detail engine, unrelated routes, and stored user records remain unchanged. */
(function(){'use strict';
 var KEY='nt_market_v221_visible_indicators';
 var SPECS=[['kospi','KOSPI','▥','index'],['kosdaq','KOSDAQ','▥','index'],['spx','S&P500','🇺🇸','index'],['nasdaq','NASDAQ','🇺🇸','index'],['vix','VIX','〰','number'],['usdkrw','원/달러','₩','fx'],['us10y','미 10년물','▤','yield'],['wti','WTI','◉','usd'],['gold','금','◆','usd'],['dxy','달러인덱스','＄','number'],['sox','필라델피아 반도체','▥','index'],['rut','러셀2000','▥','index'],['copper','구리','◆','usd'],['hyg','미국 하이일드채','▤','number']];
 var BASE=['kospi','kosdaq','spx','nasdaq','vix','usdkrw','us10y','wti','gold'];
 var lastDetailOpen=0;
 var NEWS_STORE='nt223-market-only-articles', NEWS_LAST='nt223-market-only-checks', NEWS_TRY='nt223-market-last-attempt', NEWS_BRIEFS='nt223-market-source-briefs', NEWS_EXPANDED=false, NEWS_BUSY=false, NEWS_ERROR='', NEWS_SEQ=0, NEWS_CB={}, NEWS_ACTIVE=false;
 var NEWS_TOPICS=[{id:'rates',label:'금리·물가',symbol:'▤',regex:/금리|물가|인플레이션|인플레|국채|채권금리|기준금리|연준|연방준비|중앙은행|CPI|PCE|FED|FOMC|유가|원유|WTI|OPEC|관세|물가상승/i,query:'금리 OR 물가 OR 연준 OR 국채 OR 유가 when:7d',world:'__GLOBAL__ inflation OR Federal Reserve OR interest rates when:7d'},
 {id:'earnings',label:'기업실적·경기',symbol:'▣',regex:/기업실적|실적|영업이익|순이익|매출|어닝|전망치|가이던스|GDP|경기|고용|소비|제조업|PMI|수출|경기침체|기업이익|earnings|revenue|economy|jobs/i,query:'기업 실적 OR 경기 OR 고용 OR GDP when:7d',world:'__GLOBAL__ corporate earnings OR economy OR GDP when:7d'},
 {id:'flows',label:'수급·환율',symbol:'₩',regex:/환율|원화|달러|외국인|기관|수급|자금유입|자금유출|순매수|순매도|자본유출|통화가치|달러인덱스|exchange rate|USD|KRW|investor flows/i,query:'외국인 순매수 OR 기관 수급 OR 원달러 환율 when:7d',world:'__GLOBAL__ dollar exchange rate OR foreign capital flows when:7d'},
 {id:'trend',label:'주가 추세·VIX',symbol:'▥',regex:/코스피|코스닥|나스닥|다우지수|S&P\s?500|VIX|변동성|증시|주가지수|주식시장|증시급락|증시반등|주가흐름|market volatility|stock market|wall street/i,query:'코스피 OR 나스닥 OR VIX OR 증시 when:7d',world:'__GLOBAL__ VIX OR stock market OR S&P500 when:7d'}];
 var NEWS_BLOCK=/국감|국정감사|탄핵|정쟁|청문회|여야공방|총선|대선|선거전략|의원질의|국회의원|정당공방/i;
 var NEWS_CACHE=json(NEWS_STORE,[]);if(!Array.isArray(NEWS_CACHE))NEWS_CACHE=[];var NEWS_SELECTED=null;
 function byId(id){return document.getElementById(id)}
 function e(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
 function json(k,fb){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?fb:v}catch(_){return fb}}
 function store(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(_){}}
 function selection(){var ids=json(KEY,BASE);if(!Array.isArray(ids))ids=BASE;var valid=SPECS.map(function(x){return x[0]});ids=ids.filter(function(x,i){return valid.indexOf(x)>=0&&ids.indexOf(x)===i});return ids.slice(0,9)}
 function active(){return !!(byId('rMarket')&&byId('rMarket').checked)}
 function num(n){n=Number(n);return isFinite(n)?n:null}
 function quoteMap(){var snap=(window.NOONTANGI_MARKET_ENV&&window.NOONTANGI_MARKET_ENV.snapshot&&window.NOONTANGI_MARKET_ENV.snapshot())||json('NOONTANGI_MARKET_ENV_V2',{});var m={};(snap.items||[]).forEach(function(x){if(x&&x.id)m[x.id]=x});return {snap:snap,map:m}}
 function fmt(n,kind){if(n==null)return '—';if(kind==='yield')return n.toFixed(3)+'%';if(kind==='usd')return '$'+n.toFixed(2);return n.toLocaleString('ko-KR',{maximumFractionDigits:kind==='number'?2:2})}
 function change(n){if(n==null)return '<span class="nt221-muted">변동 확인 중</span>';var sign=n>0?'+':'';return '<span class="'+(n>0?'nt221-pos':n<0?'nt221-neg':'nt221-muted')+'">'+sign+n.toFixed(2)+'%</span>'}
 function time(ts){if(!ts)return '기준시각 확인 중';var d=new Date(ts),n=d.getTime();if(!isFinite(n))return '기준시각 확인 중';return d.toLocaleString('ko-KR',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).replace(/\.$/,'')}
 function validQuote(q,id){var x=q.map[id];return !!(x&&x.valid===true&&num(x.price)!=null&&num(x.ts)!=null&&Date.now()-Number(x.ts)<120*3600000)}
 function quotePct(q,id){return validQuote(q,id)?num(q.map[id].changePct):null}
 function marketPct(v){return v==null?'—':(v>0?'+':'')+v.toFixed(2)+'%'}
 function assessment(q){
  var required=['kospi','kosdaq','spx','nasdaq','vix','usdkrw','us10y','wti'],got=required.filter(function(id){return validQuote(q,id)}).length;
  var saved=json('NOONTANGI_MARKET_SCORE_V1',{}),cur=saved.current||{},prev=saved.prev||{};
  var fresh=got===8&&num(cur.score)!=null&&Number(cur.asOf)===Number(q.snap.asOf)&&Number(q.snap.asOf)>0&&Date.now()-Number(q.snap.asOf)<120*3600000;
  if(!fresh)return {ready:false,status:'판단 보류',tone:'unknown',score:null,delta:null,count:got,reason:'시세 8개 중 검증 완료 '+got+'/8개 · 최신 평가가 확보되지 않았습니다.'};
  var score=Math.round(Math.max(0,Math.min(100,Number(cur.score)))),delta=num(prev.score)!=null&&prev.asOf!==cur.asOf?score-Number(prev.score):null;
  var tone=score>=65?'good':score>=45?'neutral':score>=30?'warn':'risk',status=score>=65?'우호 · 분할 대응':score>=45?'중립 · 선별 대응':score>=30?'주의 · 방어 점검':'위험 · 방어 우선';
  return {ready:true,status:status,tone:tone,score:score,delta:delta,count:got,reason:'8개 시세로 계산한 참고점수 · 기업 실적·실제 물가·외국인/기관 수급은 점수에 포함되지 않음'};
 }
 function marketAmount(v){var n=num(v);return n==null?'확인 불가':(n>0?'+':'')+Math.round(n).toLocaleString('ko-KR')+'억 원'}
 function signalGroups(q){var val=function(id){return quotePct(q,id)},p=function(id){var z=val(id);return z==null?'자료 없음':marketPct(z)},us=val('us10y'),oil=val('wti'),usStock=val('spx'),krStock=val('kospi'),krSmall=val('kosdaq'),nas=val('nasdaq'),fx=val('usdkrw'),vix=validQuote(q,'vix')?num(q.map.vix.price):null,vc=val('vix');
  var rateHits=[];
  if(us!=null)rateHits.push(us>0.5?'미국 장기금리가 상승해 성장주 할인율 부담이 커질 수 있습니다.':us<-.5?'미국 장기금리가 하락해 할인율 부담이 일부 완화됐습니다.':'미국 장기금리는 전일과 큰 차이가 없습니다.');
  if(oil!=null)rateHits.push(oil>2?'유가가 2% 넘게 올라 원가·물가 부담 신호가 있습니다.':oil< -2?'유가가 2% 넘게 내려 원가 부담을 낮추는 방향입니다.':'유가는 전일 대비 '+p('wti')+'입니다.');
  var rateTone=us==null&&oil==null?'unknown':(us>1||oil>3)?'risk':(us>0.5||oil>2)?'warn':(us<-.5&&oil<=0)?'good':'neutral';
  var allStock=[usStock,krStock,krSmall,nas],stockText=allStock.some(function(x){return x!=null})?'참고 시세: S&P500 '+p('spx')+' · 나스닥 '+p('nasdaq')+'. 단기 주가 변동만으로 실제 기업이익·경기 방향을 확정할 수 없습니다.':'주요 지수도 수신되지 않았습니다.';
  var ext=json('NOONTANGI_MARKET_EXTERNAL_V1',{}),flows=Array.isArray(ext.flow)?ext.flow:[],validFlows=flows.filter(function(r){return r&&r.valid===true&&/^20\d{6}$/.test(String(r.bizdate||''))&&Math.abs(Date.now()-new Date(String(r.bizdate).slice(0,4)+'-'+String(r.bizdate).slice(4,6)+'-'+String(r.bizdate).slice(6,8)+'T15:30:00+09:00').getTime())<7*86400000});
  var flowText=validFlows.length?validFlows.map(function(r){return e(r.market||'시장')+' 외국인 '+marketAmount(r.foreign)+' · 기관 '+marketAmount(r.institutional)}).join(' / '):'검증된 최신 외국인·기관 순매수 데이터 없음';
  var fxText=fx==null?'원/달러 시세가 준비되지 않았습니다.':fx>0.3?'원/달러 '+p('usdkrw')+'로 원화 약세 압력이 나타났습니다. 다만 외국인 순매도를 의미하지는 않습니다.':fx<-.3?'원/달러 '+p('usdkrw')+'로 원화 강세 방향입니다. 실제 외국인 매수 여부는 별도 확인이 필요합니다.':'원/달러 '+p('usdkrw')+'로 큰 변동은 없습니다.';
  var riskTone=(vix!=null&&vix>=30)||(vc!=null&&vc>8&&krStock!=null&&krStock<0)?'risk':(vix!=null&&vix>=23)||(krStock!=null&&krStock<-.8)||(krSmall!=null&&krSmall<-1)?'warn':(vix!=null&&vix<20&&krStock!=null&&krStock>0&&krSmall!=null&&krSmall>0)?'good':vix==null&&krStock==null?'unknown':'neutral';
  var riskText='코스피 '+p('kospi')+' · 코스닥 '+p('kosdaq')+(vix!=null?' · VIX '+vix.toFixed(2):' · VIX 미수신')+'. ';
  riskText+=riskTone==='risk'?'변동성·지수 움직임이 함께 경계 신호를 보입니다.':riskTone==='warn'?'일부 위험 신호가 나타나 추격 매수에는 주의가 필요합니다.':riskTone==='good'?'국내 지수 동반 상승과 낮은 변동성이 단기 우호 신호입니다.':'지수와 변동성이 한 방향으로 뚜렷하게 정렬되지 않았습니다.';
  return [
    {name:'금리·물가',sub:'금리·유가 시세 참고',tone:rateTone,chip:rateTone==='risk'?'부담 확대':rateTone==='good'?'부담 완화':rateTone==='unknown'?'자료 부족':'혼재',brief:'미 10년물 '+p('us10y')+' · WTI '+p('wti'),detail:(rateHits.join(' ')||'확인된 금리·유가 자료가 없습니다.')+' 실제 CPI·PCE 물가 발표는 현재 판단에 미연결입니다.',warn:'물가지표 미연결'},
    {name:'기업실적·경기',sub:'실적·경기 발표 근거',tone:'unknown',chip:'발표자료 확인 필요',brief:'실적·경기 공식 발표값 미연결',detail:stockText+' 아래 관련 기사는 참고용이며 공식 실적·경기지표를 대체하지 않습니다.',warn:'주가로 실적을 대체하지 않음'},
    {name:'수급·환율',sub:'원/달러 시세 참고',tone:'unknown',chip:'수급 판단 보류',brief:fx==null?'원/달러 자료 부족':'원/달러 '+p('usdkrw')+' · '+(validFlows.length?'수급 확인':'수급 확인 중'),detail:fxText+' '+flowText+'. '+(validFlows.length?'최근 수급 근거는 제공 시점과 시장을 확인하세요.':'검증된 수급 값이 없으므로 자금 유입·유출 판단은 보류합니다.'),warn:validFlows.length?'최근 확인 가능한 수급':'외국인·기관 수급 미연결'},
    {name:'주가 추세·VIX',sub:'지수·변동성',tone:riskTone,chip:riskTone==='risk'?'위험 확대':riskTone==='warn'?'경계':riskTone==='good'?'우호':'혼재',brief:'코스피 '+p('kospi')+' · VIX '+(vix==null?'—':vix.toFixed(2)),detail:riskText,warn:'하루 등락 기반 단기 신호'}
  ];
 }
 function marketOneLine(q,a){
  if(!a.ready)return '오늘 증시: 주요 지표 확인 중 · 종합 판단 보류';
  var kp=quotePct(q,'kospi'),kd=quotePct(q,'kosdaq'),vx=validQuote(q,'vix')?num(q.map.vix.price):null;
  var direction=kp!=null&&kd!=null?(kp>0&&kd>0?'국내증시 동반 상승':kp<0&&kd<0?'국내증시 동반 하락':'국내증시 방향 혼조'):'국내증시 방향 확인 중';
  var volatility=vx==null?'변동성 미확인':vx>=25?'변동성 경계':vx<20?'변동성 안정':'변동성 보통';
  return '오늘 증시: '+direction+' · '+volatility+' · '+(a.score>=65?'우호':a.score>=45?'선별 대응':a.score>=30?'주의':'방어 우선');
 }
 function drivers(q){var good=[],bad=[],c=function(id){return quotePct(q,id)},vix=validQuote(q,'vix')?num(q.map.vix.price):null;
  if(c('kospi')!=null&&c('kosdaq')!=null){if(c('kospi')>0&&c('kosdaq')>0)good.push('코스피·코스닥 동반 상승');else if(c('kospi')<0&&c('kosdaq')<0)bad.push('코스피·코스닥 동반 하락');}
  if(c('us10y')!=null){if(c('us10y')<-.5)good.push('미 장기금리 하락');else if(c('us10y')>.5)bad.push('미 장기금리 상승');}
  if(c('usdkrw')!=null){if(c('usdkrw')<-.3)good.push('원화 강세 방향');else if(c('usdkrw')>.3)bad.push('원화 약세 방향');}
  if(vix!=null){if(vix<18)good.push('VIX 18 아래');else if(vix>=25)bad.push('VIX 25 이상');}
  if(c('wti')!=null&&c('wti')>2)bad.push('국제유가 2% 이상 상승');
  return {good:good.slice(0,2),bad:bad.slice(0,2)};
 }
 function investmentNote(a){if(!a.ready)return '지표 검증이 끝나지 않아 신규 비중 확대 신호를 제시하지 않습니다. 기존 보유전략은 개별 근거를 기준으로 유지합니다.';
  if(a.score<30)return '장기·ETF는 현금 여력과 분할 간격을 우선하고, 단기는 새로운 진입보다 위험 노출을 줄이는 방향이 유리합니다. 종목의 실제 매매 여부는 별도 신호로 결정합니다.';
  if(a.score<45)return '신규 비중 확대를 서두르지 않고, 장기는 기업가치와 현금 여력을, 단기는 거래량·손절 기준을 더 엄격하게 확인하는 환경입니다.';
  if(a.score<65)return '시장 전체 확신이 낮은 중립 국면입니다. 장기·ETF는 계획된 분할 중심, 단기는 실제 수급과 개별 종목 신호가 분명한 경우만 검토합니다.';
  return '시세 기준 위험선호가 상대적으로 우호적입니다. 계획된 분할매수는 검토할 수 있지만 실적·수급 원자료가 없으므로 추격매수 근거로 쓰면 안 됩니다.';
 }
 function sixAxes(q,a){var c=function(id){return quotePct(q,id)},v=function(id){return validQuote(q,id)?num(q.map[id].price):null};if(!a.ready)return [];
  var avg=(c('kospi')+c('kosdaq')+c('spx')+c('nasdaq'))/4,clamp=function(x){return Math.round(Math.max(0,Math.min(100,x)))};
  return [ ['글로벌 위험선호',clamp(50+avg*12)],['변동성 안정',clamp(100-(v('vix')-12)*5)],['환율 안정',clamp(55-c('usdkrw')*18)],['금리 부담 완화',clamp(55-c('us10y')*6)],['국내 지수 확산',clamp(50+(c('kospi')+c('kosdaq'))/2*15)],['원자재 부담 완화',clamp(55-c('wti')*6)]];
 }
 function evidenceFor(group){var now=Date.now(),article=NEWS_CACHE.filter(function(x){return !!newsTopic(x.title)&&x.group===group&&Number(x.ts)>0&&now-Number(x.ts)<15*86400000&&now>=Number(x.ts)-3600000}).sort(function(a,b){return b.ts-a.ts})[0];
  if(!article)return '<p class="nt231-axis-source nt231-source-missing">관련 기사 근거 확인 중 · 시장 주요뉴스에서 수집 후 표시합니다.</p>';
  var txt=article.titleKo||(/[가-힣]/.test(article.title)?article.title:'글로벌 원문 제목 번역 중');
  return '<button type="button" class="nt231-axis-source" data-nt223-select="'+e(article.id)+'"><span>관련 기사 · '+e(day(article.ts))+' · '+e(article.source||'출처 미확인')+'</span><b>'+e(txt)+'</b></button>';
 }
 function updateEvidence(){document.querySelectorAll('#ntmeV222 [data-nt231-evidence]').forEach(function(el){var html=evidenceFor(el.getAttribute('data-nt231-evidence'));if(el.innerHTML!==html)el.innerHTML=html})}
 /* V237 · TWO USER PHOTOS: the original four-domain reference and practical investment guide.
    These reference conditions must never be presented as automatically verified live signals. */
 /* V238: actual four factors from shared correlation feed; no proxies, no additional scoring. */
 function photoFourRows(q){
  var api=window.NOONTANGI_FOUR_FACTORS;
  var groups=api&&api.build?api.build():[];
  var guidance=[
    '금리 하락 및 안정화 → 성장주 밸류에이션 확장 가능성',
    'PMI 50 이상 유지 → 실적 장세 진입 및 주도주 집중 검토',
    '인플레이션 둔화 → 기업 원가 부담 완화 및 마진 개선 가능성',
    '고객예탁금 증가와 외국인 순매수 → 시장 상승 탄력 강화 가능성'
  ];
  return groups.map(function(x,i){return {name:x.name,sub:(x.items||[]).map(function(y){return y.label}).slice(0,3).join(' · '),bullish:x.bull,bearish:x.bear,items:x.items||[],pair:x.pair,strategy:guidance[i]||''}});
 }
 function nt238DataRows(g){var checked=0,all=g.items||[],core=all.filter(function(x){return !x.supplementary}),html=all.map(function(x){var ok=!!x.value;if(ok&&!x.supplementary)checked++;return '<div class="nt238-row"><span class="nt238-row-label">'+e(x.label)+'</span><span class="nt238-row-value '+(ok?'nt238-has':'nt238-missing')+'">'+e(x.value||'미연결')+'</span>'+(ok?'<small>'+e(x.source||'출처 확인 필요')+' · '+e(x.asOf||'발표일 확인 필요')+'</small>':'')+'</div>'}).join('');
  return '<div class="nt238-observed"><b>실제 확인 자료 <small>'+checked+'/'+core.length+' 항목'+(all.length>core.length?' · 월별 참고 '+(all.length-core.length)+'건':'')+'</small></b><div class="nt238-observed-grid">'+html+'</div><p class="nt238-disclaimer">확인되지 않은 항목은 다른 지표의 차트로 대체하지 않습니다. 일부 수치만으로 4대 분야 전체를 확정 판정하지 않습니다.</p></div>';
 }
 function nt238Paired(g){if(!g.pair)return '';var p=g.pair;return '<div class="nt238-weight"><b>'+e(p.title)+' · 동일지표 가중 적용</b><p>국내 65% · 미국 35% (양국 실제 데이터 확보 시에만 적용)</p><p>한국 '+e(p.domestic)+' · '+e(p.koreanSignal)+' / 미국 '+e(p.us)+' · '+e(p.usSignal)+'</p><p>판단: '+e(p.verdict)+'</p></div>';}
 function ecosStatus(){var text='ECOS 자동 수집: 연결 확인 전';try{var j=JSON.parse(localStorage.getItem('NOONTANGI_ECOS_V245_STATE')||'{}');if(j&&j.lastAttempt)text=j.stage||text;else text='ECOS 자동 수집: 공개 피드 미설정 또는 조회 전';}catch(_){}return text;}
 function marketDashboard(q,a){var segments=photoFourRows(q),dr=drivers(q),six=sixAxes(q,a),trend=a.delta==null?'이전 점수 없음':(a.delta>0?'전일 대비 +':'전일 대비 ')+Math.round(a.delta)+'점',good=dr.good.length?dr.good.join(' · '):'우호 신호 미확인',bad=dr.bad.length?dr.bad.join(' · '):'뚜렷한 위험 신호 미확인';
  return '<section class="nt221-card nt225-dashboard nt225-tone-'+a.tone+'"><div class="nt221-head"><h2>시장환경</h2><span class="nt225-time">'+e(time(q.snap.asOf))+'</span></div>'+
   '<div class="nt225-hero"><div class="nt225-hero-copy"><span class="nt225-overline">기존 시세 8개 기반 참고평가 · 4대 구성요소 판정과 별개</span><h3>'+e(a.status)+'</h3><p class="nt225-hero-help nt231-market-oneline">'+e(marketOneLine(q,a))+'</p></div><div class="nt225-score" style="--nt225-p:'+(a.score==null?0:a.score)+'%"><strong>'+(a.score==null?'—':a.score)+'</strong><small>/ 100</small></div></div>'+
   '<div class="nt225-trend"><span class="nt225-dot"></span>'+e(a.ready?trend:'현재 점수 미산출')+' <span class="nt225-chip-note">데이터 '+a.count+'/8</span></div>'+
   '<div class="nt225-driver-grid"><div class="nt225-driver nt225-positive"><b>긍정 신호</b><p>'+e(good)+'</p></div><div class="nt225-driver nt225-negative"><b>경계 신호</b><p>'+e(bad)+'</p></div></div>'+
   '<div class="nt225-axis-title">시장환경 4대 구성요소 <small>국내+기존 해외 지표 · 항목 선택</small></div>'+
   '<p class="nt237-ref-label">사용자가 정한 판단 조건은 그대로 유지하며 실제 수치·미연결 상태를 구분합니다. 같은 한·미 지표가 함께 있을 때에만 국내 65%/미국 35%를 적용합니다.</p>'+
   '<div class="nt255-ecos-refresh" style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin:5px 0 9px"><p class="nt237-ref-label" data-ntv245-ecos-state style="font-size:13px;flex:1;margin:0">'+e(ecosStatus())+'</p><button type="button" data-ntv255-ecos-refresh style="font-size:12px;padding:7px 9px;border:1px solid #cad5de;border-radius:9px;background:#fff;color:#26556d;white-space:nowrap">ECOS 새로 확인</button></div>'+
   segments.map(function(g,i){return '<details class="nt221-axis nt225-axis nt237-axis"><summary><span class="nt225-axis-left"><span class="nt237-seq">'+(i+1)+'</span><span class="nt225-axis-text"><b>'+e(g.name)+'</b><small>'+e(g.sub)+'</small></span></span><span class="nt225-axis-right"><span class="nt225-chevron">⌄</span></span></summary><div class="nt225-axis-body nt237-axis-body"><div class="nt237-signal-pair"><div class="nt237-signal nt237-bull"><b>긍정 신호 (Bullish)</b>'+g.bullish.map(function(s){return '<p>• '+e(s)+'</p>'}).join('')+'</div><div class="nt237-signal nt237-bear"><b>부정 신호 (Bearish)</b>'+g.bearish.map(function(s){return '<p>• '+e(s)+'</p>'}).join('')+'</div></div><div class="nt237-strategy"><b>실전 적용 가이드</b><p>'+e(g.strategy)+'</p></div>'+nt238DataRows(g)+nt238Paired(g)+'</div></details>'}).join('')+
   (six.length?'<details class="nt225-six"><summary>6개 세부 판단축 · 근거 점수 보기 <span>⌄</span></summary><div class="nt225-six-grid">'+six.map(function(s){return '<div class="nt225-six-row"><span>'+e(s[0])+'</span><div class="nt225-six-rail"><i style="width:'+s[1]+'%"></i></div><b>'+s[1]+'</b></div>'}).join('')+'</div><p class="nt225-six-note">6축은 시세 지표로 계산한 참고값입니다. 기업실적·실제 수급 등을 분석한 확정 점수가 아닙니다.</p></details>':'')+
   '<div class="nt225-action"><b>오늘 시장환경 투자대응</b><p>'+e(investmentNote(a))+'</p></div></section>';
 }
  function view(){var q=quoteMap(),a=assessment(q),ids=selection();var root=byId('ntmeV222');if(!root)return;
  var dashboard=marketDashboard(q,a);
  var tiles=ids.map(function(id){var s=SPECS.filter(function(x){return x[0]===id})[0];if(!s)return '';var x=q.map[id]||{},ok=validQuote(q,id),pr=ok?num(x.price):null,pct=ok?num(x.changePct):null;return '<button type="button" class="nt221-tile" data-nt221-chart="'+e(id)+'" aria-label="'+e(s[1])+' 상세차트"><span class="name">'+e(s[2])+' '+e(s[1])+'</span><span class="value">'+e(fmt(pr,s[3]))+'</span><span class="change">'+change(pct)+'</span></button>'}).join('');
  var ind='<section class="nt221-card"><div class="nt221-head"><h2>시장지표</h2><div class="nt221-actions"><button class="nt221-btn" type="button" data-nt221-settings aria-label="시장지표 환경설정 더보기">더보기 ›</button></div></div><div class="nt221-note" style="margin-bottom:8px">환경설정에서 등록 · 최대 9개</div><div class="nt221-tiles">'+tiles+'</div><div class="nt221-timestamp">시세 기준: '+e(time(q.snap.asOf))+' · 미확인 값은 표시하지 않습니다.</div></section>';
  var currentOpen=root.querySelectorAll('details.nt221-axis[open],details.nt225-six[open]'),opened=Array.prototype.map.call(currentOpen,function(x){return Array.prototype.indexOf.call(x.parentNode.querySelectorAll('details.nt221-axis,details.nt225-six'),x)});
  root.innerHTML=dashboard+'<section class="nt221-card"><div class="nt221-head"><h2>시장 주요뉴스</h2><button type="button" class="nt221-btn" data-nt221-more>더보기 ›</button></div><div id="nt221News"><div class="nt221-empty">시장 관련 뉴스를 확인 중입니다.</div></div></section>'+ind;mountSettings();
  var panels=root.querySelectorAll('details.nt221-axis,details.nt225-six');opened.forEach(function(i){if(panels[i])panels[i].open=true});
  news();
 }
 function newsCategory(n){
  var t=String(n.titleKo||n.title||'');
  if(/원유|국제유가|유가|WTI|브렌트|OPEC|원유선물/i.test(t))return '유가';
  if(/환율|원.?달러|달러.?원|외환|달러인덱스|외환시장|환율시장|USD.?KRW/i.test(t))return '환율';
  if(/물가|CPI|PCE|인플레이션|인플레/i.test(t))return '물가';
  if(/금리|국채|채권|연준|FOMC|기준금리|채권시장|연방준비|Fed\b/i.test(t))return '금리';
  if(/외국인|기관|순매수|순매도|수급|자금유입|자금유출/i.test(t))return '수급';
  if(/기업실적|영업이익|매출|순이익|어닝|실적|earnings|revenue/i.test(t))return '실적';
  if(/고용|GDP|경기|소비|제조업|PMI|수출|economy|jobs/i.test(t))return '경기';
  if(/VIX|변동성/i.test(t))return '변동성';
  if(/증시|주가|주식시장|코스피|코스닥|S&P.?500|NASDAQ|나스닥|stock market/i.test(t))return '증시';
  return ({rates:'금리',earnings:'경기',flows:'수급',trend:'증시'})[n.group]||'경제';
 }
 function newsTopic(title){var t=String(title||'').trim();if(!t||NEWS_BLOCK.test(t)||/Dallas Cowboys|Christian Parker|Disney Adult|NFL|NBA|NHL|MLB|야구|축구|선수|감독 교체|연예|아이돌|디즈니 팬|문화행사|관광명소/i.test(t))return null;for(var i=0;i<NEWS_TOPICS.length;i++)if(NEWS_TOPICS[i].regex.test(t))return NEWS_TOPICS[i];return null;}
 function nativeResolve(){var api=window.NOONTANGI_EXTERNAL_INFO=window.NOONTANGI_EXTERNAL_INFO||{};if(api.__marketV223Hook)return;var prior=api.resolve;api.resolve=function(id,raw){if(String(id).indexOf('ntm223_')===0){var task=NEWS_CB[id];if(!task)return false;delete NEWS_CB[id];clearTimeout(task.timer);try{task.resolve(JSON.parse(String(raw||'{}')))}catch(_){task.resolve({error:'결과 형식 오류',items:[]})}return true}if(typeof prior==='function')return prior(id,raw);return false;};api.__marketV223Hook=true;}
 function nativeNews(method,args,wait){return new Promise(function(resolve){var b=window.SnowballExternalInfo;if(!b||typeof b[method]!=='function'){resolve({error:'기기 뉴스 연결을 사용할 수 없습니다.',items:[]});return}nativeResolve();var id='ntm223_'+(++NEWS_SEQ)+'_'+Date.now(),timer=setTimeout(function(){delete NEWS_CB[id];resolve({error:'원문 또는 뉴스 응답 시간 초과',items:[]})},wait||17000);NEWS_CB[id]={resolve:resolve,timer:timer};try{b[method].apply(b,args.concat(id))}catch(_){clearTimeout(timer);delete NEWS_CB[id];resolve({error:'뉴스 요청 중 오류가 발생했습니다.',items:[]})}})}
 function fixedDate(d){var x=Date.parse(d||'');return isFinite(x)?x:Date.now();}
 function day(ts){var d=new Date(ts);if(!isFinite(d.getTime()))return '날짜 미확인';return [d.getFullYear(),('0'+(d.getMonth()+1)).slice(-2),('0'+d.getDate()).slice(-2)].join('.');}function shortDay(ts){var d=new Date(ts);return isFinite(d.getTime())?('0'+(d.getMonth()+1)).slice(-2)+'.'+('0'+d.getDate()).slice(-2):'날짜 없음'}
 function newsKey(it){return String(it.link||it.url||'').trim().toLowerCase()||String(it.title||'').trim().toLowerCase().replace(/\s+/g,'');}
 function saveNews(){store(NEWS_STORE,NEWS_CACHE.slice(0,240))}
 function addNews(response,chosen){if(!response||response.error||!Array.isArray(response.items))return 0;var added=0;
 response.items.forEach(function(x){var title=String(x.title||'').trim(),url=String(x.link||x.url||'').trim();if(!/^https:\/\//i.test(url))return;
 var group=newsTopic(title);if(!group)return;var key=newsKey(x);
 if(NEWS_CACHE.some(function(n){return n.key===key||n.title.toLowerCase()===title.toLowerCase()}))return;
 NEWS_CACHE.push({key:key,id:'m'+Date.now()+'_'+Math.floor(Math.random()*1000000),group:group.id,title:title,titleKo:/[가-힣]/.test(title)?title:'',url:url,source:String(x.source||'').trim(),description:plainText(x.description||'').slice(0,800),image:(function(v){v=String(v||'').trim();return /^https:\/\/[^\s<>"']+$/i.test(v)?v:''})(x.imageUrl||x.image||x.thumbnail||''),ts:fixedDate(x.pubDate),lane:String(response.lane||'KR')});added++});
 if(added){NEWS_CACHE.sort(function(a,b){return b.ts-a.ts});NEWS_CACHE=NEWS_CACHE.slice(0,240);saveNews()}return added;}
 function renderHeadlines(){var target=byId('nt221News');if(!target)return;var all=NEWS_CACHE.filter(function(n){return !!newsTopic(n.title)}).sort(function(a,b){return b.ts-a.ts});var primary=NEWS_TOPICS.map(function(g){return all.find(function(a){return a.group===g.id})}).filter(Boolean);var rest=all.filter(function(a){return primary.indexOf(a)<0});var list=NEWS_EXPANDED?all.slice(0,45):primary.concat(rest).slice(0,7);
 var more=document.querySelector('#ntmeV222 [data-nt221-more]');if(more)more.textContent=NEWS_EXPANDED?'접기 ›':'더보기 ›';
 if(!list.length){updateEvidence();target.innerHTML='<div class="nt221-empty">'+e(NEWS_BUSY?'네 가지 시장분야의 최신 기사를 수집하고 있습니다.':(NEWS_ERROR||'일치하는 시장 뉴스가 아직 없습니다.'))+' <button type="button" class="nt221-btn" data-nt223-retry>새로고침</button></div>';return;}
 target.innerHTML=list.map(function(n){var grp=NEWS_TOPICS.find(function(g){return g.id===n.group})||NEWS_TOPICS[0];var title=n.titleKo||(/[가-힣]/.test(n.title)?n.title:'글로벌 시장 기사 · 제목 번역 중');return '<button type="button" class="nt221-newsrow nt223-newsrow" data-nt223-select="'+e(n.id)+'" aria-label="'+e(title)+' 기사 상세"><span class="nt223-sign"><span class="nt223-symbol nt232-news-category" aria-label="'+e(newsCategory(n))+'">'+e(newsCategory(n))+'</span><span class="nt223-day" title="'+e(day(n.ts))+'">'+e(shortDay(n.ts))+'</span></span><span class="nt223-headline">'+e(title)+'</span></button>'}).join('')+(NEWS_BUSY?'<div class="nt223-feed-state">새 기사 수집 중 · 저장된 기사는 그대로 표시합니다.</div>':'');
 updateEvidence();
 list.filter(function(n){return !n.titleKo&&!/[가-힣]/.test(n.title)}).slice(0,2).forEach(function(n){translateTitle(n)});
 if(!NEWS_BUSY)prefetchSoon();
 }
 function translateTitle(n){if(!n||n._translating||n.titleKo)return;n._translating=true;nativeNews('translateKorean',[n.title.slice(0,500)],15000).then(function(r){var ko=String(r.translated||'').trim();if(/[가-힣]/.test(ko)){n.titleKo=ko;saveNews();if(active())renderHeadlines()}}).finally(function(){n._translating=false})}
 function collectMarketNews(force){if(NEWS_BUSY)return Promise.resolve(false);var last=Number(json(NEWS_LAST,0))||0,lastTry=Number(json(NEWS_TRY,0))||0;if(!force&&((last&&Date.now()-last<20*60000)||(lastTry&&Date.now()-lastTry<5*60000))){renderHeadlines();return Promise.resolve(true)}
 NEWS_BUSY=true;NEWS_ERROR='';store(NEWS_TRY,Date.now());renderHeadlines();var jobs=[];NEWS_TOPICS.forEach(function(g){jobs.push({id:g.id,query:g.query});jobs.push({id:g.id,query:g.world})});var successes=0,failures=0,addedTotal=0,at=0,workers=[];
 function consume(){if(at>=jobs.length)return Promise.resolve();var job=jobs[at++];return nativeNews('searchNews',[job.query],14000).then(function(r){if(!r.error&&Array.isArray(r.items)){successes++;addedTotal+=addNews(r,job.id)}else failures++;renderHeadlines();}).then(consume)}
 workers.push(consume());workers.push(consume());return Promise.all(workers).then(function(){if(successes)store(NEWS_LAST,Date.now());if(!successes)NEWS_ERROR='시장 관련 뉴스를 가져오지 못했습니다. 연결 상태를 확인하고 새로고침을 눌러주세요.';else if(!NEWS_CACHE.some(function(n){return !!newsTopic(n.title)}))NEWS_ERROR='뉴스 피드는 연결됐지만 금리·물가·경기·환율·증시에 맞는 기사가 없습니다.';else if(failures)NEWS_ERROR='일부 출처 조회가 지연되고 있습니다.';return successes>0}).finally(function(){NEWS_BUSY=false;renderHeadlines();prefetchSoon()});}
 function selectedItem(id){return NEWS_CACHE.find(function(n){return n.id===id})||null;}
 /* V233: EXTRACTIVE, not AI generation. Never claim full-article comprehension when source is partial. */
 function plainText(raw){var x=String(raw||'');x=x.replace(/&(?:nbsp|#160|#xA0);?/gi,' ').replace(/&(?:amp|#38);?/gi,'&').replace(/&(?:quot|#34);?/gi,'\"').replace(/&(?:apos|#39);?/gi,"'").replace(/&(?:lt|#60);?/gi,'<').replace(/&(?:gt|#62);?/gi,'>');return x.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim()}
 function terms(text){return (String(text||'').toLowerCase().match(/[a-z]{4,}|[가-힣]{2,}|\d+(?:\.\d+)?/g)||[]).filter(function(t){return !/^(today|yesterday|daily|weekly|latest|reuters|tradingview|market|news|report|company|international|korea|대한|관련|기사|뉴스|경제|시장|올해|지난|이번)$/.test(t)}).slice(0,24)}
 function headlineMatch(body,item){var ts=terms(item&&item.title),b=plainText(body).toLowerCase();if(ts.length<2)return true;var unique=ts.filter(function(x,i){return ts.indexOf(x)===i}),hit=unique.filter(function(t){return b.indexOf(t)>=0}).length;return hit>=Math.min(2,unique.length)||hit/unique.length>=.32}
 function readerNoise(x){return /^(?:subscribe|sign up|sign in|read more|newsletter|privacy policy|advertisement|cookie policy|all rights reserved|this email|forwarded message|the daily docket|관련 기사|많이 본 뉴스|기사 제보|구독하기|광고|기자 소개)/i.test(x)||/unsubscribe|newsletter|privacy policy|copyright|email preferences|news briefing|editor[:：]|&nbsp;/i.test(x)}
 function sourceSummary(raw,article){var text=plainText(raw);if(!text)return '';
  var sentences=(text.match(/[^.!?。？！]+(?:[.!?。？！]+|$)/g)||[]).map(function(x){return x.trim()}).filter(function(x){return x.length>=27&&x.length<=650&&!readerNoise(x)});
  if(!sentences.length)return '';
  var ts=terms(article&&article.title),scored=sentences.map(function(x,i){var low=x.toLowerCase(),hit=ts.filter(function(t){return low.indexOf(t)>=0}).length,fig=(/\d+(?:[.,]\d+)?%|\d+(?:[.,]\d+)?\s*(?:억원|조원|달러|bp|billion|million|percent)/i.test(x)?2:0),verb=(/발표|상승|하락|증가|감소|전망|결정|계약|기록|수주|reported|said|rose|fell|announced|forecast|increased|decreased/i.test(x)?1:0);return {x:x,i:i,score:hit*3+fig+verb+Math.max(0,3-i*.4)}});
  scored.sort(function(a,b){return b.score-a.score||a.i-b.i});var chosen=scored.slice(0,Math.min(4,scored.length)).sort(function(a,b){return a.i-b.i});var res=chosen.map(function(z){return z.x}).join(' ');
  if(res.length>850)res=res.slice(0,845).replace(/\s+\S*$/,'').trim()+'…';return res;
 }
 var ARTICLE_INFLIGHT={},PREPARING=false,PREFETCH_TIMER=null,PREPARED_ONCE={};
 function readyBrief(n){var b=json(NEWS_BRIEFS,{}),v=b[n.key];return v&&(v.state==='ready'||v.state==='excerpt')&&v.summary&&!readerNoise(String(v.summary))&&(/[가-힣]/.test(v.summary))?v:null}
 function briefStore(n,b){var all=json(NEWS_BRIEFS,{});all[n.key]=b;var keys=Object.keys(all);if(keys.length>110)keys.sort(function(a,c){return Number(all[c].at||0)-Number(all[a].at||0)}).slice(110).forEach(function(k){delete all[k]});store(NEWS_BRIEFS,all)}
 function sourceExcerpt(n){var v=plainText(n&&n.description||''),t=plainText(n&&n.title||'');if(!v||v.length<90||readerNoise(v))return '';if(t&&v.toLowerCase().replace(t.toLowerCase(),'').replace(/[-–|•·\s]/g,'').length<85)return '';if(!headlineMatch(v,n))return '';return v.slice(0,650)}
 function articleFallback(n,reason){var excerpt=sourceExcerpt(n);if(!excerpt)return {state:'failed',error:reason||'본문을 확보하지 못했습니다. 원본보기에서 확인해 주세요.',at:Date.now()};if(!/[가-힣]/.test(excerpt))return {state:'failed',error:'원문 확보 실패 · 제공된 소개문도 한국어 번역이 확인되지 않았습니다.',at:Date.now()};return {state:'excerpt',summary:excerpt,partial:true,sourceLabel:'뉴스 피드 소개문',error:reason||'',at:Date.now()};}
 function prepareArticle(n,force){if(!n||!n.key)return Promise.resolve({state:'failed',error:'기사 정보가 없습니다.'});var cached=readyBrief(n);if(cached&&!force)return Promise.resolve(cached);if(ARTICLE_INFLIGHT[n.key])return ARTICLE_INFLIGHT[n.key];
  var run=nativeNews('fetchArticleSmart',[n.url,n.title,''],16000).then(function(r){
   var body=String(r&&r.articleText||'').trim();
   if(!r||!r.trustedBody||['full','partial'].indexOf(r.status)<0||body.length<160||!headlineMatch(body,n))return articleFallback(n,'원문 접근 제한·본문 불일치 또는 본문 추출 실패');
   var picked=sourceSummary(body,n),partial=r.status==='partial';
   if(picked.length<80)return articleFallback(n,'기사 핵심 문장 부족');
   var ko=/[가-힣]/.test(picked)?Promise.resolve(picked):nativeNews('translateKorean',[picked.slice(0,1450)],9500).then(function(t){var txt=plainText(t.translated||'');return /[가-힣]/.test(txt)?txt:''});
   return ko.then(function(txt){return txt?{state:'ready',summary:txt,partial:partial,at:Date.now(),finalUrl:r.finalUrl||n.url,method:'extractive'}:articleFallback(n,'기사 한국어 번역 실패')});
  }).catch(function(){return articleFallback(n,'기사 읽기 요청 실패')}).then(function(b){if(b.state==='ready'||b.state==='excerpt')briefStore(n,b);return b}).finally(function(){delete ARTICLE_INFLIGHT[n.key]});
  ARTICLE_INFLIGHT[n.key]=run;return run;
 }
 function prepareVisible(){if(PREPARING||!active()||NEWS_BUSY)return;var available=NEWS_CACHE.slice().sort(function(a,b){return b.ts-a.ts});var shortlist=NEWS_TOPICS.map(function(g){return available.find(function(n){return n.group===g.id})}).filter(Boolean);
  var pending=shortlist.filter(function(n){return !readyBrief(n)&&!PREPARED_ONCE[n.key]}).slice(0,1);if(Object.keys(ARTICLE_INFLIGHT).length||!pending.length)return;PREPARING=true;var at=0;
  function work(){if(at>=pending.length||!active()){PREPARING=false;return Promise.resolve()}var n=pending[at++];PREPARED_ONCE[n.key]=true;return prepareArticle(n).then(function(b){if(NEWS_SELECTED===n.id)detailRender(n,b);if(active())renderHeadlines()}).then(work).catch(work)}
  work();
 }
 function prefetchSoon(){if(PREFETCH_TIMER)clearTimeout(PREFETCH_TIMER);PREFETCH_TIMER=setTimeout(function(){PREFETCH_TIMER=null;prepareVisible()},5500)}
 function detailsShell(){var d=byId('nt223Detail');if(d)return d;d=document.createElement('div');d.id='nt223Detail';d.className='nt223-modal nt224-modal';d.setAttribute('aria-hidden','true');d.innerHTML='<section class="nt223-dialog nt224-panel" role="dialog" aria-modal="true" aria-label="시장 주요뉴스 기사 상세"><header class="nt223-dialog-head nt224-head"><b>시장 주요뉴스 · 기사 상세</b><button type="button" data-nt223-close aria-label="닫기">닫기 ×</button></header><div class="nt224-scroll" data-nt224-scroll id="nt223DetailBody"></div><footer class="nt223-dialog-foot nt224-foot"><button type="button" data-nt223-original>원본보기 ↗</button></footer></section>';document.body.appendChild(d);return d;}
 function displayTitle(n){var t=plainText(n&& (n.titleKo||n.title)||'');var outlet=plainText(n&&n.source||'');if(outlet&&t.toLowerCase().endsWith(' - '+outlet.toLowerCase()))t=t.slice(0,-(outlet.length+3));return t}
 function detailRender(item,brief){if(!NEWS_SELECTED||NEWS_SELECTED!==item.id)return;var d=detailsShell(),box=byId('nt223DetailBody');if(!box)return;var grp=NEWS_TOPICS.find(function(x){return x.id===item.group})||NEWS_TOPICS[0],state=brief&&brief.state||'loading',msg=(state==='ready'||state==='excerpt')?String(brief.summary||''):state==='failed'?String(brief.error||'원문을 확보하지 못했습니다. 원본보기에서 확인해 주세요.'):'기사 제목·출처를 먼저 표시했습니다. 원문 확보·한국어 번역을 진행 중이며, 출처 사정에 따라 실패할 수 있습니다.';
 box.innerHTML='<div class="nt223-detail-tag">'+e(grp.label)+' · '+e(day(item.ts))+'</div><h3>'+e(item.titleKo||item.title)+'</h3><p class="nt223-detail-source">'+e(item.source||'언론사 미확인')+'</p><p class="nt223-detail-summary">'+e(msg)+'</p>'+(state==='ready'?'<p class="nt223-detail-caveat">실제로 확인된 본문에서 주요 문장을 선정해 한국어로 정리했습니다. AI가 사실관계를 재검증한 요약은 아닙니다.</p>':state==='excerpt'?'<p class="nt223-detail-caveat">뉴스 피드 소개문만 확인됐습니다. 기사 전문 요약이 아닙니다.</p>':'')+(brief&&brief.partial&&state==='ready'?'<p class="nt223-detail-caveat">본문 일부만 확보됐습니다. 전체 기사 결론은 확인되지 않았습니다.</p>':'')+((state==='excerpt'||state==='failed')?'<button type="button" class="nt232-reader-retry" data-nt232-reader-retry>원문 다시 읽기</button>':'');if(d.getAttribute('aria-hidden')!=='false'&&!d.classList.contains('open'))window.NOONTANGI_MODAL_STANDARD.open('nt223Detail');}
 function originalUrl(url){try{if(window.SnowballBookmarks&&window.SnowballBookmarks.openUrl){window.SnowballBookmarks.openUrl(url);return}if(window.Android&&window.Android.openUrl){window.Android.openUrl(url);return}}catch(_){}window.open(url,'_blank','noopener,noreferrer')}
 function openDetail(id){var n=selectedItem(id);if(!n)return;NEWS_SELECTED=n.id;var b=readyBrief(n);detailRender(n,b);if(b)return;
  var currentId=n.id,pendingTimer=setTimeout(function(){if(NEWS_SELECTED!==currentId)return;var box=byId('nt223DetailBody');if(box&&!readyBrief(n)){var para=box.querySelector('.nt223-detail-summary');if(para)para.textContent='저장된 요약이 없어 원문 확인 중입니다. 원본보기는 지금 사용할 수 있습니다. (원본보기는 바로 사용 가능)';}},3000);
  prepareArticle(n).then(function(r){clearTimeout(pendingTimer);if(NEWS_SELECTED===currentId)detailRender(n,r)}).catch(function(){clearTimeout(pendingTimer);if(NEWS_SELECTED===currentId)detailRender(n,{state:'failed',error:'기사 처리 실패 · 원본보기를 이용해 주세요.'})});}
 function closeDetail(){NEWS_SELECTED=null;var d=byId('nt223Detail');if(d){window.NOONTANGI_MODAL_STANDARD.close('nt223Detail')}}
 function news(){renderHeadlines();if(active())collectMarketNews(false);}
  function settingsHtml(){var selected=selection();return '<div id="nt221Settings" class="nt221-overlay nt224-modal" aria-hidden="true"><section class="nt221-dialog nt224-panel" role="dialog" aria-modal="true" aria-label="시장지표 환경설정"><header class="nt221-head nt224-head"><h2>시장지표 환경설정</h2><button type="button" class="nt221-btn" data-nt221-close>닫기 ×</button></header><div class="nt224-scroll" data-nt224-scroll><p class="nt221-setting-note">표시할 시장지표를 최대 9개 선택하세요. 순서는 등록 순서로 표시됩니다.</p><div class="nt221-options">'+SPECS.map(function(x){return '<label><input type="checkbox" data-nt221-opt="'+e(x[0])+'" '+(selected.indexOf(x[0])>=0?'checked':'')+'><span>'+e(x[1])+'</span></label>'}).join('')+'</div><p id="nt221Count" class="nt221-setting-note">'+selected.length+'/9개 선택</p></div><footer class="nt224-foot"><button type="button" class="nt221-btn nt224-save" data-nt221-save>저장</button></footer></section></div>'}
 function mountSettings(){if(byId('nt221Settings'))return;var holder=document.createElement('div');holder.innerHTML=settingsHtml();document.body.appendChild(holder.firstElementChild)}
 function dialog(open){mountSettings();var d=byId('nt221Settings');if(!d)return;if(open){var ids=selection();d.querySelectorAll('[data-nt221-opt]').forEach(function(i){i.checked=ids.indexOf(i.dataset.nt221Opt)>=0});count()}window.NOONTANGI_MODAL_STANDARD[open?'open':'close']('nt221Settings');}
 function count(){var d=byId('nt221Settings');if(!d)return;var n=d.querySelectorAll('input:checked').length;var p=byId('nt221Count');if(p)p.textContent=n+'/9개 선택'+(n>9?' · 최대 9개입니다.':'')}
 function init(){var main=document.querySelector('#pageMarket main.container');if(!main)return;var root=byId('ntmeV222');if(!root){root=document.createElement('div');root.className='nt221';root.id='ntmeV222';main.insertBefore(root,main.firstChild)}view()}
 document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-nt221-settings],[data-nt221-close],[data-nt221-save],[data-nt221-more],[data-nt221-chart],[data-nt223-select],[data-nt223-retry]');if(!b)return;
  if(b.hasAttribute('data-nt221-settings')){dialog(true);return}
  if(b.hasAttribute('data-nt221-close')){dialog(false);return}
  if(b.hasAttribute('data-nt221-save')){var d=byId('nt221Settings');var ids=Array.prototype.map.call(d.querySelectorAll('input:checked'),function(x){return x.dataset.nt221Opt});if(ids.length>9){count();return}store(KEY,ids);dialog(false);view();return}
  if(b.hasAttribute('data-nt221-more')){NEWS_EXPANDED=!NEWS_EXPANDED;renderHeadlines();return}
  if(b.hasAttribute('data-nt223-retry')){collectMarketNews(true);return}
  if(b.hasAttribute('data-nt223-select')){openDetail(b.getAttribute('data-nt223-select'));return}
  if(b.hasAttribute('data-nt221-chart')){var api=window.NOONTANGI_MARKET_ENV;if(api&&typeof api.openDetail==='function'){api.openDetail(b.getAttribute('data-nt221-chart'));lastDetailOpen=Date.now()}return}
 },true);
 document.addEventListener('change',function(ev){if(ev.target&&ev.target.matches&&ev.target.matches('#nt221Settings [data-nt221-opt]')){var d=byId('nt221Settings');var n=d.querySelectorAll('input:checked').length;if(n>9)ev.target.checked=false;count()}else if(ev.target&&ev.target.id==='rMarket'&&ev.target.checked){setTimeout(view,280)}},true);
 document.addEventListener('nt224:closed',function(ev){if(ev.detail&&ev.detail.id==='nt223Detail')NEWS_SELECTED=null});
 document.addEventListener('keydown',function(ev){if(ev.key==='Escape'){dialog(false);closeDetail()}});
 document.addEventListener('click',function(ev){var retry=ev.target&&ev.target.closest&&ev.target.closest('[data-nt232-reader-retry]');if(retry){ev.preventDefault();var n=selectedItem(NEWS_SELECTED);if(!n)return;retry.disabled=true;retry.textContent='원문 확인 중…';prepareArticle(n,true).then(function(r){if(NEWS_SELECTED===n.id)detailRender(n,r)});return;}var t=ev.target&&ev.target.closest&&ev.target.closest('[data-nt223-close],[data-nt223-original]');if(!t)return;ev.preventDefault();if(t.hasAttribute('data-nt223-close')){closeDetail();return}if(t.hasAttribute('data-nt223-original')){var n=selectedItem(NEWS_SELECTED),saved=json(NEWS_BRIEFS,{}),url=n&&(saved[n.key]&&saved[n.key].finalUrl||n.url);if(url&&/^https:\/\//i.test(url))originalUrl(url);}},true);
 window.addEventListener('storage',function(ev){if(ev.key===KEY||ev.key==='NOONTANGI_MARKET_ENV_V2'||ev.key==='NOONTANGI_OFFICIAL_INDICATORS_V238')if(active())view()});
 window.addEventListener('ntv238:indicators',function(){if(active())view()});
 window.addEventListener('ntv252:ecos-shared',function(){if(active())view()});
 window.addEventListener('ntv245:status',function(){var el=document.querySelector('#ntmeV222 [data-ntv245-ecos-state]');if(el)el.textContent=ecosStatus()});
 setInterval(function(){if(active()){var d=byId('nt221Settings');if(!d||!d.classList.contains('open'))view()}},60000);
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
 window.NOONTANGI_MARKET_UI_V225={render:view,version:'V225',getIndicators:selection,collectNews:collectMarketNews,newsCount:function(){return NEWS_CACHE.length}};
})();
