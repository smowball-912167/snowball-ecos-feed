/* V248 · FX volatility fallback for the existing Yahoo KRW=X daily chart route.
 * Device-side read only; this is NOT an ECOS observation or public redistribution.
 * A validated newer/equal-day ECOS reading always takes priority.
 * No balance, score, correlation, or daily-funding series is modified. */
(function(root){'use strict';
var URL='https://query1.finance.yahoo.com/v8/finance/chart/KRW%3DX?range=3mo&interval=1d&includePrePost=false&events=div%2Csplits';
var PREFIX='ntv248fx_',STORE='NOONTANGI_V248_FX_FALLBACK_STATE',seq=0,pending={},busy=false,DAY=86400000;
var oldResolve=root.__SnowballNativeAsyncResolve;
root.__SnowballNativeAsyncResolve=function(id,raw){
 if(String(id||'').indexOf(PREFIX)!==0){if(typeof oldResolve==='function')return oldResolve(id,raw);return;}
 var p=pending[id];if(!p)return;delete pending[id];clearTimeout(p.timer);
 try{var data=JSON.parse(String(raw||''));if(data&&data.error)throw Error('FX 원천 응답 실패');p.resolve(data)}catch(e){p.reject(e)}
};
function read(k){try{return JSON.parse(root.localStorage.getItem(k)||'null')}catch(_){return null}}
function save(k,v){try{root.localStorage.setItem(k,JSON.stringify(v))}catch(_){}}
function numeric(v){if(v===null||v===undefined||v==='')return null;var n=Number(v);return isFinite(n)?n:null}
function request(){return new Promise(function(resolve,reject){
 if(!root.SnowballMarketData||typeof root.SnowballMarketData.getAsync!=='function')return reject(Error('native collection unavailable'));
 var id=PREFIX+(++seq)+'_'+Date.now();var timer=setTimeout(function(){if(pending[id]){delete pending[id];reject(Error('FX daily history timeout'))}},14000);
 pending[id]={resolve:resolve,reject:reject,timer:timer};
 try{root.SnowballMarketData.getAsync(URL,id)}catch(e){clearTimeout(timer);delete pending[id];reject(e)}
});}
function extract(data){
 var chart=data&&data.chart,r=chart&&chart.result&&chart.result[0],quote=r&&r.indicators&&r.indicators.quote&&r.indicators.quote[0],ts=r&&r.timestamp,close=quote&&quote.close;
 if(!r||!r.meta||r.meta.symbol!=='KRW=X'||!Array.isArray(ts)||!Array.isArray(close)||ts.length!==close.length)return null;
 var points=[],seen={};
 for(var i=0;i<ts.length;i++){
  var t=numeric(ts[i]),v=numeric(close[i]);
  if(t===null||v===null||v<300||v>5000)continue;
  var time=t*1000;if(!isFinite(time)||time>Date.now())continue;
  // The series is daily. Timestamp's date is the provider's trading-day key.
  var d=new Date(time),dow=d.getUTCDay(),period=d.toISOString().slice(0,10).replace(/-/g,'');
  if(dow===0||dow===6||seen[period])continue;
  seen[period]=true;points.push({period:period,value:v});
 }
 points.sort(function(a,b){return a.period.localeCompare(b.period)});
 if(points.length<21)return null;
 var last=points[points.length-1],iso=last.period.slice(0,4)+'-'+last.period.slice(4,6)+'-'+last.period.slice(6,8),age=Date.now()-Date.parse(iso+'T12:00:00Z');
 if(age< -DAY||age>12*DAY)return null;
 return {points:points,latest:last.period,iso:iso,id:'yahoo_krw_x_d'};
}
function derive(data){
 var fx=extract(data),adapter=root.NOONTANGI_ECOS_V245;
 if(!fx||!adapter||typeof adapter.volatility20!=='function')return null;
 var out=adapter.volatility20(fx);if(!out)return null;
 out.source='Yahoo Finance · KRW=X 일별종가 · 20거래일 수익률 표본표준편차(비연율화)';
 out.period=fx.latest+' / 20거래일';out.verified=true;return out;
}
function eligible(obs){
 if(!obs||!root.NOONTANGI_FOUR_FACTORS||typeof root.NOONTANGI_FOUR_FACTORS.ingest!=='function')return false;
 var saved=read('NOONTANGI_OFFICIAL_INDICATORS_V238')||{},prior=saved.krwVolatility;
 if(prior&&prior.verified===true&&isFinite(Date.parse(prior.asOf))){
  var old=Date.parse(prior.asOf),next=Date.parse(obs.asOf);
  if(old>=next)return false; // No equal-date source swap; preserves ECOS and other verified observations.
 }
 return true;
}
function refresh(force){
 var st=read(STORE)||{},now=Date.now();
 if(busy)return Promise.resolve({status:'busy'});
 if(!force&&now-Number(st.lastAttempt||0)<(st.ok?6*3600000:20*60000))return Promise.resolve({status:'cached'});
 if(!root.NOONTANGI_FOUR_FACTORS||!root.NOONTANGI_ECOS_V245)return Promise.resolve({status:'not-ready'});
 // If the ECOS series is already fresh, the extra Yahoo request is unnecessary.
 var confirmed=root.NOONTANGI_FOUR_FACTORS.official('krwVolatility');
 if(confirmed&&String(confirmed.source||'').indexOf('한국은행 ECOS')>=0)return Promise.resolve({status:'ecos-priority'});
 busy=true;save(STORE,{lastAttempt:now,ok:false,status:'requesting'});
 return request().then(function(raw){var obs=derive(raw);if(!obs)throw Error('FX source validation failed');
  var added=eligible(obs)?root.NOONTANGI_FOUR_FACTORS.ingest([obs]):0;
  save(STORE,{lastAttempt:Date.now(),ok:true,status:added?'updated':'preserved-newer',period:obs.period,source:obs.source});
  return {status:added?'updated':'preserved-newer',added:added};
 }).catch(function(){save(STORE,{lastAttempt:Date.now(),ok:false,status:'unavailable'});return {status:'unavailable'};}).finally(function(){busy=false});
}
if(root.document&&typeof root.document.addEventListener==='function')root.document.addEventListener('change',function(e){
 if(e.target&&e.target.id==='rMarket'&&e.target.checked)setTimeout(function(){refresh(false)},2100)
},true);
if(root.document&&typeof root.document.getElementById==='function'){
 var boot=function(){var tab=root.document.getElementById('rMarket');if(tab&&tab.checked)setTimeout(function(){refresh(false)},2400)};
 if(root.document.readyState==='loading')root.document.addEventListener('DOMContentLoaded',boot);else boot();
}
if(typeof module==='object'&&module.exports)module.exports={refresh:refresh,derive:derive,extract:extract,eligible:eligible,version:'V248',url:URL};
root.NOONTANGI_FX_V248={refresh:refresh,derive:derive,extract:extract,eligible:eligible,version:'V248'};
})(typeof window!=='undefined'?window:globalThis);
