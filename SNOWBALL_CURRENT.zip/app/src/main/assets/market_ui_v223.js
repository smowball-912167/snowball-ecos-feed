/* V223 market overview: dedicated news collection per four approved market domains.
   No import from major-news catalogue. User selects headline to see verified short summary.
   Old market detail engine, unrelated routes, and stored user records remain unchanged. */
(function(){'use strict';
 var KEY='nt_market_v221_visible_indicators';
 var SPECS=[['kospi','KOSPI','▥','index'],['kosdaq','KOSDAQ','▥','index'],['spx','S&P500','🇺🇸','index'],['nasdaq','NASDAQ','🇺🇸','index'],['vix','VIX','〰','number'],['usdkrw','원/달러','₩','fx'],['us10y','미 10년물','▤','yield'],['wti','WTI','◉','usd'],['gold','금','◆','usd'],['dxy','달러인덱스','＄','number'],['sox','필라델피아 반도체','▥','index'],['rut','러셀2000','▥','index'],['copper','구리','◆','usd'],['hyg','미국 하이일드채','▤','number']];
 var BASE=['kospi','kosdaq','spx','nasdaq','vix','usdkrw','us10y','wti','gold'];
 var lastDetailOpen=0;
 var NEWS_STORE='nt223-market-only-articles', NEWS_LAST='nt223-market-only-checks', NEWS_TRY='nt223-market-last-attempt', NEWS_BRIEFS='nt223-market-source-briefs', NEWS_EXPANDED=false, NEWS_BUSY=false, NEWS_ERROR='', NEWS_SEQ=0, NEWS_CB={}, NEWS_ACTIVE=false;
 var NEWS_TOPICS=[{id:'rates',label:'금리·물가',symbol:'▤',regex:/금리|물가|인플레이션|인플레|국채|채권금리|기준금리|연준|연방준비|중앙은행|CPI|PCE|FED|FOMC|유가|원유|WTI|OPEC|관세|물가상승/i,query:'금리 OR 물가 OR 연준 OR 국채 OR 유가 when:7d',world:'__GLOBAL__ inflation OR Federal Reserve OR interest rates when:7d'},
 {id:'earnings',label:'기업실적·경기',symbol:'▣',regex:/기업실적|실적|영업이익|순이익|매출|어닝|전망치|가이던스|GDP|경기|고용|소비|제조업|PMI|수출|경기침체|기업이익|earnings|revenue|economy|jobs/i,query:'기업 실적 OR 경기 OR 고용 OR GDP when:7d',world:'__GLOBAL__ corporate earnings OR economy OR GDP when:7d'},
 {id:'flows',label:'수급·환율',symbol:'₩',regex:/환율|원화|달러|외국인|기관|수급|자금유입|자금유출|순매수|순매도|자본유출|통화가치|달러인덱스|exchange rate|USD|KRW|investor flows/i,query:'외국인 순매수 OR 기관 수급 OR 원달러 환율 when:7d',world:'__GLOBAL__ dollar exchange rate OR foreign capital flows when:7d'},
 {id:'trend',label:'주가 추세·VIX',symbol:'▥',regex:/코스피|코스닥|나스닥|다우지수|S&P\s?500|VIX|변동성|증시|주가지수|주식시장|증시급락|증시반등|주가흐름|market volatility|stock market|wall street/i,query:'코스피 OR 나스닥 OR VIX OR 증시 when:7d',world:'__GLOBAL__ VIX OR stock market OR S&P500 when:7d'}];
 var NEWS_BLOCK=/국감|국정감사|탄핵|정쟁|청문회|여야공방|총선|대선|선거전략|의원질의|국회의원|정당공방/i;
 var NEWS_CACHE=json(NEWS_STORE,[]);if(!Array.isArray(NEWS_CACHE))NEWS_CACHE=[];var NEWS_SELECTED=null;
 function byId(id){return document.getElementById(id)}
 function e(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
 function json(k,fb){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?fb:v}catch(_){return fb}}
 function store(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(_){}}
 function selection(){var ids=json(KEY,BASE);if(!Array.isArray(ids))ids=BASE;var valid=SPECS.map(function(x){return x[0]});ids=ids.filter(function(x,i){return valid.indexOf(x)>=0&&ids.indexOf(x)===i});return ids.slice(0,9)}
 function active(){return !!(byId('rMarket')&&byId('rMarket').checked)}
 function num(n){n=Number(n);return isFinite(n)?n:null}
 function quoteMap(){var snap=(window.NOONTANGI_MARKET_ENV&&window.NOONTANGI_MARKET_ENV.snapshot&&window.NOONTANGI_MARKET_ENV.snapshot())||json('NOONTANGI_MARKET_ENV_V2',{});var m={};(snap.items||[]).forEach(function(x){if(x&&x.id)m[x.id]=x});return {snap:snap,map:m}}
 function fmt(n,kind){if(n==null)return '—';if(kind==='yield')return n.toFixed(3)+'%';if(kind==='usd')return '$'+n.toFixed(2);return n.toLocaleString('ko-KR',{maximumFractionDigits:kind==='number'?2:2})}
 function change(n){if(n==null)return '<span class="nt221-muted">변동 확인 중</span>';var sign=n>0?'+':'';return '<span class="'+(n>0?'nt221-pos':n<0?'nt221-neg':'nt221-muted')+'">'+sign+n.toFixed(2)+'%</span>'}
 function time(ts){if(!ts)return '기준시각 확인 중';var d=new Date(ts),n=d.getTime();if(!isFinite(n))return '기준시각 확인 중';return d.toLocaleString('ko-KR',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).replace(/\.$/,'')}
 function assessment(q){var arr=Object.keys(q.map).filter(function(k){return q.map[k]&&q.map[k].valid===true});var r=json('NOONTANGI_MARKET_SCORE_V1',{}),sc=r.current&&num(r.current.score),at=r.current&&num(r.current.asOf),fresh=Number(q.snap.asOf||0)===at;
  if(!fresh||arr.length<8||sc==null)return {status:'판단 보류',description:'핵심 시장지표의 검증이 끝나지 않아 시장 상태를 확정하지 않았습니다.'};
  return {status:sc>=65?'우호 · 관찰':sc>=45?'중립 · 관망':sc>=30?'주의 · 관망':'위험 · 방어',description:'검증된 8개 핵심지표로 산출한 시장환경 종합점수 '+Math.round(sc)+'점입니다. 지표 변화와 수급을 함께 확인한 뒤 투자 판단에 참고하세요.'};
 }
 function axisDesc(q,ids){var vals=ids.map(function(id){var x=q.map[id];if(!x||x.valid!==true)return '';var p=num(x.changePct);if(p===null)return '';var labels={us10y:'미국 10년물 국채금리',wti:'국제유가',spx:'S&P500',nasdaq:'나스닥',usdkrw:'원/달러 환율',kospi:'코스피',kosdaq:'코스닥',vix:'VIX'};return (labels[id]||x.name||id)+' '+(p>0?'+':'')+p.toFixed(2)+'%'}).filter(Boolean);return vals.length?vals.join(' · ')+' (전일 대비). 서로 다른 지표의 변화는 함께 확인해야 합니다.':'검증된 최신 자료가 없어 해석을 보류합니다.'}
 function quotePct(q,id){var x=q.map[id];return x&&x.valid===true?num(x.changePct):null}
 function trendWord(p){return p==null?'확인 중':p>0?'상승':p<0?'하락':'보합'}
 function marketNarrative(q,a){
  var rate=quotePct(q,'us10y'),oil=quotePct(q,'wti'),us=quotePct(q,'spx'),kr=quotePct(q,'kospi'),fx=quotePct(q,'usdkrw'),vol=quotePct(q,'vix');
  if([rate,oil,us,kr,fx,vol].every(function(x){return x==null}))return '최신 시장지표 확인이 완료되지 않아 현재 시장환경에 대한 판단을 보류합니다. 데이터가 들어오면 금리·물가, 경기, 자금흐름, 변동성을 함께 살펴보겠습니다.';
  var first=[];if(rate!=null)first.push('미국 10년물 국채금리 '+trendWord(rate));if(oil!=null)first.push('국제유가 '+trendWord(oil));
  var second=[];if(us!=null)second.push('미국 증시 '+trendWord(us));if(kr!=null)second.push('국내 증시 '+trendWord(kr));
  var third=[];if(fx!=null)third.push('원/달러 환율 '+trendWord(fx));if(vol!=null)third.push('변동성 지수(VIX) '+trendWord(vol));
  var sentences=[];
  if(first.length)sentences.push(first.join('·')+' 흐름을 보면 금리·물가 부담을 계속 확인할 필요가 있습니다.');
  if(second.length)sentences.push(second.join('·')+' 흐름을 함께 보며 기업실적과 경기 기대가 이어지는지 살펴봐야 합니다.');
  if(third.length)sentences.push(third.join('·')+' 흐름을 통해 자금 유입과 시장 위험의 변화를 점검해야 합니다.');
  if(sentences.length===1)sentences.push('한 지표의 하루 움직임만으로 매수·매도 신호를 확정하지 않습니다.');
  return sentences.slice(0,3).join(' ')
 }
  function view(){var q=quoteMap(),a=assessment(q),ids=selection();var root=byId('ntmeV222');if(!root)return;
  var groups=[['금리·물가','시장 부담',['us10y','wti']],['기업실적·경기','성장 방향',['spx','nasdaq']],['수급·환율','자금 흐름',['usdkrw','kospi']],['주가 추세·VIX','시장 위험',['kospi','kosdaq','vix']]];
  var dashboard='<section class="nt221-card"><div class="nt221-head"><h2>시장환경</h2><span class="nt221-note" id="nt221SourceLabel">실제 시장지표 기준</span></div><div class="nt221-status"><span class="icon">▧</span>'+e(a.status)+'</div>'+groups.map(function(g){return '<details class="nt221-axis"><summary><span>'+e(g[0])+'</span><span class="right">'+e(g[1])+' ›</span></summary><p>'+e(axisDesc(q,g[2]))+'</p></details>'}).join('')+'<div class="nt221-ai">'+e('AI 시장 설명: '+marketNarrative(q,a))+'</div></section>';
  var tiles=ids.map(function(id){var s=SPECS.filter(function(x){return x[0]===id})[0];if(!s)return '';var x=q.map[id]||{},ok=x.valid===true,pr=ok?num(x.price):null,pct=ok?num(x.changePct):null;return '<button type="button" class="nt221-tile" data-nt221-chart="'+e(id)+'" aria-label="'+e(s[1])+' 상세차트"><span class="name">'+e(s[2])+' '+e(s[1])+'</span><span class="value">'+e(fmt(pr,s[3]))+'</span><span class="change">'+change(pct)+'</span></button>'}).join('');
  var ind='<section class="nt221-card"><div class="nt221-head"><h2>시장지표</h2><div class="nt221-actions"><button class="nt221-btn" type="button" data-nt221-settings aria-label="시장지표 환경설정">⚙</button><button class="nt221-btn" type="button" data-nt221-settings>더보기 ›</button></div></div><div class="nt221-note" style="margin-bottom:8px">환경설정에서 등록 · 최대 9개</div><div class="nt221-tiles">'+tiles+'</div><div class="nt221-timestamp">시세 기준: '+e(time(q.snap.asOf))+' · 미확인 값은 표시하지 않습니다.</div></section>';
  var currentOpen=root.querySelectorAll('details.nt221-axis[open]'),opened=Array.prototype.map.call(currentOpen,function(x){return Array.prototype.indexOf.call(x.parentNode.querySelectorAll('details.nt221-axis'),x)});
  root.innerHTML=dashboard+'<section class="nt221-card"><div class="nt221-head"><h2>시장 주요뉴스</h2><button type="button" class="nt221-btn" data-nt221-more>더보기 ›</button></div><div id="nt221News"><div class="nt221-empty">시장 관련 뉴스를 확인 중입니다.</div></div></section>'+ind+settingsHtml();
  var panels=root.querySelectorAll('details.nt221-axis');opened.forEach(function(i){if(panels[i])panels[i].open=true});
  news();
 }
 function newsTopic(title){var t=String(title||'').trim();if(!t||NEWS_BLOCK.test(t))return null;for(var i=0;i<NEWS_TOPICS.length;i++)if(NEWS_TOPICS[i].regex.test(t))return NEWS_TOPICS[i];return null;}
 function nativeResolve(){var api=window.NOONTANGI_EXTERNAL_INFO=window.NOONTANGI_EXTERNAL_INFO||{};if(api.__marketV223Hook)return;var prior=api.resolve;api.resolve=function(id,raw){if(String(id).indexOf('ntm223_')===0){var task=NEWS_CB[id];if(!task)return false;delete NEWS_CB[id];clearTimeout(task.timer);try{task.resolve(JSON.parse(String(raw||'{}')))}catch(_){task.resolve({error:'결과 형식 오류',items:[]})}return true}if(typeof prior==='function')return prior(id,raw);return false;};api.__marketV223Hook=true;}
 function nativeNews(method,args,wait){return new Promise(function(resolve){var b=window.SnowballExternalInfo;if(!b||typeof b[method]!=='function'){resolve({error:'기기 뉴스 연결을 사용할 수 없습니다.',items:[]});return}nativeResolve();var id='ntm223_'+(++NEWS_SEQ)+'_'+Date.now(),timer=setTimeout(function(){delete NEWS_CB[id];resolve({error:'원문 또는 뉴스 응답 시간 초과',items:[]})},wait||17000);NEWS_CB[id]={resolve:resolve,timer:timer};try{b[method].apply(b,args.concat(id))}catch(_){clearTimeout(timer);delete NEWS_CB[id];resolve({error:'뉴스 요청 중 오류가 발생했습니다.',items:[]})}})}
 function fixedDate(d){var x=Date.parse(d||'');return isFinite(x)?x:Date.now();}
 function day(ts){var d=new Date(ts);if(!isFinite(d.getTime()))return '날짜 미확인';return [d.getFullYear(),('0'+(d.getMonth()+1)).slice(-2),('0'+d.getDate()).slice(-2)].join('.');}function shortDay(ts){var d=new Date(ts);return isFinite(d.getTime())?('0'+(d.getMonth()+1)).slice(-2)+'.'+('0'+d.getDate()).slice(-2):'날짜 없음'}
 function newsKey(it){return String(it.link||it.url||'').trim().toLowerCase()||String(it.title||'').trim().toLowerCase().replace(/\s+/g,'');}
 function saveNews(){store(NEWS_STORE,NEWS_CACHE.slice(0,240))}
 function addNews(response,chosen){if(!response||response.error||response.fallbackUsed||!Array.isArray(response.items))return 0;var added=0;
 response.items.forEach(function(x){var title=String(x.title||'').trim(),url=String(x.link||x.url||'').trim();if(!/^https:\/\//i.test(url))return;
 var group=newsTopic(title);if(!group||group.id!==chosen)return;var key=newsKey(x);
 if(NEWS_CACHE.some(function(n){return n.key===key||n.title.toLowerCase()===title.toLowerCase()}))return;
 NEWS_CACHE.push({key:key,id:'m'+Date.now()+'_'+Math.floor(Math.random()*1000000),group:chosen,title:title,titleKo:/[가-힣]/.test(title)?title:'',url:url,source:String(x.source||'').trim(),description:String(x.description||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,800),ts:fixedDate(x.pubDate),lane:String(response.lane||'KR')});added++});
 if(added){NEWS_CACHE.sort(function(a,b){return b.ts-a.ts});NEWS_CACHE=NEWS_CACHE.slice(0,240);saveNews()}return added;}
 function renderHeadlines(){var target=byId('nt221News');if(!target)return;var all=NEWS_CACHE.slice().sort(function(a,b){return b.ts-a.ts});var primary=NEWS_TOPICS.map(function(g){return all.find(function(a){return a.group===g.id})}).filter(Boolean);var rest=all.filter(function(a){return primary.indexOf(a)<0});var list=NEWS_EXPANDED?all.slice(0,45):primary.concat(rest).slice(0,7);
 var more=document.querySelector('#ntmeV222 [data-nt221-more]');if(more)more.textContent=NEWS_EXPANDED?'접기 ›':'더보기 ›';
 if(!list.length){target.innerHTML='<div class="nt221-empty">'+e(NEWS_BUSY?'네 가지 시장분야의 최신 기사를 수집하고 있습니다.':(NEWS_ERROR||'일치하는 시장 뉴스가 아직 없습니다.'))+' <button type="button" class="nt221-btn" data-nt223-retry>새로고침</button></div>';return;}
 target.innerHTML=list.map(function(n){var grp=NEWS_TOPICS.find(function(g){return g.id===n.group})||NEWS_TOPICS[0];var title=n.titleKo||(/[가-힣]/.test(n.title)?n.title:'글로벌 시장 기사 · 제목 번역 중');return '<button type="button" class="nt221-newsrow nt223-newsrow" data-nt223-select="'+e(n.id)+'" aria-label="'+e(title)+' 기사 상세"><span class="nt223-sign"><span class="nt223-symbol" aria-label="'+e(grp.label)+'">'+e(grp.symbol)+'</span><span class="nt223-day" title="'+e(day(n.ts))+'">'+e(shortDay(n.ts))+'</span></span><span class="nt223-headline">'+e(title)+'</span></button>'}).join('')+(NEWS_BUSY?'<div class="nt223-feed-state">새 기사 수집 중 · 저장된 기사는 그대로 표시합니다.</div>':'');
 list.filter(function(n){return !n.titleKo&&!/[가-힣]/.test(n.title)}).slice(0,5).forEach(function(n){translateTitle(n)});
 }
 function translateTitle(n){if(!n||n._translating||n.titleKo)return;n._translating=true;nativeNews('translateKorean',[n.title.slice(0,500)],15000).then(function(r){var ko=String(r.translated||'').trim();if(/[가-힣]/.test(ko)){n.titleKo=ko;saveNews();if(active())renderHeadlines()}}).finally(function(){n._translating=false})}
 function collectMarketNews(force){if(NEWS_BUSY)return Promise.resolve(false);var last=Number(json(NEWS_LAST,0))||0,lastTry=Number(json(NEWS_TRY,0))||0;if(!force&&((last&&Date.now()-last<20*60000)||(lastTry&&Date.now()-lastTry<5*60000))){renderHeadlines();return Promise.resolve(true)}
 NEWS_BUSY=true;NEWS_ERROR='';store(NEWS_TRY,Date.now());renderHeadlines();var jobs=[];NEWS_TOPICS.forEach(function(g){jobs.push({id:g.id,query:g.query});jobs.push({id:g.id,query:g.world})});var successes=0,failures=0,at=0,workers=[];
 function consume(){if(at>=jobs.length)return Promise.resolve();var job=jobs[at++];return nativeNews('searchNews',[job.query],14000).then(function(r){if(!r.error&&!r.fallbackUsed){successes++;addNews(r,job.id)}else failures++;renderHeadlines();}).then(consume)}
 workers.push(consume());workers.push(consume());return Promise.all(workers).then(function(){if(successes)store(NEWS_LAST,Date.now());if(!successes)NEWS_ERROR='시장 관련 뉴스를 가져오지 못했습니다. 연결 상태를 확인하고 새로고침을 눌러주세요.';else if(failures)NEWS_ERROR='일부 출처 조회가 지연되고 있습니다.';return successes>0}).finally(function(){NEWS_BUSY=false;renderHeadlines()});}
 function selectedItem(id){return NEWS_CACHE.find(function(n){return n.id===id})||null;}
 function sourceSummary(s){var text=String(s||'').replace(/\s+/g,' ').trim();if(!text)return '';
 var sentences=(text.match(/[^.!?。？！]+(?:[.!?。？！]+|$)/g)||[]).map(function(s){return s.trim()}).filter(function(s){return s.length>19});if(!sentences.length)return text.slice(0,500);
 var picks=sentences.slice(0,3);if(sentences.length>5)picks.push(sentences[Math.floor(sentences.length*.5)]);if(sentences.length>7)picks.push(sentences[sentences.length-1]);var result=picks.join(' ').trim();return result.length>720?result.slice(0,717).replace(/\s+\S*$/,'')+'…':result;}
 function detailsShell(){var d=byId('nt223Detail');if(d)return d;d=document.createElement('div');d.id='nt223Detail';d.className='nt223-modal';d.setAttribute('aria-hidden','true');d.innerHTML='<section class="nt223-dialog" role="dialog" aria-modal="true" aria-label="시장 주요뉴스 기사 상세"><header class="nt223-dialog-head"><b>시장 주요뉴스 · 기사 상세</b><button type="button" data-nt223-close aria-label="닫기">닫기 ×</button></header><div id="nt223DetailBody"></div><footer class="nt223-dialog-foot"><button type="button" data-nt223-original>원본보기 ↗</button></footer></section>';document.body.appendChild(d);return d;}
 function detailRender(item,brief){if(!NEWS_SELECTED||NEWS_SELECTED!==item.id)return;var d=detailsShell(),box=byId('nt223DetailBody');if(!box)return;var grp=NEWS_TOPICS.find(function(x){return x.id===item.group})||NEWS_TOPICS[0],state=brief&&brief.state||'loading',msg=state==='ready'?String(brief.summary||''):state==='failed'?String(brief.error||'원문을 확보하지 못했습니다. 원본보기에서 확인해 주세요.'):'선택하신 기사 원문을 확인하고 있습니다.';
 box.innerHTML='<div class="nt223-detail-tag">'+e(grp.label)+' · '+e(day(item.ts))+'</div><h3>'+e(item.titleKo||item.title)+'</h3><p class="nt223-detail-source">'+e(item.source||'언론사 미확인')+'</p><p class="nt223-detail-summary">'+e(msg)+'</p>'+(brief&&brief.partial?'<p class="nt223-detail-caveat">원문 일부만 확인해 확보된 부분만 요약했습니다.</p>':'');d.classList.add('open');d.setAttribute('aria-hidden','false');}
 function originalUrl(url){try{if(window.SnowballBookmarks&&window.SnowballBookmarks.openUrl){window.SnowballBookmarks.openUrl(url);return}if(window.Android&&window.Android.openUrl){window.Android.openUrl(url);return}}catch(_){}window.open(url,'_blank','noopener,noreferrer')}
 function openDetail(id){var n=selectedItem(id);if(!n)return;NEWS_SELECTED=n.id;var saved=json(NEWS_BRIEFS,{}),b=saved[n.key];detailRender(n,b&&b.state==='ready'?b:null);if(b&&b.state==='ready')return;
 nativeNews('fetchArticleSmart',[n.url,n.title,''],20000).then(function(r){if(NEWS_SELECTED!==n.id)return;
 if(!r||!r.trustedBody||['full','partial'].indexOf(r.status)<0||String(r.articleText||'').length<170){detailRender(n,{state:'failed',error:'기사 제목과 주소는 확보했지만 언론사 본문을 읽지 못했습니다. 접근 제한·원문 추출 오류일 수 있습니다. 원본보기로 확인할 수 있습니다.'});return}
 var extracted=sourceSummary(r.articleText),partial=r.status==='partial';var ensureKo=/[가-힣]/.test(extracted)?Promise.resolve(extracted):nativeNews('translateKorean',[extracted.slice(0,1700)],16000).then(function(z){return /[가-힣]/.test(z.translated||'')?z.translated:''});
 return ensureKo.then(function(korean){if(NEWS_SELECTED!==n.id)return;if(!korean){detailRender(n,{state:'failed',error:'원문은 확보했지만 한국어 번역에 실패했습니다. 원본보기에서 확인해 주세요.'});return}var b={state:'ready',summary:korean,partial:partial,at:Date.now(),finalUrl:r.finalUrl||n.url};var all=json(NEWS_BRIEFS,{});all[n.key]=b;var keys=Object.keys(all);if(keys.length>100)keys.sort(function(a,b){return (all[b].at||0)-(all[a].at||0)}).slice(100).forEach(function(k){delete all[k]});store(NEWS_BRIEFS,all);detailRender(n,b)});
 }).catch(function(){if(NEWS_SELECTED===n.id)detailRender(n,{state:'failed',error:'기사 원문 처리 중 오류가 발생했습니다. 원본보기에서 확인할 수 있습니다.'})});}
 function closeDetail(){NEWS_SELECTED=null;var d=byId('nt223Detail');if(d){d.classList.remove('open');d.setAttribute('aria-hidden','true')}}
 function news(){renderHeadlines();if(active())collectMarketNews(false);}
  function settingsHtml(){var selected=selection();return '<div id="nt221Settings" class="nt221-overlay" aria-hidden="true"><div class="nt221-dialog" role="dialog" aria-modal="true" aria-label="시장지표 환경설정"><div class="nt221-head"><h2>시장지표 환경설정</h2><button type="button" class="nt221-btn" data-nt221-close>닫기 ×</button></div><p class="nt221-setting-note">표시할 시장지표를 최대 9개 선택하세요. 순서는 등록 순서로 표시됩니다.</p><div class="nt221-options">'+SPECS.map(function(x){return '<label><input type="checkbox" data-nt221-opt="'+e(x[0])+'" '+(selected.indexOf(x[0])>=0?'checked':'')+'><span>'+e(x[1])+'</span></label>'}).join('')+'</div><p id="nt221Count" class="nt221-setting-note">'+selected.length+'/9개 선택</p><button type="button" class="nt221-btn" data-nt221-save>저장</button></div></div>'}
 function dialog(open){var d=byId('nt221Settings');if(!d)return;d.classList.toggle('open',!!open);d.setAttribute('aria-hidden',String(!open));if(open){var ids=selection();d.querySelectorAll('[data-nt221-opt]').forEach(function(i){i.checked=ids.indexOf(i.dataset.nt221Opt)>=0});count()}}
 function count(){var d=byId('nt221Settings');if(!d)return;var n=d.querySelectorAll('input:checked').length;var p=byId('nt221Count');if(p)p.textContent=n+'/9개 선택'+(n>9?' · 최대 9개입니다.':'')}
 function init(){var main=document.querySelector('#pageMarket main.container');if(!main)return;var root=byId('ntmeV222');if(!root){root=document.createElement('div');root.className='nt221';root.id='ntmeV222';main.insertBefore(root,main.firstChild)}view()}
 document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-nt221-settings],[data-nt221-close],[data-nt221-save],[data-nt221-more],[data-nt221-chart],[data-nt223-select],[data-nt223-retry]');if(!b)return;
  if(b.hasAttribute('data-nt221-settings')){dialog(true);return}
  if(b.hasAttribute('data-nt221-close')){dialog(false);return}
  if(b.hasAttribute('data-nt221-save')){var d=byId('nt221Settings');var ids=Array.prototype.map.call(d.querySelectorAll('input:checked'),function(x){return x.dataset.nt221Opt});if(ids.length>9){count();return}store(KEY,ids);view();return}
  if(b.hasAttribute('data-nt221-more')){NEWS_EXPANDED=!NEWS_EXPANDED;renderHeadlines();return}
  if(b.hasAttribute('data-nt223-retry')){collectMarketNews(true);return}
  if(b.hasAttribute('data-nt223-select')){openDetail(b.getAttribute('data-nt223-select'));return}
  if(b.hasAttribute('data-nt221-chart')){var api=window.NOONTANGI_MARKET_ENV;if(api&&typeof api.openDetail==='function'){api.openDetail(b.getAttribute('data-nt221-chart'));lastDetailOpen=Date.now()}return}
 },true);
 document.addEventListener('change',function(ev){if(ev.target&&ev.target.matches&&ev.target.matches('#nt221Settings [data-nt221-opt]')){var d=byId('nt221Settings');var n=d.querySelectorAll('input:checked').length;if(n>9)ev.target.checked=false;count()}else if(ev.target&&ev.target.id==='rMarket'&&ev.target.checked){setTimeout(view,280)}},true);
 document.addEventListener('keydown',function(ev){if(ev.key==='Escape'){dialog(false);closeDetail()}});
 document.addEventListener('click',function(ev){var t=ev.target&&ev.target.closest&&ev.target.closest('[data-nt223-close],[data-nt223-original]');if(!t)return;ev.preventDefault();if(t.hasAttribute('data-nt223-close')){closeDetail();return}if(t.hasAttribute('data-nt223-original')){var n=selectedItem(NEWS_SELECTED),saved=json(NEWS_BRIEFS,{}),url=n&&(saved[n.key]&&saved[n.key].finalUrl||n.url);if(url&&/^https:\/\//i.test(url))originalUrl(url);}},true);
 window.addEventListener('storage',function(ev){if(ev.key===KEY||ev.key==='NOONTANGI_MARKET_ENV_V2')if(active())view()});
 setInterval(function(){if(active()){var d=byId('nt221Settings');if(!d||!d.classList.contains('open'))view()}},60000);
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
 window.NOONTANGI_MARKET_UI_V223={render:view,version:'V223',getIndicators:selection,collectNews:collectMarketNews,newsCount:function(){return NEWS_CACHE.length}};
})();
