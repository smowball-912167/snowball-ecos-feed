/* V221 market overview: layout implementation of user-approved reference image.
   No network sources introduced; quotes/news reuse the existing verified adapters.
   Old market detail engine and non-market routes remain unchanged. */
(function(){'use strict';
 var KEY='nt_market_v221_visible_indicators';
 var SPECS=[['kospi','KOSPI','▥','index'],['kosdaq','KOSDAQ','▥','index'],['spx','S&P500','🇺🇸','index'],['nasdaq','NASDAQ','🇺🇸','index'],['vix','VIX','〰','number'],['usdkrw','원/달러','₩','fx'],['us10y','미 10년물','▤','yield'],['wti','WTI','◉','usd'],['gold','금','◆','usd'],['dxy','달러인덱스','＄','number'],['sox','필라델피아 반도체','▥','index'],['rut','러셀2000','▥','index'],['copper','구리','◆','usd'],['hyg','미국 하이일드채','▤','number']];
 var BASE=['kospi','kosdaq','spx','nasdaq','vix','usdkrw','us10y','wti','gold'];
 var lastDetailOpen=0;
 function byId(id){return document.getElementById(id)}
 function e(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
 function json(k,fb){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?fb:v}catch(_){return fb}}
 function store(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(_){}}
 function selection(){var ids=json(KEY,BASE);if(!Array.isArray(ids))ids=BASE;var valid=SPECS.map(function(x){return x[0]});ids=ids.filter(function(x,i){return valid.indexOf(x)>=0&&ids.indexOf(x)===i});return ids.slice(0,9)}
 function active(){return !!(byId('rMarket')&&byId('rMarket').checked)}
 function num(n){n=Number(n);return isFinite(n)?n:null}
 function quoteMap(){var snap=(window.NOONTANGI_MARKET_ENV&&window.NOONTANGI_MARKET_ENV.snapshot&&window.NOONTANGI_MARKET_ENV.snapshot())||json('NOONTANGI_MARKET_ENV_V2',{});var m={};(snap.items||[]).forEach(function(x){if(x&&x.id)m[x.id]=x});return {snap:snap,map:m}}
 function fmt(n,kind){if(n==null)return '—';if(kind==='yield')return n.toFixed(3)+'%';if(kind==='usd')return '$'+n.toFixed(2);return n.toLocaleString('ko-KR',{maximumFractionDigits:kind==='number'?2:2})}
 function change(n){if(n==null)return '<span class="nt221-muted">변동 확인 중</span>';var sign=n>0?'+':'';return '<span class="'+(n>0?'nt221-pos':n<0?'nt221-neg':'nt221-muted')+'">'+sign+n.toFixed(2)+'%</span>'}
 function time(ts){if(!ts)return '기준시각 확인 중';var d=new Date(ts),n=d.getTime();if(!isFinite(n))return '기준시각 확인 중';return d.toLocaleString('ko-KR',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).replace(/\.$/,'')}
 function assessment(q){var arr=Object.keys(q.map).filter(function(k){return q.map[k]&&q.map[k].valid===true});var r=json('NOONTANGI_MARKET_SCORE_V1',{}),sc=r.current&&num(r.current.score),at=r.current&&num(r.current.asOf),fresh=Number(q.snap.asOf||0)===at;
  if(!fresh||arr.length<8||sc==null)return {status:'판단 보류',description:'핵심 시장지표의 검증이 끝나지 않아 시장 상태를 확정하지 않았습니다.'};
  return {status:sc>=65?'우호 · 관찰':sc>=45?'중립 · 관망':sc>=30?'주의 · 관망':'위험 · 방어',description:'검증된 8개 핵심지표로 산출한 시장환경 종합점수 '+Math.round(sc)+'점입니다. 지표 변화와 수급을 함께 확인한 뒤 투자 판단에 참고하세요.'};
 }
 function axisDesc(q,ids){var vv=ids.map(function(id){var x=q.map[id];return x&&x.valid===true?num(x.changePct):null}).filter(function(x){return x!=null});if(!vv.length)return '관련 지표가 아직 확인되지 않았습니다.';return ids.map(function(id){var x=q.map[id];return x&&x.valid===true?(x.name||id)+' '+(x.changePct>=0?'+':'')+Number(x.changePct).toFixed(2)+'%':''}).filter(Boolean).join(' · ')+' (전일 대비). 서로 다른 지표를 단독 투자 신호로 해석하지 않습니다.'}
 function view(){var q=quoteMap(),a=assessment(q),ids=selection();var root=byId('ntmeV221');if(!root)return;
  var groups=[['금리·물가','시장 부담',['us10y','wti']],['기업실적·경기','성장 방향',['spx','nasdaq']],['수급·환율','자금 흐름',['usdkrw','kospi']],['주가 추세·VIX','시장 위험',['kospi','kosdaq','vix']]];
  var dashboard='<section class="nt221-card"><div class="nt221-head"><h2>시장환경</h2><span class="nt221-note" id="nt221SourceLabel">실제 시장지표 기준</span></div><div class="nt221-status"><span class="icon">▧</span>'+e(a.status)+'</div>'+groups.map(function(g){return '<details class="nt221-axis"><summary><span>'+e(g[0])+'</span><span class="right">'+e(g[1])+' ›</span></summary><p>'+e(axisDesc(q,g[2]))+'</p></details>'}).join('')+'<div class="nt221-ai">'+e('지표 해설: '+a.description)+'</div></section>';
  var tiles=ids.map(function(id){var s=SPECS.filter(function(x){return x[0]===id})[0];if(!s)return '';var x=q.map[id]||{},ok=x.valid===true,pr=ok?num(x.price):null,pct=ok?num(x.changePct):null;return '<button type="button" class="nt221-tile" data-nt221-chart="'+e(id)+'" aria-label="'+e(s[1])+' 상세차트"><span class="name">'+e(s[2])+' '+e(s[1])+'</span><span class="value">'+e(fmt(pr,s[3]))+'</span><span class="change">'+change(pct)+'</span></button>'}).join('');
  var ind='<section class="nt221-card"><div class="nt221-head"><h2>시장지표</h2><div class="nt221-actions"><button class="nt221-btn" type="button" data-nt221-settings aria-label="시장지표 환경설정">⚙</button><button class="nt221-btn" type="button" data-nt221-settings>더보기 ›</button></div></div><div class="nt221-note" style="margin-bottom:8px">환경설정에서 등록 · 최대 9개</div><div class="nt221-tiles">'+tiles+'</div><div class="nt221-timestamp">시세 기준: '+e(time(q.snap.asOf))+' · 미확인 값은 표시하지 않습니다.</div></section>';
  var currentOpen=root.querySelectorAll('details.nt221-axis[open]'),opened=Array.prototype.map.call(currentOpen,function(x){return Array.prototype.indexOf.call(x.parentNode.querySelectorAll('details.nt221-axis'),x)});
  root.innerHTML=dashboard+'<section class="nt221-card"><div class="nt221-head"><h2>시장 주요현황</h2><button type="button" class="nt221-btn" data-nt221-more>더보기 ›</button></div><div id="nt221News"><div class="nt221-empty">저장된 시장 관련 기사를 확인 중입니다.</div></div></section>'+ind+settingsHtml();
  var panels=root.querySelectorAll('details.nt221-axis');opened.forEach(function(i){if(panels[i])panels[i].open=true});
  news();
 }
 function topic(x){var s=[x.title,x.summary,x.description].join(' ').toLowerCase();var cats=[['금리·물가',/금리|인플레|물가|cpi|pce|fed|fomc|국채|연준|oil|유가|wti|원자재/i,'▤'],['기업실적·경기',/실적|매출|기업|경기|gdp|반도체|산업|고용|성장|소비/i,'▣'],['수급·환율',/환율|원화|달러|외국인|기관|수급|자금|순매수|순매도|외환|유동성/i,'₩'],['주가 추세·VIX',/지수|나스닥|코스피|코스닥|s&p|vix|변동성|주가|증시|주식|시장/i,'▥']];for(var i=0;i<cats.length;i++)if(cats[i][1].test(s))return {label:cats[i][0],icon:cats[i][2],level:i};return {label:'시장 연관',icon:'▥',level:4}}
 function articles(){var svc=window.NOONTANGI_ARTICLE_MONITOR;var out=[];if(!svc||typeof svc.list!=='function')return [];['domestic','global'].forEach(function(lane){try{var got=svc.list(lane);if(Array.isArray(got))out=out.concat(got)}catch(_){}});var seen={};return out.filter(function(x){if(!x||!x.title)return false;var key=String(x.url||x.title).trim().toLowerCase().replace(/\s+/g,'');if(seen[key])return false;seen[key]=true;return true}).sort(function(a,b){return Number(b.ts||0)-Number(a.ts||0)})}
 function news(){var target=byId('nt221News');if(!target)return;var all=articles(),list=all.map(function(x){return {item:x,cat:topic(x)}}).sort(function(a,b){return a.cat.level-b.cat.level||Number(b.item.ts||0)-Number(a.item.ts||0)}).slice(0,4);
  if(!list.length){target.innerHTML='<div class="nt221-empty">저장된 시장 관련 최신 기사가 없습니다. ‘더보기’에서 주요뉴스의 국내·글로벌 목록을 확인할 수 있습니다.</div>';return}
  target.innerHTML=list.map(function(y){var x=y.item,cat=y.cat,txt=String(x.summary||x.description||'');var when=x.ts?time(Number(x.ts)):'날짜 확인 중';return '<button type="button" class="nt221-newsrow" data-nt221-article="'+e(x.url||'')+'"><span class="nt221-thumb" aria-hidden="true">'+e(cat.icon)+'</span><span><span class="nt221-tag">'+e(cat.label)+'</span><h3>'+e(x.title)+'</h3><p>'+e(txt||'본문 확인은 원본 기사에서 가능합니다.')+'</p><div class="nt221-meta">'+e(x.source||'출처 확인 중')+' · '+e(when)+'</div></span></button>'}).join('')
 }
 function settingsHtml(){var selected=selection();return '<div id="nt221Settings" class="nt221-overlay" aria-hidden="true"><div class="nt221-dialog" role="dialog" aria-modal="true" aria-label="시장지표 환경설정"><div class="nt221-head"><h2>시장지표 환경설정</h2><button type="button" class="nt221-btn" data-nt221-close>닫기 ×</button></div><p class="nt221-setting-note">표시할 시장지표를 최대 9개 선택하세요. 순서는 등록 순서로 표시됩니다.</p><div class="nt221-options">'+SPECS.map(function(x){return '<label><input type="checkbox" data-nt221-opt="'+e(x[0])+'" '+(selected.indexOf(x[0])>=0?'checked':'')+'><span>'+e(x[1])+'</span></label>'}).join('')+'</div><p id="nt221Count" class="nt221-setting-note">'+selected.length+'/9개 선택</p><button type="button" class="nt221-btn" data-nt221-save>저장</button></div></div>'}
 function dialog(open){var d=byId('nt221Settings');if(!d)return;d.classList.toggle('open',!!open);d.setAttribute('aria-hidden',String(!open));if(open){var ids=selection();d.querySelectorAll('[data-nt221-opt]').forEach(function(i){i.checked=ids.indexOf(i.dataset.nt221Opt)>=0});count()}}
 function count(){var d=byId('nt221Settings');if(!d)return;var n=d.querySelectorAll('input:checked').length;var p=byId('nt221Count');if(p)p.textContent=n+'/9개 선택'+(n>9?' · 최대 9개입니다.':'')}
 function init(){var main=document.querySelector('#pageMarket main.container');if(!main)return;var root=byId('ntmeV221');if(!root){root=document.createElement('div');root.className='nt221';root.id='ntmeV221';main.insertBefore(root,main.firstChild)}view()}
 document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-nt221-settings],[data-nt221-close],[data-nt221-save],[data-nt221-more],[data-nt221-chart],[data-nt221-article]');if(!b)return;
  if(b.hasAttribute('data-nt221-settings')){dialog(true);return}
  if(b.hasAttribute('data-nt221-close')){dialog(false);return}
  if(b.hasAttribute('data-nt221-save')){var d=byId('nt221Settings');var ids=Array.prototype.map.call(d.querySelectorAll('input:checked'),function(x){return x.dataset.nt221Opt});if(ids.length>9){count();return}store(KEY,ids);view();return}
  if(b.hasAttribute('data-nt221-more')){var api=window.NOONTANGI_ARTICLE_MONITOR;if(api&&typeof api.open==='function')api.open();return}
  if(b.hasAttribute('data-nt221-chart')){var api=window.NOONTANGI_MARKET_ENV;if(api&&typeof api.openDetail==='function'){api.openDetail(b.getAttribute('data-nt221-chart'));lastDetailOpen=Date.now()}return}
  if(b.hasAttribute('data-nt221-article')){var url=b.getAttribute('data-nt221-article')||'';if(/^https:\/\//i.test(url)){window.open(url,'_blank','noopener,noreferrer')}else{var api=window.NOONTANGI_ARTICLE_MONITOR;if(api&&typeof api.open==='function')api.open()}return}
 },true);
 document.addEventListener('change',function(ev){if(ev.target&&ev.target.matches&&ev.target.matches('#nt221Settings [data-nt221-opt]')){var d=byId('nt221Settings');var n=d.querySelectorAll('input:checked').length;if(n>9)ev.target.checked=false;count()}else if(ev.target&&ev.target.id==='rMarket'&&ev.target.checked){setTimeout(view,280)}},true);
 document.addEventListener('keydown',function(ev){if(ev.key==='Escape')dialog(false)});
 window.addEventListener('storage',function(ev){if(ev.key===KEY||ev.key==='NOONTANGI_MARKET_ENV_V2')if(active())view()});
 setInterval(function(){if(active()){var d=byId('nt221Settings');if(!d||!d.classList.contains('open'))view()}},60000);
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
 window.NOONTANGI_MARKET_UI_V221={render:view,version:'V221',getIndicators:selection};
})();
