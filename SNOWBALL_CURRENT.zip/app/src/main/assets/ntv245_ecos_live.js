/* V255 15-source cache refresh and clearly labeled supplementary observations; V254 verified 20-session ECOS batch flow candidate; V253 verified import-price code (W=KRW) with safe V252 shared-cache mapping / safely approved source publishing bridge; V251 source-pipeline visibility + V247 conditional ECOS 15 bridge + V246 monthly display gate + V245 ECOS feed client: never contains ECOS_API_KEY.
 * Live requests require separately enabled and publicly reachable GitHub Pages.
 * Compatible verified observations are additive; existing newer official sources win. */
(function(root){'use strict';
var URL='https://smowball-912167.github.io/snowball-ecos-feed/ecos/feed.json',PREFIX='ntv245ecos_',STATE='NOONTANGI_ECOS_V245_STATE',waiting={},serial=0,busy=false;
var DAY=86400000;
function number(v){if(v===null||v===undefined||v==='')return null;var n=Number(v);return isFinite(n)?n:null;}
function state(){try{return JSON.parse(localStorage.getItem(STATE)||'{}')}catch(_){return {}}}
function save(s){try{localStorage.setItem(STATE,JSON.stringify(s))}catch(_){}}
var previous=root.__SnowballNativeAsyncResolve;
root.__SnowballNativeAsyncResolve=function(id,raw){
 if(String(id||'').indexOf(PREFIX)!==0){if(typeof previous==='function')return previous(id,raw);return;}
 var p=waiting[id];if(!p)return;delete waiting[id];clearTimeout(p.timer);
 if(!raw||String(raw).length>1600000)return p.reject(Error('ECOS 피드 응답 없음·과다'));
 p.resolve(raw);
};
function get(){return new Promise(function(resolve,reject){
 if(!root.SnowballMarketData||typeof root.SnowballMarketData.getAsync!=='function')return reject(Error('갤럭시 수집 연결 없음'));
 var id=PREFIX+(++serial)+'_'+Date.now();var timer=setTimeout(function(){if(waiting[id]){delete waiting[id];reject(Error('ECOS 피드 대기 초과'))}},14000);
 waiting[id]={resolve:resolve,reject:reject,timer:timer};
 try{root.SnowballMarketData.getAsync(URL,id)}catch(e){clearTimeout(timer);delete waiting[id];reject(e)}
});}
function series(feed,id,cycle,unit,maxAge){
 var s=feed.sources&&feed.sources[id];if(!s||s.cycle!==cycle||typeof s.unit!=='string'||s.unit.replace(/\s+/g,'')!==unit.replace(/\s+/g,'')||!Array.isArray(s.history))return null;
 var re=cycle==='D'?/^20\d{6}$/:/^20\d{4}$/;var by={},out=[];
 for(var i=0;i<s.history.length;i++){
  var p=s.history[i];if(!Array.isArray(p)||p.length!==2||!re.test(String(p[0]))||number(p[1])===null)return null;
  if(by[p[0]]!==undefined)return null;by[p[0]]=number(p[1]);
 }
 Object.keys(by).sort().forEach(function(k){out.push({period:k,value:by[k]})});
 if(!out.length||out[out.length-1].period!==s.latest||Math.abs(out[out.length-1].value-number(s.value))>1e-7)return null;
 var end=out[out.length-1].period,iso=cycle==='D'?end.slice(0,4)+'-'+end.slice(4,6)+'-'+end.slice(6,8):end.slice(0,4)+'-'+end.slice(4,6)+'-01';
 if(!isFinite(Date.parse(iso))||Date.parse(iso)>Date.now()+DAY||Date.now()-Date.parse(iso)>maxAge*DAY)return null;
 return {points:out,iso:iso,latest:end,id:id};
}
function observation(id,series,value,label,maxDays){
 if(!series||number(value)===null||Math.abs(value)>1e14)return null;
 var hist=series.points.slice(-36).map(function(p){var t=p.period,iso=t.length===8?t.slice(0,4)+'-'+t.slice(4,6)+'-'+t.slice(6,8):t.slice(0,4)+'-'+t.slice(4,6)+'-01';return {value:p.value,asOf:iso+'T12:00:00Z'}});
 return {id:id,value:value,asOf:series.iso+'T12:00:00Z',period:label||series.latest,
 source:'한국은행 ECOS · 조회 '+series.latest+' · V246 자동 수집',verified:true,history:hist};
}
function yoy(s){if(!s)return null;var a=s.points,n=a.length;var latest=a[n-1];if(!latest||latest.period.length!==6)return null;
 var prev=(Number(latest.period.slice(0,4))-1)+latest.period.slice(4),before=a.filter(function(x){return x.period===prev})[0];
 if(!before||before.value===0)return null;
 var val=(latest.value/before.value-1)*100;return isFinite(val)&&val> -100&&val<200?Math.round(val*1000)/1000:null;
}
// V247: Only exact source identity may unlock a new observation. No audit ZIP is a live feed.
function candidate(feed,id,table,item,cycle,unit,maxAge){
 var s=feed&&feed.sources&&feed.sources[id];
 if(!s||s.table!==table||s.item!==item||s.cycle!==cycle||s.status!=='observed_not_auto_approved')return null;
 return series(feed,id,cycle,unit,maxAge);
}
function volatility20(fx){
 if(!fx||fx.points.length<21)return null;
 var ps=fx.points,entries=[];
 for(var end=20;end<ps.length;end++){
  var returns=[],fail=false;
  for(var i=end-19;i<=end;i++){
   var prev=ps[i-1].value,curr=ps[i].value;
   if(prev<=0||curr<=0){fail=true;break;}
   var change=(curr/prev-1)*100;
   if(!isFinite(change)||Math.abs(change)>20){fail=true;break;}
   returns.push(change);
  }
  if(fail||returns.length!==20)continue;
  var mean=returns.reduce(function(a,b){return a+b;},0)/20;
  var variance=returns.reduce(function(a,b){return a+(b-mean)*(b-mean);},0)/19;
  var v=Math.sqrt(variance);
  if(!isFinite(v)||v<0||v>15)continue;
  var p=ps[end].period,iso=p.slice(0,4)+'-'+p.slice(4,6)+'-'+p.slice(6,8);
  entries.push({value:Math.round(v*1e5)/1e5,asOf:iso+'T12:00:00Z'});
 }
 if(!entries.length||entries[entries.length-1].asOf!==fx.iso+'T12:00:00Z')return null;
 var recent=entries.slice(-36),latest=recent[recent.length-1];
 return {id:'krwVolatility',value:latest.value,asOf:latest.asOf,period:fx.latest+' / 20거래일',
  source:'한국은행 ECOS · 20거래일 일간수익률 표본표준편차(비연율화)',verified:true,history:recent};
}
// V252: an *exact* source registry. The device never receives an API key.
// Only source IDs that the public publisher deliberately allows can populate this cache.
var SHARED_KEY='NOONTANGI_ECOS_SHARED_SERIES_V252';
var EXTENDED={
 'fx_d':['731Y001','0000001','D','원',12],
 'kr_base_d':['722Y001','0101000','D','연%',160],
 'kr_treasury_3y_d':['817Y002','010200000','D','연%',12],
 'kr_treasury_10y_d':['817Y002','010210000','D','연%',12],
 'us_cpi_m':['902Y008','US','M','지수',105],
 'kospi_d':['802Y001','0001000','D','1980.01.04=100',12],
 'kosdaq_d':['802Y001','0089000','D','1996.07.01=1000',12],
 'kospi_foreign_d':['802Y001','0030000','D','억원',12],
 'kosdaq_foreign_d':['802Y001','0113000','D','억원',12],
 'us_policy_m':['902Y006','US','M','%',105],
 'exports_m':['901Y118','T002','M','천불',105],
 'kr_cpi_m':['901Y009','0','M','2020=100',105],
 'import_price_m':['401Y015','*AA','M','2020=100',105],
 'ppi_m':['404Y014','*AA','M','2020=100',105],
 'customer_deposit_m':['901Y056','S23A','M','원',105],
 'credit_balance_m':['901Y056','S23E','M','원',105],
 'wti_m':['902Y003','010101','M','달러/배럴',105],
 'gold_m':['902Y003','040101','M','달러/트로이온스',105],
 'copper_m':['902Y003','040202','M','달러/톤',105]
};
function getSharedSeries(id){
 if(!Object.prototype.hasOwnProperty.call(EXTENDED,id))return null;
 try{var v=JSON.parse(localStorage.getItem(SHARED_KEY)||'{}'),x=v.sources&&v.sources[id];
  if(!x||!Array.isArray(x.points)||!x.points.length||x.points.length>440)return null;
  if(id==='import_price_m'&&(x.dimensionResolution!=='ITEM_CODE2_W_KRW_VERIFIED'||x.dimensionCode2!=='W'))return null;
  var spec=EXTENDED[id],latest=x.points[x.points.length-1];
  if(!latest||latest.period!==x.latest||latest.value!==number(latest.value)||
   x.cycle!==spec[2]||String(x.table)!==spec[0]||String(x.item)!==spec[1]||
   Date.now()-Date.parse(x.iso+'T00:00:00Z')>spec[4]*DAY)return null;
  return JSON.parse(JSON.stringify(x));
 }catch(_){return null}
}
function saveShared(feed){
 var old={};try{old=JSON.parse(localStorage.getItem(SHARED_KEY)||'{}')}catch(_){}
 var kept={};Object.keys(old.sources||{}).forEach(function(id){
  var oldrow=old.sources[id];
  // Invalidate historical C=contract-currency cache, even if still referenced by a feed.
  if(id==='import_price_m'&&(!oldrow||oldrow.dimensionResolution!=='ITEM_CODE2_W_KRW_VERIFIED'||oldrow.dimensionCode2!=='W'))return;
  if(feed.sources&&Object.prototype.hasOwnProperty.call(feed.sources,id))kept[id]=oldrow;
 });
 var result={schema:'ECOS_SHARED_V252',updatedAt:Date.now(),sources:kept},accepted=0;
 Object.keys(EXTENDED).forEach(function(id){
  var meta=EXTENDED[id],v=candidate(feed,id,meta[0],meta[1],meta[2],meta[3],meta[4]);
  if(!v||v.points.length<(meta[2]==='D'?2:13))return;
  // Multi-dimensional import-price data require explicit verified selection and provenance.
  if(id==='import_price_m'&&(!feed.sources[id]||(feed.sources[id].dimensionResolution!=='ITEM_CODE2_W_KRW_VERIFIED'||feed.sources[id].dimensionCode2!=='W'||feed.sources[id].dimensionName2!=='원화기준')))return;
  var oldrow=result.sources[id];if(oldrow&&String(oldrow.latest||'')>String(v.latest))return;
  result.sources[id]={table:meta[0],item:meta[1],cycle:meta[2],unit:meta[3],latest:v.latest,iso:v.iso,
   points:v.points.slice(-440),provenance:'published_verified_ECOS',dimensionResolution:id==='import_price_m'?'ITEM_CODE2_W_KRW_VERIFIED':null,
   dimensionCode2:id==='import_price_m'?'W':null,dimensionName2:id==='import_price_m'?'원화기준':null};
  accepted++;
 });
 if(accepted||Object.keys(kept).length!==Object.keys(old.sources||{}).length){try{localStorage.setItem(SHARED_KEY,JSON.stringify(result));window.dispatchEvent(new Event('ntv252:ecos-shared'))}catch(_){return 0}}
 return accepted;
}
function importPriceCandidate(feed){
 var x=feed.sources&&feed.sources.import_price_m;
 if(!x||x.dimensionResolution!=='ITEM_CODE2_W_KRW_VERIFIED'||x.dimensionCode2!=='W'||x.dimensionName2!=='원화기준')return null;
 var s=candidate(feed,'import_price_m','401Y015','*AA','M','2020=100',105);
 if(!s)return null;var v=s.points[s.points.length-1].value;
 if(v<=0||v>1000)return null;
 return observation('krImportPrice',s,v,s.latest+' 지수',105);
}

// V254: The chart indices define actual shared market sessions, including exchange
// holidays. Never invent daily observations from a monthly source or count 20
// calendar days as 20 trading days. Requires FOUR separately approved daily feeds.
function foreign20Candidate(feed){
 var k=candidate(feed,'kospi_d','802Y001','0001000','D','1980.01.04=100',12),
     q=candidate(feed,'kosdaq_d','802Y001','0089000','D','1996.07.01=1000',12),
     f=candidate(feed,'kospi_foreign_d','802Y001','0030000','D','억원',12),
     g=candidate(feed,'kosdaq_foreign_d','802Y001','0113000','D','억원',12);
 if(!k||!q||!f||!g||k.points.length<20||q.points.length<20||f.points.length<20||g.points.length<20)return null;
 var kp=k.points.map(function(x){return x.period}),qp=q.points.map(function(x){return x.period});
 // Both official market-index series must report precisely the same last sessions.
 if(kp.slice(-20).join('|')!==qp.slice(-20).join('|')||k.latest!==q.latest)return null;
 var fs={},gs={};f.points.forEach(function(x){fs[x.period]=x.value});g.points.forEach(function(x){gs[x.period]=x.value});
 var rows=[],end=Math.min(kp.length,qp.length); // History: 20-session rolling sums, not daily point readings.
 for(var i=19;i<end;i++){
  var dates=kp.slice(i-19,i+1),sum=0,valid=true;
  // Abort the full candidate on a source gap in the most recent 20 sessions.
  for(var j=0;j<dates.length;j++){
   var d=dates[j],a=fs[d],b=gs[d];
   if(!Object.prototype.hasOwnProperty.call(fs,d)||!Object.prototype.hasOwnProperty.call(gs,d)||
       !isFinite(a)||!isFinite(b)||Math.abs(a)>5000000||Math.abs(b)>5000000){valid=false;break}
   sum+=a+b;
  }
  if(valid&&Math.abs(sum)<100000000)rows.push({period:kp[i],value:Math.round(sum*1000)/1000});
  else if(i>=end-20)return null;
 }
 if(!rows.length||rows[rows.length-1].period!==k.latest||
    f.latest!==k.latest||g.latest!==k.latest)return null;
 var last=rows[rows.length-1],iso=last.period.slice(0,4)+'-'+last.period.slice(4,6)+'-'+last.period.slice(6,8),now=Date.now(),t=Date.parse(iso+'T00:00:00Z');
 if(!isFinite(t)||t>now+DAY||now-t>12*DAY)return null;
 var hist=rows.slice(-36).map(function(x){var d=x.period;return {value:x.value,asOf:d.slice(0,4)+'-'+d.slice(4,6)+'-'+d.slice(6,8)+'T12:00:00Z'}});
 return {id:'foreign20d',value:last.value,asOf:iso+'T12:00:00Z',period:last.period+' / KOSPI+KOSDAQ 최근 20거래일',
  source:'한국은행 ECOS · 802Y001 KOSPI·KOSDAQ 외국인 순매수 합산 · 실제 동일 거래일 20개 · 억원',verified:true,history:hist};
}

var MONTHLY_KEY='NOONTANGI_ECOS_MONTHLY_REFERENCES_V247';
function monthlyCandidates(feed){
 var spec=[['customer_deposit_m','S23A','customerDepositsMonthly'],['credit_balance_m','S23E','creditBalanceMonthly']],o={};
 spec.forEach(function(v){var id=v[0],s=candidate(feed,id,'901Y056',v[1],'M','원',105);
  if(!s||s.points.length<13)return;
  var last=s.points[s.points.length-1],value=last.value/100000000;
  if(!isFinite(value)||value<=0||value>5000000)return;
  o[v[2]]={id:v[2],value:Math.round(value*1000)/1000,asOf:s.iso+'T12:00:00Z',period:s.latest,
   source:'한국은행 ECOS · 901Y056/'+v[1]+' · 월별 참고(일별 대체 아님)',verified:true,cycle:'M'};
 });
 return o;
}
function saveMonthly(o){
 if(!o||!Object.keys(o).length)return 0;
 var old;try{old=JSON.parse(localStorage.getItem(MONTHLY_KEY)||'{}')}catch(_){old={}};
 var fresh=Object.assign({},old),n=0;
 Object.keys(o).forEach(function(id){var item=o[id],prev=fresh[id];
  if(!prev||String(item.period)>=String(prev.period||'')){fresh[id]=item;n++;}
 });
 if(n){try{localStorage.setItem(MONTHLY_KEY,JSON.stringify(fresh));window.dispatchEvent(new Event('ntv238:indicators'))}catch(_){return 0}}
 return n;
}
function match(feed){
 if(!feed||feed.schema!=='NT_ECOS_LIVE_V245'||!feed.generatedAt||!feed.sources)return [];
 var ts=Date.parse(feed.generatedAt);if(!isFinite(ts)||ts>Date.now()+DAY||Date.now()-ts>3*DAY)return [];
 var raw={
  krRate:series(feed,'kr_base_d','D','연%',160),
  kr03y:series(feed,'kr_treasury_3y_d','D','연%',12),
  krPpi:series(feed,'ppi_m','M','2020=100',95),
  krCpi:series(feed,'kr_cpi_m','M','2020=100',95),
  krExports:series(feed,'exports_m','M','천불',105)
 };
 var fx=candidate(feed,'fx_d','731Y001','0000001','D','원',12);
 var data=[observation('krRate',raw.krRate,raw.krRate&&raw.krRate.points.slice(-1)[0].value,raw.krRate&&raw.krRate.latest,160),
  observation('kr03y',raw.kr03y,raw.kr03y&&raw.kr03y.points.slice(-1)[0].value,raw.kr03y&&raw.kr03y.latest,12),
  observation('krPpi',raw.krPpi,raw.krPpi&&raw.krPpi.points.slice(-1)[0].value,raw.krPpi&&raw.krPpi.latest+' 지수',95),
  observation('krCpi',raw.krCpi,yoy(raw.krCpi),raw.krCpi&&raw.krCpi.latest+' YoY',95),
  observation('krExports',raw.krExports,yoy(raw.krExports),raw.krExports&&raw.krExports.latest+' YoY',105),
  volatility20(fx),importPriceCandidate(feed),foreign20Candidate(feed)];
 return data.filter(function(x){if(!x)return false;
  var limit={krRate:30,kr03y:30,krPpi:1000,krCpi:50,krExports:200,krwVolatility:15,krImportPrice:1000,foreign20d:100000000}[x.id];if(Math.abs(x.value)>limit)return false;
  var prior=root.NOONTANGI_FOUR_FACTORS.official(x.id);
  return !prior||Date.parse(x.asOf)>Date.parse(prior.asOf)||(x.id==='krwVolatility'&&Date.parse(x.asOf)===Date.parse(prior.asOf)&&String(prior.source||'').indexOf('Yahoo Finance')>=0);
 });
}
// No API keys, raw server errors, values or account information enter the diagnostic record.
function reason(e){
 var s=String(e&&e.message||e||'');
 if(/^ECOS_[A-Z0-9_]+$/.test(s))return s.slice(0,48);
 if(/대기 초과|timeout/i.test(s))return 'ECOS_TIMEOUT';
 if(/브리지|연결 없음/i.test(s))return 'ECOS_BRIDGE_UNAVAILABLE';
 if(/과다/i.test(s))return 'ECOS_RESPONSE_TOO_LARGE';
 return 'ECOS_UNCLASSIFIED';
}
function failure(code,old){
 save({clientVersion:'V255',lastAttempt:Date.now(),lastSuccess:old.lastSuccess||null,ok:false,
  requestStatus:'FAILED',errorCode:code,added:0,validatedCount:0,
  sourceCount:Number(old.sourceCount)||0,feedGeneratedAt:old.feedGeneratedAt||null,
  stage:'ECOS 수신 실패 · '+code+' · 기존값 유지'});
 try{window.dispatchEvent(new Event('ntv245:status'))}catch(_){}
 return {status:'not-connected',errorCode:code};
}
function refresh(force){var old=state();if(busy)return Promise.resolve({status:'busy'});
 if(!force&&old.clientVersion==='V255'&&Date.now()-Number(old.lastAttempt||0)<(old.ok?0.5:0.05)*3600000)return Promise.resolve({status:'cached'});
 if(!root.NOONTANGI_FOUR_FACTORS||typeof root.NOONTANGI_FOUR_FACTORS.ingest!=='function')return Promise.resolve({status:'not-ready'});
 busy=true;save(Object.assign({},old,{lastAttempt:Date.now(),requestStatus:'REQUESTING',errorCode:'',stage:'ECOS 공개 피드 확인 중'}));
 return get().then(function(raw){
  var data;try{data=JSON.parse(raw)}catch(_){throw Error('ECOS_INVALID_JSON')}
  if(data&&data.error){var ec=String(data.error||'');
   throw Error(/^HTTP_[0-9]{3}$/.test(ec)?'ECOS_'+ec:
     /^(REQUEST_QUEUE_FULL|REQUEST_CANCELLED|APP_PAUSED|URL_NOT_ALLOWED|APK_NATIVE_GET_ERROR)$/.test(ec)?'ECOS_'+ec:'ECOS_UPSTREAM_ERROR');}
  if(!data||data.schema!=='NT_ECOS_LIVE_V245'||!data.sources||typeof data.sources!=='object'||Array.isArray(data.sources))throw Error('ECOS_INVALID_SCHEMA');
  var issued=Date.parse(data.generatedAt);if(!isFinite(issued))throw Error('ECOS_INVALID_TIMESTAMP');
  if(issued>Date.now()+DAY)throw Error('ECOS_FUTURE_FEED');
  if(Date.now()-issued>3*DAY)throw Error('ECOS_STALE_FEED');
  var sourceIds=Object.keys(data.sources).filter(function(k){return /^[a-z][a-z0-9_]{1,40}$/.test(k)});
  if(!sourceIds.length)throw Error('ECOS_EMPTY_FEED');
  if(Number(data.sourceCount)!==sourceIds.length)throw Error('ECOS_COUNT_MISMATCH');
  var sharedAccepted=saveShared(data);
  var compatible=match(data),updated=compatible.length?root.NOONTANGI_FOUR_FACTORS.ingest(compatible):0;
  var monthly=saveMonthly(monthlyCandidates(data));
  updated=Number(updated)||0;
  var mapped=['kr_base_d','kr_treasury_3y_d','kr_cpi_m','ppi_m','exports_m','fx_d','customer_deposit_m','credit_balance_m','import_price_m','kospi_d','kosdaq_d','kospi_foreign_d','kosdaq_foreign_d'];
  var known=sourceIds.filter(function(id){return mapped.indexOf(id)>=0});
  var sharedAvailable=sourceIds.filter(function(id){return getSharedSeries(id)!==null});
  var summary={clientVersion:'V255',lastAttempt:Date.now(),lastSuccess:Date.now(),ok:true,
   requestStatus:'RECEIVED',errorCode:'',added:updated,validatedCount:compatible.length,
   sourceCount:sourceIds.length,knownMappedCount:known.length,sharedSourceCount:sharedAvailable.length,unmappedPublishedCount:sourceIds.filter(function(id){return mapped.indexOf(id)<0&&!getSharedSeries(id)}).length,
   monthlyReferenceCount:monthly,sharedSeriesUpdated:sharedAccepted,feedGeneratedAt:data.generatedAt,
   // 'received' is not proof of a currently visible app indicator or correlation chart.
   screenVerified:false,stage:'ECOS 피드 '+sourceIds.length+'원천 수신 · 공유 시계열 '+sharedAccepted+'개 · 실제값 반영 '+updated+'건'};
  save(summary);try{window.dispatchEvent(new Event('ntv245:status'))}catch(_){}
  return {status:'received',added:updated,validatedCount:compatible.length,sourceCount:sourceIds.length,sharedSeriesUpdated:sharedAccepted,screenVerified:false};
 }).catch(function(e){return failure(reason(e),old)}).finally(function(){busy=false});
}
document.addEventListener('change',function(e){if(e.target&&e.target.id==='rMarket'&&e.target.checked)setTimeout(function(){refresh(false)},1300)},true);
document.addEventListener('click',function(e){var t=e.target&&e.target.closest&&e.target.closest('[data-ntv255-ecos-refresh]');if(!t)return;e.preventDefault();if(busy)return;var prior=state();if(Date.now()-Number(prior.lastAttempt||0)<120000)return;refresh(true)},true);
function versionBadge(){var b=typeof document.getElementById==='function'&&document.getElementById('snowballBuildV42');if(b&&b.textContent!=='V60.8 · V255')b.textContent='V60.8 · V255'}
// Restore/launch directly on the Market screen also deserves one bounded refresh.
function bootMarket(){versionBadge();setTimeout(versionBadge,2100);var badge=document.getElementById('snowballBuildV42');if(badge&&typeof MutationObserver==='function'){var watch=new MutationObserver(versionBadge);watch.observe(badge,{characterData:true,childList:true,subtree:true})};var m=typeof document.getElementById==='function'?document.getElementById('rMarket'):null;if(m&&m.checked)setTimeout(function(){refresh(false)},1700)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bootMarket);else bootMarket();
root.NOONTANGI_ECOS_V245={refresh:refresh,match:match,monthlyCandidates:monthlyCandidates,volatility20:volatility20,foreign20Candidate:foreign20Candidate,getSharedSeries:getSharedSeries,state:state,version:'V255',endpoint:URL};
if(typeof module==='object'&&module.exports)module.exports=root.NOONTANGI_ECOS_V245;
})(typeof window!=='undefined'?window:globalThis);
