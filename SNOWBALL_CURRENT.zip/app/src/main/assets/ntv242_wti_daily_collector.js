/* V242 public Yahoo daily settlement history for WTI 60-completed-session arithmetic mean.
 No substitute symbols, no score changes, no assumed values or user credentials. */
(function(root){'use strict';
 var PREFIX='ntv242wti_',STATE='NOONTANGI_V242_WTI_STATE',URL='https://query1.finance.yahoo.com/v8/finance/chart/CL%3DF?range=6mo&interval=1d',BUSY=false,N=0,PENDING={};
 function error(s){return new Error(String(s||'WTI 60일선 확인 실패').slice(0,180))}
 function num(v){return v===null||v===undefined||String(v).trim()===''?null:(isFinite(Number(v))?Number(v):null)}
 function state(){try{return JSON.parse(localStorage.getItem(STATE)||'{}')}catch(_){return {}}}
 function save(s){try{localStorage.setItem(STATE,JSON.stringify(s))}catch(_){}}
 var old=root.__SnowballNativeAsyncResolve;
 root.__SnowballNativeAsyncResolve=function(id,body){if(String(id||'').indexOf(PREFIX)!==0){if(typeof old==='function')return old(id,body);return;}
  var p=PENDING[id];if(!p)return;delete PENDING[id];clearTimeout(p.timer);var raw=String(body||'');if(!raw||raw.length>1200000)return p.reject(error('Yahoo 일별 시계열 응답 이상'));
  try{var v=JSON.parse(raw);if(v.error)return p.reject(error(v.error));p.resolve(v)}catch(e){p.reject(error('JSON 자료 형식 오류'))}
 };
 function get(){return new Promise(function(resolve,reject){if(!root.SnowballMarketData||typeof root.SnowballMarketData.getAsync!=='function')return reject(error('기존 네트워크 브리지 없음'));
  var id=PREFIX+(++N)+'_'+Date.now(),timer=setTimeout(function(){if(PENDING[id]){delete PENDING[id];reject(error('일별 시계열 시간 초과'))}},16500);PENDING[id]={resolve:resolve,reject:reject,timer:timer};
  try{root.SnowballMarketData.getAsync(URL,id)}catch(e){clearTimeout(timer);delete PENDING[id];reject(e)}
 })}
 function parse(data,now){now=num(now)||Date.now();var ch=data&&data.chart&&data.chart.result;if(!Array.isArray(ch)||ch.length!==1)throw error('Yahoo 시계열 1종 불일치');
  var a=ch[0],symbol=String(a.meta&&a.meta.symbol||''),currency=String(a.meta&&a.meta.currency||''),quotes=a.indicators&&a.indicators.quote;
  if(symbol!=='CL=F'||currency!=='USD')throw error('WTI 상품 코드 또는 통화 불일치');
  if(!Array.isArray(a.timestamp)||!Array.isArray(quotes)||quotes.length!==1||!Array.isArray(quotes[0].close))throw error('종가 배열 없음');
  var prices={},ts=a.timestamp,cl=quotes[0].close;if(cl.length!==ts.length)throw error('날짜·종가 배열 길이 다름');
  for(var i=0;i<ts.length;i++){var t=num(ts[i]),v=num(cl[i]);if(t===null||v===null||v<=0||v>600||t<1000000000||t*1000>=now)continue;
   var d=new Date(t*1000).toISOString().slice(0,10);if(!/^20\d{2}-\d{2}-\d{2}$/.test(d))continue;
   // Only sessions older than 24 h: no partly formed 'today' candle.
   if(now-t*1000<24*3600000)continue;prices[d]=v;
  }
  var dayKeys=Object.keys(prices).sort(),last=dayKeys[dayKeys.length-1];if(dayKeys.length<60)throw error('완료된 거래일 60개 미만');
  if(now-Date.parse(last+'T12:00:00Z')>12*86400000)throw error('WTI 일별 자료 오래됨');
  var last60=dayKeys.slice(-60),sum=last60.reduce(function(s,d){return s+prices[d]},0),avg=sum/60;
  if(!isFinite(avg)||avg<=0)throw error('60거래일 평균 계산 실패');
  return {id:'wti60dma',value:Math.round(avg*1000)/1000,asOf:last+'T12:00:00Z',period:last+' 마감 60거래일',source:'Yahoo Finance · CL=F · 일봉 종가 60거래일 단순평균',verified:true,
   history:last60.map(function(d){return {asOf:d+'T12:00:00Z',value:prices[d]}})};
 }
 function refresh(force){if(BUSY)return Promise.resolve({status:'busy'});var s=state(),now=Date.now(),gap=s.success?23*3600000:7*3600000;
  if(!force&&now-Number(s.lastAttempt||0)<gap)return Promise.resolve({status:'cached'});
  if(!root.NOONTANGI_FOUR_FACTORS||typeof root.NOONTANGI_FOUR_FACTORS.ingest!=='function')return Promise.resolve({status:'not-ready'});
  BUSY=true;save({lastAttempt:now,success:false,status:'WTI 자료 확인 중'});
  return get().then(function(j){var metric=parse(j,Date.now());var count=root.NOONTANGI_FOUR_FACTORS.ingest([metric]);
   save({lastAttempt:now,success:count===1,lastSuccess:count?Date.now():s.lastSuccess,count:count,status:count?'확인 완료':'미연결'});return {status:count?'received':'failed',count:count};
  }).catch(function(e){save({lastAttempt:now,success:false,lastSuccess:s.lastSuccess||null,count:0,status:'미연결',error:String(e.message||e).slice(0,120)});return {status:'failed',error:String(e.message||e)}}).finally(function(){BUSY=false});
 }
 if(typeof document!=='undefined')document.addEventListener('change',function(e){if(e.target&&e.target.id==='rMarket'&&e.target.checked)setTimeout(function(){refresh(false)},1300)},true);
 root.NOONTANGI_WTI_HISTORY_V242={refresh:refresh,parse:parse,state:state};
 if(typeof module==='object'&&module.exports)module.exports=root.NOONTANGI_WTI_HISTORY_V242;
})(typeof window!=='undefined'?window:globalThis);
