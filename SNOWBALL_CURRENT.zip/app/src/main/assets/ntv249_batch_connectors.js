/* V249 verified batch: one deployment, no placeholder readings or private API keys.
 * Keyless ISM official report + 20 observed Korean trading sessions from existing flow journal
 * + fail-closed finance JSON bridge for a future server-side, definition-verified public feed.
 * Existing direct daily series, ECOS gate, score, journal and accounts remain unchanged. */
(function(root){'use strict';
var ID='NOONTANGI_V249_BATCH_STATUS', STARTUP_STATUS='NOONTANGI_V257_FINANCE_STARTUP', FLOWKEY='NOONTANGI_V249_MARKET_DAILY_FLOW';
var FINANCE_URL='https://smowball-912167.github.io/snowball-ecos-feed/market/finance.json';
var ISP='https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/';
var PREFIX='ntv249_';var q={},serial=0,busy=false, DAY=86400000;
var MONTHS=['january','february','march','april','may','june','july','august','september','october','november','december'];
function num(x){if(x===null||x===undefined||x==='')return null;var v=Number(x);return Number.isFinite(v)?v:null}
function read(key){try{return JSON.parse(root.localStorage.getItem(key)||'null')}catch(_){return null}}
function save(key,v){try{root.localStorage.setItem(key,JSON.stringify(v))}catch(_){}}
function date(s){if(!/^20\d{6}$/.test(String(s||'')))return null;var z=String(s),y=+z.slice(0,4),m=+z.slice(4,6),d=+z.slice(6,8);var t=Date.UTC(y,m-1,d,12);return new Date(t).toISOString().slice(0,10).replace(/-/g,'')===z?t:null}
function priorOk(id,obs){var old=(read('NOONTANGI_OFFICIAL_INDICATORS_V238')||{})[id];return !old||old.verified!==true||!Number.isFinite(Date.parse(old.asOf))||Date.parse(obs.asOf)>Date.parse(old.asOf)}
function ingest(id,v,key,period,source,history){var asof=key.slice(0,4)+'-'+key.slice(4,6)+'-'+key.slice(6,8)+'T12:00:00Z';var out={id:id,value:v,asOf:asof,period:period||key,source:source,verified:true,history:history||[]};if(!priorOk(id,out)||!root.NOONTANGI_FOUR_FACTORS||!root.NOONTANGI_FOUR_FACTORS.ingest)return 0;return root.NOONTANGI_FOUR_FACTORS.ingest([out])}
var prev=root.__SnowballNativeAsyncResolve;
root.__SnowballNativeAsyncResolve=function(id,raw){if(String(id||'').indexOf(PREFIX)!==0){if(typeof prev==='function')return prev(id,raw);return;}var job=q[id];if(!job)return;delete q[id];clearTimeout(job.timer);if(!raw||String(raw).length>400000)job.reject(Error('source unavailable'));else job.resolve(String(raw));};
function get(url){return new Promise(function(resolve,reject){if(!root.SnowballMarketData||typeof root.SnowballMarketData.getAsync!=='function')return reject(Error('native API unavailable'));var id=PREFIX+(++serial)+'_'+Date.now();var timer=setTimeout(function(){delete q[id];reject(Error('timeout'))},12000);q[id]={resolve:resolve,reject:reject,timer:timer};try{root.SnowballMarketData.getAsync(url,id)}catch(ex){clearTimeout(timer);delete q[id];reject(ex)}})}
function marketName(s){var z=String(s||'').toUpperCase().trim();if(z==='KOSPI'||z==='코스피'||z==='유가증권')return 'KOSPI';if(z==='KOSDAQ'||z==='코스닥')return 'KOSDAQ';return null}
// V262: Only finalized sessions enter local journal; old provisional values may be
// replaced by later confirmed closes. Never write on-device values to public Pages.
function marketFinal(x,today,now){
 var d=String(x&&x.bizdate||''),phase=String(x&&x.phase||'');
 if(phase==='historical')return d<today;
 if(phase==='pre')return d<today;
 // Trading-day after-hours snapshots before 16:00 KST may still be provisional.
 if(phase==='closed'){
  if(d<today)return true;
  var t=new Date(now+9*3600000),mins=t.getUTCHours()*60+t.getUTCMinutes();
  return d===today&&mins>=16*60;
 }
 return false;
}
function storeFlow(){
 var ext=read('NOONTANGI_MARKET_EXTERNAL_V1'),list=[];
 if(ext&&Array.isArray(ext.flowHistory))list=list.concat(ext.flowHistory);
 if(ext&&Array.isArray(ext.flow))list=list.concat(ext.flow);
 var saved=read(FLOWKEY)||{},added=0,now=Date.now(),kst=new Date(now+9*3600000).toISOString().slice(0,10).replace(/-/g,'');
 list.forEach(function(x){
  if(!x||x.valid!==true)return;
  var m=marketName(x.market),d=String(x.bizdate||''),t=date(d),v=num(x.foreign);
  if(!m||!t||v===null||Math.abs(v)>5000000||t>now+DAY||now-t>60*DAY||!marketFinal(x,kst,now))return;
  var old=saved[d]||{},flag='_final_'+m;
  // Overwrite an earlier provisional observation with the final session value.
  if(old[m]===undefined||old[flag]!==true||old[m]!==v){old[m]=v;old[flag]=true;saved[d]=old;added++}
 });
 var pruned=0;Object.keys(saved).forEach(function(d){var t=date(d);if(!t||now-t>60*DAY){delete saved[d];pruned++}});
 if(added||pruned)save(FLOWKEY,saved);
 return added;
}
// V260: Weekend/holiday-safe 20-session computation is enabled ONLY when
// separately approved ECOS KOSPI and KOSDAQ index series prove the exact same
// last 20 trading sessions. Without that trusted calendar, preserve the strict
// V249 fail-closed behavior; no guessed holidays and no public feed changes.
function hasVerifiedMarketCalendar(last){
 var api=root.NOONTANGI_ECOS_V245;
 if(!api||typeof api.getSharedSeries!=='function')return false;
 var k=api.getSharedSeries('kospi_d'),q=api.getSharedSeries('kosdaq_d');
 if(!k||!q||k.table!=='802Y001'||q.table!=='802Y001'||
    k.item!=='0001000'||q.item!=='0089000'||k.cycle!=='D'||q.cycle!=='D'||
    !Array.isArray(k.points)||!Array.isArray(q.points)||
    k.points.length<20||q.points.length<20)return false;
 var kd=k.points.slice(-20).map(function(x){return String(x.period||'')});
 var qd=q.points.slice(-20).map(function(x){return String(x.period||'')});
 return kd.join('|')===qd.join('|')&&kd.join('|')===last.join('|')&&
        String(k.latest)===last[last.length-1]&&String(q.latest)===last[last.length-1];
}
function computeForeign20(){
 var all=read(FLOWKEY)||{};
 var keys=Object.keys(all).filter(function(x){return date(x)!==null&&all[x]&&all[x]._final_KOSPI===true&&all[x]._final_KOSDAQ===true&&num(all[x].KOSPI)!==null&&num(all[x].KOSDAQ)!==null}).sort();
 var last=keys.slice(-20);if(last.length<20)return null;
 var now=Date.now();
 if(now-date(last[last.length-1])>7*DAY||date(last[last.length-1])-date(last[0])>36*DAY)return null;
 if(!hasVerifiedMarketCalendar(last)){
  // Legacy conservative fallback rejects unknown missing weekdays.
  for(var i=1;i<last.length;i++){
   var diff=date(last[i])-date(last[i-1]);if(diff<DAY||diff>6*DAY)return null;
   for(var g=date(last[i-1])+DAY;g<date(last[i]);g+=DAY){
    var dw=new Date(g).getUTCDay();if(dw!==0&&dw!==6)return null;
   }
  }
 }
 var value=last.reduce(function(s,k){return s+all[k].KOSPI+all[k].KOSDAQ},0);
 if(!Number.isFinite(value)||Math.abs(value)>50000000)return null;
 return {id:'foreign20d',value:Math.round(value*1000)/1000,key:last[last.length-1],
  history:last.map(function(k){return {value:all[k].KOSPI+all[k].KOSDAQ,asOf:k.slice(0,4)+'-'+k.slice(4,6)+'-'+k.slice(6,8)+'T12:00:00Z'}})};
}
function flowCoverage(){var all=read(FLOWKEY)||{},rows=Object.keys(all).filter(function(d){return date(d)!==null&&all[d]&&all[d]._final_KOSPI===true&&all[d]._final_KOSDAQ===true&&num(all[d].KOSPI)!==null&&num(all[d].KOSDAQ)!==null}).sort();return {confirmedPairs:Math.min(rows.length,60),latest:rows.length?rows[rows.length-1]:'',needed:Math.max(0,20-rows.length)}}
function collectFlow(){var added=storeFlow(),o=computeForeign20(),coverage=flowCoverage(),status={version:'V262',confirmedPairs:coverage.confirmedPairs,needed:coverage.needed,latest:coverage.latest,eligible:!!o};save('NOONTANGI_V262_FOREIGN20_COVERAGE',status);return {stored:added,ready:!!o,coverage:status,published:o?ingest(o.id,o.value,o.key,o.key+' / KOSPI+KOSDAQ 최근 20거래일','기존 검증된 KOSPI·KOSDAQ 외국인 일별 순매수 원장 · 합계',o.history):0}}
function stripHtml(t){return String(t||'').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ').replace(/<[^>]*>/g,' ').replace(/&(?:reg|#174|nbsp);/gi,' ').replace(/&amp;/gi,'&').replace(/[®™]/g,' ').replace(/\s+/g,' ').trim()}
function parseIsm(html){var text=stripHtml(html);var h=/\b(September|October|November|December|January|February|March|April|May|June|July|August)\s+(20\d\d)\s+ISM\s+Manufacturing\s+PMI\s+Report/i.exec(text);if(!h)return null;var mi=MONTHS.indexOf(h[1].toLowerCase()),y=Number(h[2]),dateKey=String(y)+String(mi+1).padStart(2,'0')+'01';var target=new Date(Date.UTC(y,mi+1,1,12)).getTime()-DAY; // reporting month-end, not publication day
if(mi<0||target>Date.now()+DAY||Date.now()-target>70*DAY)return null;
var v=null;var p=/Manufacturing\s+PMI\s+(?:at|registered)\s+([0-9]{2}(?:\.[0-9])?)\s*(?:percent|%)/ig;var m;while((m=p.exec(text))!==null){var n=num(m[1]);if(n!==null&&n>=20&&n<=80){v=n;break}}if(v===null)return null;return {value:v,key:new Date(Date.UTC(y,mi+1,0,12)).toISOString().slice(0,10).replace(/-/g,''),period:String(y)+'-'+String(mi+1).padStart(2,'0')+' 월 / ISM 제조업',url:ISP+MONTHS[mi]+'/'}}
function collectIsm(){var now=new Date(),lastMonth=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth()-1,1));var m=MONTHS[lastMonth.getUTCMonth()],url=ISP+m+'/';return get(url).then(function(html){var x=parseIsm(html);if(!x)return {status:'unverified'};var n=ingest('ismPmi',x.value,x.key,x.period,'미국 ISM 공식 제조업 PMI 발표 · '+x.url,[]);return {status:n?'updated':'preserved',value:x.value}}).catch(function(){return {status:'unavailable'}})}
function validFinanceFeed(raw){var f=JSON.parse(raw);if(!f||f.schema!=='SNOWBALL_FINANCE_VERIFIED_V1'||f.publisher!=='SNOWBALL-APPROVED-SOURCES'||!f.generatedAt||!f.sources)return [];var t=Date.parse(f.generatedAt);if(!Number.isFinite(t)||t>Date.now()+DAY||Date.now()-t>3*DAY)return [];
var spec={customerDeposits:{id:'customerDeposits',code:'CUSTOMER_DEPOSITS',unit:'억원'},creditBalance:{id:'creditBalance',code:'CREDIT_LOANS_OUTSTANDING',unit:'억원'}},out=[];
Object.keys(spec).forEach(function(id){var s=f.sources[id],z=spec[id];if(!s||s.definition!==z.code||s.cycle!=='D'||s.unit!==z.unit||s.provider!=='금융위원회 금융투자협회종합통계정보'||s.licenseReviewed!==true)return;var d=String(s.latest||''),v=num(s.value),at=date(d);if(!at||v===null||v<=0||v>5000000||Date.now()-at>14*DAY||!Array.isArray(s.history)||s.history.length<2)return;
var hist=s.history.filter(function(row){return Array.isArray(row)&&row.length===2&&date(String(row[0]))!==null&&num(row[1])!==null&&num(row[1])>0}).sort(function(a,b){return String(a[0]).localeCompare(String(b[0]))});if(hist.length!==s.history.length||String(hist[hist.length-1][0])!==d||Math.abs(hist[hist.length-1][1]-v)>1e-7)return;out.push({id:id,value:v,key:d,period:d+' / 일별',source:'금융위원회 금융투자협회종합통계정보 · '+z.code+' · 일별',history:hist.slice(-36).map(function(p){var k=String(p[0]);return {value:p[1],asOf:k.slice(0,4)+'-'+k.slice(4,6)+'-'+k.slice(6,8)+'T12:00:00Z'}})})});return out}

/* V261 Finance extensions: the SAME approved finance.json request can carry
 * optional LICENSED daily series. Missing/unauthorized series stay unavailable;
 * the app never substitutes an indicator or manufactures a current reading.
 * A flag supplied by a feed is a publisher attestation, NOT legal permission;
 * publisher must retain documentary permission from each rights holder. */
function licenseOk(s,provider){
 return !!s&&s.provider===provider&&s.licenseReviewed===true&&
   s.publicRedistributionAuthorized===true&&typeof s.licenseEvidence==='string'&&
   /^https:\/\/[^\s]{12,220}$/.test(s.licenseEvidence)&&
   s.cycle==='D'&&date(String(s.latest||''))!==null;
}
function histAt(d,v){return {value:v,asOf:d.slice(0,4)+'-'+d.slice(4,6)+'-'+d.slice(6,8)+'T12:00:00Z'};}
function sourceRecent(s,maxAge){var d=date(String(s.latest||''));return d!==null&&d<=Date.now()+DAY&&Date.now()-d<=maxAge*DAY;}
function uniqueDailyPairs(rows,minCount,maxCount){
 if(!Array.isArray(rows)||rows.length<minCount||rows.length>maxCount)return null;
 var map={},last='';for(var i=0;i<rows.length;i++){
  var a=rows[i],d=a&&String(a[0]||''),t=date(d),v=a&&num(a[1]);
  if(!Array.isArray(a)||a.length!==2||t===null||v===null||d<=last)return null;
  last=d;map[d]=v;
 }return map;
}
// Credit ratio: FSC's whole-market credit-loan balance / KOSPI+KOSDAQ total market cap.
// Do NOT use deposits or a single-stock's credit balance ratio as a proxy.
function creditRatioExtension(s,base){
 if(!licenseOk(s,'금융위원회+한국거래소')||!sourceRecent(s,14)||
   s.definition!=='CREDIT_LOANS_TO_TOTAL_MARKET_CAP'||s.unit!=='%'||
   s.formula!=='100*CREDIT_LOANS_OUTSTANDING/(KOSPI_MKTCAP+KOSDAQ_MKTCAP)'||
   s.marketCapProvider!=='한국거래소 KRX'||!base||base.key!==s.latest||
   !Array.isArray(s.history)||s.history.length<2||s.history.length>45)return null;
 var value=null,h=[],prev='';
 for(var i=0;i<s.history.length;i++){
  var r=s.history[i],d=r&&String(r[0]||''),bal=r&&num(r[1]),kp=r&&num(r[2]),qd=r&&num(r[3]);
  if(!Array.isArray(r)||r.length!==4||!date(d)||d<=prev||bal===null||kp===null||qd===null||
     bal<=0||kp<=0||qd<=0||bal>5000000||kp+qd<bal*10)return null;
  if(d===s.latest&&Math.abs(bal-base.value)>0.015)return null;
  var n=100*bal/(kp+qd);if(!Number.isFinite(n)||n<=0||n>=10)return null;
  h.push(histAt(d,Math.round(n*1e6)/1e6));prev=d;
 }
 if(prev!==s.latest||Math.abs(h[h.length-1].value-num(s.value))>0.00001)return null;
 value=h[h.length-1].value;
 return {id:'creditRatio',key:s.latest,value:value,period:s.latest+' / 시총 대비',
  source:'금융위원회 신용융자잔고 / 한국거래소 KOSPI+KOSDAQ 시가총액 (%)',history:h.slice(-36)};
}
// Exact KOSPI+KOSDAQ combined foreign FLOW for official SAME 20 sessions.
function foreign20Extension(s){
 if(!licenseOk(s,'한국은행 ECOS')||!sourceRecent(s,12)||s.definition!=='KOSPI_KOSDAQ_FOREIGN_NETBUY_20D'||
   s.unit!=='억원'||s.table!=='802Y001'||!s.codes||
   s.codes.kospiIndex!=='0001000'||s.codes.kosdaqIndex!=='0089000'||
   s.codes.kospiForeign!=='0030000'||s.codes.kosdaqForeign!=='0113000'||
   !Array.isArray(s.tradingDates)||s.tradingDates.length!==20||
   !Array.isArray(s.history)||s.history.length!==20)return null;
 var sum=0,h=[],prior='';
 for(var i=0;i<20;i++){
  var d=String(s.tradingDates[i]||''),r=s.history[i];
  if(!date(d)||d<=prior||!Array.isArray(r)||r.length!==3||String(r[0])!==d)return null;
  var kp=num(r[1]),qd=num(r[2]);if(kp===null||qd===null||Math.abs(kp)>5000000||Math.abs(qd)>5000000)return null;
  sum+=kp+qd;prior=d;h.push(histAt(d,kp+qd));
 }
 if(prior!==s.latest||date(prior)-date(String(s.tradingDates[0]))>36*DAY||
   Math.abs(sum)>100000000||num(s.value)===null||Math.abs(sum-num(s.value))>0.015)return null;
 return {id:'foreign20d',key:s.latest,value:Math.round(sum*1000)/1000,
  period:s.latest+' / 양시장 20거래일',
  source:'한국은행 ECOS 802Y001 · KOSPI+KOSDAQ 외국인 순매수 20거래일 합산',history:h};
}
function vkospiExtension(s){
 if(!licenseOk(s,'한국거래소 KRX')||!sourceRecent(s,10)||
  s.definition!=='VKOSPI200_CLOSE'||s.unit!=='지수'||
  s.indexName!=='VKOSPI200'||!Array.isArray(s.history))return null;
 var m=uniqueDailyPairs(s.history,2,45);if(!m||!Object.prototype.hasOwnProperty.call(m,s.latest))return null;
 var dates=Object.keys(m),v=m[s.latest];if(dates[dates.length-1]!==s.latest||v<=0||v>200||
   Math.abs(v-num(s.value))>0.00001||dates.some(function(d){return m[d]<=0||m[d]>200}))return null;
 return {id:'vkospi',key:s.latest,value:v,period:s.latest+' / VKOSPI200',
  source:'한국거래소 KRX · VKOSPI200 공식 일별 종가',history:dates.slice(-36).map(function(d){return histAt(d,m[d])})};
}
function optionalFinance(f,base){
 var src=f&&f.sources||{},out=[];
 var validators=[['foreign20d',foreign20Extension],['creditRatio',function(s){return creditRatioExtension(s,base)}],['vkospi',vkospiExtension]];
 validators.forEach(function(entry){var x=entry[1](src[entry[0]]);if(x)out.push(x)});
 return out;
}
function validFinanceExtended(raw){
 var f;try{f=JSON.parse(raw)}catch(_){return []}
 if(!f||f.schema!=='SNOWBALL_FINANCE_VERIFIED_V1'||f.publisher!=='SNOWBALL-APPROVED-SOURCES'||
   !f.sources||!Number.isFinite(Date.parse(f.generatedAt))||
   Date.parse(f.generatedAt)>Date.now()+DAY||Date.now()-Date.parse(f.generatedAt)>3*DAY)return [];
 var existing=validFinanceFeed(raw),credit=existing.filter(function(x){return x.id==='creditBalance'})[0];
 return existing.concat(optionalFinance(f,credit));
}

var financeInFlight=null;
function collectFinance(){if(financeInFlight)return financeInFlight;financeInFlight=get(FINANCE_URL).then(function(raw){var records=validFinanceExtended(raw),n=0;records.forEach(function(x){n+=ingest(x.id,x.value,x.key,x.period,x.source,x.history)});return {status:records.length?'verified':'unavailable',verified:records.length,updated:n}}).catch(function(){return {status:'not-published',verified:0,updated:0}}).finally(function(){financeInFlight=null});return financeInFlight}
function refresh(force){var s=read(ID)||{},now=Date.now();var flow=collectFlow();if(busy)return Promise.resolve({status:'busy',flow:flow});if(!force&&now-Number(s.lastAttempt||0)<(s.success?8:2)*3600000)return Promise.resolve({status:'cached',flow:flow});busy=true;save(ID,{lastAttempt:now,success:false});return Promise.allSettled([collectIsm(),collectFinance()]).then(function(arr){var out={version:'V249',lastAttempt:Date.now(),flow:flow,ism:arr[0].status==='fulfilled'?arr[0].value:{status:'failed'},finance:arr[1].status==='fulfilled'?arr[1].value:{status:'failed'}};out.success=out.ism.status==='updated'||out.finance.updated>0||flow.published>0;save(ID,out);return out}).finally(function(){busy=false})}
/* V257: prefetch ONLY verified finance data when app initially loads, no Market tab entry needed.
 * Exactly one GET when it succeeds; up to two extra attempts after failure/partial feed.
 * No background activity when app is closed; on-focus and foreground periodic checks are throttled.
 * Original market-triggered ISM/flow collectors and already verified cache remain intact. */
var startupAttempts=0,startupFinished=false,startupInFlight=false,lastAutoFinance=0,retryTimer=null;
var AUTO_MIN_INTERVAL=30*60000;
function storeFinanceAuto(status,reason){save(STARTUP_STATUS,{version:'V257',attempts:startupAttempts,lastAttempt:new Date().toISOString(),reason:reason,status:status&&status.status||'unavailable',verified:Number(status&&status.verified||0)});}
function startupFinanceAttempt(){
 if(startupFinished||startupInFlight||startupAttempts>=3||root.document&&root.document.hidden)return;
 startupAttempts++;startupInFlight=true;lastAutoFinance=Date.now();
 collectFinance().then(function(result){
   startupInFlight=false;storeFinanceAuto(result,'app-launch');
   if(result.verified>=2){startupFinished=true;return;}
   if(startupAttempts>=3){startupFinished=true;return;}
   retryTimer=setTimeout(function(){retryTimer=null;startupFinanceAttempt()},startupAttempts===1?20000:60000);
 });
}
function periodicFinance(){
 if(!startupFinished){if(!retryTimer)startupFinanceAttempt();return;}
 if(root.document&&root.document.hidden)return;
 if(Date.now()-lastAutoFinance<AUTO_MIN_INTERVAL)return;
 lastAutoFinance=Date.now();collectFinance().then(function(result){storeFinanceAuto(result,'foreground-refresh')});
}
function bootFinance(){setTimeout(startupFinanceAttempt,1800);
  root.addEventListener('focus',periodicFinance);
  root.document.addEventListener('visibilitychange',function(){if(!root.document.hidden)periodicFinance()});
  setInterval(periodicFinance,30*60000);
}
function guideFinance(){var doc=root.document.querySelector('#nt1232Guide .nt-master-doc');if(!doc||doc.querySelector('#ntv257-finance-autofetch-guide'))return;var el=root.document.createElement('section');el.id='ntv257-finance-autofetch-guide';el.className='nt-master-v';el.innerHTML='<h3>V257 · 앱 실행 시 일별 금융자료 자동 수신</h3><p>눈탱이 앱을 실행하면 시장환경 메뉴를 누르지 않아도 금융위원회 고객예탁금·신용융자 잔고 2개를 공개 검증 피드에서 자동으로 확인한다. 성공 시 1회 조회하고 자료 부재·접속 실패 시에만 최대 2회 추가 시도한다. 마지막 정상 통계와 날짜를 보존하며 미확인 자료를 0으로 대체하지 않는다.</p><p>서버는 매일 오전 8시 10분(한국시간) 통계 갱신을 예약한다. 앱이 실행 중일 때만 30분 이상 지난 경우 다시 확인하며, 앱을 완전히 종료하면 별도의 백그라운드 수집을 하지 않는다. 인증키는 앱에 포함하지 않고, 기존 ECOS 15개·시장환경·계좌·뉴스·차트를 유지한다. GitHub 빌드 성공과 갤럭시 설치·재시작 시 실제 수신은 별도 확인이 필요하다.</p>';doc.prepend(el);if(!doc.querySelector('#ntv262-foreign20-guide')){var v262=root.document.createElement('section');v262.id='ntv262-foreign20-guide';v262.className='nt-master-v';v262.innerHTML='<h3>V262 · 외국인 20거래일 로컬 이력 수집 개선</h3><p>기존 네이버 KOSPI·KOSDAQ 수급 응답에서 검증된 장마감 자료와 응답에 실제 포함된 과거 거래일만 기기에 저장한다. 장중 잠정 수치는 보관하지 않으며, 시장정보가 도착한 직후 수급 원장을 갱신한다. 과거 20거래일이 없다면 데이터를 만들어 채우지 않는다. 과거 데이터 자체가 한 건만 오면 이력도 한 건으로 처리한다. 두 시장 20개 확정일과 실제 거래일 검증이 충족된 때에만 연결하고, 공개 권한이 없는 ECOS 4개 원천을 공개하지 않는다. 고객예탁금·신용융자 및 금융 5/8 기존 표시를 보존한다.</p>';doc.prepend(v262)}}
if(root.document){root.document.addEventListener('change',function(e){if(e.target&&e.target.id==='rMarket'&&e.target.checked){setTimeout(function(){refresh(false)},2300);setTimeout(collectFlow,11000)}},true);
 var boot=function(){var t=root.document.getElementById('rMarket');if(t&&t.checked)setTimeout(function(){refresh(false)},2600);bootFinance();guideFinance()};
 if(root.document.readyState==='loading')root.document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 root.document.addEventListener('click',function(e){if(e.target&&e.target.closest&&e.target.closest('#nt1232GuideOpen,[data-v1232-guide-open]'))setTimeout(guideFinance,0)},true);
}
root.NOONTANGI_BATCH_V249={refresh:refresh,collectFlow:collectFlow,computeForeign20:computeForeign20,parseIsm:parseIsm,validFinanceFeed:validFinanceFeed,validFinanceExtended:validFinanceExtended,refreshFinance:collectFinance,financeAutoState:function(){return read(STARTUP_STATUS)},version:'V262',flowCoverage:flowCoverage};
if(typeof module==='object'&&module.exports)module.exports=root.NOONTANGI_BATCH_V249;
})(typeof window!=='undefined'?window:globalThis);
