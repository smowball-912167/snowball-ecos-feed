/* V240: narrowly scoped OECD source integration for Korea CPI (YoY) and Korea CLI.
   Original indicator names, signs, 65/35 condition and existing menus unchanged.
   No fallback to price-chart proxies, unverified values, or invented scoring.
   Source: OECD SDMX Data Explorer, restricted endpoints whitelisted natively. */
(function(root){'use strict';
 var PREFIX='ntv240oecd_',STATE='NOONTANGI_V240_OECD_STATE',WAIT=23*3600000,RETRY=8*3600000;
 var CPI_URL='https://sdmx.oecd.org/public/rest/data/OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL,1.0/KOR.M.N.CPI.PA._T.N.GY?startPeriod=2025-01&dimensionAtObservation=AllDimensions&format=csvfile',CLI_URL='https://sdmx.oecd.org/public/rest/data/OECD.SDD.STES,DSD_STES@DF_CLI,4.1/KOR.M.LI...AA...H?startPeriod=2025-01&dimensionAtObservation=AllDimensions&format=csvfile';
 var waiting={},serial=0,busy=false;
 function n(v){if(v===null||v===undefined||String(v).trim()==='')return null;var x=Number(v);return isFinite(x)?x:null;}
 function state(){try{return JSON.parse(localStorage.getItem(STATE)||'{}')}catch(_){return {}}}
 function store(s){try{localStorage.setItem(STATE,JSON.stringify(s))}catch(_){}}
 function err(s){return new Error(String(s||'OECD 수신 오류').slice(0,180));}
 var prior=root.__SnowballNativeAsyncResolve;
 root.__SnowballNativeAsyncResolve=function(id,body){
  if(String(id||'').indexOf(PREFIX)!==0){if(typeof prior==='function')return prior(id,body);return;}
  var t=waiting[id];if(!t)return;delete waiting[id];clearTimeout(t.timer);
  if(!body||String(body).length>900000){t.reject(err('OECD 데이터 비어 있음·용량 초과'));return;}
  var s=String(body).trim();
  if(s[0]==='{'){try{var obj=JSON.parse(s);if(obj.error){t.reject(err(obj.error));return}}catch(_){}}
  if(s[0]==='<'||s[0]==='{'){t.reject(err('CSV 대신 XML/JSON 오류 응답'));return}
  t.resolve(s);
 };
 function get(url){return new Promise(function(resolve,reject){
  if(!(root.SnowballMarketData&&typeof root.SnowballMarketData.getAsync==='function'))return reject(err('기본 데이터 브리지 없음'));
  var id=PREFIX+(++serial)+'_'+Date.now();var timer=setTimeout(function(){if(waiting[id]){delete waiting[id];reject(err('OECD 수신 시간 초과'))}},27000);
  waiting[id]={resolve:resolve,reject:reject,timer:timer};
  try{root.SnowballMarketData.getAsync(url,id)}catch(e){clearTimeout(timer);delete waiting[id];reject(e)}
 });}
 // Quoted CSV reader: CRLF, escaped quotes and commas inside cells supported.
 function csv(text){text=String(text||'').replace(/^\uFEFF/,'');var rows=[],row=[],cell='',quoted=false;
  for(var i=0;i<text.length;i++){var c=text[i];if(c==='"'){
   if(quoted&&text[i+1]==='"'){cell+='"';i++}else quoted=!quoted;
  }else if(c===','&&!quoted){row.push(cell);cell='';}
  else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(function(z){return z.trim()!==''}))rows.push(row);row=[];cell='';}
  else cell+=c;
  }if(quoted)throw err('OECD CSV 따옴표 오류');row.push(cell);if(row.some(function(z){return z.trim()!==''}))rows.push(row);return rows;
 }
 function history(text,kind){var rows=csv(text);if(rows.length<2)throw err('OECD CSV 열이 없음');
  var h=rows[0].map(function(s){return s.trim().replace(/^\uFEFF/,'')}),columns={};h.forEach(function(s,i){columns[s]=i});
  ['REF_AREA','FREQ','TIME_PERIOD','OBS_VALUE'].forEach(function(key){if(columns[key]===undefined)throw err('OECD CSV 필수 열 누락 '+key)});
  function field(r,key){return columns[key]===undefined?'':String(r[columns[key]]||'').trim()}
  var pts={};rows.slice(1).forEach(function(r){if(r.length!==h.length||field(r,'REF_AREA')!=='KOR'||field(r,'FREQ')!=='M')return;
   if(kind==='cpi'){
    if(field(r,'MEASURE')!=='CPI'||field(r,'METHODOLOGY')!=='N'||field(r,'UNIT_MEASURE')!=='PA'||field(r,'EXPENDITURE')!=='_T'||field(r,'ADJUSTMENT')!=='N'||field(r,'TRANSFORMATION')!=='GY')return;
   }else{
    if(field(r,'MEASURE')!=='LI'||field(r,'ADJUSTMENT')!=='AA'||field(r,'METHODOLOGY')!=='H')return;
    if(columns.UNIT_MEASURE!==undefined&&field(r,'UNIT_MEASURE')!=='IX')return;
   }
   var date=field(r,'TIME_PERIOD'),value=n(field(r,'OBS_VALUE'));
   if(!/^20\d\d-(0[1-9]|1[0-2])$/.test(date)||value===null)return;
   if(kind==='cpi'&&(value< -20||value>40))return;
   if(kind==='cli'&&(value<50||value>150))return;
   pts[date]={date:date+'-01',value:value};
  });var out=Object.keys(pts).sort().map(function(x){return pts[x]});
  if(out.length<2)throw err('OECD 목표 한국 시계열 미확인');
  var last=out[out.length-1],age=Date.now()-Date.parse(last.date+'T12:00:00Z'),limit=kind==='cpi'?75:150;
  if(age< -86400000||age>limit*86400000)throw err('OECD 자료 최신성 조건 미충족');
  var source=kind==='cpi'?'OECD SDMX · 한국 CPI 전년동월 상승률':'OECD SDMX · 한국 CLI 진폭조정 지수';
  return [{id:kind==='cpi'?'krCpi':'oecdCli',value:Math.round(last.value*1000)/1000,asOf:last.date+'T12:00:00Z',period:last.date.slice(0,7)+(kind==='cpi'?' YoY':' CLI'),source:source,verified:true,
   history:out.slice(-24).map(function(x){return {value:x.value,asOf:x.date+'T12:00:00Z'}})}];
 }
 function refresh(force){if(busy)return Promise.resolve({status:'busy'});var old=state(),now=Date.now();
  if(!force&&now-Number(old.lastAttempt||0)<(old.success?WAIT:RETRY))return Promise.resolve({status:'cached'});
  if(!root.NOONTANGI_FOUR_FACTORS||typeof root.NOONTANGI_FOUR_FACTORS.ingest!=='function')return Promise.resolve({status:'not-ready'});
  busy=true;store({lastAttempt:now,success:false,stage:'한국 CPI·CLI 수집 중'});
  return Promise.allSettled([get(CPI_URL).then(function(x){return history(x,'cpi')}),get(CLI_URL).then(function(x){return history(x,'cli')})]).then(function(r){
   var good=[],errors=[];r.forEach(function(x){if(x.status==='fulfilled')good=good.concat(x.value);else errors.push(String(x.reason&&x.reason.message||x.reason).slice(0,130))});
   var count=good.length?root.NOONTANGI_FOUR_FACTORS.ingest(good):0;
   store({lastAttempt:now,success:count>0,lastSuccess:count?Date.now():old.lastSuccess||null,count:count,errors:errors,stage:count?'수신 완료':'미연결 · 원본 점검 필요'});
   return {status:count?'received':'failed',count:count,errors:errors};
  }).finally(function(){busy=false});
 }
 document.addEventListener('change',function(e){if(e.target&&e.target.id==='rMarket'&&e.target.checked)setTimeout(function(){refresh(false)},900)},true);
 root.NOONTANGI_OECD_COLLECTOR_V240={version:'V240',refresh:refresh,parse:history,csv:csv,state:state};
 if(typeof module==='object'&&module.exports)module.exports=root.NOONTANGI_OECD_COLLECTOR_V240;
})(typeof window!=='undefined'?window:globalThis);
