/* SNOWBALL V208: visible verification of feed freshness and one eligible recommendation.
 * Never fabricate a fresh article, price, recommendation, or investment-flow observation.
 * User approval required for watchlist and actual trading remains manual. */
(function(){'use strict';
var APP='V208',running={news:false,fire:false},lastShown={};
function byId(x){return document.getElementById(x)}
function bridge(){return !!(window.SnowballExternalInfo&&typeof window.SnowballExternalInfo.searchNews==='function')}
function modeOf(kind){var root=kind==='news'?byId('ntv190ArticleMonitor'):byId('ntv106Firemouth');
 var tabs=root&&root.querySelectorAll('[data-article-mode],[data-v190-article-mode],[data-v162-scope],[data-fire-scope],[data-fire-mode],[data-fm106-fire-tab]');
 if(tabs&&tabs.length){for(var i=0;i<tabs.length;i++){var t=tabs[i];if(!t.classList.contains('on')&&!t.classList.contains('active')&&t.getAttribute('aria-selected')!=='true')continue;var v=String(t.dataset.articleMode||t.dataset.v190ArticleMode||t.dataset.v162Scope||t.dataset.fireScope||t.dataset.fireMode||t.dataset.fm106FireTab||'');if(/global|GLOBAL/.test(v))return 'global';if(/domestic|KR/.test(v))return 'domestic'}}
 return 'domestic';
}
function api(kind){return kind==='news'?window.NOONTANGI_ARTICLE_MONITOR:window.NOONTANGI_FIRE_SERVICE}
function htmlesc(s){return String(s||'').replace(/[&<>"']/g,function(x){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[x]})}
function getStatus(kind){var service=api(kind),mode=modeOf(kind),data={};
 try{data=service&&service.status&&service.status()||{}}catch(e){}
 var row=data.statusByMode&&data.statusByMode[mode]||{},t=Number(data.lastSuccessByMode&&data.lastSuccessByMode[mode]||data.lastSuccess||data.lastRun||0),count=0;
 try{var res=service&&service.list&&service.list(mode);count=Array.isArray(res)?res.length:0}catch(e){}
 var age=t?Math.max(0,(Date.now()-t)/3600000):Infinity;
 var when=t?new Date(t).toLocaleString('ko-KR',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}):'확인기록 없음';
 var state=!bridge()?'검색 연결 없음':count===0?'검증 완료 목록 없음':age>24?'오래된 목록':age>4?'재확인 필요':'저장 목록';if(row.state==='fail')state='최근 검색 실패 · '+state;
 return {mode:mode,count:count,at:t,when:when,state:state,age:age,bridge:bridge(),details:row&&row.state||'',reason:String(row.errorSummary||data.errorSummary||'').slice(0,100)};
}
function surface(kind){var base=kind==='news'?byId('ntv190ArticleMonitor'):byId('ntv106Firemouth');if(!base)return null;
 var dest=kind==='news'?base.querySelector('.v190-art-shell'):base.querySelector('.fm107-recent-card');if(!dest)return null;
 var id='ntv208-status-'+kind,bar=byId(id);
 if(!bar){bar=document.createElement('div');bar.id=id;bar.className='ntv208-refresh-state';bar.setAttribute('role','status');bar.setAttribute('aria-live','polite');bar.innerHTML='<span data-v208-status-text></span><button type="button" data-v208-refresh="'+kind+'">지금 재확인</button>';
 var first=dest.querySelector('.v152-fire-status');if(first)first.insertAdjacentElement('afterend',bar);else dest.insertBefore(bar,dest.firstChild)}return bar;
}
function render(kind){var bar=surface(kind),st=getStatus(kind);if(!bar)return st;
 var el=bar.querySelector('[data-v208-status-text]');var msg=(kind==='news'?'주요뉴스':'불주댕이')+' · '+(st.mode==='global'?'글로벌':'국내')+' · 확인 '+st.count+'건 · '+st.when+' · '+st.state;
 if(st.reason)msg+=' ('+st.reason+')';if(running[kind])msg+=' · 재확인 중';
 if(el&&el.textContent!==msg)el.textContent=msg;
 var btn=bar.querySelector('[data-v208-refresh]');if(btn){btn.disabled=!!running[kind];btn.title='원문검증 후 목록이 준비됩니다. 갱신 성공을 보장하지 않습니다.'}
 return st;
}
function manualRefresh(kind){if(running[kind])return Promise.resolve(false);var st=getStatus(kind),service=api(kind);if(!st.bridge||!service||typeof service.refresh!=='function'){render(kind);return Promise.resolve(false)}
 running[kind]=true;render(kind);
 return Promise.resolve().then(function(){return service.refresh(st.mode,'v208-visible-user-recheck')}).then(function(x){return x},function(){return false}).finally(function(){running[kind]=false;render(kind)})
}
function aiBanner(){var list=document.querySelector('.photo3-picker-list'),modal=list&&list.closest('.photo3-picker-backdrop');if(!list||!modal)return;
 var ai=modal.querySelector('[data-photo3-tab="ai"].on,[data-photo3-tab="ai"].active,[data-photo3-tab="ai"][aria-selected="true"]');
 // Some older tabs use a parent CSS-class owner, but AI list empty text is definitive.
 if(!ai&&!/자동추천|AI추천|추천 후보/.test(list.textContent||''))return;
 var container=list.parentElement,el=container&&container.querySelector('.ntv208-ai-proof');if(!container)return;
 if(!el){el=document.createElement('div');el.className='ntv208-ai-proof';container.insertBefore(el,list)}
 var picks=[];try{picks=window.NOONTANGI_V200_AI&&window.NOONTANGI_V200_AI.list()||[]}catch(e){}
 var head='AI추천 1종목 우선 검증 · '+Math.min(1,picks.length)+'건';
 var tail=picks.length?' · '+picks[0].name+' ('+picks[0].code+') · 근거를 눌러 출처 및 누적수급을 확인하세요. 관심 등록은 직접 별표로 선택합니다.':' · 검증 근거를 충족한 후보가 없습니다. 실제 자료 없이 추천종목을 생성하지 않습니다.';
 var msg=head+tail;if(el.textContent!==msg)el.textContent=msg;
}
function refreshAll(){render('news');render('fire');aiBanner()}
function boot(){refreshAll();document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-v208-refresh]');if(b){e.preventDefault();e.stopPropagation();manualRefresh(b.getAttribute('data-v208-refresh'));return}
 if(e.target.closest&&e.target.closest('[data-photo3-tab="ai"],.photo3-picker-row,[data-v190-article-open],[data-v106-firemouth-open]'))setTimeout(refreshAll,100)},true);
 document.addEventListener('change',function(e){if(e.target&&e.target.closest&&e.target.closest('#ntv190ArticleMonitor,#ntv106Firemouth'))setTimeout(refreshAll,90)},true);
 window.addEventListener('ntv199-stocks-updated',function(){setTimeout(aiBanner,50)});
 window.addEventListener('ntv207-accum-updated',function(){setTimeout(aiBanner,50)});
 setInterval(function(){if(document.visibilityState==='hidden')return;var n=byId('ntv190ArticleMonitor'),f=byId('ntv106Firemouth'),p=document.querySelector('.photo3-picker-backdrop');if(n&&n.classList.contains('open')||f&&f.classList.contains('open')||p)refreshAll()},12000);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
window.NOONTANGI_V208_QA={getStatus:getStatus,render:render,manualRefresh:manualRefresh,refreshAll:refreshAll,version:APP};
})();
