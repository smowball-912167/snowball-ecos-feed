/* SNOWBALL V207 — verified price / investor flow divergence watcher.
   Independent diagnostic, never a claim of proven manipulation/secret positions.
   No orders, no automatic watch-list registration, no synthetic historical data. */
(function(){'use strict';
var KEY='ntv207_accumulation_snapshots_v1',CSV='snowball_v139_krx_flow_',CSV_META='snowball_v139_krx_flow_meta_';
var WINDOWS=[20,60,120,250,750];
function num(v){var n=Number(v);return isFinite(n)?n:NaN}
function read(k,def){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?def:v}catch(_e){return def}}
function dateKey(t){var d=new Date(Number(t));return isFinite(d.getTime())?[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'):''}
function fmt(n){return Math.round(n||0).toLocaleString('ko-KR')}
function pct(n){return (n>=0?'+':'')+n.toFixed(1)+'%'}
function uniq(rows){var map=Object.create(null);(Array.isArray(rows)?rows:[]).forEach(function(r){var t=num(r&&r.time),k=dateKey(t);if(k)map[k]=r});return Object.keys(map).sort().map(function(k){return Object.assign({day:k},map[k])})}
function validatedPrice(rows){return uniq(rows).filter(function(r){return num(r.close)>0&&num(r.volume)>0&&num(r.time)>0}).map(function(r){return {day:r.day,time:num(r.time),close:num(r.close),volume:num(r.volume)}})}
function validatedFlow(rows){return uniq(rows).filter(function(r){return num(r.time)>0&&isFinite(num(r.foreign))&&isFinite(num(r.inst))}).map(function(r){return {day:r.day,time:num(r.time),foreign:num(r.foreign),inst:num(r.inst),person:isFinite(num(r.person))?num(r.person):null}})}
function sum(rows,k){return rows.reduce(function(n,r){return n+num(r[k])},0)}
function obvDelta(rows){var obv=0;for(var i=1;i<rows.length;i++){if(rows[i].close>rows[i-1].close)obv+=rows[i].volume;else if(rows[i].close<rows[i-1].close)obv-=rows[i].volume}return obv}
function stageFor(prices,flows,days){
 var p=prices.slice(-days),fst=p[0]&&p[0].day;
 if(!fst||p.length<Math.max(18,Math.ceil(days*.80)))return null;
 var fm={};flows.forEach(function(f){fm[f.day]=f});
 var paired=p.filter(function(r){return !!fm[r.day]});
 // Do not estimate missing investor trades as zero; don't label a period without sufficient coverage.
 if(paired.length<Math.max(18,Math.ceil(days*.80))||paired.length/p.length<.82)return null;
 var f=paired.map(function(r){return fm[r.day]}),foreign=sum(f,'foreign'),inst=sum(f,'inst'),combined=foreign+inst;
 var start=paired[0],end=paired[paired.length-1],pricePct=(end.close/start.close-1)*100;
 var closes=paired.map(function(x){return x.close}),rangePct=(Math.max.apply(null,closes)/Math.min.apply(null,closes)-1)*100;
 var volume=sum(p,'volume'),buyerRate=volume>0?combined/volume:0,positiveDays=f.filter(function(x){return x.foreign+x.inst>0}).length;
 var q=Math.floor(f.length/4),quarterPositive=0;
 for(var j=0;j<4;j++){var part=f.slice(j*q,j===3?f.length:(j+1)*q);var partSum=part.reduce(function(z,x){return z+x.foreign+x.inst},0);if(partSum>0)quarterPositive++}
 var obv=obvDelta(p),meanVol=NaN;if(p.length>=25){var tail=p.slice(-5),base=p.slice(-25,-5);meanVol=(sum(tail,'volume')/5)/(sum(base,'volume')/20)}
 var sideways=pricePct<=7&&pricePct>=-15&&rangePct<=25;
 var divergence=sideways&&combined>0&&buyerRate>=.005;
 var gradual=quarterPositive>=3&&positiveDays/f.length>=.48;
 var obvRise=obv>0;
 var quietVolume=isFinite(meanVol)&&meanVol<=.8;
 var score=(divergence?2:0)+(gradual?2:0)+(obvRise?1:0)+(quietVolume?1:0)+(foreign>0&&inst>0?1:0);
 var status=divergence&&gradual&&score>=5?'매집 의심':divergence&&score>=3?'수급 누적 관찰':'매집 판정 보류';
 return {tradingDays:paired.length,requestedDays:days,start:start.day,end:end.day,foreign:foreign,inst:inst,combined:combined,priceStart:start.close,priceEnd:end.close,pricePct:pricePct,rangePct:rangePct,buyerRate:buyerRate,positiveDays:positiveDays,quarterPositive:quarterPositive,obvDirection:obv>0?'상승':obv<0?'하락':'변화 없음',volume5vs20:isFinite(meanVol)?meanVol:null,divergence:divergence,gradual:gradual,score:score,status:status};
}
function analyze(input){
 input=input||{};var code=String(input.code||'').trim();if(!/^\d{6}$/.test(code))return {ok:false,reason:'국내 종목코드 확인 필요'};
 if(input.periodType&&String(input.periodType)!=='일봉')return {ok:false,code:code,reason:'일봉 가격자료가 필요합니다'};
 var prices=validatedPrice(input.prices),flows=validatedFlow(input.flows);
 if(prices.length<20||flows.length<18)return {ok:false,code:code,reason:'일봉 가격 또는 외국인·기관 실제 순매수 자료 부족',priceRows:prices.length,flowRows:flows.length};
 var options=[];WINDOWS.forEach(function(n){var a=stageFor(prices,flows,n);if(a)options.push(a)});
 if(!options.length)return {ok:false,code:code,reason:'같은 거래일의 가격·수급 자료 부족',priceRows:prices.length,flowRows:flows.length};
 // Prefer sustained (60d+) findings; short 20d reading is only an early observation.
 var confirmed=options.filter(function(x){return x.status==='매집 의심'}).sort(function(a,b){return b.tradingDays-a.tradingDays});
 var watched=options.filter(function(x){return x.status==='수급 누적 관찰'}).sort(function(a,b){return b.score-a.score||b.tradingDays-a.tradingDays});
 var best=confirmed[0]||watched[0]||options.slice().sort(function(a,b){return b.tradingDays-a.tradingDays})[0];
 var observed=Date.parse(best.end+'T00:00:00'),ageDays=(Date.now()-observed)/86400000,stale=ageDays>12;
 if(stale){best=Object.assign({},best,{status:'자료 갱신 필요'})}
 else if(best.requestedDays===20&&best.status==='매집 의심'){best=Object.assign({},best,{status:'초기 매집 의심(20거래일)'})}
 return {ok:true,code:code,name:String(input.name||code),source:String(input.source||'자료출처 미확인'),sourceAt:input.sourceAt||null,priceRows:prices.length,flowRows:flows.length,asOf:best.end,stale:stale,periods:options,best:best,generatedAt:new Date().toISOString(),
 note:'외국인·기관 일별 순매수 누계는 보유잔고나 동일 투자주체의 매집 확증이 아닙니다. OBV는 가격·거래량 지표이며 외국인/기관 순매수로 오인하면 안 됩니다. 거래원 창구·프로그램매매도 최종 매수주체의 직접 증거가 아닙니다.'};
}
function loadMap(){var r=read(KEY,{});return r&&typeof r==='object'&&!Array.isArray(r)?r:{}}
function get(code){var v=loadMap()[String(code||'')];if(!v||!v.ok)return null;var age=(Date.now()-Date.parse(v.generatedAt))/86400000;if(age>45)return null;var flowAge=(Date.now()-Date.parse(String(v.asOf||'')+'T00:00:00'))/86400000;if(flowAge>12&&!v.stale){v=Object.assign({},v,{stale:true,best:Object.assign({},v.best,{status:'자료 갱신 필요'})})}return v}
function save(result){if(!result||!result.ok)return false;var m=loadMap(),old=m[result.code],n=result.best;
 var sig=[result.asOf,n.tradingDays,n.foreign,n.inst,n.pricePct,n.status,result.source].join('|');if(old&&old.signature===sig)return false;
 result.signature=sig;m[result.code]=result;var keys=Object.keys(m).sort(function(a,b){return Date.parse(m[b].generatedAt||0)-Date.parse(m[a].generatedAt||0)});
 keys.slice(100).forEach(function(x){delete m[x]});try{localStorage.setItem(KEY,JSON.stringify(m))}catch(_e){return false}
 if(typeof window.dispatchEvent==='function'){try{window.dispatchEvent(new Event('ntv207-accum-updated'))}catch(_e){}}
 return true}
function capture(){try{
 var st=window.__SNOWBALL_V60_STATE,stockFn=window.__SNOWBALL_V60_STOCK,c=typeof stockFn==='function'?stockFn():null;
 if(!st||!c||!/^\d{6}$/.test(String(c.code||''))||!Array.isArray(st.rows)||!Array.isArray(st.flows)||st.tf!=='일봉')return false;
 var csv=read(CSV+String(c.code),[]),meta=read(CSV_META+String(c.code),null),flows=(Array.isArray(csv)&&csv.length>st.flows.length)?csv:st.flows,src=flows===csv?'KRX CSV 원천':st.flowProvider||'저장 수급';
 var result=analyze({code:c.code,name:c.name,prices:st.rows,flows:flows,source:src,sourceAt:meta&&meta.importedAt,periodType:'일봉'});
 return save(result);
 }catch(_e){return false}}
function describe(r){if(!r||!r.ok)return '외국인·기관 장기 수급은 아직 확인되지 않았습니다.';
 var b=r.best,kind=(b.status==='매집 의심'||b.status.indexOf('초기 매집 의심')===0)?'가격-수급 다이버전스 · 매집 의심':b.status;
 return kind+' ('+b.start+' ~ '+b.end+', '+b.tradingDays+'거래일)\n'+
 '외국인 누적 순매수 '+fmt(b.foreign)+'주 / 기관 '+fmt(b.inst)+'주 / 합계 '+fmt(b.combined)+'주\n'+
 '같은 기간 종가 '+fmt(b.priceStart)+'원 → '+fmt(b.priceEnd)+'원 ('+pct(b.pricePct)+'), 가격 변동범위 '+b.rangePct.toFixed(1)+'%\n'+
 '분석기간 OBV 방향 '+b.obvDirection+' · 실제 자료 '+r.source+' ('+r.asOf+')\n'+
 (r.stale?'※ 최근 자료가 아닙니다. 현재 매집 중이라는 표현을 사용하지 않습니다.\n':'')+
 '※ 순매수는 보유주식 증가나 은밀한 가격 조작의 확증이 아닙니다. 사업·재무·희석 위험을 함께 검증해야 합니다.'}
function shortReason(r){if(!r||!r.ok)return '';
 var b=r.best;
 if(r.stale)return '외국인·기관 수급: 과거 자료('+r.asOf+')이며 재확인이 필요합니다.';
 if(b.status==='매집 의심'||b.status.indexOf('초기 매집 의심')===0){return '추가 관찰 근거: '+b.start+'~'+b.end+' ('+b.tradingDays+'거래일) 동안 주가 '+pct(b.pricePct)+'로 횡보/약세인 반면 외국인 '+fmt(b.foreign)+'주·기관 '+fmt(b.inst)+'주 순매수(합계 '+fmt(b.combined)+'주)가 누적돼 가격-수급 다이버전스에 따른 매집 의심 신호가 나타났습니다. 실제 보유 증가나 세력 개입의 확증은 아닙니다.'}
 if(b.status==='수급 누적 관찰')return '수급 보조근거: '+b.start+'~'+b.end+' ('+b.tradingDays+'거래일) 외국인·기관 합산 순매수 '+fmt(b.combined)+'주, 주가 '+pct(b.pricePct)+'; 지속성 추가 확인이 필요합니다.';
 return ''}
window.NOONTANGI_V207_ACCUMULATION={analyze:analyze,capture:capture,get:get,save:save,describe:describe,shortReason:shortReason,storageKey:KEY};
window.addEventListener('snowball-krx-imported',function(){setTimeout(capture,500)});
window.addEventListener('pageshow',function(){setTimeout(capture,600)});
// Capture only when real chart/flow rows are available; no broad whole-market scanning is claimed.
if(typeof document!=='undefined')document.addEventListener('change',function(e){if(e.target&&e.target.closest&&e.target.closest('#pageShort'))setTimeout(capture,1200)},true);
if(typeof document!=='undefined')document.addEventListener('click',function(e){if(e.target&&e.target.closest&&e.target.closest('.photo3-picker-row,[data-photo3-pick]'))setTimeout(capture,1500)},true);
if(typeof document!=='undefined'&&typeof setInterval==='function')setInterval(function(){if(document.visibilityState!=='hidden'&&document.getElementById('rShort')&&document.getElementById('rShort').checked)capture()},60000);
})();
