/* 눈탱이 V226: 20개 기자 취재분야 / 테마별 베테랑 기자. 후보는 필자 확인 전까지 기사로 승격하지 않는다. */
(function(){'use strict';
var DB=window.NTV226_VETERAN_ROSTER;if(!DB||!Array.isArray(DB.roster))return;
var CACHE='ntv226-veteran-byline-confirmed-v2', LEGACY='ntv226-veteran-byline-confirmed-v1', CHECK='ntv226-veteran-checks-v1';
function load(key,alt){try{var v=JSON.parse(localStorage.getItem(key)||'null');return v===null?alt:v;}catch(e){return alt;}}
var records=load(CACHE,null),checks=load(CHECK,{});
if(!records||typeof records!=='object'){
 // Preserve verified veteran evidence from V226, but NEVER keep its menu-derived themeIds.
 var legacy=load(LEGACY,{});records={};Object.keys(legacy||{}).forEach(function(k){if(Array.isArray(legacy[k]))records[k]=legacy[k].filter(function(e){return e&&e.verified;}).map(function(e){return Object.assign({},e,{themeIds:[],reclassifyNeeded:true});});});
}
if(!checks||typeof checks!=='object')checks={};
function persist(){try{localStorage.setItem(CACHE,JSON.stringify(records));localStorage.setItem(CHECK,JSON.stringify(checks));}catch(e){}}
var theme=0,group=0,lane='KR',panel=null,busy={},pending={},sequence=0,queue=[],activeJobs=0;
function make(tag,cls,txt){var e=document.createElement(tag);if(cls)e.className=cls;if(txt!==undefined)e.textContent=txt;return e;}
function clean(x){return String(x||'').replace(/\s+/g,' ').trim();}
function dateStr(s){var d=new Date(s||'');return isNaN(d.getTime())?'':d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
function safeUrl(u){return /^https:\/\//i.test(String(u||''));}
function reporterFor(id){var s=String(id).split('-'),g=DB.roster[Number(s[0])-1];if(!g)return null;var r=s[1]==='GLOBAL'?g.global:g.domestic;var p=r[Number(s[2])-1];return p&&!p.disabled?p:null;}
function bylineMatch(byline,person){if(!byline||!person)return false;var found=clean(byline).toLowerCase();if(!found)return false;
 return person.aliases.some(function(a){var name=clean(a).toLowerCase();if(name.length<2||/라인|취재팀|특파원팀/.test(name))return false;
 var text=found.replace(/[\[\](),;|]/g,' ');var pos=text.indexOf(name);
 while(pos!==-1){var left=text.charAt(pos-1),right=text.charAt(pos+name.length),isKo=/[가-힣]/.test(name);
 if(isKo?(!/[가-힣]/.test(left)&&!/[가-힣]/.test(right)):(!/[a-z]/.test(left)&&!/[a-z]/.test(right)))return true;
 pos=text.indexOf(name,pos+name.length);}return false;});}
function canonicalUrl(s){try{var u=new URL(String(s||''));u.hash='';Array.from(u.searchParams.keys()).forEach(function(k){if(/^(utm_|fbclid|gclid|igshid|ref$|source$)/i.test(k))u.searchParams.delete(k);});return u.toString();}catch(e){return String(s||'');}}
function allVeteranArticles(){var seen={},result=[];Object.keys(records).forEach(function(id){if(!reporterFor(id))return;(records[id]||[]).forEach(function(e){if(!e||!e.verified||!safeUrl(e.url))return;var key=canonicalUrl(e.url);if(!seen[key]){seen[key]=e;result.push(e);}else if(!seen[key].themeIds?.length && e.themeIds?.length){var at=result.indexOf(seen[key]);if(at>=0)result[at]=e;seen[key]=e;}});});result.sort(function(a,b){return String(b.date||'').localeCompare(String(a.date||''));});return result;}
function relatedArticles(id){return allVeteranArticles().filter(function(e){return Array.isArray(e.themeIds)&&e.themeIds.indexOf(Number(id))>=0;});}
function hash(s){var h=2166136261;for(var i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(36);}
function native(method,args,limit){return new Promise(function(resolve){var n=window.SnowballExternalInfo;if(!n||typeof n[method]!=='function'){resolve({error:'기기 뉴스 수집 기능 없음'});return;}
 var owner=window.NOONTANGI_EXTERNAL_INFO=window.NOONTANGI_EXTERNAL_INFO||{},id='ntv226_'+(++sequence)+'_'+Date.now();
 if(!owner.__v226Bridge){var prev=owner.resolve;owner.resolve=function(key,json){if(String(key||'').indexOf('ntv226_')===0){var job=pending[key];if(!job)return false;delete pending[key];clearTimeout(job.timer);try{job.resolve(JSON.parse(String(json||'{}')));}catch(e){job.resolve({error:'서버 응답 해석 실패'});}return true;}return typeof prev==='function'?prev(key,json):false;};owner.__v226Bridge=true;}
 var timer=setTimeout(function(){if(!pending[id])return;delete pending[id];resolve({error:'요청 제한시간 초과'});},limit||12500);pending[id]={timer:timer,resolve:resolve};
 try{n[method].apply(n,(args||[]).concat(id));}catch(e){clearTimeout(timer);delete pending[id];resolve({error:'기기 호출 실패'});}
 });}
function queryOf(p){var n=(p.aliases||[])[0];if(!n||/라인|취재팀|특파원팀/.test(n))return '';
 // Indexed author names are only discovery hints, NEVER evidence of authorship.
 return (p.region==='GLOBAL'?'__GLOBAL__':'')+'"'+n+'" when:365d';}
function runJob(fn){return new Promise(function(resolve){queue.push({fn:fn,resolve:resolve});pump();});}
function pump(){while(activeJobs<2&&queue.length){var job=queue.shift();activeJobs++;Promise.resolve().then(job.fn).then(job.resolve,function(){job.resolve(false);}).finally(function(){activeJobs--;pump();});}}
function initialData(p){return Array.isArray(records[p.id])?records[p.id]:[];}
function evidenceState(p){if(busy[p.id])return '필자 확인 중';var t=checks[p.id];if(!t)return '기사 확인 전';var count=initialData(p).length;if(count)return '확인된 기사 '+count+'건';return t.error?'수집 실패 · 재시도 가능':'필자 확인 기사 없음';}
function seed(e,res,koSummary){var a=window.NTV211_THEME_ARTICLE;if(a&&typeof a.seedVerified==='function')a.seedVerified(e,res,koSummary);if(a&&e.titleKo&&typeof a.seedKoreanTitle==='function')a.seedKoreanTitle(e,e.titleKo);}
function firstParagraph(body){var parts=String(body||'').split(/(?<=[.!?。！？])\s+/).map(clean).filter(function(x){return x.length>30;});return parts.slice(0,5).join(' ').slice(0,1200)||clean(body).slice(0,850);}
function toKorean(summary){if(/[가-힣]/.test(summary))return Promise.resolve(summary);return native('translateKorean',[summary.slice(0,1700)],8500).then(function(r){var ko=clean(r.translated);return /[가-힣]/.test(ko)?ko:'';});}
function checkPerson(p,force){var prev=checks[p.id];if(!force&&prev&&Date.now()-Number(prev.at||0)<12*3600*1000 && !initialData(p).some(function(e){return e.reclassifyNeeded;}))return Promise.resolve();if(busy[p.id])return busy[p.id];
 var query=queryOf(p);if(!query){checks[p.id]={at:Date.now(),error:'개인 필자명 없음'};persist();paint();return Promise.resolve();}
 busy[p.id]=runJob(function(){return native('searchNews',[query],13500).then(function(data){if(!data||data.error||data.fallbackUsed||!Array.isArray(data.items))throw Error(clean(data&&data.error)||'기자검색 결과 없음');
 var candidates=data.items.filter(function(it){return safeUrl(it.link||it.url)&&clean(it.title);}).slice(0,10);
 var flow=Promise.resolve([]);candidates.forEach(function(it){flow=flow.then(function(found){if(found.length>=3)return found;return native('fetchArticleSmart',[String(it.link||it.url),clean(it.title),''],19500).then(function(r){
 // Only primary article byline evidence may admit a candidate.
 if(!r||!r.trustedBody||!bylineMatch(r.author,p)||!clean(r.articleText)||clean(r.articleText).length<170)return found;
 var url=clean(r.finalUrl)||String(it.link||it.url);if(!safeUrl(url))return found;
 var date=dateStr(it.pubDate),classification=window.NTV226_VETERAN_THEME_CLASSIFIER&&window.NTV226_VETERAN_THEME_CLASSIFIER.classify(clean(it.title),r.articleText);
 if(!classification)return found;
 var entry={title:clean(it.title),publisher:clean(it.source)||p.outlet,date:date,
 themeIds:classification.themeIds,classificationEvidence:classification.evidence,
 classificationMethod:classification.method,region:[p.region],url:url,index:'v226_'+hash(canonicalUrl(url)),type:'article',author:clean(r.author),reporterId:p.id,verified:true,verifiedAt:Date.now()};
 return Promise.all([toKorean(firstParagraph(r.articleText)),toKorean(entry.title)]).then(function(values){
 var ko=values[0],titleKo=values[1];if(titleKo&&/[가-힣]/.test(titleKo))entry.titleKo=titleKo;
 if(ko){seed(entry,r,ko);entry.summaryReady=true;}else entry.summaryReady=false;
 found.push(entry);return found;});
 });});});return flow;}).then(function(list){var merged=initialData(p).concat(list).filter(function(it){return it&&it.verified&&safeUrl(it.url);});var seen={},unique=[];merged.sort(function(a,b){return String(b.date).localeCompare(String(a.date));}).forEach(function(it){var key=canonicalUrl(it.url);if(!seen[key] || (seen[key].reclassifyNeeded && !it.reclassifyNeeded)){if(seen[key])unique.splice(unique.indexOf(seen[key]),1);unique.push(it);seen[key]=it;}});records[p.id]=unique.slice(0,40);checks[p.id]={at:Date.now(),error:''};persist();}).catch(function(err){checks[p.id]={at:Date.now(),error:String(err&&err.message||'검색 실패')};persist();});}).finally(function(){delete busy[p.id];paint();try{window.dispatchEvent(new CustomEvent('ntv226-veteran-updated',{detail:{theme:theme,group:group}}));}catch(_){}});paint();return busy[p.id];}
function beginLane(force){var g=DB.roster[group-1];if(!g)return Promise.resolve([]);var people=lane==='GLOBAL'?g.global:g.domestic;var jobs=people.filter(function(p){return !p.disabled;}).map(function(p){return checkPerson(p,!!force);});paint();return Promise.all(jobs);}
function renderArticle(e,parent){var el=make('div','vr226-article');var button=make('button','vr226-title',e.titleKo||e.title);button.type='button';button.addEventListener('click',function(){var service=window.NTV211_THEME_ARTICLE;if(service&&service.open)service.open(e);else if(safeUrl(e.url))window.open(e.url,'_blank');});el.appendChild(button);
 el.appendChild(make('div','vr226-meta',[e.author,e.publisher,e.date||'날짜 미확인',e.summaryReady?'한 문단 요약 준비됨':'원문 확인 · 한글 요약 대기'].join(' · ')));
 var tags=make('div','vr226-tags');(e.themeIds||[]).forEach(function(id){var labels=window.NTV226_VETERAN_THEME_CLASSIFIER&&window.NTV226_VETERAN_THEME_CLASSIFIER.labels||{};tags.appendChild(make('span','vr226-tag',labels[id]||('테마 '+id)));});if(!e.themeIds||!e.themeIds.length)tags.appendChild(make('span','vr226-tag vr226-unclassified',e.reclassifyNeeded?'본문 재분류 대기':'테마 미분류 · 기사 보관'));el.appendChild(tags);parent.appendChild(el);}
function paint(){if(!panel||!panel.isConnected||!group)return;var selected=DB.roster[group-1];if(!selected)return;
 panel.textContent='';var head=make('div','vr226-head');head.appendChild(make('h3','', '베테랑'));head.appendChild(make('p','','검증된 기자가 직접 작성한 기사를 별도 보관하고, 실제 기사 내용을 기준으로 여러 성장테마에 연결합니다. 기자의 담당 분야만으로 분류하지 않습니다.'));panel.appendChild(head);
 var labels=window.NTV226_VETERAN_THEME_CLASSIFIER&&window.NTV226_VETERAN_THEME_CLASSIFIER.labels||{};
 var related=relatedArticles(theme),summary=make('section','vr226-related');summary.appendChild(make('h4','','이 테마 관련 기사 · '+related.length+'건'));
 summary.appendChild(make('p','','선택 테마: '+(labels[theme]||'성장테마')+' · 국내/글로벌 기자 전체에서 실제 내용이 연결된 기사 · 하나의 기사는 여러 테마에 표시될 수 있습니다.'));
 if(related.length)related.slice(0,50).forEach(function(e){renderArticle(e,summary);});else summary.appendChild(make('p','vr226-empty','아직 내용과 필자가 확인된 관련 기사가 없습니다. 기자별 새로확인을 통해 자료를 쌓습니다.'));panel.appendChild(summary);
 var unclassified=allVeteranArticles().filter(function(e){return !e.themeIds||!e.themeIds.length;});if(unclassified.length){var shelf=make('details','vr226-shelf');shelf.appendChild(make('summary','', '미분류 보관 기사 '+unclassified.length+'건 (삭제하지 않음)'));unclassified.slice(0,20).forEach(function(e){renderArticle(e,shelf);});panel.appendChild(shelf);}
 var select=make('select','vr226-select');select.setAttribute('aria-label','기자 전문 취재 분야');DB.roster.forEach(function(g){var op=make('option','',g.id+'. '+g.name);op.value=g.id;op.selected=g.id===group;select.appendChild(op);});select.addEventListener('change',function(){group=Number(select.value);lane='KR';paint();beginLane(false);});panel.appendChild(select);
 var tabs=make('div','vr226-tabs');[['KR','국내 기자'],['GLOBAL','글로벌 기자']].forEach(function(t){var b=make('button','vr226-tab',t[1]);b.type='button';b.setAttribute('aria-pressed',String(lane===t[0]));b.addEventListener('click',function(){lane=t[0];paint();beginLane(false);});tabs.appendChild(b);});panel.appendChild(tabs);
 var people=(lane==='GLOBAL'?selected.global:selected.domestic).filter(function(p){return !p.disabled;});
 var line=make('div','vr226-toolbar');line.appendChild(make('span','','아래 후보 기자는 기사 원문 필자 확인 후 저장 · 위에는 내용 관련 기사만 표시')); 
 var retry=make('button','vr226-reload','기사 새로확인');retry.type='button';retry.addEventListener('click',function(){beginLane(true);});line.appendChild(retry);panel.appendChild(line);
 people.forEach(function(p){var card=make('section','vr226-person');var title=make('div','vr226-personhead');title.appendChild(make('strong','',p.name));title.appendChild(make('span','',p.outlet));card.appendChild(title);card.appendChild(make('div','vr226-status',evidenceState(p)));
 var list=initialData(p).filter(function(e){return Array.isArray(e.themeIds)&&e.themeIds.indexOf(theme)>=0;});
 if(list.length){list.forEach(function(e){renderArticle(e,card);});}
 else{card.appendChild(make('p','vr226-empty',busy[p.id]?'기자 원문과 실제 필자를 확인하고 있습니다.':initialData(p).length?'검증된 다른 주제의 기사는 보관 중이며, 현재 테마의 관련 기사는 없습니다.':'확인된 기사가 없습니다. 검색 결과가 없거나 언론사에서 필자를 제공하지 않을 수 있습니다.'));}panel.appendChild(card);});
 panel.appendChild(make('p','vr226-disclaimer','현재 후보 명단의 소속·활동 여부는 전체 검증되지 않았습니다. 기사 검색 결과만으로 필자를 확정하지 않습니다. 기사 요약은 원문이 확보된 경우에만 작성합니다.'));}
function open(root,appTheme,defaultRegion){if(!root)return;theme=Number(appTheme);group=Number(DB.appThemeMap[theme]||1);lane=defaultRegion==='GLOBAL'?'GLOBAL':'KR';panel=make('section','vr226-root');panel.id='ntv226-veteran';root.appendChild(panel);paint();beginLane(false);}
function reopen(root,appTheme){open(root,appTheme);}
var css=make('style');css.textContent=`
#ntv226-veteran{background:#fff;max-width:100%;margin-top:12px;padding-bottom:32px;font-family:system-ui,-apple-system,'Noto Sans KR',sans-serif}
#ntv226-veteran .vr226-head h3{font-size:25px;line-height:1.35;margin:2px 0 5px;color:#17324f;font-weight:750}
#ntv226-veteran .vr226-head p{font-size:15px;color:#596d81;line-height:1.6;margin:4px 0 14px}
#ntv226-veteran .vr226-related{border:1px solid #a5c8eb;border-radius:14px;background:#f5faff;padding:13px;margin:12px 0 18px}
#ntv226-veteran .vr226-related h4{font-size:20px;font-weight:650;color:#19446a;margin:0 0 5px}
#ntv226-veteran .vr226-related>p{font-size:14px;line-height:1.6;color:#526e82;margin:4px 0 8px}
#ntv226-veteran .vr226-shelf{border:1px solid #d8e1e8;border-radius:12px;padding:11px;margin:12px 0;color:#526b7e}
#ntv226-veteran .vr226-shelf summary{cursor:pointer;min-height:36px;font-size:15px}
#ntv226-veteran .vr226-tags{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}
#ntv226-veteran .vr226-tag{font-size:12px;line-height:1.5;border:1px solid #d0e3f3;border-radius:10px;padding:2px 7px;background:#e9f3fd;color:#346089}
#ntv226-veteran .vr226-tag.vr226-unclassified{background:#eee;color:#666;border-color:#ddd}
#ntv226-veteran .vr226-select{width:100%;font-size:17px;min-height:51px;border:1px solid #bdcede;background:#f9fbff;border-radius:12px;padding:9px}
#ntv226-veteran .vr226-tabs{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin:14px 0 10px}
#ntv226-veteran .vr226-tab{background:#f2f6fa;color:#345875;border:1px solid #d8e4ee;border-radius:12px;min-height:49px;font-size:17px;font-weight:650}
#ntv226-veteran .vr226-tab[aria-pressed=true]{color:white;background:#255b8b;border-color:#255b8b}
#ntv226-veteran .vr226-toolbar{display:flex;align-items:center;justify-content:space-between;gap:9px;font-size:13px;color:#657385;margin:10px 0}
#ntv226-veteran .vr226-reload{background:#fff;color:#255b8b;border:1px solid #b9d2e8;border-radius:9px;min-height:44px;white-space:nowrap;padding:6px 12px;font-size:15px;font-weight:650}
#ntv226-veteran .vr226-person{border:1px solid #dae5ec;border-radius:14px;padding:12px 13px;margin:10px 0;background:#fff;box-shadow:0 3px 12px #20334d0a}
#ntv226-veteran .vr226-personhead{display:flex;flex-wrap:wrap;gap:7px;align-items:baseline}
#ntv226-veteran .vr226-personhead strong{font-size:19px;font-weight:700;color:#142e46}
#ntv226-veteran .vr226-personhead span{font-size:14px;color:#647688}
#ntv226-veteran .vr226-status{font-size:13px;color:#40709a;margin:6px 0 5px}
#ntv226-veteran .vr226-article{padding:13px 0;border-top:1px solid #e7edf3}
#ntv226-veteran .vr226-title{display:block;width:100%;border:0;text-align:left;background:#fff;color:#17324f;padding:0;font-size:18px;line-height:1.5;font-weight:550;overflow-wrap:anywhere}
#ntv226-veteran .vr226-meta{font-size:13px;color:#718096;line-height:1.55;margin-top:6px}
#ntv226-veteran .vr226-empty{color:#7c8997;font-size:14px;line-height:1.6;margin:10px 0 0}
#ntv226-veteran .vr226-disclaimer{font-size:13px;line-height:1.55;color:#657282;margin:15px 3px}
`;document.head.appendChild(css);
window.NTV226_VETERAN_REPORTERS={open:open,refreshSelected:function(){return beginLane(true);},refreshTheme:function(themeId,region,force){theme=Number(themeId);group=Number(DB.appThemeMap[theme]||1);if(region==='ALL'){lane='KR';var kr=beginLane(!!force);lane='GLOBAL';var globalArticles=beginLane(!!force);return Promise.all([kr,globalArticles]);}lane=region==='GLOBAL'?'GLOBAL':'KR';return beginLane(!!force);},bylineMatch:bylineMatch,allVeteranArticles:allVeteranArticles,relatedArticles:relatedArticles,roster:DB,version:'V229-MULTITHEME',count:120};
})();
