# V232 / 60313 / 2026-10-17

Changes: (1) indicator-detail modal top bound measured from #ntv127GlobalHeader and bottom from #mainNav, scroll to exact top; (2) 6 periods one compact 6-column row; (3) market news relevance: keep RSS fallback when matching headline, use actual topic, fetch trusted full article preferentially, show labeled RSS teaser only when substantive and clearly not a full article; retry source; (4) titles 10% smaller and category text replacing images.

Static verification only. Does not assert any new live publisher connectivity or APK install.
