# V235 | 2026-10-17

1. Startup: hides outdated static/mock HOME while account overview initializes; releases with bounded time limit to prevent infinite blank app; no data deletion. Initial app screenshots will not expose the seeded 132,450,000 won amount before dynamic state is ready.
2. Account details: individual/pension/IRP/etc. remove duplicate yield/stock-quantity trend block beneath existing account holdings. Do not delete user ledger, snapshots, or independent Reports menu.
3. Market environment: compact, neutral cards (no old gradient), less padding & excessive gaps, preserve readable typography. No change to market fetchers, data, scroll and signal algorithms.
4. versionCode 60316; short versionName 6.0.8-r9-v235; same applicationId and GitHub signing configuration.
5. Manual DOCX + in-app guide updated. Mobile update installation requires real-device confirmation.
