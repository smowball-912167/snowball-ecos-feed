# V271 — Natural conversation legacy-router cleanup (2026-10-24)

- App support routing now requires explicit app-support intent; assistant name, latest-information terms, selected stocks and generic financial discussion are not sufficient to switch providers.
- AI voice is a user preference (Gemini / existing device voice), persistent across response providers, independent of words in a question. In case of Gemini synthesis failure the existing device TTS remains an audible fallback and its status is shown.
- Chat sends only current live conversational history, not older canned/legacy AI records. When offline it reports offline truthfully instead of pretending canned app answers are ChatGPT.
- Native Android voice navigation and JS classification respect the highest-ranked final speech hypothesis, and route only explicit menu/read commands; ordinary speech and uncertain commands reach the AI. No implicit stock prefix is added.
- App build 60348 / 6.0.8-r9-v271. Existing user data, app voice presets, ECOS, financial sources, trading views and server keys unchanged.

Limitations: real-device test required; Samsung speech recognizer may still misrecognize spoken words and may ignore requested silence durations; Gemini TTS fallback may temporarily use device voice if the upstream audio API fails.
