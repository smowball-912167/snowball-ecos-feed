# SNOWBALL V264: AI 자연대화/대화 시작 모드

- 기존 V262 앱 소스 기반. V263은 별도 ECOS 공급부 워크플로이며 앱 APK 버전으로 혼동하지 않음.
- 눈탱이 앱·빌드·기능 관련 질문: ChatGPT(OpenAI Responses API); 기타 자유대화: Gemini(GenerateContent API). 단일 버튼 및 대화 이력 공유.
- 환경설정 > AI 목소리: 버튼 방식(기본)/상시 대화(사용자가 명시적으로 선택), 서버 HTTPS 주소, 대화 전송 동의.
- Android 음성·기사 선택읽기·시장환경·보유계좌 기능 기존 로직 보존. 앱 pause 시 마이크 종료, foreground 복귀 시 상시 대화 설정이면 자동 청취.
- AI API 키는 앱에 없음. 선택한 서버가 실행 중이고 사용자 전송 동의가 있어야 실제 Gemini/OpenAI 답변 가능.
- 화자 인증·본인 목소리 학습은 아직 미구현. 전용 온디바이스 화자 임베딩 모델 필요. 미등록을 등록완료로 오인하지 않도록 UI 명시.
- 실제 APK 빌드와 단말 음성 인식 테스트는 수행 전. CI 빌드·실기기 검증 별도 필요.
- Gateway client access-code is stored encrypted with Android Keystore AES/GCM, not in app ZIP or WebView localStorage. Server-side OpenAI and Gemini API keys are never embedded.
- Optional Google Search grounding is not automatically enabled: it may incur extra fees and requires provider policy-aware citation UI.
