# V228 – Theme header fixed + veteran shortcuts
- V227 toolbar position:sticky was not stable inside nested route scroll containers. Use position:fixed below the single symbol header and a 73px spacer. Existing article-detail toolbar retains its own overlay.
- 20 growth themes: two sibling controls per row: theme article list / veteran reporter shortcut, avoiding invalid button nesting.
- Preserve original 20-theme history, byline-validated veteran records, and saved original article URLs.
- Regression tests: fixed toolbar bounding rect stable while scrolling, veteran shortcut opens correct thematic reporter view, Android back routing, source identity SHA matching.
