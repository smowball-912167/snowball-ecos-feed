V241: BIS monthly policy KR/US and FRED T10YIE BEI collectors, no scores / no proxies. Device fetch not yet tested.
