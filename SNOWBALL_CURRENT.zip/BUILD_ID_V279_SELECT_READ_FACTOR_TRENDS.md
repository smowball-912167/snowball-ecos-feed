# V279 · SELECT READ ISOLATION · FOUR FACTOR HISTORY CHART
versionCode=60356
versionName=6.0.8-r9-v279
scope=Native selected TTS no voice interruption STT. Four-factor per-indicator chart with 7 periods and approved upper/lower dashed thresholds, missing-history disclosure.
sourceBaseline=V278 (2026-10-24 source ZIP)
buildStatus=SOURCE_ONLY; GITHUB_SIGNED_APK_REQUIRED; SAMSUNG_TTS_TEST_PENDING
