'use strict';
const assert=require('assert'),vm=require('vm'),fs=require('fs');
let doc={readyState:'loading',addEventListener(){},getElementById(){return null}};
let box={document:doc,window:null,localStorage:{getItem(){return null},setItem(){}},NOONTANGI_FOUR_FACTORS:{official(){return null},ingest(){return 0}},module:{exports:{}},setTimeout(){},clearTimeout(){},console};box.window=box;
vm.createContext(box);vm.runInContext(fs.readFileSync(__dirname+'/app/src/main/assets/ntv245_ecos_live.js','utf8'),box);
const m=box.module.exports;let months=[];let yy=new Date().getUTCFullYear(),mon=new Date().getUTCMonth()+1;
for(let i=17;i>=0;i--){let d=new Date(Date.UTC(yy,mon-1-i,1));months.push(d.toISOString().slice(0,7).replace('-',''))}
let rows=months.map((d,i)=>[d,120+i*.4]),latest=rows[rows.length-1][0];
function imp(dim){return {table:'401Y015',item:'*AA',cycle:'M',unit:'2020=100',latest,value:rows[rows.length-1][1],history:rows,
 status:'observed_not_auto_approved',dimensionResolution:'ITEM_CODE2_W_KRW_VERIFIED',dimensionCode2:dim,dimensionName2:'원화기준'}}
let feed={schema:'NT_ECOS_LIVE_V245',generatedAt:new Date().toISOString(),sources:{import_price_m:imp('W')}};
assert(m.match(feed).some(x=>x.id==='krImportPrice'));
feed.sources.import_price_m=imp('C');assert(!m.match(feed).some(x=>x.id==='krImportPrice'));
feed.sources.import_price_m=imp('W');feed.sources.import_price_m.dimensionName2='계약통화기준';assert(!m.match(feed).some(x=>x.id==='krImportPrice'));
console.log('PASS V253 import-price W, reject C and bad metadata regression');
